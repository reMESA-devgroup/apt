/* CPU-only harness: production batch planning, clipping and resolve; mock
 * resource ownership and native raster callback. No hardware qualification. */
#define _POSIX_C_SOURCE 200809L
#include <time.h>
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <limits.h>
#define MAX2(a,b) ((a)>(b)?(a):(b))
#define MIN2(a,b) ((a)<(b)?(a):(b))
#define MESA_PRIM_TRIANGLES 4
#define MESA_PRIM_TRIANGLE_STRIP 5
#define MESA_PRIM_TRIANGLE_FAN 6
#define PIPE_MASK_RGBA 15
#define PIPE_MAP_READ 1
#define PIPE_MAP_WRITE 2
#define PIPE_FORMAT_R32G32_FLOAT 1
#define PIPE_FORMAT_R8G8B8A8_UNORM 2
#define PIPE_FORMAT_B8G8R8A8_UNORM 3
#define PIPE_FORMAT_B8G8R8X8_UNORM 4
#define PIPE_SWIZZLE_X 0
#define PIPE_SWIZZLE_Y 1
#define PIPE_SWIZZLE_Z 2
#define PIPE_SWIZZLE_W 3
#define PIPE_SWIZZLE_1 5
#define FIXED_COUNT 3
#define FIXED_BLEND 0
#define FIXED_DSA 1
#define FIXED_RASTER 2
static int remesa_texture_draw_values(const void *data,size_t bytes,unsigned count){return bytes==count*24u?0:EINVAL;}
#include "geometry.inc"
#include "remesa_compositor_resolve.h"
#include "remesa_egl33_stats.h"
struct pipe_resource {unsigned width0,height0,format;};
struct resource {struct pipe_resource base;size_t bytes;bool shared_rt,shared_opaque,has_contents,shared_refresh;unsigned maps;int write_error;uint8_t *data;};
struct pipe_screen {int dummy;};
struct screen {struct pipe_screen base; size_t host_buffer_bytes;struct {struct {uint64_t max_resource_bytes;} resource_limits;} device;};
struct pipe_context {struct pipe_screen *screen;void *stream_uploader,*const_uploader;};
struct pipe_draw_info {unsigned mode,index_size,instance_count,start_instance;bool primitive_restart;};
struct pipe_draw_start_count_bias {unsigned start,count;};
struct pipe_draw_indirect_info {int dummy;};
struct pipe_box {int x,y,width,height,depth;};
struct pipe_transfer {size_t stride;};
struct pipe_sampler_view {unsigned format,swizzle_r,swizzle_g,swizzle_b,swizzle_a;};
struct fixed {bool deleted,depth_enabled,cull_face,flat,scissor,compositor_blend;unsigned colormask;};
struct rc_program {unsigned outputs;};
struct shader {struct rc_program compositor;};
struct context {struct pipe_context base;bool egl33_release;struct egl33_stats egl33;bool failed_submission,viewport_set,invalid_viewport,invalid_elements,invalid_constants,constant_rejections[2],sample_enabled,invalid_fixed[3],scissor_set,invalid_scissor,texture_graph_detached;struct {void *owner;} owned_texture_scene;struct pipe_resource *target,*depth_target;struct fixed *bound_fixed[3];struct mock_elements {unsigned count;} *bound_elements;unsigned vb_count;struct {struct {struct pipe_resource *resource;} buffer;unsigned buffer_offset;} vb;struct {unsigned src_format,vertex_buffer_index,src_stride,src_offset;} position;struct {float scale[2],translate[2];} viewport;struct {unsigned minx,miny,maxx,maxy;} compositor_scissor;struct shader *bound_vertex,*bound_fragment;void *textures;struct pipe_context *compositor_scratch;int error,publication_error;};
static struct context *c(struct pipe_context *p){return (struct context*)p;}
static struct screen *s(struct pipe_screen *p){return (struct screen*)p;}
static struct resource *r(struct pipe_resource *p){return (struct resource*)p;}
static unsigned submissions,close_calls,write_maps,publish_calls,fail_at,uploads,drops,replays;static bool sampled_mock,opaque_mock;static int view_mock_error;static struct context scratch;
static struct resource *mock_cpu;static bool mock_uv, mock_direct, mock_map_fail;static uint8_t *mock_external;static unsigned direct_reads,direct_writes;
static int hybrid_constants(struct context *ctx,bool vs,uint8_t *d,size_t *n){*n=0;return 0;}
static int hybrid_fragment(const struct rc_program *p,const void *u,size_t n,uint8_t rgba[4],bool *sampled,bool *opaque,uint8_t *opacity){memcpy(rgba,(uint8_t[]){64,32,16,128},4);*sampled=sampled_mock;*opaque=opaque_mock;*opacity=255;return 0;}
static int remesa_texture_fragment0_view(void *t,const struct pipe_sampler_view **out){static struct pipe_sampler_view view={2,0,1,2,3};if(view_mock_error)return view_mock_error;*out=&view;return 0;}
static int rc_window_vertex(const struct rc_program *p,const void *u,size_t n,const float pos[2],const float scale[2],const float trans[2],struct rc_vertex *out){*out=(struct rc_vertex){pos[0],pos[1],mock_uv?(pos[0]-1)/4:.25f,mock_uv?(pos[1]-1)/4:.25f};return 0;}
static bool color_rt_format(struct pipe_screen *p,unsigned f){return f==PIPE_FORMAT_B8G8R8A8_UNORM;}
static void u_upload_unmap(void *p){}
static void *map(struct pipe_context *p,struct pipe_resource *res,unsigned l,unsigned flags,const struct pipe_box *box,struct pipe_transfer **tr){static struct pipe_transfer t; if(mock_cpu&&res==&mock_cpu->base&&mock_map_fail){c(p)->error=EIO;return NULL;} t.stride=res->width0*4u;*tr=&t;if(flags==PIPE_MAP_WRITE)write_maps++;return r(res)->data+(size_t)box->y*t.stride+(res==c(p)->target?(size_t)box->x*4:(size_t)box->x);}
static void unmap(struct pipe_context *p,struct pipe_transfer *tr){}
static int hre_shared_rt_sync(struct pipe_screen *p,struct resource *res,bool publish){assert(s(p)->host_buffer_bytes==0);if(publish)publish_calls++;return 0;}
static int hre_shared_rt_region(struct pipe_screen *p,struct resource *res,bool publish,unsigned x,unsigned y,unsigned w,unsigned h){assert(w&&h&&x+w<=res->base.width0&&y+h<=res->base.height0);return hre_shared_rt_sync(p,res,publish);}
static size_t host_buffer_limit(struct screen *sc){return sc->device.resource_limits.max_resource_bytes;}
static bool host_buffer_reserve(struct screen *sc,size_t n){sc->host_buffer_bytes+=n;return true;}
static int remesa_context_release_texture_scene(struct pipe_context *p){close_calls++;c(p)->owned_texture_scene.owner=NULL;c(p)->texture_graph_detached=false;return 0;}
static void invalidate_resource(struct pipe_context *p,struct pipe_resource *res){}
static int hybrid_native_scratch(struct pipe_context *p,const struct rc_scratch *sz,const struct rc_native_vertex *mesh,unsigned nv,const uint8_t rgba[4],bool sampled,uint8_t *color,uint8_t *depth,bool reuse_input,bool keep_graph){
 if(reuse_input){assert(scratch.owned_texture_scene.owner&&!scratch.texture_graph_detached);replays++;}else uploads++;
 submissions++;if(fail_at==submissions)return EIO;
 unsigned x0=sz->width,y0=sz->height,x1=0,y1=0;
 for(unsigned i=0;i<nv;i++){unsigned x=(unsigned)lroundf((mesh[i].p[0]+1)*sz->width/2),y=(unsigned)lroundf((1-mesh[i].p[1])*sz->height/2);x0=MIN2(x0,x);y0=MIN2(y0,y);x1=MAX2(x1,x);y1=MAX2(y1,y);}
 memset(depth,255,sz->width*sz->height*4);memset(color,0,sz->width*sz->height*4);
 for(unsigned y=y0;y<y1;y++)for(unsigned x=x0;x<x1;x++){size_t a=((size_t)y*sz->width+x)*4;depth[a]=depth[a+1]=0;depth[a+2]=0xa0;memcpy(color+a,(uint8_t[]){rgba[2],rgba[1],rgba[0],rgba[3]},4);}
 c(p)->compositor_scratch=&scratch.base;scratch.owned_texture_scene.owner=&scratch;scratch.texture_graph_detached=!keep_graph;if(!keep_graph)drops++;return 0;
}
static bool egl26_source_candidate(struct pipe_context *p,struct pipe_resource **out,bool *rgba,bool *nearest){if(!mock_cpu)return false;*out=&mock_cpu->base;*rgba=false;*nearest=false;return true;}
static bool egl26_direct_target(struct resource *b){return mock_direct;}
static int egl26_external_region(struct pipe_screen *p,struct resource *b,bool publish,unsigned x,unsigned y,unsigned w,unsigned h,uint8_t *pixels){
 assert(mock_external);if(publish)direct_writes++;else direct_reads++;
 for(unsigned j=0;j<h;j++){uint8_t *a=mock_external+((size_t)(y+j)*b->base.width0+x)*4;uint8_t *z=pixels+(size_t)j*w*4;if(publish)memcpy(a,z,w*4);else memcpy(z,a,w*4);}return 0;
}
#include "batch.inc"
static void make_quad(float *p,float x,float y,float w,float h){float v[]={x,y,x+w,y,x,y+h,x,y+h,x+w,y,x+w,y+h};memcpy(p,v,sizeof v);}
int main(void){
 unsigned n=0;assert(!rc_egl18_pair_count(MESA_PRIM_TRIANGLES,12,&n)&&n==2);assert(!rc_egl18_pair_count(MESA_PRIM_TRIANGLES,768,&n)&&n==128);assert(rc_egl18_pair_count(MESA_PRIM_TRIANGLES,774,&n));assert(rc_egl18_pair_count(MESA_PRIM_TRIANGLES,9,&n));assert(rc_egl18_pair_count(1,12,&n));assert(!rc_egl18_pair_count(MESA_PRIM_TRIANGLE_STRIP,6,&n)&&n==2);assert(!rc_egl18_pair_count(MESA_PRIM_TRIANGLE_FAN,4,&n)&&n==1);
 struct rc_vertex strip[]={{0,0,0,0},{0,10,0,1},{10,0,.5,0},{10,10,.5,1},{20,0,1,0},{20,10,1,1}};struct rc_egl18_rect rect;assert(!rc_egl18_rect_make(strip,MESA_PRIM_TRIANGLE_STRIP,1,64,64,12,0,64,64,&rect)&&rect.x0==12&&rect.x1==20&&rect.v[0].u==.5f);
 struct rc_vertex fan[]={{0,0,0,0},{10,0,1,0},{10,10,1,1},{0,10,0,1}};assert(!rc_egl18_rect_make(fan,MESA_PRIM_TRIANGLE_FAN,0,64,64,0,0,64,64,&rect)&&rect.x1==10&&rect.y1==10);
 struct screen sc={.device.resource_limits.max_resource_bytes=10000000};struct context ctx={.base.screen=&sc.base,.egl33_release=true,.viewport_set=true,.sample_enabled=true,.vb_count=1,.position={PIPE_FORMAT_R32G32_FLOAT,0,8,0}};struct fixed fixed[3]={{.compositor_blend=true,.colormask=15},{},{}};for(unsigned i=0;i<3;i++)ctx.bound_fixed[i]=&fixed[i];struct mock_elements elements={1};ctx.bound_elements=&elements;struct shader sh={.compositor.outputs=2};ctx.bound_vertex=ctx.bound_fragment=&sh;
 float verts[24];make_quad(verts,1,1,10,10);make_quad(verts+12,6,6,10,10);uint8_t fb[64*64*4]={0};struct resource target={.base={64,64,PIPE_FORMAT_B8G8R8A8_UNORM},.shared_rt=true,.bytes=sizeof fb,.data=fb};struct resource vb={.bytes=sizeof verts,.data=(uint8_t*)verts};ctx.target=&target.base;ctx.vb.buffer.resource=&vb.base;struct pipe_draw_info info={.mode=MESA_PRIM_TRIANGLES,.instance_count=1};struct pipe_draw_start_count_bias draw={.count=12};
 sampled_mock=true;assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==2&&close_calls==2&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);assert(fb[(2*64+2)*4+3]==128&&fb[(8*64+8)*4+3]==192&&fb[(13*64+13)*4+3]==128&&fb[0]==0);assert(ctx.egl33.batches==1&&ctx.egl33.native_tiles==2);puts("EGL18_BATCH_OVERLAP_ORDER_PASS");
 memset(fb,0,sizeof fb);submissions=close_calls=write_maps=publish_calls=0;fail_at=2;assert(hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)==EIO);assert(submissions==2&&close_calls==1&&write_maps==0&&publish_calls==0&&sc.host_buffer_bytes==0);for(unsigned i=0;i<sizeof fb;i++)assert(!fb[i]);assert(ctx.egl33.batches==1);puts("EGL18_BATCH_NO_PARTIAL_PUBLICATION_PASS");
 fail_at=0;submissions=close_calls=0;verts[12]+=.5f;assert(hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)==ENOTSUP);assert(submissions==0&&write_maps==0);puts("EGL18_BATCH_PREFLIGHT_REFUSAL_PASS");
 make_quad(verts+12,6,6,10,10);draw.count=6;assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==1&&close_calls==1&&write_maps==1&&publish_calls==1);puts("EGL18_SINGLE_RECT_REGRESSION_PASS");
 /* 1280x800: validate multiple tile origins and untouched gap. */
 uint8_t *large=calloc(1280u*800u,4);assert(large);target.base.width0=1280;target.base.height0=800;target.bytes=1280u*800u*4;target.data=large;
 submissions=close_calls=write_maps=publish_calls=0;draw.count=12;make_quad(verts,0,0,500,500);make_quad(verts+12,600,550,300,250);
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==13&&close_calls==13&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);
 assert(large[(499u*1280+499)*4+3]==128&&large[(550u*1280+600)*4+3]==128&&large[(799u*1280+899)*4+3]==128&&large[(500u*1280+500)*4+3]==0);puts("EGL18_DESKTOP_TILED_BATCH_PASS");
 setenv("REMESA_HRE_EGL22_REUSE","2",1);memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==13&&close_calls==7&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);
 assert(large[(499u*1280+499)*4+3]==128&&large[(550u*1280+600)*4+3]==128&&large[(799u*1280+899)*4+3]==128&&large[(500u*1280+500)*4+3]==0);puts("EGL22_BOUNDED_SESSION_MOCK_PASS");
 for(unsigned limit=4;limit<=8;limit*=2){setenv("REMESA_HRE_EGL22_REUSE",limit==4?"4":"8",1);memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=0;assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==13&&close_calls==(13+limit-1)/limit&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);assert(large[(499u*1280+499)*4+3]==128&&large[(799u*1280+899)*4+3]==128);}
 puts("EGL23_BOUNDED_PERSISTENCE_PASS");
 setenv("REMESA_HRE_EGL23_COMPACT","1",1);unsetenv("REMESA_HRE_EGL22_REUSE");memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=0;draw.count=6;make_quad(verts,900,700,9,27);assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==1&&close_calls==1&&large[(700u*1280+900)*4+3]==128&&large[(726u*1280+908)*4+3]==128&&large[(727u*1280+908)*4+3]==0);puts("EGL23_COMPACT_DAMAGE_PASS");unsetenv("REMESA_HRE_EGL23_COMPACT");
 setenv("REMESA_HRE_EGL24_GRAPH","1",1);setenv("REMESA_HRE_EGL22_REUSE","4",1);
 draw.count=12;make_quad(verts,0,0,500,500);make_quad(verts+12,600,550,300,250);
 memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=uploads=drops=replays=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));
 assert(submissions==13&&close_calls==4&&uploads==4&&drops==4&&replays==9&&write_maps==1&&publish_calls==1&&!scratch.owned_texture_scene.owner);
 assert(large[(499u*1280+499)*4+3]==128&&large[(799u*1280+899)*4+3]==128);puts("EGL24_ATTACHED_GRAPH_SCHEDULING_PASS");
 memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=uploads=drops=replays=0;fail_at=2;
 assert(hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)==EIO);
 assert(submissions==2&&close_calls==1&&!scratch.owned_texture_scene.owner&&write_maps==0&&publish_calls==0&&sc.host_buffer_bytes==0);
 for(size_t i=0;i<target.bytes;i++)assert(!large[i]);fail_at=0;puts("EGL24_ATTACHED_FAILURE_CLEANUP_PASS");
 setenv("REMESA_HRE_EGL24_WIDE","1",1);submissions=close_calls=write_maps=publish_calls=uploads=drops=replays=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(submissions==5&&close_calls==2&&uploads==2&&drops==2&&replays==3&&write_maps==1&&publish_calls==1);
 assert(large[(499u*1280+499)*4+3]==128&&large[(799u*1280+899)*4+3]==128&&large[(500u*1280+500)*4+3]==0);puts("EGL24_WIDE_TILE_PLANNER_PASS");
 unsetenv("REMESA_HRE_EGL24_WIDE");unsetenv("REMESA_HRE_EGL24_GRAPH");
 setenv("REMESA_HRE_EGL24_SOLID","1",1);sampled_mock=false;memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=0;
 make_quad(verts,1,1,10,10);make_quad(verts+12,6,6,10,10);
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(!submissions&&!close_calls&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);
 assert(large[(2u*1280+2)*4+3]==128&&large[(8u*1280+8)*4+3]==192&&large[(13u*1280+13)*4+3]==128&&large[0]==0);
 assert(large[(8u*1280+8)*4]==24&&large[(8u*1280+8)*4+1]==48&&large[(8u*1280+8)*4+2]==96);puts("EGL24_CPU_SOLID_ORDER_PASS");
 sampled_mock=true;submissions=0;assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&submissions==2);puts("EGL24_SAMPLED_NOT_CPU_FALLBACK_PASS");
 uint8_t pixel[4]={10,20,30,40};egl24_solid_rect(pixel,4,1,1,(uint8_t[]){1,2,3,255},true,true);assert(!memcmp(pixel,(uint8_t[]){3,2,1,255},4));
 egl24_solid_rect(pixel,4,1,1,(uint8_t[]){10,20,30,40},false,false);assert(!memcmp(pixel,(uint8_t[]){30,20,10,40},4));puts("EGL24_SOLID_OPAQUE_REPLACE_PASS");
 /* Wide, odd-sized fill with padded and deliberately unaligned storage. */
 uint8_t fill[1+3*79];memset(fill,0xa5,sizeof fill);
 egl24_solid_rect(fill+1,79,17,3,(uint8_t[]){3,7,19,255},true,true);
 for(unsigned y=0;y<3;y++)for(unsigned x=0;x<79;x++)assert(fill[1+y*79+x]==(x>=68?0xa5:((uint8_t[]){19,7,3,255})[x%4]));
 assert(fill[0]==0xa5);puts("EGL32_SOLID_PADDED_FILL_PASS");
 unsetenv("REMESA_HRE_EGL24_SOLID");
 struct rc_scratch sz;assert(!rc_scratch_make(224,224,&sz));
 struct rc_vertex quad[6]={{0,0,0,0},{500,0,1,0},{0,500,0,1},{0,500,0,1},{500,0,1,0},{500,500,1,1}};
 assert(!rc_egl18_rect_make(quad,MESA_PRIM_TRIANGLES,0,1280,800,0,0,1280,800,&rect));
 struct rc_native_vertex mesh[42];unsigned nv=0;
 assert(egl25_affine_tile(&rect,&sz,224,224,0,0,224,224,mesh,&nv)&&nv==6);
 assert(fabsf(mesh[0].uv[0]-.448f)<.000001f&&fabsf(mesh[5].uv[1]-.896f)<.000001f);
 assert(egl25_affine_tile(&rect,&sz,448,448,0,0,52,52,mesh,&nv)&&nv==6&&mesh[5].uv[0]==1);
 rect.v[5].u=.5f;assert(!egl25_affine_tile(&rect,&sz,0,0,0,0,224,224,mesh,&nv));
 rect.v[5].u=1;rect.v[3].u=.25f;assert(!egl25_affine_tile(&rect,&sz,0,0,0,0,224,224,mesh,&nv));
 puts("EGL25_AFFINE_FULL_EDGE_AND_REFUSAL_PASS");
 setenv("REMESA_HRE_EGL25_AFFINE","1",1);setenv("REMESA_HRE_EGL24_GRAPH","1",1);setenv("REMESA_HRE_EGL22_REUSE","8",1);setenv("REMESA_HRE_EGL24_WIDE","1",1);
 make_quad(verts,0,0,500,500);make_quad(verts+12,600,550,300,250);memset(large,0,target.bytes);submissions=close_calls=write_maps=publish_calls=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&submissions==5&&close_calls==1&&publish_calls==1);
 assert(large[(499u*1280+499)*4+3]==128&&large[(799u*1280+899)*4+3]==128);puts("EGL25_GOD_MODE_MOCK_PASS");
 /* New path: nonuniform source, actual planner and pixel kernel. */
 uint8_t tex[4*4*4];for(unsigned i=0;i<16;i++){tex[4*i]=i+1;tex[4*i+1]=2*i;tex[4*i+2]=3*i;tex[4*i+3]=128;}
 struct resource tex_res={.base={4,4,PIPE_FORMAT_B8G8R8A8_UNORM},.bytes=sizeof tex,.data=tex};mock_cpu=&tex_res;mock_uv=true;
 target.base.width0=64;target.base.height0=64;target.bytes=sizeof fb;target.data=fb;
 memset(fb,0,sizeof fb);draw.count=6;make_quad(verts,1,1,4,4);fixed[0].compositor_blend=false;
 setenv("REMESA_HRE_EGL26_BLIT","1",1);submissions=close_calls=write_maps=publish_calls=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(!submissions&&!close_calls&&write_maps==1&&publish_calls==1&&sc.host_buffer_bytes==0);
 for(unsigned y=0;y<4;y++)assert(!memcmp(fb+((y+1)*64+1)*4,tex+y*16,16));assert(!fb[0]);puts("EGL26_CPU_TEXTURE_1TO1_PASS");
 /* Direct staging with overwrite skips reading external, but publishes exact pixels. */
 uint8_t external[sizeof fb];memset(external,31,sizeof external);memset(fb,0,sizeof fb);mock_external=external;mock_direct=true;
 setenv("REMESA_HRE_EGL26_DIRECT","1",1);write_maps=publish_calls=direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(!submissions&&write_maps==1&&!publish_calls&&!direct_reads&&direct_writes==1&&sc.host_buffer_bytes==0);
 for(unsigned y=0;y<4;y++)assert(!memcmp(external+((y+1)*64+1)*4,tex+y*16,16));assert(external[0]==31);puts("EGL26_DIRECT_OVERWRITE_PASS");
 fixed[0].compositor_blend=true;memset(external,32,sizeof external);direct_reads=direct_writes=write_maps=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(direct_reads==1&&direct_writes==1&&write_maps==1&&external[0]==32&&external[(64+1)*4]==17);puts("EGL26_DIRECT_BLEND_PASS");
 /* Opaque source-over must not read the destination, but translucent still must. */
 setenv("REMESA_HRE_EGL28_HOST_SYNC","1",1);opaque_mock=true;memset(external,77,sizeof external);direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&!direct_reads&&direct_writes==1);
 for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){size_t a=((y+1)*64+x+1)*4,z=(y*4+x)*4;assert(!memcmp(external+a,tex+z,3)&&external[a+3]==255);}
 assert(external[0]==77);opaque_mock=false;direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&direct_reads==1&&direct_writes==1);
 unsetenv("REMESA_HRE_EGL28_HOST_SYNC");puts("EGL28_OPAQUE_SKIP_READ_TRANSPARENT_PRESERVED_PASS");
 mock_map_fail=true;direct_reads=direct_writes=write_maps=0;uint8_t before[sizeof external];memcpy(before,external,sizeof before);
 assert(hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)==EIO);assert(direct_reads==1&&!direct_writes&&!write_maps&&!memcmp(before,external,sizeof external)&&sc.host_buffer_bytes==0);mock_map_fail=false;ctx.error=0;puts("EGL26_SOURCE_FAIL_NO_PUBLICATION_PASS");
 /* EGL34: positive exact unit BGRA copies with forced alpha and padded rows. */
 {uint8_t src34[2*44],dst34[2*48];for(size_t j=0;j<sizeof src34;j++)src34[j]=(uint8_t)(j*3);memset(dst34,0xa5,sizeof dst34);
 struct egl26_blit_plan p34={.u=.5,.v=.5,.du=1,.dv=1,.unit=true};
 egl26_blit(&p34,src34,44,10,2,dst34,48,10,2,false,true,true,true,255);
 for(unsigned y=0;y<2;y++)for(unsigned x=0;x<48;x++)assert(dst34[y*48+x]==(x>=40?0xa5:x%4==3?255:src34[y*44+x]));puts("EGL34_OPAQUE_LINEAR_BLIT_PASS");}
 /* Unit flip, clipped sampling, channel conversion, opaque alpha and nearest scaling. */
 struct rc_vertex q2[6]={{0,0,1,1},{4,0,0,1},{0,4,1,0},{0,4,1,0},{4,0,0,1},{4,4,0,0}};
 assert(!rc_egl18_rect_make(q2,MESA_PRIM_TRIANGLES,0,64,64,1,1,64,64,&rect));struct egl26_blit_plan plan;
 assert(egl26_plan(&rect,4,4,false,&plan)&&plan.unit);uint8_t out[36]={0};egl26_blit(&plan,tex,16,4,4,out,12,3,3,true,true,true,false,255);
 assert(out[0]==tex[4*10+2]&&out[2]==tex[4*10]&&out[3]==255&&out[32]==tex[2]);puts("EGL26_CLIP_FLIP_SWIZZLE_PASS");
 assert(!egl26_plan(&rect,8,8,false,&plan)&&egl26_plan(&rect,8,8,true,&plan)&&!plan.unit);
 rect.v[5].u=.3f;assert(!egl26_plan(&rect,4,4,true,&plan));puts("EGL26_LINEAR_SCALE_AND_NONAFFINE_REFUSAL_PASS");
 /* unsupported linear scaling falls back to native, not false CPU evidence */
 mock_uv=false;mock_cpu=NULL;submissions=direct_writes=direct_reads=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&submissions==1&&direct_reads==1&&direct_writes==1);puts("EGL26_NATIVE_DIRECT_REGION_PASS");
 /* Native replacement: exact coverage oracle still runs, skip destination
  * read and redundant per-pixel resolve. Compare against old native path. */
 opaque_mock=true;memset(external,79,sizeof external);memset(fb,79,sizeof fb);direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&direct_reads==1&&direct_writes==1);uint8_t native_ref[sizeof external];memcpy(native_ref,external,sizeof native_ref);
 memset(external,79,sizeof external);memset(fb,79,sizeof fb);direct_reads=direct_writes=0;setenv("REMESA_HRE_EGL31_NATIVE_RESOLVE","1",1);
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&!direct_reads&&direct_writes==1&&!memcmp(native_ref,external,sizeof native_ref));
 opaque_mock=false;direct_reads=direct_writes=0;assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&direct_reads==1&&direct_writes==1);
 unsetenv("REMESA_HRE_EGL31_NATIVE_RESOLVE");puts("EGL31_NATIVE_REPLACE_DISCARD_AND_TRANSLUCENT_MOCK_PASS");
 mock_direct=false;unsetenv("REMESA_HRE_EGL26_DIRECT");submissions=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&submissions==1);puts("EGL26_NATIVE_FALLBACK_PASS");
 /* Sparse union: two far rectangles + overlapping blend, byte-exact vs
  * original dense path, external and backing holes preserved. */
 sampled_mock=false;setenv("REMESA_HRE_EGL24_SOLID","1",1);setenv("REMESA_HRE_EGL28_HOST_SYNC","1",1);setenv("REMESA_HRE_EGL26_DIRECT","1",1);mock_direct=true;
 draw.count=12;make_quad(verts,1,1,4,4);make_quad(verts+12,55,55,4,4);
 memset(external,31,sizeof external);memset(fb,31,sizeof fb);fixed[0].compositor_blend=true;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));uint8_t reference[sizeof fb];memcpy(reference,external,sizeof reference);
 memset(external,31,sizeof external);memset(fb,31,sizeof fb);setenv("REMESA_HRE_EGL30_SPARSE","1",1);direct_reads=direct_writes=write_maps=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(direct_reads==1&&direct_writes==1&&write_maps==1&&!memcmp(reference,external,sizeof reference)&&!memcmp(reference,fb,sizeof fb));
 fixed[0].compositor_blend=false;memset(external,77,sizeof external);memset(fb,77,sizeof fb);direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1));assert(!direct_reads&&direct_writes==1&&external[0]==77&&external[(30*64+30)*4]==77&&external[(1*64+1)*4]==16);
 struct rc_egl18_rect rs[3]={{.x0=1,.y0=1,.x1=5,.y1=5},{.x0=3,.y0=3,.x1=7,.y1=7},{.x0=55,.y0=55,.x1=59,.y1=59}};
 struct egl30_damage dmg;egl30_damage_make(&dmg,rs,3,1,1,59,59);assert(egl30_damage_copy(&dmg,NULL,0,NULL,0,false)==(16+16-4+16)*4);
 puts("EGL30_SPARSE_BLEND_OVERWRITE_UNION_PASS");
 /* Dense but disjoint opaque rectangles: no destination read, holes intact. */
 make_quad(verts,1,1,20,20);make_quad(verts+12,23,1,20,20);
 memset(external,71,sizeof external);memset(fb,71,sizeof fb);direct_reads=direct_writes=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&direct_reads==1&&direct_writes==1);
 memcpy(reference,external,sizeof reference);
 memset(external,71,sizeof external);memset(fb,71,sizeof fb);direct_reads=direct_writes=0;
 setenv("REMESA_HRE_EGL32_DENSE_DISCARD","1",1);
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&!direct_reads&&direct_writes==1&&!memcmp(reference,external,sizeof reference));
 unsetenv("REMESA_HRE_EGL32_DENSE_DISCARD");puts("EGL32_DENSE_DISCARD_HOLES_PASS");
 unsetenv("REMESA_HRE_EGL30_SPARSE");unsetenv("REMESA_HRE_EGL24_SOLID");unsetenv("REMESA_HRE_EGL28_HOST_SYNC");unsetenv("REMESA_HRE_EGL26_DIRECT");mock_direct=false;sampled_mock=true;fixed[0].compositor_blend=true;draw.count=6;make_quad(verts,1,1,4,4);
 /* Direct CLOSE keeps the final graph attached through the authenticated close. */
 setenv("REMESA_HRE_EGL29_DIRECT_CLOSE","1",1);setenv("REMESA_HRE_EGL29_ADAPTIVE","1",1);
 unsetenv("REMESA_HRE_EGL26_BLIT");submissions=close_calls=drops=write_maps=publish_calls=0;
 assert(!hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)&&submissions==1&&close_calls==1&&!drops&&write_maps==1&&publish_calls==1&&!scratch.owned_texture_scene.owner);
 puts("EGL29_DIRECT_CLOSE_MOCK_PASS");
 view_mock_error=ENOENT;submissions=write_maps=publish_calls=0;
 assert(hybrid_draw(&ctx.base,&info,0,NULL,&draw,1)==ENOENT&&!submissions&&!write_maps&&!publish_calls);puts("EGL29_MISSING_VIEW_FAIL_CLOSED_PASS");
 free(large);
 return 0;
}
