#!/usr/bin/env python3
import argparse,hashlib,json,os,pathlib,tempfile
p=argparse.ArgumentParser();p.add_argument('tree',type=pathlib.Path);p.add_argument('--check',action='store_true');a=p.parse_args()
r=a.tree.resolve();d=pathlib.Path(__file__).resolve().parent
if (r/'VERSION').read_text().strip()!='25.2.0':p.error('Expected Mesa 25.2.0')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
changes=json.loads((d/'manifest.json').read_text());pending=[]
for rel,h in changes.items():
 f=r/rel;s=d/'overlay'/rel
 if f.is_symlink() or not f.parent.resolve().is_relative_to(r) or not f.parent.is_dir() or sha(s)!=h['after']:p.error('invalid path/overlay '+rel)
 if f.exists() and not f.is_file():p.error('not a file '+rel)
 old=sha(f) if f.exists() else None
 if old==h['after']:continue
 if old not in h['before']:p.error('source mismatch; no files changed: '+rel)
 pending.append((f,s))
if not a.check:
 for f,s in pending:
  mode=f.stat().st_mode&0o777 if f.exists() else 0o644
  with tempfile.NamedTemporaryFile(dir=f.parent,delete=False) as t:t.write(s.read_bytes());tmp=pathlib.Path(t.name)
  os.chmod(tmp,mode);tmp.replace(f)
print('EGL34_'+('CHECK' if a.check else 'APPLIED'),len(pending),'changes')
