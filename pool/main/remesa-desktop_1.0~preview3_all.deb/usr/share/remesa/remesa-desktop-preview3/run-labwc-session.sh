#!/bin/bash
set -euo pipefail
: "${REMESA_LABWC_LOG:?missing log path}"
labwc -d & compositor=$!
client=''
cleanup(){ echo LABWC_SHUTDOWN_BEGIN; if [[ -n $client ]]; then kill "$client" 2>/dev/null || :; wait "$client" 2>/dev/null || :; fi; kill "$compositor" 2>/dev/null || :; wait "$compositor" 2>/dev/null || :; echo LABWC_SHUTDOWN_END; }
trap cleanup EXIT
trap 'exit 143' TERM INT
socket=''
for i in $(seq 1 80); do
 kill -0 "$compositor" 2>/dev/null || { wait "$compositor" || exit $?; exit 1; }
 for f in "$XDG_RUNTIME_DIR"/wayland-*; do [[ -S $f ]] && { socket=${f##*/}; break; }; done
 [[ -n $socket ]] && break
 sleep 0.25
done
[[ -n $socket ]] || { echo LABWC_SOCKET_NOT_CREATED; exit 1; }
export WAYLAND_DISPLAY="$socket"
echo "LABWC_SOCKET_CREATED $socket"
command -v weston-simple-shm >/dev/null || { echo LABWC_SHM_CLIENT_UNAVAILABLE; exit 1; }
echo LABWC_SHM_CLIENT_START
weston-simple-shm & client=$!
for i in $(seq 1 240); do
 kill -0 "$compositor" 2>/dev/null || { echo LABWC_EXITED; exit 1; }
 kill -0 "$client" 2>/dev/null || { echo LABWC_SHM_CLIENT_EXITED; exit 1; }
 if grep -Eq '^HRE_COMPOSITOR_HYBRID_REJECT |^HRE_GLES_DRAW_RESULT errno=[1-9]|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO' "$REMESA_LABWC_LOG"; then echo LABWC_DRAW_FAILED_BEFORE_SHUTDOWN; exit 1; fi
 if grep -q '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$REMESA_LABWC_LOG"; then
  echo LABWC_TEXTURE_DRAW_OBSERVED_BEFORE_SHUTDOWN
  echo LABWC_SHM_CLIENT_ALIVE; echo LABWC_SERVER_ALIVE; exit 0
 fi
 sleep .5
done
echo LABWC_TEXTURE_DRAW_TIMEOUT_BEFORE_SHUTDOWN
exit 1
