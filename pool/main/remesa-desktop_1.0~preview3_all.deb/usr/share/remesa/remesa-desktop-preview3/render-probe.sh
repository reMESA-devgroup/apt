#!/usr/bin/env bash
# Non-root open and EGL/GBM admission are separate evidence.
set -euo pipefail
[[ $EUID != 0 ]] || { echo 'Do not use sudo'; exit 2; }
D=$(cd "$(dirname "$0")" && pwd)
R=/opt/remesa/12.3/lib
P=/sys/module/remesa_gma500gfx/parameters/render_probe_unprivileged
if [[ -r $P ]]; then echo "render_probe_unprivileged=$(cat "$P")"; else echo 'Kernel boot parameter not readable as user (0400 is expected)'; fi
python3 - <<'PYOPEN'
import glob,os,pathlib,sys
nodes=[]
for n in glob.glob('/dev/dri/renderD*'):
 p=pathlib.Path('/sys/class/drm')/pathlib.Path(n).name/'device'
 try:
  if (p/'vendor').read_text().strip()=='0x8086' and (p/'device').read_text().strip()=='0x8108' and (p/'driver/module').resolve(strict=True).name=='remesa_gma500gfx': nodes.append(n)
 except OSError: pass
if len(nodes)!=1: sys.exit('EGL34_NONROOT_OPEN_FAIL ambiguous experimental node')
try:
 fd=os.open(nodes[0],os.O_RDWR|os.O_CLOEXEC|os.O_NOFOLLOW);os.close(fd)
except OSError as e: sys.exit('EGL34_NONROOT_OPEN_FAIL '+str(e))
print('EGL34_NONROOT_OPEN_PASS uid=%d (no submission)'%os.geteuid())
PYOPEN
# Do not alter graphics global settings or enable experimental gates.
exec env -i PATH=/usr/bin:/bin HOME="$HOME" LANG=C.UTF-8 LD_LIBRARY_PATH="$R" LIBGL_DRIVERS_PATH="$R/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 python3 "$D/probe-egl-gbm.py" gbm
