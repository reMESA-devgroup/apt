/* Test the allocator ABI and GEM lifecycle without any DRM hardware. */
#include "allocator.c"
#include <assert.h>
#include <stdarg.h>
static unsigned created,exported,imported,closed,destroyed;static bool fail_import;
int __wrap_ioctl(int fd,unsigned long req,...){(void)fd;va_list ap;va_start(ap,req);void *v=va_arg(ap,void*);va_end(ap);
 if(req==DRM_IOCTL_MODE_CREATE_DUMB){struct drm_mode_create_dumb*c=v;c->handle=17;c->pitch=256;c->size=16384;created++;return 0;}
 if(req==DRM_IOCTL_PRIME_HANDLE_TO_FD){struct drm_prime_handle*p=v;assert(p->handle==17);p->fd=memfd_create("mock",MFD_CLOEXEC);assert(p->fd>=0);assert(!ftruncate(p->fd,16384));exported++;return 0;}
 if(req==DRM_IOCTL_PRIME_FD_TO_HANDLE){if(fail_import){errno=EIO;return -1;}struct drm_prime_handle*p=v;assert(p->fd>=0);p->handle=24;imported++;return 0;}
 if(req==DRM_IOCTL_GEM_CLOSE){assert(((struct drm_gem_close*)v)->handle==24);closed++;return 0;}
 if(req==DRM_IOCTL_MODE_DESTROY_DUMB){assert(((struct drm_mode_destroy_dumb*)v)->handle==17);destroyed++;return 0;}
 abort();}
static uint32_t canonical(uint32_t v){return v;}
int main(void){struct gbm_core c={.v0={.core_version=1,.format_canonicalize=canonical}};assert(GBM_GET_BACKEND_PROC(&c)->v0.backend_version==1);struct alloc_device a={.base.v0.fd=8,.primary=9};uint64_t m=DRM_FORMAT_MOD_LINEAR;
 struct gbm_bo*b=create_bo(&a.base,64,64,GBM_FORMAT_ARGB8888,GBM_BO_USE_RENDERING,&m,1);assert(b&&b->v0.handle.u32==24&&stride(b,0)==256&&planes(b)==1&&modifier(b)==m);int f=get_fd(b);assert(f>=0&&fcntl(f,F_GETFD)&FD_CLOEXEC);close(f);destroy_bo(b);assert(created==1&&exported==1&&imported==1&&closed==1&&destroyed==1);
 fail_import=true;assert(!create_bo(&a.base,64,64,GBM_FORMAT_XRGB8888,GBM_BO_USE_RENDERING,&m,1));assert(created==2&&exported==2&&imported==1&&closed==1&&destroyed==2);m=42;assert(!create_bo(&a.base,64,64,GBM_FORMAT_XRGB8888,GBM_BO_USE_RENDERING,&m,1));assert(!create_bo(&a.base,64,64,GBM_FORMAT_XRGB8888,GBM_BO_USE_PROTECTED,NULL,0));assert(created==2);puts("ALLOCATOR_MOCK_PASS");}
