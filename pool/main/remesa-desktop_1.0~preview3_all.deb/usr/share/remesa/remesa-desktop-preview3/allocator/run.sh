#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); P=${1:-/home/gama/remesa-egl}; E=${2:-$(dirname "$D")}
[[ $EUID == 0 ]] || { echo 'Run with sudo on existing PRIME mmap boot'; exit 2; }
[[ $(dpkg-query -W -f='${Version}' remesa-hre-cross) == '1.0~topology2.egl13' ]] || exit 2
T=$(mktemp -d /tmp/remesa-alloc.XXXXXX); trap 'rm -rf -- "$T"' EXIT
cc -I"$D/include" -Wall -Wextra -Werror -O2 -fPIC -shared -fvisibility=hidden "$D/allocator.c" -o "$T/remesa_alloc_gbm.so"
# Run the same guarded headless test, without repeating the qualified EGL probe.
grep -Fq 'bash "$D/test-egl.sh" "$P" patched' "$E/test-labwc.sh"
grep -Fq 'export WLR_RENDERER=gles2 WLR_BACKENDS=headless WLR_HEADLESS_OUTPUTS=1' "$E/test-labwc.sh"
sed '/^bash "\$D\/test-egl.sh" "\$P" patched$/d; /^export WLR_RENDERER=gles2 WLR_BACKENDS=headless WLR_HEADLESS_OUTPUTS=1$/a export GBM_BACKEND=remesa_alloc GBM_BACKENDS_PATH="$D:/opt/remesa/12.3/lib/gbm" REMESA_GBM_ALLOCATOR_ONLY=1' "$E/test-labwc.sh" > "$T/test-labwc.sh"
cp "$E/run-labwc-session.sh" "$T/"
L=$(mktemp /tmp/remesa-allocator.XXXXXX); echo "Allocator diagnostic: $L"
set +e
bash "$T/test-labwc.sh" "$P" 2>&1 | tee "$L"; rc=${PIPESTATUS[0]}
set -e
grep -E 'HRE_GBM_|LABWC_SOCKET|LABWC_SERVER|HRE_GLES_DRAW_RESULT|HRE_NATIVE_RETIRED|errno=|Failed|failed|ERROR' "$L" | tail -80 || :
if ! grep -q '^HRE_GBM_ALLOCATOR_ONLY ' "$L"; then echo 'ALLOCATOR_BACKEND_NOT_SELECTED'; exit 1; fi
if ! grep -q '^HRE_GBM_PUBLIC_BO ' "$L"; then echo 'ALLOCATOR_DEVICE_ONLY_NO_BO'; exit 1; fi
echo 'PUBLIC_GBM_ALLOCATION_EVIDENCE (not rendering qualification)'
exit "$rc"
