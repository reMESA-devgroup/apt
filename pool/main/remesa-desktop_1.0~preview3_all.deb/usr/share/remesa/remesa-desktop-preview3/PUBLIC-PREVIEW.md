# reMESA Desktop Preview 2 — Nested X11 / Wayland (EGL34)

This is a **technical preview**, not a general-purpose released graphics driver. The EGL34 private Mesa runtime and experimental kernel are unchanged. The nested desktop uses the host graphics stack; it is NOT physical SGX535 qualification. No binaries for additional kernels are bundled. Only install trusted archives; verify SHA256SUMS before executing scripts, particularly those requesting sudo. The checksum list checks integrity, not publisher identity.

## Try inside X11 (no reboot, no kernel or Mesa modifications)

On Debian/antiX from your normal graphical terminal:

```
sha256sum -c SHA256SUMS
bash install.sh --nested-only --check
bash install.sh --nested-only --deps
~/.local/bin/remesa-desktop-nested x11
```

`--deps` requests sudo only for apt packages from existing repositories. If you already have the dependencies, `bash nested.sh x11` runs directly from the extracted directory without installing anything. If your distro does not package Labwc or builds wlroots without the X11 backend, install an appropriate distro-supported build; no automatic third-party repository is added. The nested compositor uses Pixman by default; for host GLES2 try `bash nested.sh x11 gles2`. There is no silent fallback to native DRM. For a Wayland parent use `bash nested.sh wayland` (or `~/.local/bin/remesa-desktop-nested wayland`). Run locally with DISPLAY/WAYLAND_DISPLAY set, not plain SSH. Host library overrides are cleared to avoid accidental private driver selection. Custom PRoot graphics setups may require additional configuration.

Super+Esc exits the nested compositor. Each session has a private socket/config/D-Bus and its own log under `${XDG_STATE_HOME:-$HOME/.local/state}/remesa`. The existing graphical session remains running. The bottom taskbar, wallpaper, notifications, settings, audio and Wi-Fi indicators are shared with the native desktop. Network setup uses existing services; it does not replace them. Some host services, audio, tray applications, app single-instance behavior and PolicyKit depend on distribution/session integration. Only Wayland clients are explicitly launched; nested Xwayland client support has not been qualified.

Uninstall the per-user nested profile (no boot changes): `bash install.sh --nested-only --uninstall`. APT packages and logs remain. Run before reinstalling. Also available from `$HOME/.local/share/remesa/desktop-nested/install.sh` while installed.

## GLES2 tests

Click **3D** on the panel, or run `python3 "$XDG_RUNTIME_DIR/assets/test3d.py" --seconds 20` from the nested Foot terminal. Directly on the host, `python3 desktop/client/test3d.py --seconds 15` tests the host SDL2/EGL stack. Use `--oracle-only` to run just the shader, texture and depth readback checks. The demo requests GLES 2.0; a compatible higher-version context may be returned. It reports vendor, renderer, version, pixel oracle and cube swap rate. Swap rate is not the displayed FPS. If the renderer is llvmpipe, this is software, even when the cube is fluid. A renderer name alone never proves hardware execution. Some Pixman-only nested configurations cannot supply an EGL context; test the host directly or try the GLES2 nested renderer. SDL2 is required.

## Native experimental Poulsbo install

See DESKTOP-INSTALL.md for the prior native requirements and rollback. `bash install.sh --deps --deb /path/EGL34.deb --kernel-module /path/remesa_gma500gfx.ko` requires a matching trusted module and i386 runtime, or reuses a verified previous EGL14 boot. No kernel or Mesa binary is shipped in this archive. Do not replace stock GRUB entry. Use `remesa-desktop nested-x11` or `remesa-desktop nested` from an existing graphical session after native installation if desired. `remesa-desktop test3d` tests the ordinary client stack, not private HRE GPU work.

From the experimental boot, stop the display manager from TTY/SSH and run `remesa-desktop test3d-native 60` (or `bash native-test3d.sh 60` from source). This runs the existing privileged SGX535 compositor test in native3d mode and requires physical retirement receipts, successful sampled draws and clean shutdown. It does not run the host cube on the private driver and does not prove unrestricted application GLES2, 60 FPS, or rootless private IOCTLs. Never start while another compositor owns DRM. The stock boot remains the recovery path. Native non-root opening uses the existing render gate and restricted group; private IOCTLs remain protected.

## Qualification status

- Local: SDL2 X11 GLES test under Xvfb/llvmpipe, pixel checks and animated cube; existing EGL34 row oracle; syntax and GRUB fixture tests.
- Pending: real Labwc nested X11/Wayland session, native install and reboot on target, physical 2D/3D, rootless private rendering and multi-client isolation, sustained frame timing, additional kernels. Do not label this as a stable hardware driver.
