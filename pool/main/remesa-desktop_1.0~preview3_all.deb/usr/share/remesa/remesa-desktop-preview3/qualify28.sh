#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "EGL28 QUALIFICATION FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd); cd "$D"
MODE=${1:-cloud}; [[ $MODE == cloud || $MODE == compare ]] || exit 2
OUT=$(mktemp -d "$HOME/egl28-results.XXXXXX"); echo "RESULTS=$OUT"
sudo -v
sudo dpkg -i "$HOME/remesa-hre-cross_1.0~topology2.egl28_i386.deb"
sudo bash run.sh --preflight
run_test(){
 local name=$1; shift
 local rc=0 log
 echo "=== EGL28 TEST: $name ==="
 sudo bash desktop/run.sh "$@" 2>&1 | tee "$OUT/$name-run.log" || rc=$?
 log=$(sed -n 's/^EGL19_DESKTOP_EXIT=[0-9]* LOG=\(\/tmp\/remesa-egl19-desktop\.[[:alnum:]]*\)$/\1/p' "$OUT/$name-run.log" | tail -1)
 if [[ -n $log ]]; then sudo python3 profile28.py "$log" | tee "$OUT/$name-profile.log"; fi
 [[ $rc == 0 ]] || { echo "FAILED $name rc=$rc"; return "$rc"; }
 [[ -n $log ]] && sudo grep -q '^EGL19_CLEAN_SHUTDOWN$' "$log"
 if [[ $name == cloudtail ]]; then
  sudo grep -Eq '^HRE_EGL28_DMA .*errno=0$' "$log" || { echo 'EGL28 no DMA evidence'; return 1; }
  if sudo grep -Eq '^HRE_EGL28_DMA .*errno=[1-9][0-9]*$' "$log"; then echo 'EGL28 DMA error'; return 1; fi
 fi
}
if [[ $MODE == compare ]]; then
 run_test baseline --stage desktop --seconds 120 --cloud15 --hardware-cursor
fi
run_test cloudtail --stage desktop --seconds 120 --cloudtail --hardware-cursor
printf 'Results: %s\n' "$OUT"
