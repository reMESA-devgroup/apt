#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
python3 - "$D" "$T" <<'PY'
from pathlib import Path
import sys
p,t=map(Path,sys.argv[1:]);s=next((p/'overlay').rglob('remesa_screen.c')).read_text();(t/'host.inc').write_text(s[s.index('static uint64_t egl28_clock('):s.index('static int hre_shared_rt_sync(')]);(t/'region.inc').write_text(s[s.index('static int hre_shared_rt_region('):s.index('static struct pipe_resource *hre_import_sampler(',s.index('static int hre_shared_rt_region('))]); c=next((p/'overlay').rglob('remesa_compositor_live.inc')).read_text(); (t/'direct.inc').write_text(c[c.index('static bool egl26_direct_target('):c.index('#define RC_EGL18_MAX_RECTS')]); (t/'sparse.inc').write_text('#define RC_EGL18_MAX_RECTS 128u\nstruct rc_egl18_rect {unsigned x0,y0,x1,y1;};\n'+c[c.index('/* EGL30: exact union'):c.index('/* EGL30_EXTERNAL_END */')])
PY
cat > "$T/test.c" <<'C'
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/mman.h>
#define DMA_BUF_SYNC_START 0
#define DMA_BUF_SYNC_END 4
#define DMA_BUF_SYNC_WRITE 2
#define DMA_BUF_SYNC_READ 1
struct remesa_shared_image {int fd;unsigned width,height,pitch,offset;size_t end;bool poisoned;};
struct pipe_screen {size_t host_buffer_bytes;};
#define screen pipe_screen
struct resource {void *host_data,*bo;size_t bytes;struct remesa_shared_image *shared_sampler;bool shared_rt,shared_writable,native_clear_owner,has_contents,shared_discard,shared_cache_valid,shared_opaque;unsigned maps,stride;int write_error,pass;void *shared_cache;unsigned char data[80];};
static struct screen *s(struct pipe_screen *p){return p;}
static int resource_sync(struct pipe_screen *p,struct resource *b,uint64_t t){(void)p;(void)b;(void)t;return 0;}
static int fallback;
static int hre_shared_rt_sync(struct pipe_screen *p,struct resource *b,bool pub){(void)p;(void)b;(void)pub;fallback++;return 0;}
static bool host_buffer_reserve(struct screen *s,size_t n){s->host_buffer_bytes+=n;return true;}
static int resource_map_backing(struct pipe_screen *p,struct resource *b,bool wr,void **o){(void)p;(void)wr;*o=b->data;return 0;}
static void resource_unmap_backing(struct pipe_screen *p,struct resource *b,bool wr){(void)p;(void)b;(void)wr;}
static int remesa_render_pass_admit_cpu_write(int *p){(void)p;return 0;}
static int remesa_render_pass_cpu_write(int *p){++*p;return 0;}
static bool fail_end,fail_start;static int sync_count;
static int remesa_dmabuf_sync(int fd,uint64_t flags){(void)fd;sync_count++;return ((fail_end&&(flags&DMA_BUF_SYNC_END))||(fail_start&&!(flags&DMA_BUF_SYNC_END)))?EIO:0;}
#include "host.inc"
#include "region.inc"
#include "direct.inc"
#include "sparse.inc"
int main(void){
 FILE *f=tmpfile();assert(f);int fd=fileno(f);assert(!ftruncate(fd,96));unsigned char *ext=mmap(NULL,96,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);assert(ext!=MAP_FAILED);memset(ext,7,96);
 struct remesa_shared_image sh={.fd=fd,.width=4,.height=4,.pitch=20,.offset=8,.end=96};struct pipe_screen sc={0};struct resource b={.shared_rt=true,.shared_sampler=&sh,.shared_writable=true,.has_contents=true,.stride=20,.shared_opaque=true};memset(b.data,3,sizeof b.data);
 assert(!hre_shared_rt_region(&sc,&b,false,1,1,2,2));assert(b.pass==1&&sc.host_buffer_bytes==0&&sync_count==2);
 for(unsigned i=0;i<80;i++){unsigned y=i/20,x=i%20;bool hit=y>=1&&y<=2&&x>=4&&x<12;assert(b.data[i]==(hit?(x%4==3?255:7):3));}
 memset(b.data,9,sizeof b.data);assert(!hre_shared_rt_region(&sc,&b,true,1,1,2,2));assert(sc.host_buffer_bytes==0&&sync_count==4);
 for(unsigned i=0;i<96;i++){bool hit=i>=8&&i<88&&(i-8)/20>=1&&(i-8)/20<=2&&(i-8)%20>=4&&(i-8)%20<12;assert(ext[i]==(hit?((i-8)%4==3?255:9):7));}
 assert(hre_shared_rt_region(&sc,&b,true,3,3,2,2)==EINVAL);assert(!hre_shared_rt_region(&sc,&b,false,0,0,4,4)&&fallback==1);
 /* Test actual packed direct helper using real mmap, simulated DMA-BUF sync. */
 unsigned char packed[16];assert(egl26_direct_target(&b));int old_sync=sync_count;unsigned char old_backing[80];memcpy(old_backing,b.data,80);
 assert(!egl26_external_region(&sc,&b,false,1,1,2,2,packed));assert(sync_count==old_sync+2&&!memcmp(b.data,old_backing,80));
 for(unsigned i=0;i<16;i++)assert(packed[i]==(i%4==3?255:9));
 memset(packed,12,16);for(unsigned i=3;i<16;i+=4)packed[i]=255;
 assert(!egl26_external_region(&sc,&b,true,1,1,2,2,packed)&&sync_count==old_sync+4);
 for(unsigned i=0;i<96;i++){bool hit=i>=8&&i<88&&(i-8)/20>=1&&(i-8)/20<=2&&(i-8)%20>=4&&(i-8)%20<12;assert(ext[i]==(hit?((i-8)%4==3?255:12):7));}
 b.shared_discard=true;assert(!egl26_direct_target(&b)&&egl26_external_region(&sc,&b,false,1,1,2,2,packed)==EINVAL);b.shared_discard=false;
 fail_end=true;assert(egl26_external_region(&sc,&b,true,1,1,2,2,packed)==EOWNERDEAD&&b.write_error==EOWNERDEAD&&sh.poisoned);puts("EGL26_DIRECT_REGION_MMAP_AND_POISON_PASS");
 b.write_error=0;sh.poisoned=false;
 /* Host direct path: padded rows, no temporary, XRGB alpha and guards. */
 fail_end=false; b.host_data=b.data;b.bytes=sizeof b.data;b.shared_discard=false;
 assert(!setenv("REMESA_HRE_EGL28_HOST_SYNC","1",1));
 memset(ext,23,96);memset(b.data,5,sizeof b.data);int before_sync=sync_count;
 assert(!egl28_host_sync(&sc,&b,false,0,0,4,4));assert(sync_count==before_sync+2&&sc.host_buffer_bytes==0);
 for(unsigned y=0;y<4;y++)for(unsigned x=0;x<20;x++)assert(b.data[y*20+x]==(x>=16?5:(x%4==3?255:23)));
 memset(b.data,11,sizeof b.data);assert(!egl28_host_sync(&sc,&b,true,1,1,2,2));
 for(unsigned y=0;y<4;y++)for(unsigned x=0;x<20;x++){bool hit=y>=1&&y<=2&&x>=4&&x<12;assert(ext[8+y*20+x]==(hit?(x%4==3?255:11):23));}
 fail_start=true;unsigned char saved[80];memcpy(saved,b.data,80);assert(egl28_host_sync(&sc,&b,false,0,0,4,4)==EIO&&!memcmp(saved,b.data,80)&&!sh.poisoned);fail_start=false;
 b.shared_opaque=false;memset(ext,42,96);assert(!egl28_host_sync(&sc,&b,false,0,0,4,4)&&b.data[3]==42);b.shared_opaque=true;
 b.maps=1;assert(egl28_host_sync(&sc,&b,false,0,0,4,4)==EBUSY);b.maps=0;
 fail_end=true;assert(egl28_host_sync(&sc,&b,false,0,0,4,4)==EOWNERDEAD&&sh.poisoned&&b.write_error==EOWNERDEAD);
 puts("EGL28_HOST_SYNC_STRIDE_ALPHA_POISON_PASS");b.host_data=NULL;b.write_error=0;sh.poisoned=false;unsetenv("REMESA_HRE_EGL28_HOST_SYNC");
 /* Actual sparse helper, padded stride and nonzero DMA-BUF offset. */
 fail_end=false;memset(ext,39,96);unsigned char sparse[64];memset(sparse,77,64);
 struct rc_egl18_rect rs[3]={{0,0,1,2},{0,1,2,2},{3,3,4,4}};struct egl30_damage d;
 egl30_damage_make(&d,rs,3,0,0,4,4);size_t bytes=egl30_damage_copy(&d,NULL,0,NULL,0,false);assert(bytes==16);
 before_sync=sync_count;assert(!egl30_external_damage(&sc,&b,false,&d,sparse,16,bytes)&&sync_count==before_sync+2);
 for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++)for(unsigned k=0;k<4;k++){
  bool hit=(x==0&&y<2)||(x==1&&y==1)||(x==3&&y==3);assert(sparse[(y*4+x)*4+k]==(hit?(k==3?255:39):77));}
 memset(sparse,12,64);assert(!egl30_external_damage(&sc,&b,true,&d,sparse,16,bytes)&&sync_count==before_sync+4);
 for(unsigned i=0;i<96;i++){
  unsigned y=i>=8?(i-8)/20:99,x=i>=8?((i-8)%20)/4:99;
  bool hit=(x==0&&y<2)||(x==1&&y==1)||(x==3&&y==3);assert(ext[i]==(hit?12:39));}
 unsigned char old_ext[96];memcpy(old_ext,ext,96);fail_start=true;assert(egl30_external_damage(&sc,&b,true,&d,sparse,16,bytes)==EIO&&!memcmp(old_ext,ext,96)&&!sh.poisoned);fail_start=false;
 fail_end=true;assert(egl30_external_damage(&sc,&b,true,&d,sparse,16,bytes)==EOWNERDEAD&&sh.poisoned&&b.write_error==EOWNERDEAD);
 puts("EGL30_SPARSE_DMA_STRIDE_GUARD_SYNC_PASS");b.write_error=0;sh.poisoned=false;
 fail_end=true;assert(hre_shared_rt_region(&sc,&b,true,1,1,1,1)==EOWNERDEAD&&sh.poisoned&&b.write_error==EOWNERDEAD&&sc.host_buffer_bytes==0);munmap(ext,96);fclose(f);puts("EGL22_REGION_TRANSFER_MOCK_PASS");
}
C
cc -std=c11 -Wall -Wextra -Werror -O2 -I"$T" "$T/test.c" -o "$T/test"; "$T/test"
