#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cc -std=c11 -Wall -Wextra -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -I"$D/tests/view-bank" -I"$D/overlay/src/gallium/drivers/sgx535" "$D/tests/view-bank/test.c" -o "$T/test"
"$T/test"
