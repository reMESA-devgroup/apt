# EGL29 — native admission and terminal close experiment
Base: EGL28, private i386 runtime. No kernel/boot/USSE changes. Keep 40 GPU slots.

## ENOENT
The first observed hybrid rejection is before BATCH_PLAN. The archived topology2 bank limits cumulative view creation to 1024 and retains destroyed entries. This is a plausible explanation, not a confirmed physical root cause; 1024 CPU blits is not necessarily 1024 views. The new opt-in Gallium mode frees views only when their reference count reaches zero, retains live references and the owner proxy until the last late release. The raw-pointer strict lab mode keeps its original tombstones and cap. The compositor runner enables the mode; --strict-views disables it. Never pass a pointer after its last Gallium reference is released. New logs distinguish view creation, bind, sampler admission, constants and vertex map failures. Sticky publication_error is unchanged.

## Native performance
--native3d disables the CPU texture blitter and retains CPU solid draws, affine graph reuse, host RT, direct regions, texture cache, adaptive scratch buckets and KMS cursor. Native remains CPU resolve + actual SGX535 raster, limited qualified shader subset.
--direct-close is independent and experimental: after successful paired readback and oracle, terminal CLOSE is authenticated using the existing release_owned path while the graph is attached; no new publication occurs before success. The archived kernel source private_graph_reset_dpm_locked clears/flushed both DPM pools on DROP; terminal release instead checks idle, seals and ownership. The actual installed module and backend still need physical verification; the next OPEN may still pay for pristine DPM allocation. No checks are bypassed. Disable --direct-close to return to the known path. No claim of 60 FPS.

## Commands
Tab: REMESA_BUILD_JOBS=6 bash deploy-test.sh full
Modes cloud (new CPU path), compare (baseline + new CPU), native (two native Foot tests), full (all). Fail closed at the first failing run. User must provide SSH/sudo passwords and interact similarly in each test.
Mini: sudo bash desktop/run.sh --stage foot --seconds 60 --native3d --hardware-cursor
Only after pass: sudo bash desktop/run.sh --stage foot --seconds 60 --native3d --direct-close --hardware-cursor
Profiler: python3 profile29.py LOG. Full hybrid wall time includes geometry/constant preparation but not page flip or app latency. KMS witness polls every 100ms and is not a FPS counter.
