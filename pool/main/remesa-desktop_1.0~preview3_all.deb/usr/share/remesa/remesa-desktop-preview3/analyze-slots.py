#!/usr/bin/env python3
"""Report the first complete EGL21 pressure inventory, never infer a leak."""
import argparse,re,sys
p=argparse.ArgumentParser();p.add_argument('log');a=p.parse_args()
slots={};owners={};retired=set();fail=False
with open(a.log,errors='replace') as f:
 for line in f:
  for m in re.finditer(r'HRE_NATIVE_RETIRED\b[^\n]*?operation=(\d+)',line):retired.add(m.group(1))
  for tag in ('HRE_EGL21_GALLIUM','HRE_EGL21_SLOT','HRE_EGL21_ACCOUNT'):
   if tag not in line:continue
   data=dict(re.findall(r'(\w+)=([^\s]+)',line.split(tag,1)[1])); dev=data.get('device','');bo=data.get('bo','');event=data.get('event','')
   if tag.endswith('GALLIUM'):
    if event=='create':owners[(dev,bo)]=data
    elif event=='destroy':owners.pop((dev,bo),None)
   elif tag.endswith('SLOT') and event in ('pressure','scanout_pressure','device_close'):
    slots.setdefault((dev,event),{})[int(data['index'])]=data
   elif tag.endswith('ACCOUNT'):
    inv=slots.pop((dev,event),{});cap=int(data['capacity']); live=[x for x in inv.values() if x['live']=='1'];total=sum(int(x['allocated']) for x in live)
    ok=len(inv)==cap==40 and len(live)==int(data['live']) and total==int(data['bo']) and int(data['bo'])+int(data['shader'])==int(data['total']) and data['consistent']=='1'
    print('INVENTORY',event,'complete_and_consistent='+str(ok),data)
    for i,x in sorted(inv.items()):
     g=owners.get((dev,x['bo']),{}) if x['live']=='1' else {}
     print(i,x['generation'],x['allocated'],x['origin'],x['reason'],'refs='+x['refs'],'scene='+x['scene'],'retired='+x['last_retired'],'gallium_cookie='+g.get('cookie','unknown'),'bind='+g.get('bind','unknown'))
    fail|=not ok
    if event in ('pressure','scanout_pressure'):
     print('Distinct operation IDs observed before pressure (not a qualification count):',len(retired));sys.exit(1 if fail else 0)
print('No pressure inventory found; no proof of exhaustion or its absence.');sys.exit(1 if fail else 2)
