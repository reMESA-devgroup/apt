#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
python3 - "$D/overlay/src/mesa/state_tracker/st_sampler_view.c" "$T/frontend-extracted.inc" <<'PY'
import sys,pathlib
s=pathlib.Path(sys.argv[1]).read_text(); start=s.index('static struct pipe_sampler_view *\nst_texture_set_sampler_view('); end=s.index('/**\n * Release all sampler views',start)
pathlib.Path(sys.argv[2]).write_text(s[start:end])
PY
cc -std=c11 -Wall -Wextra -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -I"$T" -I"$D/tests/view-bank" -I"$D/overlay/src/gallium/drivers/sgx535" "$D/tests/view-bank/frontend.c" -o "$T/test"
"$T/test"
