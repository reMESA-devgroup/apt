#!/usr/bin/env python3
"""Unprivileged, non-submitting private EGL/GBM admission checks.
No version overrides, no experimental gates, no KMS changes, no software fallback claim.
Each mode is independent; a successful surface is NOT a qualified render or presentation.
"""
import argparse, ctypes as C, glob, os, pathlib, sys
P=C.c_void_p; I=C.c_int; U=C.c_uint; S=C.c_char_p; PI=C.POINTER(I)
R=pathlib.Path('/opt/remesa/12.3/lib')
def bind(lib,n,t,*a):
 f=getattr(lib,n);f.restype=t;f.argtypes=list(a);return f

def load(n): return C.CDLL(str(R/n),use_errno=True)
def identity(node):
 p=pathlib.Path('/sys/class/drm')/pathlib.Path(node).name/'device'
 try:return (p/'vendor').read_text().strip()=='0x8086' and (p/'device').read_text().strip()=='0x8108' and (p/'driver/module').resolve(strict=True).name=='remesa_gma500gfx'
 except OSError:return False

def egl_api():
 e=load('libEGL.so.1')
 for n,t,a in [('eglGetPlatformDisplay',P,[U,P,P]),('eglGetError',U,[]),('eglInitialize',U,[P,PI,PI]),('eglTerminate',U,[P]),('eglQueryString',S,[P,I]),('eglGetConfigs',U,[P,P,I,PI]),('eglGetConfigAttrib',U,[P,P,I,PI]),('eglCreatePlatformWindowSurface',P,[P,P,P,P]),('eglDestroySurface',U,[P,P])]:bind(e,n,t,*a)
 return e

def need(e,v,stage):
 if not v:raise RuntimeError(f'{stage} EGL_ERROR=0x{e.eglGetError():04x}')
 return v

def configs(e,d):
 n=I();need(e,e.eglGetConfigs(d,None,0,C.byref(n)),'GET_CONFIG_COUNT')
 if not 0<n.value<=4096:raise RuntimeError(f'NO_CONFIGS count={n.value}')
 a=(P*n.value)();m=I();need(e,e.eglGetConfigs(d,a,n.value,C.byref(m)),'GET_CONFIGS')
 if not 0<m.value<=n.value:raise RuntimeError('INVALID_CONFIG_COUNT')
 def attrib(cfg,k):
  v=I();need(e,e.eglGetConfigAttrib(d,cfg,k,C.byref(v)),'GET_CONFIG_ATTRIB');return v.value
 # WINDOW_BIT and GLES2, explicitly conformant, not slow/nonconformant.
 out=[(x,attrib(x,0x302e)) for x in a[:m.value] if attrib(x,0x3033)&4 and attrib(x,0x3040)&4 and attrib(x,0x3042)&4 and attrib(x,0x3027)==0x3038]
 print('EGL_CONFORMANT_ES2_WINDOW_CONFIGS',len(out),flush=True)
 if not out:raise RuntimeError('NO_CONFORMANT_ES2_WINDOW_CONFIG')
 return out

def initialize(e,platform,native):
 d=need(e,e.eglGetPlatformDisplay(platform,native,None),'GET_PLATFORM_DISPLAY');a,b=I(),I()
 need(e,e.eglInitialize(d,C.byref(a),C.byref(b)),'INITIALIZE')
 print('EGL_INITIALIZED',a.value,b.value,'vendor=',e.eglQueryString(d,0x3053),'apis=',e.eglQueryString(d,0x308d),flush=True)
 return d

def gbm_probe():
 nodes=[x for x in sorted(glob.glob('/dev/dri/renderD*')) if identity(x)]
 if len(nodes)!=1:raise RuntimeError(f'EXPECTED_ONE_REMESA_RENDER_NODE found={nodes}')
 fd=os.open(nodes[0],os.O_RDWR|os.O_CLOEXEC|os.O_NOFOLLOW)
 print('NONROOT_RENDER_NODE_OPEN_OK',nodes[0],flush=True)
 dev=surf=bo=d=es=None;g=e=None
 try:
  g=load('libgbm.so.1');e=egl_api()
  for n,t,a in [('gbm_create_device',P,[I]),('gbm_device_destroy',None,[P]),('gbm_device_get_backend_name',S,[P]),('gbm_bo_create',P,[P,U,U,U,U]),('gbm_bo_get_fd',I,[P]),('gbm_bo_destroy',None,[P]),('gbm_surface_create',P,[P,U,U,U,U]),('gbm_surface_destroy',None,[P])]:bind(g,n,t,*a)
  dev=g.gbm_create_device(fd)
  if not dev:raise RuntimeError('GBM_CREATE_DEVICE_FAILED')
  print('GBM_DEVICE_OK backend=',g.gbm_device_get_backend_name(dev),flush=True)
  fmt=0x34325258 # XRGB8888
  bo=g.gbm_bo_create(dev,64,64,fmt,4) # GBM_BO_USE_RENDERING
  if not bo:raise RuntimeError('GBM_RENDER_BO_CREATE_FAILED')
  print('GBM_RENDER_BO_OK',flush=True)
  shared=g.gbm_bo_get_fd(bo)
  if shared<0:raise RuntimeError('GBM_BO_EXPORT_FAILED')
  os.close(shared);print('GBM_BO_EXPORT_FD_OK (not SGX rendering evidence)',flush=True)
  d=initialize(e,0x31d7,dev)
  cfg=next((x for x,visual in configs(e,d) if visual==fmt),None)
  if not cfg:raise RuntimeError('NO_MATCHING_XRGB8888_EGL_CONFIG')
  surf=g.gbm_surface_create(dev,64,64,fmt,4)
  if not surf:raise RuntimeError('GBM_SURFACE_CREATE_FAILED')
  es=need(e,e.eglCreatePlatformWindowSurface(d,cfg,surf,None),'EGL_GBM_WINDOW_SURFACE')
  print('EGL_GBM_WINDOW_SURFACE_CREATED (no draw, swap, KMS or compositor qualification)',flush=True)
 finally:
  if es:e.eglDestroySurface(d,es)
  if d:e.eglTerminate(d)
  if surf:g.gbm_surface_destroy(surf)
  if bo:g.gbm_bo_destroy(bo)
  if dev:g.gbm_device_destroy(dev)
  os.close(fd)

def wayland_probe():
 if not os.environ.get('WAYLAND_DISPLAY'):raise RuntimeError('NO_WAYLAND_SESSION')
 w=C.CDLL('libwayland-client.so.0');connect=bind(w,'wl_display_connect',P,S);disconnect=bind(w,'wl_display_disconnect',None,P)
 wl=connect(None)
 if not wl:raise RuntimeError('WAYLAND_CONNECT_FAILED')
 d=None
 try:
  print('WAYLAND_CONNECTED',flush=True);e=egl_api();d=initialize(e,0x31d8,wl);configs(e,d)
  print('EGL_WAYLAND_WINDOW_CONFIGS_AVAILABLE (not compositor GPU proof)',flush=True)
 finally:
  if d:e.eglTerminate(d)
  disconnect(wl)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['gbm','wayland']);a=p.parse_args()
 if os.geteuid()==0:sys.exit('Run without sudo; this is an unprivileged admission probe')
 forbidden=[k for k in os.environ if k.startswith('REMESA_') or k in ('LD_PRELOAD','MESA_GLES_VERSION_OVERRIDE','MESA_GL_VERSION_OVERRIDE','MESA_EXTENSION_OVERRIDE','MESA_NO_ERROR','LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER')]
 if forbidden:sys.exit('Refusing environment overrides: '+', '.join(sorted(forbidden)))
 try:(gbm_probe if a.mode=='gbm' else wayland_probe)()
 except (RuntimeError,OSError,AttributeError) as e:print('PRESENTATION_ADMISSION_FAIL',str(e),file=sys.stderr,flush=True);sys.exit(1)
