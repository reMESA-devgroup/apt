# reMESA Desktop Preview — EGL34

**Trusted, supervised technical preview. Not a public production driver.**

This package adds a desktop profile and installer to the existing EGL34 runtime. It does not introduce a new Mesa binary version, change the 40 GPU slots, or modify kernel source. It targets the Dell Mini 12 / Poulsbo 8086:8108 and an i386 Debian/antiX installation using GRUB and initramfs-tools. Kernel policy allows 5.10–6.10 and 6.18 as an exception; a matching EGL14 LINEAR module for each exact kernel is mandatory. The range is not a claim of validated builds or hardware support.

## Installation from stock

1. From the extracted directory run `bash install.sh --check` (read-only).
2. Have `~/remesa-hre-cross_1.0~topology2.egl34_i386.deb` ready, or have EGL34 already installed. If the historical EGL14 initramfs and its root-owned build ID are present, the installer extracts and validates the matching .ko from there. Otherwise supply `--kernel-module /path/remesa_gma500gfx.ko` explicitly. Do not use a module built for a different kernel.
3. Run `bash install.sh` (requests sudo). Optional `--deps` installs desktop dependencies from existing configured apt repositories, without adding repositories. Some packages may require distribution backports; if unavailable, install them using your existing distribution workflow. NetworkManager/ConnMan are not installed or switched automatically.
4. Reboot manually, select **reMESA Desktop (experimental)**. The stock kernel, module and initramfs remain available. On antiX stop slimski from SSH/TTY (`sudo sv down slimski`).
5. Run `remesa-desktop test` for a two-minute smoke test, or `remesa-desktop` for the interactive session without a time limit. Super+Esc exits. Root compositor is still an experimental requirement; all desktop clients run as the invoking non-root user. No autologin or sudoers changes. Logs remain in `/tmp/remesa-egl19-desktop.*` and release-mode counters/errors remain active.

## Desktop

Bottom Waybar taskbar with app launcher, open apps, minimize/restore, tray, network, sound, battery, clock and settings. Original static JPEG wallpaper (1280x800), dark Labwc theme with rectangular borders, no blur/animation/shadows; Mako notifications; Fuzzel launcher. Network settings use existing NetworkManager or ConnMan; display settings use wdisplays and volume uses pavucontrol. Optional tools and PolicyKit/session permissions affect usability. Stock app EGL libraries remain in use by normal clients.

## DRM

`remesa-desktop status` reports node/ACL and `remesa-desktop probe` tests opening and EGL/GBM admission without sudo. Boot hook explicitly enables `render_probe_unprivileged=1` and `noirq=1`. Installer sets group `remesa-render` and a udev rule matching only the experimental Poulsbo render node; launcher applies effective 0660 and the user ACL after authenticated boot. New group membership requires a new login. The exact module retains its private command guard. Opening the node is not evidence of rootless private 2D/3D rendering, general GLES2 support, or multi-client isolation. No global Mesa overrides or world-writable render node are intended. Confirm permissions after reboot.

## Rollback

Choose stock in GRUB, then `bash /opt/remesa/desktop-preview/install.sh --uninstall`. Removes this new profile, entry, initramfs and build ID, and only its own new group membership/rule. The old EGL14 entry and the private Mesa package are retained. The group itself and apt dependencies remain. A failed boot-staging transaction rolls back new boot/profile files and attempts GRUB regeneration; installed apt dependencies and private runtime are not rolled back. If GRUB regeneration fails, inspect it before rebooting. Do not delete the stock initramfs. The installer intentionally refuses an already installed preview instead of overwriting it.

## Offline checks

`python3 installer/test-host.py`: Bash syntax, config JSON/XML, GRUB fixture clone with microcode, source unchanged, systemd isolation and refusal when no stock entry. `bash test-egl34-rows.sh`: existing EGL34 SSE2 and scalar pixel oracle. No actual initramfs installation, target boot, GPU test, desktop screenshot or rootless private ioctl test in this environment.

Preview 2: see PUBLIC-PREVIEW.md for the rootless nested installer, X11/Wayland launchers and GLES2 tests.

## Preview 3 migration hotfix
The native installer checks the known legacy `remesa-hre-v123 <= 12.3~rc7` package before desktop dependency installation. It simulates removal and refuses plans involving unrelated changes; the actual dpkg removal names only that legacy package and does not force dependencies. No generic APT repair, automatic reboot or startup, or package downloading outside configured APT repositories is added. Legacy package removal and dependency changes are not rolled back on later failure. Existing Preview 2 installation still requires stock boot and explicit uninstall before native reinstall. The Mesa/kernel sources and binary requirements are unchanged. This is an incremental developer archive, not a standalone reproducible public source release. See RELEASE-GATE.md.
