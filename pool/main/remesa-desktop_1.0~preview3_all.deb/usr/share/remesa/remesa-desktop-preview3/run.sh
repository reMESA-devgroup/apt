#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
exec bash "$D/native/run.sh" "$@"
