#!/usr/bin/env python3
"""Isolated GPU scratch test: native sampled quad, alpha and depth coverage."""
import ctypes as c, pathlib, sys, faulthandler, os, time
faulthandler.enable()
from scratch_geometry import fixture, verify_pixels
if len(sys.argv)!=2:raise SystemExit('Usage: probe-scratch.py /opt/remesa/12.3')
if os.geteuid()!=0 or 'remesa_boot=prime-mmap' not in pathlib.Path('/proc/cmdline').read_text().split():raise SystemExit('Requires isolated PRIME mmap boot and root')
w,h,mesh,source_rgba,rect=fixture()
r=pathlib.Path(sys.argv[1]);e=c.CDLL(str(r/'lib/libEGL.so.1'));g=c.CDLL(str(r/'lib/libGLESv2.so.2'))
P=c.c_void_p; I=c.c_int; U=c.c_uint; S=c.c_char_p; PI=c.POINTER(I)
def bind(lib,name,result,args):
 f=getattr(lib,name);f.restype=result;f.argtypes=args;return f
for n,t,a in [('eglGetPlatformDisplay',P,[U,P,P]),('eglInitialize',U,[P,PI,PI]),('eglGetError',U,[]),('eglQueryString',S,[P,I]),('eglGetConfigs',U,[P,P,I,PI]),('eglGetConfigAttrib',U,[P,P,I,PI]),('eglBindAPI',U,[U]),('eglCreateContext',P,[P,P,P,PI]),('eglMakeCurrent',U,[P,P,P,P]),('eglDestroyContext',U,[P,P]),('eglTerminate',U,[P])]:bind(e,n,t,a)
def need(value,stage):
 if not value:raise RuntimeError(f'{stage}: EGL error 0x{e.eglGetError():04x}')
 return value
def attrib(d,cfg,key):
 value=I();need(e.eglGetConfigAttrib(d,cfg,key,c.byref(value)),f'config {key:#x}');return value.value
D=need(e.eglGetPlatformDisplay(0x31DD,None,None),'get display');ctx=None;surface=None;current=False;initialized=False
try:
 major,minor=I(),I();need(e.eglInitialize(D,c.byref(major),c.byref(minor)),'initialize');initialized=True
 print(f'EGL_INITIALIZED {major.value}.{minor.value}',flush=True)
 apis=e.eglQueryString(D,0x308D) or b'';print('EGL_CLIENT_APIS',apis,flush=True)
 if b'OpenGL_ES' not in apis.split():raise RuntimeError('GLES lab API not admitted')
 n=I();need(e.eglGetConfigs(D,None,0,c.byref(n)),'config count')
 if not 0<n.value<=4096:raise RuntimeError('invalid config count')
 cfgs=(P*n.value)();got=I();need(e.eglGetConfigs(D,cfgs,n.value,c.byref(got)),'configs')
 if not 0<got.value<=n.value:raise RuntimeError('invalid returned count')
 cfg=next((x for x in cfgs[:got.value] if attrib(D,x,0x3040)&4 and not attrib(D,x,0x3042)&4 and attrib(D,x,0x3027)==0x3051),None)
 if not cfg:raise RuntimeError('no explicitly non-conformant ES2 config')
 print('EGL_ES2_CONFIG_NONCONFORMANT',flush=True)
 need(e.eglBindAPI(0x30A0),'bind ES');attrs=(I*3)(0x3098,2,0x3038)
 ctx=need(e.eglCreateContext(D,cfg,None,attrs),'create context');print('EGL_CONTEXT_CREATED',flush=True)
 bind(e,'eglCreatePbufferSurface',P,[P,P,PI]);bind(e,'eglDestroySurface',U,[P,P])
 surface=need(e.eglCreatePbufferSurface(D,cfg,(I*5)(0x3057,w,0x3056,h,0x3038)),'pbuffer')
 current=bool(need(e.eglMakeCurrent(D,surface,surface,ctx),'make current'));print('EGL_CONTEXT_CURRENT',flush=True)
 get=bind(g,'glGetString',S,[U]);err=bind(g,'glGetError',U,[])
 renderer=get(0x1f01) or b'';version=get(0x1f02) or b'';glsl=get(0x8b8c) or b''
 print('GL_RENDERER',renderer,flush=True);print('GL_VERSION',version,flush=True);print('GLSL_VERSION',glsl,flush=True)
 if b'12.3 RC7 HRE' not in renderer or b'[topology-1]' not in renderer or b'sgx535' not in renderer.lower() or any(x in renderer.lower() for x in (b'llvmpipe',b'softpipe',b'swrast')) or not version.startswith(b'OpenGL ES '):raise RuntimeError('unexpected GLES dispatch/renderer')
 if err():raise RuntimeError('GL dispatch error')
 def gl(n,t,*a):
  f=bind(g,n,t,list(a))
  def checked(*args):
   print("GLES_CALL_BEGIN",n,flush=True);result=f(*args);check(n);print('GLES_CALL_PASS',n,flush=True);return result
  return checked
 def check(stage):
  x=err()
  if x:raise RuntimeError(f'{stage}: GL error {x:#x}')
 F=c.c_float; PU=c.POINTER(U)
 create=gl('glCreateShader',U,U); source=gl('glShaderSource',None,U,I,c.POINTER(S),PI);compile=gl('glCompileShader',None,U); status=gl('glGetShaderiv',None,U,U,PI)
 def shader(kind,code):
  sh=create(kind);src=S(code);source(sh,1,c.byref(src),None);compile(sh);v=I();status(sh,0x8b81,c.byref(v))
  if not v.value:
   buf=c.create_string_buffer(4096);gl('glGetShaderInfoLog',None,U,I,PI,P)(sh,len(buf),None,buf);raise RuntimeError(buf.value)
  return sh
 vs=shader(0x8b31,b'attribute vec4 position; attribute vec2 uv; varying vec2 texcoord; void main(){gl_Position=position;texcoord=uv;}')
 fs=shader(0x8b30,b'precision mediump float; varying vec2 texcoord; uniform sampler2D image; void main(){gl_FragColor=texture2D(image,texcoord);}')
 program=gl('glCreateProgram',U)();attach=gl('glAttachShader',None,U,U);attach(program,vs);attach(program,fs)
 loc=gl('glBindAttribLocation',None,U,U,S);loc(program,0,b'position');loc(program,1,b'uv');gl('glLinkProgram',None,U)(program)
 v=I();gl('glGetProgramiv',None,U,U,PI)(program,0x8b82,c.byref(v))
 if not v.value:
  buf=c.create_string_buffer(4096);gl('glGetProgramInfoLog',None,U,I,PI,P)(program,len(buf),None,buf);raise RuntimeError(buf.value)
 gl('glUseProgram',None,U)(program);check('program');print('GLES_SHADER_LINK_PASS',flush=True)
 tex=U();gl('glGenTextures',None,I,PU)(1,c.byref(tex));gl('glBindTexture',None,U,U)(0x0de1,tex)
 param=gl('glTexParameteri',None,U,U,I)
 for key,val in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:param(0x0de1,key,val)
 rgba=(c.c_ubyte*16)(*(source_rgba*4))
 gl('glTexImage2D',None,U,I,I,I,I,I,U,U,P)(0x0de1,0,0x1908,2,2,0,0x1908,0x1401,rgba)
 uniform=gl('glGetUniformLocation',I,U,S)(program,b'image');assert uniform>=0;gl('glUniform1i',None,I,I)(uniform,0)
 vertices=(F*len(mesh))(*mesh)
 bo=U();gl('glGenBuffers',None,I,PU)(1,c.byref(bo));gl('glBindBuffer',None,U,U)(0x8892,bo);gl('glBufferData',None,U,c.c_ssize_t,P,U)(0x8892,c.sizeof(vertices),vertices,0x88e4)
 pointer=gl('glVertexAttribPointer',None,U,I,U,c.c_ubyte,I,P);enable=gl('glEnableVertexAttribArray',None,U)
 pointer(0,4,0x1406,0,24,None);pointer(1,2,0x1406,0,24,P(16));enable(0);enable(1)
 gl('glDisable',None,U)(0x0bd0) # GL_DITHER: not implemented
 gl('glEnable',None,U)(0x0b71) # GL_DEPTH_TEST, same LESS/write as physical probe
 gl('glDepthFunc',None,U)(0x0201);gl('glDepthMask',None,c.c_ubyte)(1)
 gl('glViewport',None,I,I,I,I)(0,0,w,h);check('setup')
 print('HRE_SCRATCH_BEGIN',w,h,'rectangle',rect,'RGBA',source_rgba,flush=True)
 gl('glDrawArrays',None,U,I,I)(4,0,len(mesh)//6)
 gl('glFinish',None)()
 read=gl('glReadPixels',None,I,I,I,I,U,U,P)
 pixels=(c.c_ubyte*(w*h*4))();read(0,0,w,h,0x1908,0x1401,pixels)
 from collections import Counter
 print('HRE_SCRATCH_COLOR_WITNESS',Counter(tuple(pixels[i:i+4]) for i in range(0,len(pixels),4)).most_common(8),flush=True)
 i=((h//2)*w+w//2)*4
 print('HRE_SCRATCH_CENTER_RGBA',list(pixels[i:i+4]),flush=True)
 # NV_read_depth is advertised by this experimental context. Verify rather
 # than assume that this path exposes the actual depth mask.
 depths=(c.c_uint32*(w*h))();read(0,0,w,h,0x1902,0x1405,depths)
 verify_pixels(w,h,bytes(pixels),list(depths),source_rgba,rect)
 print('HRE_SCRATCH_COLOR_DEPTH_PASS',flush=True)
finally:
 if current:need(e.eglMakeCurrent(D,None,None,None),'release current')
 if ctx:need(e.eglDestroyContext(D,ctx),'destroy context')
 if surface:need(e.eglDestroySurface(D,surface),'destroy surface')
 if initialized:need(e.eglTerminate(D),'terminate')
print('GLES_CONTEXT_LAB_CLEAN_CLOSE',flush=True)
