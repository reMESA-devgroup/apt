#!/usr/bin/env bash
set -Eeuo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cat > "$T/rows.c" <<'C'
#include "remesa_egl34_rows.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 uint8_t src[4*257+16],out[sizeof src],expected[sizeof src];
 for(size_t i=0;i<sizeof src;i++)src[i]=(uint8_t)(i*19+i/7);
 for(size_t off=0;off<8;off++)for(size_t n=1;n<=257;n++)for(int opaque=0;opaque<=1;opaque++){
  memset(out,0xa5,sizeof out);memcpy(expected,src,sizeof src);
  assert(!egl34_readback_row(out+off,src+off,expected+off,n,opaque));
  for(size_t i=0;i<sizeof out;i++){
   uint8_t q=i<off||i>=off+4*n?0xa5:opaque&&(i-off)%4==3?255:src[i];assert(out[i]==q);
  }
  expected[off+4*n-1]^=1;assert(egl34_readback_row(out+off,src+off,expected+off,n,opaque));
 }
 puts("EGL34_ROWS_EXACT_ALPHA_PADDING_ORACLE_PASS");return 0;
}
C
case $(uname -m) in x86_64|i?86) variants=('-msse2' '-mno-sse2');; *) variants=('');; esac
for flags in "${variants[@]}"; do
 cc -std=c11 -O2 -Wall -Wextra -Werror $flags -I"$D/overlay/src/gallium/drivers/sgx535" "$T/rows.c" -o "$T/rows"
 "$T/rows"
done
