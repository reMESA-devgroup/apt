# EGL30 WINDOW TURBO

Based on EGL29B. Opt-in `--window-turbo` on top of CLOUDTAIL. For eligible CPU solid or CPU texture draws with an initialized direct shared render target, computes the exact union of clipped rectangles by horizontal span merging in y bands. Transfers and commits only those spans, with one DMA-BUF START/END pair per direction. Primitive order remains unchanged. Opaque or nonblended sparse draws do not read the destination. XRGB alpha normalization happens after copying to RAM. Dense batches use the existing path. Native raster path is unchanged. The temporary allocation remains bbox-sized; uninitialized holes are never copied in sparse mode. This is not a frame-level batching or hardware 2D implementation.

In the supplied log, a 1,534,376-byte bounding box covered 15,985 reported pixels; the exact union can be smaller if rectangles overlap. The potential traffic reduction is about 95.8% per direction, not a measured timing improvement.

Run from the existing ARM build environment:
    REMESA_BUILD_JOBS=6 bash deploy-test.sh window
or compare the previous CLOUDTAIL path to WINDOW TURBO (120 seconds each):
    REMESA_BUILD_JOBS=6 bash deploy-test.sh compare
Drag and resize windows repeatedly during both tests. No PASS without sparse evidence in window mode, clean shutdown, and the previous error checks. Use --cloudtail for comparison on the EGL30 runtime. Full i386 build and physical qualification pending. No kernel changes, no new slot limits, no FPS claim.
