#!/usr/bin/env python3
"""EGL24: native retirement, graph decisions, DROP callback and CPU solid path.
A successful composition batch is not necessarily one display frame."""
import re,sys,statistics
from collections import Counter,defaultdict
if len(sys.argv)!=2: sys.exit('Usage: python3 profile26.py LOG')
rows=[];native=[];drop=[];cpu=[];counts=Counter();region=Counter();group=Counter();modes=[];last_native=None;reused_native=defaultdict(list);tile_labels=[];errors=Counter()
def fields(s):return {k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',s)}
def append_valid(dst,d,keys):
 if all(k in d for k in keys):dst.append(d)
with open(sys.argv[1],errors='replace') as f:
 for l in f:
  if 'EGL24_CONFIG ' in l or 'EGL25_CONFIG ' in l or 'EGL26_CONFIG ' in l:modes.append(l.strip())
  if 'HRE_EGL24_GRAPH_TILE ' in l:
   d=fields(l);group[(d.get('reuse_input'),d.get('keep'))]+=1;tile_labels.append(d.get('reuse_input'))
  if 'HRE_EGL23_NATIVE ' in l:
   d=fields(l);append_valid(native,d,('setup_us','draw_us','read_us','drop_us','tail_us'))
   if tile_labels:
    label=tile_labels.pop(0)
    if label in (0,1):reused_native[label].append(d)
  if 'HRE_EGL26_CPU_BLIT_WORK ' in l:append_valid(cpu,fields(l),('pixels','us'))
  if 'HRE_EGL24_DROP ' in l:append_valid(drop,fields(l),('callback_us','collect_us'))
  if 'HRE_EGL22_TIMING ' in l:append_valid(rows,fields(l),('tiles','total_us','import_us','native_us','close_us','publish_us'))
  for tag in ('HRE_EGL26_CPU_BLIT_PASS','HRE_EGL26_BLIT_FALLBACK','HRE_EGL26_NATIVE_CACHE_HIT','HRE_EGL26_SHARED_UNCHANGED','HRE_EGL26_DIRECT_REGION','HRE_EGL26_DISCARD_READ','HRE_EGL25_AFFINE_TILE','HRE_NATIVE_RETIRED','HRE_EGL22_DPM_REUSE','HRE_COMPOSITOR_SESSION_BOUNDARY','HRE_EGL21B_RESIDENT_UPLOAD','HRE_EGL24_GRAPH_REPLAY','HRE_EGL24_GRAPH_REBUILD','HRE_EGL24_SOLID_PASS','EGL15_KMS_FB_CHANGE','EGL19_CLEAN_SHUTDOWN','HRE_TILE_FAIL','HRE_EGL22_REGION_FAIL','HRE_EGL21C_SHARED_FAIL','EGL19_DRAW_FAILED','HRE_NATIVE_STAGE_FAIL','HRE_COMPOSITOR_SESSION_CLOSE_FAIL'):
   if tag in l:counts[tag]+=1
  if 'HRE_EGL24_GRAPH_REBUILD ' in l:
   match=re.search(r'reason=(\w+)',l)
   if match:counts['rebuild_'+match[1]]+=1
  if 'HRE_EGL22_REGION_PASS ' in l or 'HRE_EGL21C_SHARED_PASS ' in l or 'HRE_EGL26_DIRECT_REGION ' in l:
   d=fields(l)
   if 'publish' in d and 'bytes' in d:region['publish' if d['publish']==1 else 'import']+=d['bytes']
  if any(x in l for x in ('HRE_TILE_FAIL','HRE_NATIVE_STAGE_FAIL','HRE_COMPOSITOR_SESSION_CLOSE_FAIL','HRE_COMPOSITOR_HYBRID_REJECT')):
   d=fields(l)
   if d.get('errno'):errors[d['errno']]+=1
for mode in modes:print(mode)
print('Successful composition batches:',len(rows),'native tiles:',sum(r['tiles'] for r in rows))
def stats(dataset,keys):
 for k in keys:
  v=sorted(r[k]/1000 for r in dataset if k in r)
  if v:print(f'  {k[:-3]}: median={statistics.median(v):.2f} ms p95={v[(95*len(v)+99)//100-1]:.2f} ms sum={sum(v):.2f} ms n={len(v)}')
stats(rows,('total_us','import_us','native_us','close_us','publish_us'))
print('CPU texture blits:',len(cpu),'pixels:',sum(r['pixels'] for r in cpu))
if cpu:
 vals=sorted(r['us']/1000 for r in cpu);print(f'  CPU blit incl. map: median={statistics.median(vals):.2f} ms p95={vals[(95*len(vals)+99)//100-1]:.2f} ms')
print('Native tile samples:',len(native));stats(native,('setup_us','draw_us','read_us','drop_us','tail_us'))
print('Authenticated graph DROP samples:',len(drop));stats(drop,('callback_us','collect_us'))
for (reuse,keep),n in sorted(group.items(),key=lambda x:str(x[0])):print(f'Graph tile reuse_input={reuse} keep={keep}: {n}')
for label in (0,1):
 if reused_native[label]:
  print('Tile samples with '+('resident input' if label else 'fresh input')+':',len(reused_native[label]));stats(reused_native[label],('setup_us','draw_us','drop_us'))
for k,v in counts.items():print(k,v)
for k,v in region.items():print(f'{k} transferred bytes (logged):',v)
for k,v in sorted(errors.items()):print('errno',k,'count',v)
print('Clean shutdown:', 'yes' if counts['EGL19_CLEAN_SHUTDOWN'] else 'not recorded')
print('Note: GRAPH_REPLAY is a successful vertex update decision, not a retirement counter; use HRE_NATIVE_RETIRED for physical receipts.')

if counts["HRE_NATIVE_RETIRED"]: print("DROP callbacks per physical retirement:",round(len(drop)/counts["HRE_NATIVE_RETIRED"],3))
print("Note: DROP callback time may overlap DRAW or CLOSE; do not add it to total time.")
