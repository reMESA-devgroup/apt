#!/bin/bash
set -euo pipefail
D=/opt/remesa/desktop-preview
[[ $EUID != 0 ]] || { echo 'Run as normal user'; exit 2; }
case ${1:-start} in
 start) [[ $# -le 1 ]]; sudo bash "$D/render-access.sh" enable; exec sudo bash "$D/desktop/run.sh" --session --stage desktop --gpu-mixed --hardware-cursor --release;;
 nested-x11) shift; exec bash "$D/nested.sh" x11 "$@";;
 nested) shift; exec bash "$D/nested.sh" wayland "$@";;
 test3d) shift; exec python3 "$D/desktop/client/test3d.py" "$@";;
 test3d-native) shift; exec bash "$D/native-test3d.sh" "$@";;
 probe) exec bash "$D/render-probe.sh";;
 status) exec sudo bash "$D/render-access.sh" status;;
 test) [[ $# -le 1 ]]; sudo bash "$D/render-access.sh" enable; exec sudo bash "$D/desktop/run.sh" --stage desktop --seconds 120 --gpu-mixed --hardware-cursor --release;;
 *) echo 'Usage: remesa-desktop [start|test|probe|status|nested-x11|nested|test3d|test3d-native]'; exit 2;;
esac
