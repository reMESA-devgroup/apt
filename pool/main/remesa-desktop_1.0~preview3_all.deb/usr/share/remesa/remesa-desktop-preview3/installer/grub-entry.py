#!/usr/bin/env python3
"""Clone a simple generated Linux entry, preserving root/search/microcode lines."""
import re, sys
path, kernel, tag = sys.argv[1:]
lines = open(path).read().splitlines()
for i, line in enumerate(lines):
    if not re.match(r'^\s*menuentry\s', line): continue
    body=[]
    for l in lines[i+1:]:
        if l.strip()=='}': break
        if re.match(r'^\s*(menuentry|submenu)\s',l): break
        body.append(l)
    linux=[l for l in body if re.match(r'^\s*linux(?:efi)?\s',l) and re.search(r'/vmlinuz-'+re.escape(kernel)+r'(?:\s|$)',l)]
    init=[l for l in body if re.match(r'^\s*initrd(?:efi)?\s',l) and re.search(r'/initrd\.img-'+re.escape(kernel)+r'(?:\s|$)',l)]
    if len(linux)!=1 or len(init)!=1 or 'recovery' in line.lower() or 'remesa_boot=' in linux[0] or re.search(r'\s(?:single|rescue|emergency|systemd\.unit=rescue\.target)(?:\s|$)',linux[0]): continue
    if any('{' in l or '}' in l for l in body): continue
    print("menuentry 'reMESA Desktop (experimental)' --id remesa-desktop-preview {")
    for l in body:
        if l==linux[0]:
            l += ' module_blacklist=gma500_gfx modprobe.blacklist=gma500_gfx remesa_gma500gfx.render_probe_unprivileged=1 remesa_boot=egl34-desktop'
            if __import__('os').environ.get('REMESA_NATIVE_INIT')=='systemd':
                l += ' systemd.unit=multi-user.target systemd.mask=display-manager.service'
        if l==init[0]: l=re.sub(r'/initrd\.img-'+re.escape(kernel)+r'(?=\s|$)', '/initrd.img-'+tag,l)
        print(l)
    print('}'); sys.exit(0)
sys.exit('No simple matching stock GRUB entry; no boot changes made')
