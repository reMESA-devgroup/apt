#!/usr/bin/env bash
# Only migrate the known conflicting reMESA package; no force flags or autoremove.
set -euo pipefail
export LC_ALL=C
legacy=remesa-hre-v123
record=$(dpkg-query -W -f='${db:Status-Status} ${Version}' "$legacy" 2>/dev/null) || exit 0
read -r status version <<< "$record"
case "$status" in not-installed|config-files) exit 0;; esac
[[ -n $version ]] || { echo 'Cannot identify legacy reMESA version' >&2; exit 2; }
if ! dpkg --compare-versions "$version" le '12.3~rc7'; then exit 0; fi
printf 'Migrating known conflicting package: %s (%s)\n' "$legacy" "$version"
plan=$(apt-get -s --no-auto-remove remove "$legacy") || { echo 'Cannot resolve legacy package safely' >&2; exit 2; }
# No additional installs, purges or removals. Allow configuration only of the current runtime.
if ! awk -v legacy="$legacy" '
function base(x){sub(/:[^:]+$/, "", x);return x}
$1=="Remv" {if(base($2)!=legacy) bad=1; else n++}
$1=="Inst" || $1=="Purg" {bad=1}
$1=="Conf" && base($2)!="remesa-hre-cross" {bad=1}
END{exit (bad || n!=1)}' <<< "$plan"; then
 printf '%s\n' "$plan" >&2; echo 'Migration refused: unrelated package changes proposed' >&2; exit 2
fi
# dpkg limits the actual removal to this exact package and checks dependencies itself.
dpkg --remove "$legacy"
echo REMESA_LEGACY_MIGRATION_PASS
