#!/usr/bin/env python3
import os, pathlib, subprocess, tempfile
script=pathlib.Path(__file__).with_name('migrate-legacy.sh')
with tempfile.TemporaryDirectory() as t:
 p=pathlib.Path(t)
 for name,body in {
 'dpkg-query':'if [ "$CASE" = absent ]; then exit 1; fi; if [ "$CASE" = newer ]; then echo "installed 12.4"; else echo "unpacked 12.3~rc7"; fi',
 'dpkg':'case "$1" in --compare-versions) exec /usr/bin/dpkg "$@";; --remove) echo "$*" >> "$CALLS";; *) exit 99;; esac',
 'apt-get':'case "$CASE" in unsafe) printf "Remv remesa-hre-v123 [12.3~rc7]\\nRemv labwc [1]\\n";; install) printf "Remv remesa-hre-v123 [12.3~rc7]\\nInst other [1]\\n";; none) echo "0 to remove";; fail) exit 1;; *) printf "Remv remesa-hre-v123 [12.3~rc7]\\nConf remesa-hre-cross (1)\\n";; esac'
 }.items():
  q=p/name;q.write_text('#!/bin/sh\n'+body+'\n');q.chmod(0o755)
 for case,ok,removed in [('absent',True,False),('newer',True,False),('safe',True,True),('unsafe',False,False),('install',False,False),('none',False,False),('fail',False,False)]:
  calls=p/'calls';calls.unlink(missing_ok=True); env=dict(os.environ,PATH=str(p)+':'+os.environ['PATH'],CASE=case,CALLS=str(calls));r=subprocess.run(['bash',str(script)],env=env,capture_output=True,text=True)
  assert (r.returncode==0)==ok,(case,r.stdout,r.stderr); assert calls.exists()==removed,case
  if removed: assert calls.read_text()=='--remove remesa-hre-v123\n'
  print('PASS',case)
