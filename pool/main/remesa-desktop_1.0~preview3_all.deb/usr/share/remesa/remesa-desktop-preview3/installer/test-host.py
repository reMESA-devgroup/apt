#!/usr/bin/env python3
import json, os, pathlib, subprocess, tempfile, xml.etree.ElementTree as ET
D=pathlib.Path(__file__).resolve().parent.parent
for p in [D/'install.sh',D/'installer/launcher.sh',D/'desktop/run.sh',D/'desktop/tools/session.sh',D/'desktop/client/session.sh',D/'desktop/client/settings.sh',D/'render-access.sh',D/'native/tools/activate.sh',D/'desktop/tools/activate.sh',D/'deploy-test.sh']:
    subprocess.run(['bash','-n',str(p)],check=True)
config=json.loads((D/'desktop/client/waybar.json').read_text())
assert config['position']=='bottom' and 'wlr/taskbar' in config['modules-left']
assert {'network','battery','pulseaudio','tray','custom/settings','custom/notifications'} <= set(config['modules-right'])
assert config['wlr/taskbar']['on-click']=='minimize-raise'
root=ET.parse(D/'desktop/config/rc.xml').getroot();assert root.findtext('theme/name')=='reMESA'
assert root.find('mouse/context[@name="Iconify"]/mousebind/action').get('name')=='Iconify'
with tempfile.TemporaryDirectory() as t:
    p=pathlib.Path(t)/'grub.cfg'; k='5.10.240-antix.1-486-smp'; tag='remesa-desktop-'+k
    text=f"menuentry 'antiX recovery' {{\n linux /boot/vmlinuz-{k} root=UUID=test single\n initrd /boot/initrd.img-{k}\n}}\nmenuentry 'antiX' {{\n search --no-floppy --fs-uuid --set=root test\n linux /boot/vmlinuz-{k} root=UUID=test ro quiet\n initrd /boot/intel-ucode.img /boot/initrd.img-{k}\n}}\n"
    p.write_text(text);cmd=['python3',str(D/'installer/grub-entry.py'),str(p),k,tag];env=dict(os.environ,REMESA_NATIVE_INIT='runit');out=subprocess.check_output(cmd,env=env,text=True)
    assert 'remesa_boot=egl34-desktop' in out and 'render_probe_unprivileged=1' in out and 'module_blacklist=gma500_gfx' in out and '/boot/intel-ucode.img /boot/initrd.img-'+tag in out and 'single' not in out and p.read_text()==text
    env['REMESA_NATIVE_INIT']='systemd';assert 'systemd.mask=display-manager.service' in subprocess.check_output(cmd,env=env,text=True)
    p.write_text(text.split("menuentry 'antiX'",1)[0]);assert subprocess.run(cmd,capture_output=True).returncode!=0
print('DESKTOP_INSTALLER_HOST_PASS: shell syntax, JSON, XML, GRUB fixtures, stock source unchanged')
