#!/usr/bin/env bash
set -Eeuo pipefail
D=$(cd "$(dirname "$0")/.." && pwd)
[[ $EUID != 0 ]] || { echo 'Use ordinary account; only dependency installation requests sudo.'; exit 2; }
deps=0; mode=install
while (($#)); do case $1 in --deps) deps=1;; --check) mode=check;; --uninstall) mode=uninstall;; *) echo 'Usage: bash install.sh --nested-only [--deps|--check|--uninstall]'; exit 2;; esac; shift; done
DEST=$HOME/.local/share/remesa/desktop-nested; BIN=$HOME/.local/bin/remesa-desktop-nested
if [[ $mode == uninstall ]]; then
 [[ -f $DEST/.remesa-nested-profile && ! -L $DEST && ! -L $BIN && -f $BIN ]] || { echo 'No managed nested installation'; exit 2; }
 cmp -s "$BIN" "$DEST/installer/nested-launcher.sh" || { echo 'Launcher changed; inspect manually'; exit 2; }
 rm -- "$BIN"; rm -rf -- "$DEST"; echo 'Nested profile removed; distro packages and logs retained'; exit 0
fi
if [[ $deps == 1 && $mode == install ]]; then
 sudo apt-get install --no-install-recommends labwc waybar foot thunar fuzzel swaybg mako-notifier dbus python3 libsdl2-2.0-0 wdisplays pavucontrol libnotify-bin
fi
missing=0
for c in labwc waybar foot thunar fuzzel swaybg mako dbus-run-session setsid python3; do command -v "$c" >/dev/null || { echo "Missing $c"; missing=1; }; done
if ! python3 -c 'import ctypes; ctypes.CDLL("libSDL2-2.0.so.0")' 2>/dev/null; then echo 'Missing SDL2 runtime (3D demo)'; missing=1; fi
if [[ $mode == check ]]; then echo "NESTED_CHECK missing=$missing (no boot or DRM changes)"; exit "$missing"; fi
((missing==0)) || { echo 'Install dependencies or use --deps'; exit 2; }
[[ ! -e $DEST && ! -L $DEST && ! -e $BIN && ! -L $BIN ]] || { echo 'Nested installation exists; uninstall first'; exit 2; }
mkdir -p "$(dirname "$DEST")" "$(dirname "$BIN")"
T=$(mktemp -d "$(dirname "$DEST")/.stage.XXXXXXXX"); created=0; bin_created=0; done_install=0
cleanup(){ local rc=$?; trap - EXIT; rm -rf -- "$T"; if [[ $done_install == 0 ]]; then [[ $bin_created == 0 ]] || rm -f -- "$BIN"; [[ $created == 0 ]] || rm -rf -- "$DEST"; fi; exit "$rc"; }; trap cleanup EXIT
mkdir -p "$T/installer"; cp -a "$D/desktop" "$T/"; cp "$D/nested.sh" "$D/install.sh" "$T/"; cp "$D/installer/nested-launcher.sh" "$D/installer/install-nested.sh" "$T/installer/"; touch "$T/.remesa-nested-profile"
[[ -z $(find "$T" ! -type f ! -type d -print -quit) ]] || { echo 'Unexpected nonregular profile file'; exit 2; }
mv -T "$T" "$DEST"; created=1; install -m 755 "$DEST/installer/nested-launcher.sh" "$BIN"; bin_created=1; done_install=1
printf '%s\n' 'REMESA_NESTED_INSTALL_PASS (desktop profile only)' "Run: $BIN x11" 'No GRUB, kernel, render-node or system Mesa changes.'
