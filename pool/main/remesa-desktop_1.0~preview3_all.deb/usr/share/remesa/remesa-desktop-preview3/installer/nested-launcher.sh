#!/usr/bin/env bash
set -euo pipefail
D=$HOME/.local/share/remesa/desktop-nested
case ${1:-x11} in
 x11|wayland) exec bash "$D/nested.sh" "$@";;
 test3d) shift; exec python3 "$D/desktop/client/test3d.py" "$@";;
 *) echo 'Usage: remesa-desktop-nested [x11|wayland] [pixman|gles2] OR test3d [--seconds N]'; exit 2;;
esac
