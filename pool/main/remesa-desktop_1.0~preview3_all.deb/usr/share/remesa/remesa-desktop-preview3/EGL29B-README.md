# EGL29B — frontend sampler view cache repair

Mesa 25.2 state tracker associates texture cache entries with the stored `st` owner. reMESA's view->context is a destruction-only proxy; comparing it to st->pipe prevented cache hits, replacement, and context-specific release. The private SGX535-only Mesa runtime uses sv->st == st in all three paths. The actual view lifetime callbacks and strict lab tombstones remain unchanged. The 1024 view and 40 GPU slot limits are unchanged.

The physical EGL29 log counted 191 view creation failures, but did not supply their original errno. This fixes a demonstrated frontend cache defect, not a proven explanation for every ENOENT. No kernel or native rendering change. On failure the profiler now prints the original view errno and capacity marker. The qualification still fails closed. Full i386 build and physical test pending.

Run from existing ARM cross environment:
    REMESA_BUILD_JOBS=6 bash deploy-test.sh full
