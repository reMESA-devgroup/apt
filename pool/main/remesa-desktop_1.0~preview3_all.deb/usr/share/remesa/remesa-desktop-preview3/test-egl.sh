#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); P=${1:-$HOME/remesa-egl}; MODE=${2:-patched}
[[ $EUID == 0 ]] || { echo 'Run via sudo, with the existing experimental boot'; exit 2; }
[[ $(dpkg-query -W -f='${Status}' remesa-hre-cross) == 'install ok installed' ]] || exit 2
case "$MODE:$(dpkg-query -W -f='${Version}' remesa-hre-cross)" in
 quick:1.0~topology2.egl1) probe=probe-egl-preenumerate.py;;
 patched:1.0~topology2.egl13) probe=probe-egl-dmabuf-lab.py;;
 *) echo 'Expected EGL1 for quick mode or EGL13 for patched mode'; exit 2;;
esac
bash "$P/tools/activate-v116c2.sh"
R=/opt/remesa/12.3; L=$(mktemp /tmp/remesa-egl13.XXXXXX)
echo "Log: $L"
H=0; if [[ ${REMESA_TEST_HYBRID:-0} == 1 || ${REMESA_TEST_TILED:-0} == 1 ]]; then H=1; fi
env -u LD_PRELOAD -u GALLIUM_DRIVER -u LIBGL_ALWAYS_SOFTWARE -u MESA_GL_VERSION_OVERRIDE -u MESA_EXTENSION_OVERRIDE -u MESA_NO_ERROR -u MESA_GLSL_VERSION_OVERRIDE -u GBM_BACKENDS_PATH -u EGL_PLATFORM -u GBM_BACKEND \
 LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 EGL_LOG_LEVEL=debug \
 REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_HRE_GLES_LAB=1 MESA_GLES_VERSION_OVERRIDE=2.0 REMESA_HRE_EGL_DMABUF_LAB=1 REMESA_DRI_TRACE=1 \
 REMESA_HRE_COMPOSITOR_HYBRID="$H" REMESA_TEST_TILED="${REMESA_TEST_TILED:-0}" REMESA_TEST_HYBRID="${REMESA_TEST_HYBRID:-0}" REMESA_HRE_RECEIPTS=1 REMESA_HRE_UPLOAD_REBIND=1 REMESA_TEST_XRGB_RT="${REMESA_TEST_XRGB_RT:-0}" python3 "$D/$probe" 2>&1 | tee "$L"
grep -q '^EGL_DMABUF_LAB_PASS' "$L"
echo GBM_EGL_DMABUF_PHYSICAL_PASS

if [[ ${REMESA_TEST_HYBRID:-0} == 1 ]]; then
 grep -q '^HYBRID_PHYSICAL_DRAW1_PIXELS_PASS$' "$L"
 grep -q '^HYBRID_PHYSICAL_DRAW2_BLEND_PASS$' "$L"
 [[ $(grep -c '^HRE_COMPOSITOR_HYBRID_DRAW_OK ' "$L") == 2 ]]
 [[ $(grep -c '^HRE_NATIVE_RETIRED .*phase=9 ledger=0x7 retired=1$' "$L") == 2 ]]
 ! grep -q '^HRE_COMPOSITOR_HYBRID_REJECT ' "$L" || exit 1
 echo HYBRID_TWO_NATIVE_DRAWS_PHYSICAL_PASS
fi

if [[ ${REMESA_TEST_TILED:-0} == 1 ]]; then
 grep -q '^HYBRID_TILED_DESKTOP_PIXELS_PASS$' "$L"
 grep -q '^HYBRID_TILED_NPOT_TEXTURE_BLEND_PASS$' "$L"
 [[ $(grep -c '^HRE_COMPOSITOR_HYBRID_DRAW_OK ' "$L") == 2 ]]
 [[ $(grep -c '^HRE_NATIVE_RETIRED .*phase=9 ledger=0x7 retired=1$' "$L") == 30 ]]
 ! grep -q '^HRE_COMPOSITOR_HYBRID_REJECT ' "$L" || exit 1
 echo HYBRID_TILED_PHYSICAL_PASS
fi
