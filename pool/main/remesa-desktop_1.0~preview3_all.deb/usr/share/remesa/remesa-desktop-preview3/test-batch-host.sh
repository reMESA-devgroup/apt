#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
# Compile the actual production batch planner and hybrid_draw body, not a copy.
python3 - "$D" "$T" <<'PY'
from pathlib import Path
import sys
p,t=map(Path,sys.argv[1:]); s=next((p/'overlay').rglob('remesa_compositor_live.inc')).read_text(); s=s[s.index('#define RC_EGL18_MAX_RECTS'):]; a=s.index('/* EGL31_GPU2D_BEGIN */'); b=s.index('/* EGL31_GPU2D_END */')+len('/* EGL31_GPU2D_END */'); s=s[:a]+'''static int egl31_gpu2d(struct pipe_context *p,struct pipe_resource *input,const struct egl26_blit_plan *plan,const uint8_t *src,size_t stride,uint8_t *dst,size_t ds,unsigned w,unsigned h,bool rgba,bool opaque,bool dest_opaque,bool blend,uint8_t opacity,bool *used){unsigned x,y;(void)egl31_copy_coords(plan,input->width0,input->height0,w,h,&x,&y);*used=false;return 0;}\n'''+s[b:]; a=s.index('/* EGL30_EXTERNAL_BEGIN'); b=s.index('/* EGL30_EXTERNAL_END */')+len('/* EGL30_EXTERNAL_END */'); s=s[:a]+"""static int egl30_external_damage(struct pipe_screen *p,struct resource *b,bool publish,const struct egl30_damage *d,uint8_t *pixels,size_t stride,size_t bytes){
 uint8_t *ext=mock_external+((size_t)d->y0*b->base.width0+d->x0)*4;
 if(publish){direct_writes++;assert(egl30_damage_copy(d,ext,b->base.width0*4,pixels,stride,false)==bytes);}
 else {direct_reads++;assert(egl30_damage_copy(d,pixels,stride,ext,b->base.width0*4,b->shared_opaque)==bytes);}
 return 0;
}
"""+s[b:]; (t/'batch.inc').write_text(s); g=(p/'remesa_compositor_geometry.h').read_text(); g=g[g.index('struct rc_vertex'):g.index('/* Reference resolve')]; a=g.index('static inline int rc_window_vertex'); b=g.index('static inline float rc_edge_coord',a); (t/'geometry.inc').write_text(g[:a]+g[b:])
PY
cc -std=c11 -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-unused-parameter -O2 -I"$T" -I"$D" -I"$D/overlay/src/gallium/drivers/sgx535" "$D/test-batch.c" -lm -o "$T/test"
"$T/test"
