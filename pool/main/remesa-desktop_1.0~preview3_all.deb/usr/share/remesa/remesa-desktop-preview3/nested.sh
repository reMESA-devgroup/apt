#!/usr/bin/env bash
set -Eeuo pipefail
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID != 0 ]] || { echo 'Run nested mode as your ordinary desktop user, never root.' >&2; exit 2; }
backend=${1:-x11}; renderer=${2:-pixman}
[[ $# -le 2 && $backend =~ ^(x11|wayland)$ && $renderer =~ ^(pixman|gles2)$ ]] || { echo 'Usage: bash nested.sh [x11|wayland] [pixman|gles2]'; exit 2; }
for c in labwc waybar foot thunar fuzzel swaybg mako dbus-run-session setsid python3; do command -v "$c" >/dev/null || { echo "Missing $c; run bash install.sh --nested-only --deps" >&2; exit 2; }; done
if [[ $backend == x11 ]]; then [[ -n ${DISPLAY:-} ]] || { echo 'Start from an X11 graphical terminal (DISPLAY missing).'; exit 2; }; else [[ -n ${WAYLAND_DISPLAY:-} ]] || { echo 'Start from a Wayland graphical terminal.'; exit 2; }; fi
exec dbus-run-session -- bash "$D/desktop/tools/nested-session.sh" "$backend" "$renderer"
