#!/usr/bin/env python3
"""Isolated root-only EGL DMA-BUF lab: import, external update, FBO clear publication.
No display mode change. PASS is not GPU rasterization or Labwc evidence.
"""
import ctypes as C
import fcntl, glob, mmap, os, pathlib, struct, sys
from importlib.machinery import SourceFileLoader
base=SourceFileLoader('probe_egl_gbm',str(pathlib.Path(__file__).with_name('probe-egl-gbm.py'))).load_module()
P,I,U,S,PI=base.P,base.I,base.U,base.S,base.PI
TILED=os.environ.get("REMESA_TEST_TILED")=="1"
W,H=(1280,720) if TILED else (64,64)
XR=TILED or os.environ.get("REMESA_TEST_XRGB_RT")=="1"

def ioctl(fd,n,fmt,*args):
    data=bytearray(struct.pack(fmt,*args))
    request=(3<<30)|(len(data)<<16)|(ord('d')<<8)|n
    fcntl.ioctl(fd,request,data,True)
    return struct.unpack(fmt,data)

def sync(fd,flags):
    fcntl.ioctl(fd,0x40086200,struct.pack('=Q',flags))

def run():
    if os.geteuid()!=0: raise RuntimeError('Use test-egl-dmabuf-lab.sh')
    if not {'remesa_boot=native','remesa_boot=v116c2-hre','remesa_boot=prime-mmap'}.intersection(pathlib.Path('/proc/cmdline').read_text().split()): raise RuntimeError('Select experimental boot first')
    if os.environ.get('REMESA_HRE_EGL_DMABUF_LAB')!='1' or os.environ.get('MESA_GLES_VERSION_OVERRIDE')!='2.0': raise RuntimeError('Expected explicit experimental EGL mode')
    for key in ('LD_PRELOAD','GALLIUM_DRIVER','LIBGL_ALWAYS_SOFTWARE','MESA_GL_VERSION_OVERRIDE','MESA_EXTENSION_OVERRIDE','MESA_NO_ERROR'):
        if key in os.environ:raise RuntimeError('Refusing override '+key)
    cards=[p for p in glob.glob('/dev/dri/card*') if base.identity(p)]
    renders=[p for p in glob.glob('/dev/dri/renderD*') if base.identity(p)]
    if len(cards)!=1 or len(renders)!=1:raise RuntimeError('Expected one matched primary and render node')
    if pathlib.Path('/sys/class/drm',pathlib.Path(cards[0]).name,'device').resolve()!=pathlib.Path('/sys/class/drm',pathlib.Path(renders[0]).name,'device').resolve():raise RuntimeError('DRM device mismatch')
    primary=render=shared=-1;handle=0;dev=d=ctx=surface=image=None;tex=U();fbo=U();current=False;rb=U()
    e=g=gl=drm=None
    try:
        render=os.open(renders[0],os.O_RDWR|os.O_CLOEXEC|os.O_NOFOLLOW)
        print('LAB_RENDER_OPEN_OK',flush=True)
        primary=os.open(cards[0],os.O_RDWR|os.O_CLOEXEC|os.O_NOFOLLOW)
        height,width,bpp,flags,handle,pitch,size=ioctl(primary,0xb2,'=IIIIIIQ',H,W,32,0,0,0,0)
        if not handle or pitch<W*4 or size<(H-1)*pitch+W*4 or size>64*1024*1024:raise RuntimeError('Invalid dumb layout')
        drm=C.CDLL('libdrm.so.2',use_errno=True)
        prime=base.bind(drm,'drmPrimeHandleToFD',I,I,U,U,PI)
        fd=I(-1)
        if prime(primary,handle,os.O_CLOEXEC|os.O_RDWR,C.byref(fd))!=0:raise RuntimeError('PRIME export failed')
        shared=fd.value
        with mmap.mmap(shared,size,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE) as buf:
            sync(shared,2) # START WRITE
            try:
                buf[:]=b'\0'*size
                for y in range(H):buf[y*pitch:y*pitch+W*4]=bytes([29,83,197,0 if XR else 255])*W
            finally:sync(shared,6) # END WRITE
        print('PUBLIC_DMA_BUF_FILLED',pitch,size,flush=True)
        g=base.load('libgbm.so.1');e=base.egl_api();gl=base.load('libGLESv2.so.2')
        base.bind(g,'gbm_create_device',P,I);base.bind(g,'gbm_device_destroy',None,P)
        dev=g.gbm_create_device(render)
        if not dev:raise RuntimeError('GBM device failed')
        d=base.initialize(e,0x31d7,dev)
        ext=(e.eglQueryString(d,0x3055) or b'').split()
        if b'EGL_EXT_image_dma_buf_import' not in ext:raise RuntimeError('EGL_EXT_image_dma_buf_import missing')
        print('EGL_DMABUF_EXTENSION_PRESENT',flush=True)
        for n,t,a in [('eglBindAPI',U,[U]),('eglChooseConfig',U,[P,PI,C.POINTER(P),I,PI]),('eglCreateContext',P,[P,P,P,PI]),('eglDestroyContext',U,[P,P]),('eglCreatePbufferSurface',P,[P,P,PI]),('eglMakeCurrent',U,[P,P,P,P]),('eglGetProcAddress',P,[S])]:base.bind(e,n,t,*a)
        def attrs(*v):return (I*len(v))(*v)
        def proc(name,ret,*args):
            addr=e.eglGetProcAddress(name.encode())
            if not addr:raise RuntimeError('Missing '+name)
            return C.CFUNCTYPE(ret,*args)(addr)
        create=proc('eglCreateImageKHR',P,P,P,U,P,PI);destroy=proc('eglDestroyImageKHR',U,P,P)
        target=proc('glEGLImageTargetTexture2DOES',None,U,P)
        base.need(e,e.eglBindAPI(0x30a0),'BIND_ES')
        surfaceless=b'EGL_KHR_surfaceless_context' in ext
        cfg=P();count=I();config_attrs=attrs(0x3033,0 if surfaceless else 1,0x3040,4,0x3038)
        base.need(e,e.eglChooseConfig(d,config_attrs,C.byref(cfg),1,C.byref(count)),'CHOOSE_CONFIG')
        if not count.value:raise RuntimeError('No suitable GLES2 config')
        if not surfaceless:surface=base.need(e,e.eglCreatePbufferSurface(d,cfg,attrs(0x3057,1,0x3056,1,0x3038)),'PBUFFER')
        ctx=base.need(e,e.eglCreateContext(d,cfg,None,attrs(0x3098,2,0x3038)),'ES2_CONTEXT')
        base.need(e,e.eglMakeCurrent(d,surface,surface,ctx),'MAKE_CURRENT');current=True
        for n,t,a in [('glGetString',S,[U]),('glGetError',U,[]),('glGenTextures',None,[I,C.POINTER(U)]),('glBindTexture',None,[U,U]),('glDeleteTextures',None,[I,C.POINTER(U)]),('glGenFramebuffers',None,[I,C.POINTER(U)]),('glBindFramebuffer',None,[U,U]),('glDeleteFramebuffers',None,[I,C.POINTER(U)]),('glFramebufferTexture2D',None,[U,U,U,U,I]),('glCheckFramebufferStatus',U,[U]),('glReadPixels',None,[I,I,I,I,U,U,P])]:base.bind(gl,n,t,*a)
        renderer=(gl.glGetString(0x1f01) or b'').decode(errors='replace');print('GL_RENDERER',renderer,flush=True)
        if 'SGX535' not in renderer or 'reMESA' not in renderer:raise RuntimeError('Unexpected renderer')
        image=base.need(e,create(d,None,0x3270,None,attrs(0x3057,W,0x3056,H,0x3271,(0x34325258 if XR else 0x34325241),0x3272,shared,0x3273,0,0x3274,pitch,0x3038)),'EGL_DMA_BUF_IMAGE')
        print('EGL_DMA_BUF_IMAGE_CREATED',flush=True)
        gl.glGenTextures(1,C.byref(tex));gl.glBindTexture(0x0de1,tex);target(0x0de1,image)
        if gl.glGetError():raise RuntimeError('EGLImage texture bind failed')
        gl.glGenFramebuffers(1,C.byref(fbo));gl.glBindFramebuffer(0x8d40,fbo)
        if XR:
            for n,t,a in [('glGenRenderbuffers',None,[I,C.POINTER(U)]),('glBindRenderbuffer',None,[U,U]),('glFramebufferRenderbuffer',None,[U,U,U,U]),('glDeleteRenderbuffers',None,[I,C.POINTER(U)])]:base.bind(gl,n,t,*a)
            gl.glGenRenderbuffers(1,C.byref(rb));gl.glBindRenderbuffer(0x8d41,rb)
            proc('glEGLImageTargetRenderbufferStorageOES',None,U,P)(0x8d41,image)
            if gl.glGetError():raise RuntimeError('XR24 renderbuffer image bind failed')
            gl.glFramebufferRenderbuffer(0x8d40,0x8ce0,0x8d41,rb)
        else:gl.glFramebufferTexture2D(0x8d40,0x8ce0,0x0de1,tex,0)
        if gl.glCheckFramebufferStatus(0x8d40)!=0x8cd5:raise RuntimeError('Imported image is not FBO-readable')
        pixels=(C.c_ubyte*(W*H*4))();gl.glReadPixels(0,0,W,H,0x1908,0x1401,pixels)
        if gl.glGetError() or bytes(pixels)!=bytes([197,83,29,255])*(W*H):raise RuntimeError('Imported image pixel mismatch')
        print('EGL_DMABUF_PIXELS_PASS',flush=True)
        with mmap.mmap(shared,size,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE) as buf:
            sync(shared,2)
            try:
                for y in range(H):buf[y*pitch:y*pitch+W*4]=bytes([61,45,23,0 if XR else 255])*W
            finally:sync(shared,6)
        gl.glReadPixels(0,0,W,H,0x1908,0x1401,pixels)
        if gl.glGetError() or bytes(pixels)!=bytes([23,45,61,255])*(W*H):raise RuntimeError('External update not visible through EGLImage')
        print('EGL_DMABUF_EXTERNAL_UPDATE_PASS',flush=True)
        base.bind(gl,'glClearColor',None,C.c_float,C.c_float,C.c_float,C.c_float)
        base.bind(gl,'glClear',None,U);base.bind(gl,'glFinish',None)
        gl.glClearColor(1.0,0.0,0.0,0.25 if XR else 1.0);gl.glClear(0x4000);gl.glFinish()
        if gl.glGetError():raise RuntimeError('FBO clear failed')
        with mmap.mmap(shared,size,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ) as buf:
            sync(shared,1)
            try:
                for y in range(H):
                    if buf[y*pitch:y*pitch+W*4]!=bytes([0,0,255,255])*W:raise RuntimeError('Clear not published into original DMA-BUF')
            finally:sync(shared,5)
        if XR:print('EGL5_XRGB_RENDERBUFFER_PASS',flush=True)
        else:
            # Level-zero NPOT upload only; no sampling/mipmap claim.
            nt=U();gl.glGenTextures(1,C.byref(nt))
            try:
                gl.glBindTexture(0x0de1,nt)
                base.bind(gl,'glTexParameteri',None,U,U,I)
                base.bind(gl,'glTexImage2D',None,U,I,I,I,I,I,U,U,P)
                for key,value in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:gl.glTexParameteri(0x0de1,key,value)
                data=(C.c_ubyte*(250*250*4))()
                gl.glTexImage2D(0x0de1,0,0x1908,250,250,0,0x1908,0x1401,data)
                err=gl.glGetError()
                if err:raise RuntimeError('NPOT upload failed GL_ERROR='+hex(err))
                print('EGL5_NPOT_UPLOAD_GL_NO_ERROR',flush=True)
            finally:gl.glDeleteTextures(1,C.byref(nt))
        if os.environ.get('REMESA_TEST_HYBRID')=='1':
            if XR:raise RuntimeError('Hybrid exact pixel probe uses AR24')
            helper=SourceFileLoader('hybrid_probe',str(pathlib.Path(__file__).with_name('hybrid-probe.py'))).load_module()
            helper.run(gl,base,shared,size,pitch,sync,W,H)
        if TILED:
            helper=SourceFileLoader('tiled_probe',str(pathlib.Path(__file__).with_name('tiled-probe.py'))).load_module()
            helper.run(gl,base,shared,size,pitch,sync,W,H)
        print('EGL_DMABUF_LAB_PASS (import, update, clear; not GPU draw or compositor qualification)',flush=True)
    finally:
        if current:
            if fbo.value:gl.glDeleteFramebuffers(1,C.byref(fbo))
            if rb.value:gl.glDeleteRenderbuffers(1,C.byref(rb))
            if tex.value:gl.glDeleteTextures(1,C.byref(tex))
        if image:destroy(d,image)
        if current:e.eglMakeCurrent(d,None,None,None)
        if ctx:e.eglDestroyContext(d,ctx)
        if surface:e.eglDestroySurface(d,surface)
        if d:e.eglTerminate(d)
        if dev:g.gbm_device_destroy(dev)
        if shared>=0:os.close(shared)
        if handle:ioctl(primary,0xb4,'=I',handle)
        if primary>=0:os.close(primary)
        if render>=0:os.close(render)

if __name__=='__main__':
    try:run()
    except (RuntimeError,OSError,AttributeError) as exc:
        print('EGL_DMABUF_FAIL',exc,file=sys.stderr);sys.exit(1)
