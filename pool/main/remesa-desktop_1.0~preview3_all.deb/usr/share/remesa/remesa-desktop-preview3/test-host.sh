#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); M=$(realpath "$1"); B=$M/build-native-probe-v116; G=$B/generated; A=$M/src/gallium/drivers/sgx535
C=(-std=c11 -D_GNU_SOURCE -DHAVE_ENDIAN_H -DHAVE_SECURE_GETENV -DHAVE_PTHREAD -DHAVE_STRUCT_TIMESPEC -DREMESA_WITH_MESA_HEADERS -DREMESA_WITH_NIR -I"$D" -I"$A" -I"$A/include" -I"$M/include" -I"$M/src" -I"$M/src/gallium/include" -I"$M/src/gallium/auxiliary" -I"$M/src/compiler" -I"$M/src/compiler/nir" -I"$G/compiler/nir" -I"$G/compiler" -I"$G" -I"$M/include/drm-uapi" -O2 -g -ffunction-sections -fdata-sections)
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cc "${C[@]}" -Wl,--gc-sections "$D/test.c" "$B/lib.a" -lm -pthread -o "$T/test"
"$T/test"
