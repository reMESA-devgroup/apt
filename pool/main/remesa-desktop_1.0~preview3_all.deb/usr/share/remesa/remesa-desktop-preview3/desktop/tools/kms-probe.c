/* Public KMS only: no modeset, no PAGE_FLIP, no private HRE owner. */
#include "../allocator/allocator.c"
#include <inttypes.h>
#include <time.h>
static uint32_t canonical(uint32_t f){return f;}
static int open_card(const char *path){char id[PATH_MAX];int fd=open(path,O_RDWR|O_CLOEXEC|O_NOFOLLOW);if(fd<0)return -1;if(!identity(fd,id)){close(fd);errno=ENODEV;return -1;}return fd;}
static int crtcs(int fd,uint32_t ids[32],unsigned *n){struct drm_mode_card_res r={0};if(xio(fd,DRM_IOCTL_MODE_GETRESOURCES,&r))return -1;if(!r.count_crtcs||r.count_crtcs>32){errno=EOVERFLOW;return -1;}r.crtc_id_ptr=(uintptr_t)ids;*n=r.count_crtcs;r.count_fbs=0;r.count_connectors=0;r.count_encoders=0;if(xio(fd,DRM_IOCTL_MODE_GETRESOURCES,&r))return -1;if(r.count_crtcs>*n){errno=EAGAIN;return -1;}*n=r.count_crtcs;return 0;}
static int preflight(int fd){
 struct gbm_core c={.v0={.core_version=1,.format_canonicalize=canonical}};GBM_GET_BACKEND_PROC(&c);
 struct drm_get_cap cap={.capability=DRM_CAP_PRIME};if(xio(fd,DRM_IOCTL_GET_CAP,&cap))return -1;
 if((cap.value&(DRM_PRIME_CAP_IMPORT|DRM_PRIME_CAP_EXPORT))!=(DRM_PRIME_CAP_IMPORT|DRM_PRIME_CAP_EXPORT)){errno=ENOTSUP;return -1;}
 printf("EGL15_PRIME_CAPS value=%" PRIu64 "\n",(uint64_t)cap.value);
 cap.capability=DRM_CAP_ADDFB2_MODIFIERS;if(xio(fd,DRM_IOCTL_GET_CAP,&cap))return -1;
 printf("EGL15_ADDFB2_MODIFIERS value=%" PRIu64 "\n",(uint64_t)cap.value);
 uint32_t ids[32];unsigned n;if(crtcs(fd,ids,&n))return -1;
 for(unsigned i=0;i<n;i++){struct drm_mode_crtc q={.crtc_id=ids[i]};if(xio(fd,DRM_IOCTL_MODE_GETCRTC,&q))return -1;printf("EGL15_INITIAL_CRTC id=%u fb=%u active=%u size=%ux%u\n",q.crtc_id,q.fb_id,q.mode_valid,q.mode.hdisplay,q.mode.vdisplay);}
 struct gbm_device *dev=create_device(fd,1);if(!dev)return -1;
 const uint32_t formats[]={DRM_FORMAT_XRGB8888,DRM_FORMAT_ARGB8888};uint64_t m=DRM_FORMAT_MOD_INVALID;int rc=0;
 for(unsigned i=0;i<2;i++){
  struct gbm_bo *bo=create_bo(dev,64,64,formats[i],GBM_BO_USE_SCANOUT|GBM_BO_USE_RENDERING,&m,1);if(!bo){rc=-1;break;}
  struct drm_mode_fb_cmd2 fb={.width=64,.height=64,.pixel_format=formats[i],.handles={bo->v0.handle.u32},.pitches={bo->v0.stride}};
  if(xio(fd,DRM_IOCTL_MODE_ADDFB2,&fb)){perror("EGL15_ADDFB2");rc=-1;}else{
   printf("EGL15_ADDFB2_PASS format=%08x fb=%u pitch=%u (not displayed)\n",formats[i],fb.fb_id,bo->v0.stride);
   if(xio(fd,DRM_IOCTL_MODE_RMFB,&fb.fb_id)){perror("EGL15_RMFB");rc=-1;}
  }
  destroy_bo(bo);if(rc)break;
 }
 destroy_device(dev);return rc;
}
static int watch(int fd){uint32_t ids[32],last[32]={0};unsigned n;bool seen[32]={0};if(crtcs(fd,ids,&n))return -1;
 for(;;){for(unsigned i=0;i<n;i++){struct drm_mode_crtc q={.crtc_id=ids[i]};if(xio(fd,DRM_IOCTL_MODE_GETCRTC,&q))return -1;
  uint32_t now=q.mode_valid?q.fb_id:0;if(!seen[i]||now!=last[i]){printf("EGL15_KMS_STATE crtc=%u fb=%u active=%u size=%ux%u\n",ids[i],now,q.mode_valid,q.mode.hdisplay,q.mode.vdisplay);
   if(seen[i]&&now&&last[i]&&now!=last[i])printf("EGL15_KMS_FB_CHANGE crtc=%u from=%u to=%u\n",ids[i],last[i],now);
   last[i]=now;seen[i]=true;}}
  struct timespec t={.tv_nsec=100000000};nanosleep(&t,NULL);
 }
}
int main(int argc,char **argv){setvbuf(stdout,NULL,_IOLBF,0);if(argc!=3||geteuid()!=0||!boot_ok())return 2;int fd=open_card(argv[2]);if(fd<0){perror("EGL15_CARD");return 1;}int r;if(!strcmp(argv[1],"preflight"))r=preflight(fd);else if(!strcmp(argv[1],"watch"))r=watch(fd);else r=-1;if(r)perror("EGL15_KMS_PROBE");close(fd);return r?1:0;}
