#!/bin/bash
set -euo pipefail
[[ $EUID != 0 ]] || exit 2
stage=${1:?}; pids=(); names=()
cleanup(){ for p in "${pids[@]}"; do kill -TERM "$p" 2>/dev/null || :; done; for p in "${pids[@]}"; do wait "$p" 2>/dev/null || :; done; }
trap cleanup EXIT
trap 'exit 143' TERM INT
start(){ local name=$1; shift; "$@" & local p=$!; pids+=("$p"); names+=("$name"); echo "EGL19_CLIENT_START name=$name pid=$p uid=$EUID"; sleep 3; kill -0 "$p" 2>/dev/null || { echo "EGL19_CLIENT_EXIT name=$name"; exit 1; }; }
# These clients use the distribution libraries, not the private HRE loader.
# The compositor alone owns the experimental GPU context.
if [[ $stage != foot ]]; then
 # Optional services run as the ordinary client account, never as root.
 if command -v swaybg >/dev/null; then swaybg -i "$XDG_RUNTIME_DIR/assets/wallpaper.jpg" -m fill & pids+=("$!"); names+=(wallpaper); fi
 if command -v mako >/dev/null; then mako & pids+=("$!"); names+=(notifications); fi
 if [[ -x /usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1 ]]; then /usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1 & pids+=("$!"); names+=(polkit); fi
fi
start foot foot
if [[ $stage != foot ]]; then
 start waybar waybar -c "$XDG_CONFIG_HOME/waybar/config" -s "$XDG_CONFIG_HOME/waybar/style.css"
fi
if [[ $stage == desktop ]]; then
 start thunar thunar "$HOME"
 # Optional wallpaper and notifications can be launched from Foot after the core test.
fi
echo "EGL19_CLIENTS_READY stage=$stage uid=$EUID"
while :; do
 for i in "${!pids[@]}"; do
  # Closing the terminal or file manager manually is normal once ready.
  if [[ ${names[i]} == waybar ]] && ! kill -0 "${pids[i]}" 2>/dev/null; then echo EGL19_PANEL_EXITED; exit 1; fi
 done
 sleep 1
done
