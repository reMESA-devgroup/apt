#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID != 0 ]] || exit 2
D=$(cd "$(dirname "$0")/.." && pwd)
backend=${1:?}; renderer=${2:?}
[[ $backend =~ ^(x11|wayland)$ && $renderer =~ ^(pixman|gles2)$ ]] || exit 2
oldrt=${XDG_RUNTIME_DIR:-}; parent=${WAYLAND_DISPLAY:-}; olddata=${XDG_DATA_HOME:-$HOME/.local/share}
if [[ $backend == wayland ]]; then
 [[ -n $parent ]] || exit 2
 if [[ $parent != /* ]]; then [[ -n $oldrt ]] || { echo 'Missing parent XDG_RUNTIME_DIR'; exit 2; }; parent=$oldrt/$parent; fi
 [[ -S $parent ]] || { echo "Parent Wayland socket missing: $parent"; exit 2; }
fi
# No private driver overrides, privileged gates, DRM backend or global configuration.
for v in ${!REMESA_@} ${!WLR_@}; do unset "$v"; done
unset LD_PRELOAD LD_LIBRARY_PATH LIBGL_DRIVERS_PATH MESA_LOADER_DRIVER_OVERRIDE MESA_GLES_VERSION_OVERRIDE MESA_GL_VERSION_OVERRIDE MESA_GLSL_VERSION_OVERRIDE MESA_EXTENSION_OVERRIDE MESA_NO_ERROR GALLIUM_DRIVER LIBGL_ALWAYS_SOFTWARE GBM_BACKEND GBM_BACKENDS_PATH EGL_PLATFORM LIBSEAT_BACKEND
umask 077
RT=$(mktemp -d "${TMPDIR:-/tmp}/remesa-nested.XXXXXXXX")
LBASE=${XDG_STATE_HOME:-$HOME/.local/state}/remesa; mkdir -p "$LBASE"; L=$(mktemp "$LBASE/nested.XXXXXXXX.log")
comp=; client=
cleanup(){ local rc=$?; trap - EXIT; if [[ -n $client ]]; then kill -TERM -- "-$client" 2>/dev/null || :; wait "$client" 2>/dev/null || :; fi; if [[ -n $comp ]]; then kill -TERM "$comp" 2>/dev/null || :; wait "$comp" 2>/dev/null || :; fi; rm -rf -- "$RT"; echo "NESTED_EXIT=$rc LOG=$L"; exit "$rc"; }
trap cleanup EXIT; trap 'exit 130' INT; trap 'exit 143' TERM HUP
mkdir -p "$RT/config/waybar" "$RT/config/fuzzel" "$RT/config/mako" "$RT/data/themes/reMESA/openbox-3" "$RT/assets" "$RT/labwc"
cp "$D/config/"* "$RT/labwc/"
cp "$D/client/waybar.json" "$RT/config/waybar/config"; cp "$D/client/style.css" "$RT/config/waybar/style.css"
cp "$D/client/fuzzel.ini" "$RT/config/fuzzel/fuzzel.ini"; cp "$D/client/mako.conf" "$RT/config/mako/config"
cp "$D/client/wallpaper.jpg" "$D/client/settings.sh" "$D/client/test3d.py" "$RT/assets/"
cp "$D/client/theme/openbox-3/themerc" "$RT/data/themes/reMESA/openbox-3/themerc"
# Keep host app menu and audio paths without modifying host configs.
export XDG_DATA_DIRS="$olddata:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
if [[ -n $oldrt ]]; then
 [[ ! -S $oldrt/pulse/native || -n ${PULSE_SERVER:-} ]] || export PULSE_SERVER="unix:$oldrt/pulse/native"
 [[ ! -S $oldrt/pipewire-0 || -n ${PIPEWIRE_RUNTIME_DIR:-} ]] || export PIPEWIRE_RUNTIME_DIR="$oldrt"
fi
export XDG_RUNTIME_DIR="$RT" XDG_CONFIG_HOME="$RT/config" XDG_DATA_HOME="$RT/data" XDG_SESSION_TYPE=wayland
export WLR_BACKENDS="$backend" WLR_RENDERER="$renderer" WLR_X11_OUTPUTS=1 WLR_WL_OUTPUTS=1
if [[ $renderer == gles2 ]]; then export WLR_RENDERER_ALLOW_SOFTWARE=1; fi
if [[ $backend == x11 ]]; then unset WAYLAND_DISPLAY; else export WAYLAND_DISPLAY="$parent"; unset DISPLAY; fi
printf 'NESTED_START backend=%s renderer=%s (host stack; not SGX535 evidence) LOG=%s\n' "$backend" "$renderer" "$L"
labwc -C "$RT/labwc" >>"$L" 2>&1 & comp=$!
socket=
for ((i=0;i<120;i++)); do
 kill -0 "$comp" 2>/dev/null || { tail -30 "$L" >&2; exit 1; }
 for f in "$RT"/wayland-*; do [[ -S $f ]] && { socket=$f; break; }; done
 [[ -z $socket ]] || break; sleep .25
done
[[ -n $socket ]] || { echo 'Nested Wayland socket timeout'; tail -30 "$L"; exit 1; }
# Clients must not accidentally connect to the parent X server.
unset DISPLAY; export WAYLAND_DISPLAY="$socket" GDK_BACKEND=wayland QT_QPA_PLATFORM=wayland SDL_VIDEODRIVER=wayland
unset WLR_BACKENDS WLR_RENDERER WLR_X11_OUTPUTS WLR_WL_OUTPUTS WLR_RENDERER_ALLOW_SOFTWARE
setsid --wait bash "$D/client/session.sh" desktop >>"$L" 2>&1 & client=$!
echo "NESTED_SOCKET_READY $socket (Super+Esc to exit; 3D button tests host GLES2)"
while kill -0 "$comp" 2>/dev/null; do
 kill -0 "$client" 2>/dev/null || { echo 'Nested client session exited'; tail -30 "$L"; exit 1; }; sleep .5
done
rc=0; wait "$comp" || rc=$?; comp=; exit "$rc"
