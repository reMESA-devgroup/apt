#!/usr/bin/env python3
"""SDL2 GLES2 window; shader/texture/depth pixel oracle, then animated 3D cube."""
import argparse, ctypes as C, ctypes.util, math, sys, time
p=argparse.ArgumentParser(); p.add_argument('--seconds',type=float,default=15); p.add_argument('--oracle-only',action='store_true'); a=p.parse_args()
if not math.isfinite(a.seconds) or not 1<=a.seconds<=120: p.error('seconds must be 1..120')
I=C.c_int; U=C.c_uint; F=C.c_float; P=C.c_void_p; S=C.c_char_p
s=C.CDLL(ctypes.util.find_library('SDL2-2.0') or 'libSDL2-2.0.so.0')
def bind(obj,n,r,*args):
 f=getattr(obj,n); f.restype=r; f.argtypes=args; return f
init=bind(s,'SDL_Init',I,U); error=bind(s,'SDL_GetError',S); attr=bind(s,'SDL_GL_SetAttribute',I,I,I); window=bind(s,'SDL_CreateWindow',P,S,I,I,I,I,U); context=bind(s,'SDL_GL_CreateContext',P,P); proc=bind(s,'SDL_GL_GetProcAddress',P,S); swap=bind(s,'SDL_GL_SwapWindow',None,P); interval=bind(s,'SDL_GL_SetSwapInterval',I,I); poll=bind(s,'SDL_PollEvent',I,P); size=bind(s,'SDL_GL_GetDrawableSize',None,P,C.POINTER(I),C.POINTER(I)); delete=bind(s,'SDL_GL_DeleteContext',None,P); destroy=bind(s,'SDL_DestroyWindow',None,P); quit_s=bind(s,'SDL_Quit',None)
def check(v,msg):
 if not v: raise RuntimeError(msg+': '+error().decode(errors='replace'))
def gl(n,r,*args):
 q=proc(n.encode()); check(q,n); return C.CFUNCTYPE(r,*args)(q)
def run(w):
 get=gl('glGetString',S,U); renderer=(get(0x1f01) or b'unknown').decode(); version=(get(0x1f02) or b'unknown').decode(); print('GLES_VENDOR',get(0x1f00), 'GLES_RENDERER',renderer,'GLES_VERSION',version,flush=True)
 if 'OpenGL ES' not in version: raise RuntimeError('Not an OpenGL ES context')
 print('RENDERER_CLASS', 'software' if any(x in renderer.lower() for x in ('llvmpipe','softpipe','swrast','software','swiftshader')) else 'unverified-host-renderer',flush=True)
 create=gl('glCreateShader',U,U); source=gl('glShaderSource',None,U,I,C.POINTER(S),P); compile_=gl('glCompileShader',None,U); shaderiv=gl('glGetShaderiv',None,U,U,C.POINTER(I)); shaderlog=gl('glGetShaderInfoLog',None,U,I,P,P)
 def shader(kind,txt):
  sh=create(kind); src=S(txt); source(sh,1,C.byref(src),None); compile_(sh); ok=I(); shaderiv(sh,0x8b81,C.byref(ok))
  if not ok.value:
   log=C.create_string_buffer(4096); shaderlog(sh,4096,None,log); raise RuntimeError(log.value.decode(errors='replace'))
  return sh
 vs=shader(0x8b31,b'attribute vec3 pos; attribute vec2 uv; uniform mat4 m; varying vec2 v; void main(){gl_Position=m*vec4(pos,1.0);v=uv;}')
 fs=shader(0x8b30,b'precision mediump float; varying vec2 v; uniform sampler2D tex; uniform vec4 tint; void main(){gl_FragColor=texture2D(tex,v)*tint;}')
 program=gl('glCreateProgram',U)(); attach=gl('glAttachShader',None,U,U); attach(program,vs); attach(program,fs); gl('glLinkProgram',None,U)(program); ok=I(); gl('glGetProgramiv',None,U,U,C.POINTER(I))(program,0x8b82,C.byref(ok));
 if not ok.value: raise RuntimeError('GLES link failed')
 gl('glUseProgram',None,U)(program); loc=gl('glGetAttribLocation',I,U,S); uni=gl('glGetUniformLocation',I,U,S); pos=loc(program,b'pos'); uv=loc(program,b'uv'); mat=uni(program,b'm'); tint=uni(program,b'tint'); tex=uni(program,b'tex'); assert min(pos,uv,mat,tint,tex)>=0
 gen=gl('glGenTextures',None,I,C.POINTER(U)); t=U(); gen(1,C.byref(t)); gl('glBindTexture',None,U,U)(0x0de1,t); param=gl('glTexParameteri',None,U,U,I)
 for k,v in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:param(0x0de1,k,v)
 # Texture has two clearly different texels, so oracle tests actual sampling.
 pixels=(C.c_ubyte*8)(255,255,255,255,0,0,255,255); gl('glTexImage2D',None,U,I,I,I,I,I,U,U,P)(0x0de1,0,0x1908,2,1,0,0x1908,0x1401,pixels); gl('glUniform1i',None,I,I)(tex,0)
 matrix=gl('glUniformMatrix4fv',None,I,I,C.c_ubyte,C.POINTER(F)); color=gl('glUniform4f',None,I,F,F,F,F); pointer=gl('glVertexAttribPointer',None,U,I,U,C.c_ubyte,I,P); enable=gl('glEnableVertexAttribArray',None,U); enable(pos); enable(uv)
 draw=gl('glDrawArrays',None,U,I,I); clear=gl('glClear',None,U); gl('glClearColor',None,F,F,F,F)(0.03,0.03,0.05,1); gl('glEnable',None,U)(0x0b71); gl('glDepthFunc',None,U)(0x0201); viewport=gl('glViewport',None,I,I,I,I); read=gl('glReadPixels',None,I,I,I,I,U,U,P); err=gl('glGetError',U)
 def dimensions():
  x=I();y=I();size(w,C.byref(x),C.byref(y)); return x.value,y.value
 def mesh(vertices):
  data=(F*len(vertices))(*vertices); pointer(pos,3,0x1406,0,20,C.cast(data,P)); pointer(uv,2,0x1406,0,20,C.c_void_p(C.addressof(data)+12)); draw(4,0,len(vertices)//5)
 def transform(values): matrix(mat,1,0,(F*16)(*values))
 def tri(z,u): return [-.8,-.8,z,u,.5,.8,-.8,z,u,.5,0,.8,z,u,.5]
 ww,hh=dimensions(); check(ww>0 and hh>0,'drawable'); viewport(0,0,ww,hh); clear(0x4100); transform([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]); color(tint,1,0,0,1); mesh(tri(-.5,.25)); color(tint,1,1,1,1); mesh(tri(.5,.75)); out=(C.c_ubyte*4)(); read(ww//2,hh//2,1,1,0x1908,0x1401,out)
 if not(out[0]>200 and out[1]<30 and out[2]<30): raise RuntimeError('Depth/near pixel mismatch '+str(list(out)))
 clear(0x4100); mesh(tri(0,.75)); read(ww//2,hh//2,1,1,0x1908,0x1401,out)
 if not(out[2]>200 and out[0]<30 and out[1]<30) or err(): raise RuntimeError('Texture pixel oracle failed '+str(list(out)))
 print('GLES2_PIXEL_ORACLE_PASS shader texture depth (not physical GPU proof)',flush=True); swap(w)
 if a.oracle_only:return
 # Six cube faces, each two triangles. Perspective and depth are exercised.
 faces=[((-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)),((1,-1,-1),(-1,-1,-1),(-1,1,-1),(1,1,-1)),((-1,-1,-1),(-1,-1,1),(-1,1,1),(-1,1,-1)),((1,-1,1),(1,-1,-1),(1,1,-1),(1,1,1)),((-1,1,1),(1,1,1),(1,1,-1),(-1,1,-1)),((-1,-1,-1),(1,-1,-1),(1,-1,1),(-1,-1,1))]
 meshes=[]
 for face in faces:
  verts=[]
  for j in (0,1,2,0,2,3):verts.extend((*face[j],*((.1,.1),(.9,.1),(.9,.9),(.1,.9))[j]))
  meshes.append(verts)
 def mul(x,y):return [sum(x[k*4+r]*y[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]
 interval(1); start=time.monotonic(); frames=0; ev=(U*32)(); running=True
 while running and time.monotonic()-start<a.seconds:
  while poll(ev):
   if ev[0] in (0x100,0x300) or (ev[0]==0x200 and bytes(ev)[12]==14):running=False
  if not running:break
  ww,hh=dimensions()
  if not ww or not hh:time.sleep(.02);continue
  viewport(0,0,ww,hh); clear(0x4100); t0=time.monotonic()-start; c=math.cos(t0); z=math.sin(t0); b=math.cos(t0*.7); d=math.sin(t0*.7)
  ry=[c,0,-z,0,0,1,0,0,z,0,c,0,0,0,0,1]; rx=[1,0,0,0,0,b,d,0,0,-d,b,0,0,0,-4.5,1]; proj=[1.6*hh/ww,0,0,0,0,1.6,0,0,0,0,-1.02,-1,0,0,-.202,0]; transform(mul(proj,mul(rx,ry)))
  for verts,rgba in zip(meshes,[(1,.3,.3,1),(.3,1,.3,1),(.3,.7,1,1),(1,.8,.3,1),(.9,.3,1,1),(.3,1,1,1)]): color(tint,*rgba);mesh(verts)
  if err():raise RuntimeError('GLES error during cube')
  swap(w); frames+=1
  # Bound CPU consumption on hosts that ignore vsync.
  time.sleep(.001)
 elapsed=time.monotonic()-start; print(f'GLES2_CUBE frames={frames} elapsed={elapsed:.2f}s swap_rate={frames/max(elapsed,.001):.2f} (not display FPS)',flush=True)
 if not frames: raise RuntimeError('No cube frames')
if __name__=='__main__':
 w=ctx=None
 try:
  check(init(0x20)==0,'SDL_Init');
  for k,v in [(17,2),(18,0),(21,4),(6,16),(5,1)]:check(attr(k,v)==0,'SDL_GL_SetAttribute')
  w=window(b'reMESA GLES2 - pixel oracle and cube',0x2fff0000,0x2fff0000,320,240,0x2|0x4|0x20);check(w,'SDL_CreateWindow');ctx=context(w);check(ctx,'SDL_GL_CreateContext');run(w)
 except Exception as e: print('GLES2_TEST_FAIL',e,file=sys.stderr);sys.exit(1)
 finally:
  if ctx:delete(ctx)
  if w:destroy(w)
  quit_s()
