#!/bin/bash
# EGL19: desktop qualification using unmodified EGL18 Mesa and EGL14 kernel.
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID == 0 ]] || { echo 'Run sudo bash run.sh on the EGL14 experimental boot'; exit 2; }
stage=desktop; seconds=60; preflight=0; reuse=4; verbose=0; compact=0; hwcursor=1; graph=0; wide=0; solid=0; affine=0; blit=0; direct=0; nativecache=0; scanout=0; hostrt=0; cloudtail=0; liveviews=1; native3d=0; directclose=0; adaptive=0; sparse=0; gpu2d=0; release=0; interactive=0
while (($#)); do
 case $1 in
  --release) release=1; shift;;
  --session) interactive=1; shift;;
  --debug) release=0; shift;;
  --stage) stage=${2:?}; shift 2;;
  --seconds) seconds=${2:?}; shift 2;;
  --preflight) preflight=1; shift;;
  --reuse-two) reuse=2; shift;;
  --serial) reuse=1; shift;;
  --reuse-four) reuse=4; shift;;
  --reuse-eight) reuse=8; shift;;
  --compact) compact=1; shift;;
  --hardware-cursor) hwcursor=1; shift;;
  --software-cursor) hwcursor=0; shift;;
  --blit) blit=1; shift;;
  --direct-region) direct=1; shift;;
  --native-cache) nativecache=1; shift;;
  --direct-scanout) scanout=1; shift;;
  --host-rt) hostrt=1; shift;;
  --strict-views) liveviews=0; shift;;
  --native3d) native3d=1; cloudtail=1; adaptive=1; hostrt=1; affine=1; graph=1; wide=1; solid=1; reuse=8; blit=0; direct=1; nativecache=1; shift;;
  --direct-close) directclose=1; shift;;
  --adaptive) adaptive=1; shift;;
  --gpu-mixed) gpu2d=1; sparse=1; cloudtail=1; hostrt=1; affine=1; graph=1; wide=1; solid=1; reuse=8; blit=1; direct=1; nativecache=1; adaptive=1; shift;;
  --window-turbo) sparse=1; cloudtail=1; hostrt=1; affine=1; graph=1; wide=1; solid=1; reuse=8; blit=1; direct=1; nativecache=1; shift;;
  --cloudtail) cloudtail=1; hostrt=1; affine=1; graph=1; wide=1; solid=1; reuse=8; blit=1; direct=1; nativecache=1; shift;;
  --cloud15) hostrt=1; affine=1; graph=1; wide=1; solid=1; reuse=8; blit=1; direct=1; nativecache=1; shift;;
  --cloud) affine=1; graph=1; wide=1; solid=1; reuse=8; blit=1; direct=1; nativecache=1; shift;;
  --affine) affine=1; shift;;
  --god-mode) affine=1; graph=1; wide=1; solid=1; reuse=8; shift;;
  --graph-reuse) graph=1; shift;;
  --legacy-drop) graph=0; shift;;
  --wide) wide=1; shift;;
  --solid-fast) solid=1; shift;;
  --verbose-alloc) verbose=1; shift;;
  *) echo 'Usage: sudo bash run.sh [--release|--debug] [--session] [--stage foot|panel|desktop] [--seconds 30..1800] [--preflight] [--serial|--reuse-two|--reuse-four|--reuse-eight] [--compact] [--hardware-cursor|--software-cursor] [--graph-reuse|--legacy-drop] [--wide] [--solid-fast] [--affine|--god-mode|--cloud] [--cloud15|--cloudtail|--window-turbo|--gpu-mixed] [--host-rt] [--blit] [--direct-region] [--native-cache] [--direct-scanout] [--verbose-alloc] [--native3d] [--direct-close] [--adaptive] [--strict-views]'; exit 2;;
 esac
done
[[ $stage =~ ^(foot|panel|desktop)$ && $seconds =~ ^[0-9]{1,4}$ ]] && ((10#$seconds >= 30 && 10#$seconds <= 1800)) || exit 2
seconds=$((10#$seconds))
if [[ $interactive == 1 ]]; then seconds=0; [[ $stage == desktop && $preflight == 0 ]] || exit 2; fi
[[ $(dpkg-query -W -f='${Version}' remesa-hre-cross) == '1.0~topology2.egl34' ]] || { echo 'Expected EGL34 runtime'; exit 2; }
U=${SUDO_USER:-}; [[ -n $U && $U != root && $(id -u "$U") != 0 ]] || { echo 'Invoke using sudo from normal user'; exit 2; }
UH=$(getent passwd "$U" | cut -d: -f6); [[ -d $UH ]] || exit 2
R=/opt/remesa/12.3
for f in "$R/lib/libEGL.so.1" "$R/lib/libgbm.so.1"; do [[ -e $f ]] || { echo "Missing $f"; exit 2; }; done
for cmd in cc labwc dbus-run-session timeout runuser setfacl setsid foot ps getent python3; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 2; }; done
if [[ $stage != foot ]]; then for cmd in waybar fuzzel; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 2; }; done; fi
if [[ $stage == desktop ]]; then command -v thunar >/dev/null || { echo "Missing thunar"; exit 2; }; fi
# Never choose a different GPU or module.
cards=(); for d in /sys/class/drm/card[0-9]*; do
 [[ ${d##*/} =~ ^card[0-9]+$ && -r $d/device/vendor && -r $d/device/device ]] || continue
 [[ $(cat "$d/device/vendor") == 0x8086 && $(cat "$d/device/device") == 0x8108 && $(basename "$(readlink -f "$d/device/driver/module")") == remesa_gma500gfx && -c /dev/dri/${d##*/} ]] && cards+=("/dev/dri/${d##*/}")
done
[[ ${#cards[@]} == 1 ]] || { echo 'Expected exactly one reMESA primary DRM node'; exit 2; }
CARD=${cards[0]}
# Capture the six lab gates before activation; restore only after a normal
# process exit, never turn them off while Labwc is still running.
P=/sys/module/remesa_gma500gfx/parameters
GATES=(memory hre_dynamic matrix_submit texture_graph texture_qualify twod_copy)
old=(); for gate in "${GATES[@]}"; do old+=("$(cat "$P/remesa_${gate}_enabled")"); done
B=''; RT=''; UR=''; activated=0
cleanup(){
 if [[ $activated == 1 ]] && pgrep -x 'labwc|Xwayland' >/dev/null; then
  echo "EGL19_CLEANUP_DEFERRED: compositor still alive; retain gates and runtime directories" >&2; return
 fi
 if [[ $activated == 1 ]] && ! pgrep -x 'labwc|Xwayland' >/dev/null; then
  for i in "${!GATES[@]}"; do printf '%s\n' "${old[i]}" > "$P/remesa_${GATES[i]}_enabled" || :; done
 fi
 [[ -z $B ]] || rm -rf -- "$B"
 [[ -z $RT ]] || rm -rf -- "$RT"
 [[ -z $UR ]] || rm -rf -- "$UR"
}
trap cleanup EXIT
bash "$D/tools/activate.sh"
activated=1
B=$(mktemp -d /tmp/remesa-egl15-bin.XXXXXX); RT=$(mktemp -d /run/remesa-egl15.XXXXXX)
chmod 700 "$RT"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 -fPIC -shared -fvisibility=hidden "$D/allocator/allocator.c" -o "$B/remesa_alloc_gbm.so"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/tools/kms-probe.c" -o "$B/kms-probe"
for v in ${!REMESA_@}; do unset "$v"; done
unset LD_PRELOAD GALLIUM_DRIVER LIBGL_ALWAYS_SOFTWARE MESA_GL_VERSION_OVERRIDE MESA_GLSL_VERSION_OVERRIDE MESA_EXTENSION_OVERRIDE MESA_NO_ERROR GBM_BACKENDS_PATH GBM_BACKEND EGL_PLATFORM DISPLAY WAYLAND_DISPLAY WLR_DRM_DEVICES WLR_RENDERER_ALLOW_SOFTWARE WLR_HEADLESS_OUTPUTS WLR_RENDERER WLR_BACKENDS LIBSEAT_BACKEND
export REMESA_GBM_ALLOCATOR_ONLY=1 REMESA_GBM_NATIVE_SCANOUT=1
PL=$(mktemp /tmp/remesa-egl15-preflight.XXXXXX)
echo "EGL15 preflight: $PL"
"$B/kms-probe" preflight "$CARD" 2>&1 | tee "$PL"
[[ $(grep -c '^EGL15_ADDFB2_PASS ' "$PL" || :) == 2 ]] || exit 1
echo EGL15_PUBLIC_SCANOUT_BUFFER_PREFLIGHT_PASS
[[ $preflight == 0 ]] || exit 0
UR=$(mktemp -d /run/remesa-egl19-client.XXXXXX)
mkdir -p "$UR/config/waybar" "$UR/config/fuzzel"
cp "$D/client/waybar.json" "$UR/config/waybar/config"
cp "$D/client/style.css" "$UR/config/waybar/style.css"
cp "$D/client/fuzzel.ini" "$UR/config/fuzzel/fuzzel.ini"
cp "$D/client/session.sh" "$UR/client.sh"
mkdir -p "$UR/config/mako" "$UR/assets" "$RT/data/themes/reMESA/openbox-3"
cp "$D/client/mako.conf" "$UR/config/mako/config"
cp "$D/client/wallpaper.jpg" "$D/client/settings.sh" "$D/client/test3d.py" "$UR/assets/"
cp "$D/client/theme/openbox-3/themerc" "$RT/data/themes/reMESA/openbox-3/themerc"
export XDG_DATA_HOME="$RT/data"
chown -R "$U:$(id -gn "$U")" "$UR"
chmod 700 "$UR"
export XDG_RUNTIME_DIR="$RT" XDG_CONFIG_HOME="$RT/config" XDG_CONFIG_DIRS="$RT/config" XDG_SESSION_TYPE=wayland
mkdir -p "$XDG_CONFIG_HOME"
export LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 EGL_LOG_LEVEL=debug
export GBM_BACKEND=remesa_alloc GBM_BACKENDS_PATH="$B:$R/lib/gbm"
export REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_DRI_TRACE=1 REMESA_HRE_GLES_LAB=1 MESA_GLES_VERSION_OVERRIDE=2.0 REMESA_HRE_EGL_DMABUF_LAB=1
export REMESA_HRE_COMPOSITOR_PLAN=1 REMESA_HRE_COMPOSITOR_HYBRID=1 REMESA_HRE_RECEIPTS=1 REMESA_HRE_UPLOAD_REBIND=1
export REMESA_HRE_COMPOSITOR_RESIDENCY=1
export REMESA_HRE_EGL22_REUSE="$reuse"
if [[ $compact == 1 ]]; then export REMESA_HRE_EGL23_COMPACT=1; fi
if [[ $affine == 1 ]]; then export REMESA_HRE_EGL25_AFFINE=1; fi
if [[ $graph == 1 ]]; then export REMESA_HRE_EGL24_GRAPH=1; fi
if [[ $wide == 1 ]]; then export REMESA_HRE_EGL24_WIDE=1; fi
if [[ $solid == 1 ]]; then export REMESA_HRE_EGL24_SOLID=1; fi
if [[ $blit == 1 ]]; then export REMESA_HRE_EGL26_BLIT=1; fi
if [[ $direct == 1 ]]; then export REMESA_HRE_EGL26_DIRECT=1; fi
if [[ $nativecache == 1 ]]; then export REMESA_HRE_EGL26_NATIVE_CACHE=1; fi
if [[ $hostrt == 1 ]]; then export REMESA_HRE_EGL27_HOST_RT=1; fi
if [[ $sparse == 1 ]]; then export REMESA_HRE_EGL30_SPARSE=1; else unset REMESA_HRE_EGL30_SPARSE; fi
echo "EGL30_CONFIG sparse=$sparse"
if [[ $gpu2d == 1 ]]; then export REMESA_HRE_EGL31_GPU2D=1 REMESA_HRE_EGL32_CACHE2=1; fi
if [[ $sparse == 1 ]]; then export REMESA_HRE_EGL32_DENSE_DISCARD=1; fi
if [[ $native3d == 1 || $gpu2d == 1 ]]; then export REMESA_HRE_EGL31_NATIVE_RESOLVE=1; fi
echo "EGL31_CONFIG gpu2d=$gpu2d"
if [[ $cloudtail == 1 ]]; then export REMESA_HRE_EGL28_HOST_SYNC=1; fi
if [[ $liveviews == 1 ]]; then export REMESA_HRE_EGL29_LIVE_VIEWS=1; fi
if [[ $directclose == 1 ]]; then export REMESA_HRE_EGL29_DIRECT_CLOSE=1; fi
if [[ $adaptive == 1 ]]; then export REMESA_HRE_EGL29_ADAPTIVE=1; fi
if [[ $native3d == 1 && ( $blit == 1 || $gpu2d == 1 ) ]]; then echo 'native3d and CPU blit conflict'; exit 2; fi
echo "EGL29_CONFIG liveviews=$liveviews native3d=$native3d directclose=$directclose adaptive=$adaptive cloudtail=$cloudtail"
echo "EGL28_CONFIG cloudtail=$cloudtail hostrt=$hostrt blit=$blit direct=$direct nativecache=$nativecache scanout_requested=$scanout affine=$affine reuse=$reuse graph=$graph wide=$wide solid=$solid compact=$compact hardware_cursor_requested=$hwcursor"
if [[ $verbose == 0 ]]; then export REMESA_HRE_QUIET_ALLOC=1; fi
export WLR_RENDERER=gles2 WLR_BACKENDS=drm,libinput WLR_DRM_DEVICES="$CARD" WLR_DRM_NO_ATOMIC=1 WLR_DRM_NO_MODIFIERS=1
if [[ $scanout == 0 ]]; then export WLR_SCENE_DISABLE_DIRECT_SCANOUT=1; else unset WLR_SCENE_DISABLE_DIRECT_SCANOUT; fi
if [[ $hwcursor == 0 ]]; then export WLR_NO_HARDWARE_CURSORS=1; else unset WLR_NO_HARDWARE_CURSORS; fi
if [[ -S /run/seatd.sock ]]; then export LIBSEAT_BACKEND=seatd; fi
L=$(mktemp /tmp/remesa-egl19-desktop.XXXXXX); export REMESA_LABWC_LOG="$L"
export REMESA_EGL33_RELEASE="$release"
if [[ $release == 1 ]]; then
 unset REMESA_DRI_TRACE
 export REMESA_HRE_EGL33_RELEASE=1 EGL_LOG_LEVEL=warning
 echo 'EGL33_RELEASE logging=summary-only (physical receipt gates unchanged)'
fi
echo "EGL19 desktop diagnostic: $L ($CARD)"
limit=(); if ((seconds>0)); then limit=(timeout --signal=TERM --kill-after=15s "$((seconds+100))s"); fi
set +e
if [[ $release == 1 ]]; then
 "${limit[@]}" dbus-run-session -- bash "$D/tools/session.sh" "$D" "$B" "$CARD" "$U" "$UH" "$UR" "$stage" "$seconds" >>"$L" 2>&1
 rc=$?
else
 "${limit[@]}" dbus-run-session -- bash "$D/tools/session.sh" "$D" "$B" "$CARD" "$U" "$UH" "$UR" "$stage" "$seconds" 2>&1 | tee "$L"
 rc=${PIPESTATUS[0]}
fi
set -e
echo "EGL19_DESKTOP_EXIT=$rc LOG=$L"
if [[ $rc != 0 ]]; then tail -30 "$L" >&2; exit "$rc"; fi
if [[ $release == 1 ]]; then
 python3 "$D/tools/check-release.py" "$L" "$stage"
else
 bash "$D/tools/check-evidence.sh" "$L" "$stage" "$blit"
fi
