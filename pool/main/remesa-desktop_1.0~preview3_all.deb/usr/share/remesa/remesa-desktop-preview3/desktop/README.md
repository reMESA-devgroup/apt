# reMESA EGL19 Desktop qualification

Launcher/configuration only. Requires the physically demonstrated EGL18 runtime (remesa-hre-cross 1.0~topology2.egl18) and authenticated EGL14 LINEAR boot. The GBM allocator, KMS probe and activation script are byte-identical to EGL18. No Mesa source or module changes, no installer, no GRUB edits, no replacement of user configuration.

## Mini 12

Check installed programs: `command -v foot waybar fuzzel thunar setfacl`. If missing and available in your existing distribution repositories, install only missing dependencies (package `acl` provides `setfacl`). Keep the current experimental runtime installed. From the normal SSH account, stop the display manager with `sudo sv down slimski` and use:

* `sudo bash run.sh --stage foot --seconds 120`: terminal only.
* `sudo bash run.sh --stage panel --seconds 180`: terminal and Waybar. Click Apps to open Fuzzel, then dismiss or launch a trusted local Wayland program. Click Terminal or Arquivos for applications installed on the host.
* `sudo bash run.sh --stage desktop --seconds 300`: starts Foot, Waybar and Thunar; Fuzzel from the panel. Move windows, type in the terminal, open Fuzzel, and observe the LCD.

Do not run as a permanent desktop yet. The test ends after the specified duration (30–1800 seconds) and validates evidence, or stops upon HRE/GBM/KMS errors. Super+Escape requests an early exit; early termination is not a qualified timed run. Logs at `/tmp/remesa-egl19-desktop.*`. Optional Mako and Swaybg can be tested later, without modifying the baseline.

The compositor remains privileged because the private kernel admission requires it. Applications are launched under the invoking non-root account with a separate runtime/config directory and D-Bus session, with only that account granted access to the compositor socket via ACL. No private Mesa environment is injected into clients; client-side rendering may be software. The compositor requires the reMESA SGX535 renderer, sampled draws, physical retirement, KMS changes and clean shutdown. This is not a security boundary for untrusted clients: only use trusted local applications. Do not browse the web from this experimental privileged compositor. XWayland and unprivileged compositor operation are not qualified. Do not use an existing graphical session simultaneously.

Offline host test: `bash test-host.sh`. Verifies shell syntax, XML/JSON/INI parsing, absence of Execute in privileged configuration, C compilation, GBM allocator mock and positive/negative log fixtures. Actual Labwc startup with ACL, application visuals, Fuzzel interaction, performance and stability require the physical Mini 12. Log parser only establishes session-level HRE/KMS evidence and window mapping, not pixel equivalence or per-app acceleration.
