/* SPDX-License-Identifier: MIT */
/* reMESA headless lab: public GEM allocation, no private HRE owner. */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <glob.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <unistd.h>
#include "gbm_backend_abi.h"
#include "drm.h"
#include "drm_fourcc.h"
struct alloc_device { struct gbm_device base; int primary; };
struct alloc_bo { struct gbm_bo base; uint32_t handle; int fd; size_t size; uint64_t modifier; };
static const struct gbm_core *core;
static int xio(int fd, unsigned long req, void *arg) { int r; do { r=ioctl(fd,req,arg); } while(r<0 && errno==EINTR); return r; }
static bool read_eq(const char *path,const char *want) { char v[64]; FILE *f=fopen(path,"r"); if(!f)return false; bool ok=fgets(v,sizeof v,f)!=NULL; fclose(f); if(!ok)return false; v[strcspn(v,"\r\n")]=0; return !strcmp(v,want); }
static bool identity(int fd,char out[PATH_MAX]) {
 struct stat st; char path[PATH_MAX]; if(fstat(fd,&st)||!S_ISCHR(st.st_mode)||major(st.st_rdev)!=226)return false;
 snprintf(path,sizeof path,"/sys/dev/char/%u:%u/device",major(st.st_rdev),minor(st.st_rdev));
 if(!realpath(path,out))return false;
 if(snprintf(path,sizeof path,"%s/vendor",out)>=(int)sizeof path||!read_eq(path,"0x8086"))return false;
 if(snprintf(path,sizeof path,"%s/device",out)>=(int)sizeof path||!read_eq(path,"0x8108"))return false;
 if(snprintf(path,sizeof path,"%s/driver/module",out)>=(int)sizeof path)return false;
 char mod[PATH_MAX]; if(!realpath(path,mod))return false;
 return !strcmp(strrchr(mod,'/')+1,"remesa_gma500gfx");
}
static bool boot_ok(void) { char line[4096]; FILE *f=fopen("/proc/cmdline","r"); if(!f)return false; bool ok=fgets(line,sizeof line,f)!=NULL; fclose(f); if(!ok)return false; char *save=NULL; for(char *p=strtok_r(line," \n\r\t",&save);p;p=strtok_r(NULL," \n\r\t",&save))if(!strcmp(p,"remesa_boot=egl14-linear"))return true; return false; }
static int primary_for(int fd) { char id[PATH_MAX], other[PATH_MAX]; if(!identity(fd,id)){errno=ENODEV;return -1;} glob_t g={0}; if(glob("/dev/dri/card[0-9]*",0,NULL,&g)){globfree(&g);errno=ENODEV;return -1;} int result=-1; for(size_t i=0;i<g.gl_pathc;i++){int p=open(g.gl_pathv[i],O_RDWR|O_CLOEXEC|O_NOFOLLOW); if(p<0)continue; if(identity(p,other)&&!strcmp(id,other)){if(result>=0){close(result);close(p);result=-1;break;}result=p;}else close(p);}globfree(&g);if(result<0)errno=ENODEV;return result; }
static int supported(struct gbm_device *d,uint32_t format,uint32_t usage){(void)d;format=core->v0.format_canonicalize(format);const uint32_t allowed=GBM_BO_USE_SCANOUT|GBM_BO_USE_RENDERING|GBM_BO_USE_LINEAR;return !(usage&~allowed)&&(format==GBM_FORMAT_ARGB8888||format==GBM_FORMAT_XRGB8888);}
static int planes_for(struct gbm_device*d,uint32_t f,uint64_t m){return supported(d,f,0)&&(m==DRM_FORMAT_MOD_LINEAR||m==DRM_FORMAT_MOD_INVALID)?1:-1;}
static void close_handle(int fd,uint32_t handle){if(handle){struct drm_gem_close c={.handle=handle};if(xio(fd,DRM_IOCTL_GEM_CLOSE,&c))perror("HRE_ALLOC_GEM_CLOSE");}}
static void destroy_dumb(int fd,uint32_t handle){if(handle){struct drm_mode_destroy_dumb c={.handle=handle};if(xio(fd,DRM_IOCTL_MODE_DESTROY_DUMB,&c))perror("HRE_ALLOC_DESTROY_DUMB");}}
static struct gbm_bo *create_bo(struct gbm_device *d,uint32_t w,uint32_t h,uint32_t f,uint32_t usage,const uint64_t *mods,unsigned n){
 struct alloc_device *a=(void*)d; if(!w||!h||w>4096||h>4096||!supported(d,f,usage)||(n&&!mods)){errno=EINVAL;return NULL;}
 bool linear=false,implicit=false;
 for(unsigned i=0;i<n;i++){linear|=mods[i]==DRM_FORMAT_MOD_LINEAR;implicit|=mods[i]==DRM_FORMAT_MOD_INVALID;}
 if(n&&!linear&&!implicit){errno=ENOTSUP;return NULL;}
 /* Legacy KMS without ADDFB2 modifiers: preserve implicit negotiation.
  * Physical layout stays linear regardless of the reported modifier. */
 const char *native=getenv("REMESA_GBM_NATIVE_SCANOUT");
 bool legacy=native&&!strcmp(native,"1")&&(usage&GBM_BO_USE_SCANOUT);
 uint64_t selected=(legacy&&(!n||implicit))||(!linear&&implicit)?DRM_FORMAT_MOD_INVALID:DRM_FORMAT_MOD_LINEAR;
 struct alloc_bo *b=calloc(1,sizeof *b);if(!b)return NULL;b->fd=-1;b->modifier=selected;
 struct drm_mode_create_dumb c={.width=w,.height=h,.bpp=32}; if(xio(a->primary,DRM_IOCTL_MODE_CREATE_DUMB,&c))goto fail;
 b->handle=c.handle; if(!c.handle||c.pitch<(uint64_t)w*4||c.size<(uint64_t)c.pitch*h||c.size>64u*1024u*1024u){errno=EOVERFLOW;goto fail;}
 struct drm_prime_handle p={.handle=c.handle,.flags=DRM_CLOEXEC|DRM_RDWR,.fd=-1}; if(xio(a->primary,DRM_IOCTL_PRIME_HANDLE_TO_FD,&p))goto fail;b->fd=p.fd;if(b->fd<0){errno=EIO;goto fail;}
 /* Return a handle in the caller's DRM file, not the independently opened primary. */
 struct drm_prime_handle imp={.fd=b->fd}; if(xio(d->v0.fd,DRM_IOCTL_PRIME_FD_TO_HANDLE,&imp))goto fail;
 b->base.gbm=d;b->base.v0.width=w;b->base.v0.height=h;b->base.v0.stride=c.pitch;b->base.v0.format=core->v0.format_canonicalize(f);b->base.v0.handle.u32=imp.handle;b->size=c.size;
 if(!imp.handle){errno=EIO;goto fail;}
 fprintf(stderr,"HRE_GBM_PUBLIC_BO %ux%u pitch=%u size=%zu usage=0x%x modifier=%016llx scanout=%u\n",w,h,c.pitch,b->size,usage,(unsigned long long)b->modifier,!!(usage&GBM_BO_USE_SCANOUT));return &b->base;
fail: {int e=errno;if(b->fd>=0)close(b->fd);destroy_dumb(a->primary,b->handle);free(b);errno=e;return NULL;}
}
static void destroy_bo(struct gbm_bo *bo){struct alloc_bo*b=(void*)bo;struct alloc_device*a=(void*)bo->gbm;close_handle(bo->gbm->v0.fd,bo->v0.handle.u32);close(b->fd);destroy_dumb(a->primary,b->handle);free(b);}
static int get_fd(struct gbm_bo*bo){return fcntl(((struct alloc_bo*)bo)->fd,F_DUPFD_CLOEXEC,0);}
static int plane_fd(struct gbm_bo*bo,int p){if(p){errno=EINVAL;return -1;}return get_fd(bo);}
static int planes(struct gbm_bo*bo){(void)bo;return 1;}
static union gbm_bo_handle handle(struct gbm_bo*bo,int p){if(!p)return bo->v0.handle;errno=EINVAL;return (union gbm_bo_handle){.s32=-1};}
static uint32_t stride(struct gbm_bo*bo,int p){if(!p)return bo->v0.stride;errno=EINVAL;return 0;}
static uint32_t offset(struct gbm_bo*bo,int p){(void)bo;if(p)errno=EINVAL;return 0;}
static uint64_t modifier(struct gbm_bo*bo){return ((struct alloc_bo*)bo)->modifier;}
/* No GBM surfaces, external imports or CPU maps: this is an allocator only. */
static struct gbm_bo *no_import(struct gbm_device*d,uint32_t t,void*b,uint32_t u){(void)d;(void)t;(void)b;(void)u;errno=ENOTSUP;return NULL;}
static void *no_map(struct gbm_bo*b,uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t f,uint32_t*s,void**m){(void)b;(void)x;(void)y;(void)w;(void)h;(void)f;(void)s;(void)m;errno=ENOTSUP;return NULL;}
static void no_unmap(struct gbm_bo*b,void*m){(void)b;(void)m;}
static int no_write(struct gbm_bo*b,const void*p,size_t n){(void)b;(void)p;(void)n;errno=ENOTSUP;return -1;}
static struct gbm_surface *no_surface(struct gbm_device*d,uint32_t w,uint32_t h,uint32_t f,uint32_t u,const uint64_t*m,unsigned n){(void)d;(void)w;(void)h;(void)f;(void)u;(void)m;(void)n;errno=ENOTSUP;return NULL;}
static void destroy_device(struct gbm_device*d){struct alloc_device*a=(void*)d;close(a->primary);free(a);}
static struct gbm_device *create_device(int fd,uint32_t ver){
 const char *opt=getenv("REMESA_GBM_ALLOCATOR_ONLY");if(!opt||strcmp(opt,"1")||geteuid()!=0||!boot_ok()){errno=EPERM;return NULL;}
 int p=primary_for(fd);if(p<0)return NULL;uint64_t cap=0;struct drm_get_cap c={.capability=DRM_CAP_PRIME};if(xio(p,DRM_IOCTL_GET_CAP,&c)||!(c.value&DRM_PRIME_CAP_EXPORT)){close(p);errno=ENOTSUP;return NULL;}cap=c.value;
 struct alloc_device*a=calloc(1,sizeof *a);if(!a){close(p);return NULL;}a->primary=p;
 a->base.v0=(struct gbm_device_v0){.backend_version=ver,.fd=fd,.name="remesa_alloc",.destroy=destroy_device,.is_format_supported=supported,.get_format_modifier_plane_count=planes_for,.bo_create=create_bo,.bo_import=no_import,.bo_map=no_map,.bo_unmap=no_unmap,.bo_write=no_write,.bo_get_fd=get_fd,.bo_get_planes=planes,.bo_get_handle=handle,.bo_get_plane_fd=plane_fd,.bo_get_stride=stride,.bo_get_offset=offset,.bo_get_modifier=modifier,.bo_destroy=destroy_bo,.surface_create=no_surface};
 fprintf(stderr,"HRE_GBM_ALLOCATOR_ONLY primary=%d prime=%llu (no HRE owner acquired)\n",p,(unsigned long long)cap);return &a->base;
}
static const struct gbm_backend backend={.v0={.backend_version=GBM_BACKEND_ABI_VERSION,.backend_name="remesa_alloc",.create_device=create_device}};
__attribute__((visibility("default"))) const struct gbm_backend *GBM_GET_BACKEND_PROC(const struct gbm_core *c){core=c;return &backend;}
