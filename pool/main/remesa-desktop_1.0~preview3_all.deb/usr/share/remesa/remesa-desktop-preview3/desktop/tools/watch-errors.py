#!/usr/bin/env python3
"""Incremental log watchdog. No repeated full-file scan; no line discarded at chunk boundaries."""
import re, sys, time
BAD = re.compile(rb'^HRE_EGL29_(?:VIEW_CREATE_FAIL|VIEW_BIND_FAIL|ADMISSION_FAIL) |^HRE_EGL29B_VIEW_CAPACITY |^HRE_TILE_FAIL |^HRE_COMPOSITOR_HYBRID_REJECT |^HRE_COMPOSITOR_SESSION_CLOSE_FAIL |^HRE_GLES_DRAW_RESULT errno=[1-9]|^HRE_RC3_UPLOAD errno=[1-9]|^HRE_EGL(?:16|17|18)_.*FAIL|^HRE_EGL31_GPU2D_ORACLE_FAIL |^HRE_EGL28_DMA .*errno=[1-9]|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO|step=hre-native-owner errno=16')
def bad(line): return BAD.search(line) is not None

def watch(path, once=False):
    pending = b''
    with open(path,'rb') as f:
        while True:
            block=f.read(65536)
            if block:
                lines=(pending+block).split(b'\n'); pending=lines.pop()
                for line in lines:
                    if bad(line):
                        print('EGL33_WATCH_ERROR '+line.decode(errors='replace'),file=sys.stderr,flush=True)
                        return 1
                if len(pending)>1048576:
                    print('EGL33_WATCH_ERROR oversized log record',file=sys.stderr,flush=True); return 1
            elif once:
                return int(bad(pending))
            else: time.sleep(.25)
if __name__=='__main__':
    sys.exit(watch(sys.argv[1],len(sys.argv)>2 and sys.argv[2]=='--once'))
