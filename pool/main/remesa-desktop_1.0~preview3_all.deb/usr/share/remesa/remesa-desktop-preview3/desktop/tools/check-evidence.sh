#!/bin/bash
set -euo pipefail
L=${1:?}; stage=${2:?}
need(){ grep -Eq "$1" "$L" || { echo "EGL19_MISSING $1"; exit 1; }; }
need 'GL renderer: reMESA .*SGX535'
need "^EGL19_CLIENTS_READY stage=$stage uid=[1-9][0-9]*$"
need '^EGL19_CLIENT_START name=foot .*uid=[1-9][0-9]*$'
need '\[map\].*identifier=[^,]*[Ff]oot'
if [[ $stage != foot ]]; then need '^EGL19_CLIENT_START name=waybar .*uid=[1-9][0-9]*$'; fi
if [[ $stage == desktop ]]; then
 need '^EGL19_CLIENT_START name=thunar .*uid=[1-9][0-9]*$'
 need '\[map\].*identifier=[^,]*[Tt]hunar'
fi
if [[ ${3:-0} == 1 ]] && grep -Eq '^HRE_EGL26_CPU_BLIT_PASS |^HRE_EGL31_GPU2D_PASS ' "$L"; then
 echo 'EGL31_TEXTURE_EVIDENCE (CPU, physical 2D and physical 3D receipts separately classified)'
 if grep -q '^HRE_NATIVE_RETIRED ' "$L"; then echo 'EGL26_NATIVE_ACTIVITY_RECORDED (inspect physical receipts separately)'; fi
else
 need '^HRE_NATIVE_RETIRED .*retired=1'
 need '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 '
fi
need '^EGL15_KMS_FB_CHANGE '
need '^EGL19_CLEAN_SHUTDOWN$'
if grep -Eq '^HRE_EGL29_(VIEW_CREATE_FAIL|VIEW_BIND_FAIL|ADMISSION_FAIL) |^HRE_TILE_FAIL |^HRE_COMPOSITOR_HYBRID_REJECT |^HRE_COMPOSITOR_SESSION_CLOSE_FAIL |^HRE_GLES_DRAW_RESULT errno=[1-9]|^EGL19_DRAW_FAILED|^HRE_EGL18_.*FAIL|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO|step=hre-native-owner errno=16' "$L"; then echo EGL19_FAILED; exit 1; fi
echo 'EGL26_DESKTOP_EVIDENCE (stage-specific; visual/app interaction verification pending; root compositor, CPU/native paths separately logged)'
