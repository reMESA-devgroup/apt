#!/bin/bash
set -eu
[[ $EUID != 0 ]] || exit 2
message(){ if command -v notify-send >/dev/null; then notify-send 'reMESA' "$*"; else printf '%s\n' "$*"; fi; }
launch(){ if command -v "$1" >/dev/null; then "$@"; else message "Não instalado: $1"; fi; }
network(){
 if command -v nmcli >/dev/null && nmcli -t -f RUNNING general 2>/dev/null | grep -qx running; then
  if command -v nm-connection-editor >/dev/null; then launch nm-connection-editor; elif command -v nmtui >/dev/null; then launch foot nmtui; else message 'Instale network-manager ou network-manager-gnome para a interface de configuração.'; fi
 elif command -v connmanctl >/dev/null && connmanctl state >/dev/null 2>&1; then
  if command -v connman-gtk >/dev/null; then launch connman-gtk; else launch foot connmanctl; fi
 else message 'Gerenciador de rede não detectado. Use a configuração de rede do antiX; nenhum serviço será alterado.'; fi
}
choice=${1:-}
if [[ -z $choice ]]; then choice=$(printf '%s\n' 'Rede e Wi-Fi' 'Áudio' 'Tela' 'Notificações' 'Gerenciador de arquivos' 'Monitor de processos' | fuzzel --dmenu --prompt='Configurações > ') || exit 0; fi
case "$choice" in network|'Rede e Wi-Fi') network;; 'Áudio') launch pavucontrol;; 'Tela') launch wdisplays;; 'Notificações') launch makoctl restore;; 'Gerenciador de arquivos') launch thunar;; 'Monitor de processos') launch foot top;; esac
