#!/bin/bash
set -euo pipefail
D=${1:?}; B=${2:?}; CARD=${3:?}; U=${4:?}; UH=${5:?}; UR=${6:?}; stage=${7:?}; seconds=${8:?}; L=${REMESA_LABWC_LOG:?}
compositor='' client='' watcher='' errorwatch=''
stop(){ local p=${1:-}; [[ -n $p ]] || return 0; kill -TERM "$p" 2>/dev/null || :; wait "$p" 2>/dev/null || :; }
stop_clients(){ if [[ -n $client ]]; then
 if [[ $(ps -o pgid= -p "$client" | tr -d ' ') == "$client" ]]; then kill -TERM -- "-$client" 2>/dev/null || :; else kill -TERM "$client" 2>/dev/null || :; fi
 wait "$client" 2>/dev/null || :; client=''; fi; }
cleanup(){ stop_clients; stop "$watcher"; stop "$compositor"; stop "$errorwatch"; }
trap cleanup EXIT
trap 'exit 143' TERM INT
if [[ ${REMESA_EGL33_RELEASE:-0} == 1 ]]; then
 labwc -C "$D/config" -V & compositor=$!
else
 labwc -C "$D/config" -d & compositor=$!
fi
python3 "$D/tools/watch-errors.py" "$L" & errorwatch=$!
socket=''
for i in $(seq 1 120); do
 kill -0 "$compositor" 2>/dev/null || { echo EGL19_COMPOSITOR_EXITED; exit 1; }
 for f in "$XDG_RUNTIME_DIR"/wayland-*; do [[ -S $f ]] && { socket=$f; break; }; done
 [[ -n $socket ]] && break; sleep .5
done
[[ -n $socket ]] || { echo EGL19_SOCKET_TIMEOUT; exit 1; }
# ACL grants only the invoking account access to the root-owned socket.
setfacl -m "u:$U:--x" "$XDG_RUNTIME_DIR"
setfacl -m "u:$U:rw-" "$socket"
grep -Eq 'GL renderer: reMESA .*SGX535' "$L" || { echo EGL19_HRE_RENDERER_NOT_SELECTED; exit 1; }
"$B/kms-probe" watch "$CARD" & watcher=$!
sleep .5
kill -0 "$watcher" || exit 1
echo "EGL19_NATIVE_SOCKET $socket"
# Clean client environment: never inherit root's private Mesa variables or DBus.
setsid --wait runuser -u "$U" -- env -i HOME="$UH" USER="$U" LOGNAME="$U" PATH=/usr/local/bin:/usr/bin:/bin LANG=C.UTF-8 TERM=xterm-256color XDG_RUNTIME_DIR="$UR" XDG_CONFIG_HOME="$UR/config" XDG_SESSION_TYPE=wayland WAYLAND_DISPLAY="$socket" GDK_BACKEND=wayland QT_QPA_PLATFORM=wayland dbus-run-session -- bash "$UR/client.sh" "$stage" & client=$!
start=$SECONDS
while ((seconds == 0 || SECONDS-start < seconds)); do
 if ! kill -0 "$errorwatch" 2>/dev/null; then echo EGL19_DRAW_FAILED; exit 1; fi
 if ! kill -0 "$compositor" 2>/dev/null; then
  rc=0; wait "$compositor" || rc=$?; compositor=''
  if [[ $seconds == 0 && $rc == 0 ]]; then
   stop_clients; stop "$watcher"; watcher=''; stop "$errorwatch"; errorwatch=''
   python3 "$D/tools/watch-errors.py" "$L" --once || exit 1
   echo EGL19_CLEAN_SHUTDOWN; exit 0
  fi
  echo "EGL19_COMPOSITOR_EXITED_EARLY rc=$rc"; exit 1
 fi
 kill -0 "$watcher" 2>/dev/null || { echo EGL19_WATCH_EXITED; exit 1; }
 kill -0 "$client" 2>/dev/null || { echo EGL19_CLIENT_SESSION_EXITED; exit 1; }
 sleep 1
done
stop_clients; stop "$watcher"; watcher=''
kill -TERM "$compositor"; rc=0; wait "$compositor" || rc=$?; compositor=''
[[ $rc == 0 ]] || { echo "EGL19_SHUTDOWN_ERROR rc=$rc"; exit 1; }
stop "$errorwatch"; errorwatch=''
python3 "$D/tools/watch-errors.py" "$L" --once || { echo EGL19_DRAW_FAILED; exit 1; }
echo EGL19_CLEAN_SHUTDOWN
