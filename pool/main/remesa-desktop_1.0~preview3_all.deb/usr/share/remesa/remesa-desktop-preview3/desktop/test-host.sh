#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
for f in "$D"/*.sh "$D"/tools/*.sh "$D"/client/*.sh "$D"/config/autostart "$D"/config/shutdown; do bash -n "$f"; done
python3 - "$D" <<'PY'
import pathlib,sys,json,xml.etree.ElementTree as E,configparser
p=pathlib.Path(sys.argv[1]); json.loads((p/'client/waybar.json').read_text())
for f in (p/'config').glob('*.xml'):
 root=E.parse(f).getroot(); assert all(x.get('name','').lower() != 'execute' for x in root.iter('action'))
c=configparser.ConfigParser(); c.read(p/'client/fuzzel.ini'); assert c['main']['terminal']=='foot'
print('EGL19_CONFIG_PARSE_PASS')
PY
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 -fPIC -shared -fvisibility=hidden "$D/allocator/allocator.c" -o "$T/remesa_alloc_gbm.so"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/allocator/test-mock.c" -Wl,--wrap=ioctl -o "$T/mock"
"$T/mock"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/tools/kms-probe.c" -o "$T/kms-probe"
echo EGL19_HOST_BUILD_PASS
cat > "$T/log" <<'LOG'
GL renderer: reMESA 12.3 / PowerVR SGX535
HRE_NATIVE_RETIRED sequence=1 phase=9 ledger=0x7 retired=1
HRE_COMPOSITOR_HYBRID_DRAW_OK covered=576 sampled=1 blend=1 tiles=1 (native raster, CPU resolve)
EGL15_KMS_FB_CHANGE crtc=1 from=2 to=3
EGL19_CLIENT_START name=foot pid=10 uid=1000
[map] identifier=foot, title=foot
EGL19_CLIENT_START name=waybar pid=11 uid=1000
EGL19_CLIENT_START name=thunar pid=12 uid=1000
[map] identifier=thunar, title=home
EGL19_CLIENTS_READY stage=desktop uid=1000
EGL19_CLEAN_SHUTDOWN
LOG
bash "$D/tools/check-evidence.sh" "$T/log" desktop
for stage in foot panel; do sed "s/stage=desktop/stage=$stage/" "$T/log" > "$T/$stage"; bash "$D/tools/check-evidence.sh" "$T/$stage" "$stage"; done
for pat in '^EGL15_KMS_FB_CHANGE' '^EGL19_CLIENT_START name=waybar' 'identifier=thunar' '^HRE_NATIVE_RETIRED' '^EGL19_CLEAN_SHUTDOWN'; do
 sed "/$pat/d" "$T/log" > "$T/bad"; if bash "$D/tools/check-evidence.sh" "$T/bad" desktop; then exit 1; fi
done
for err in 'HRE_GLES_DRAW_RESULT errno=95' 'HRE_COMPOSITOR_HYBRID_REJECT errno=12' 'EGL19_DRAW_FAILED'; do
 cp "$T/log" "$T/bad"; echo "$err" >> "$T/bad"; if bash "$D/tools/check-evidence.sh" "$T/bad" desktop; then exit 1; fi
done
sed 's/uid=1000/uid=0/g' "$T/log" > "$T/bad"; if bash "$D/tools/check-evidence.sh" "$T/bad" desktop; then exit 1; fi
sed '/^HRE_NATIVE_RETIRED /d;/^HRE_COMPOSITOR_HYBRID_DRAW_OK /d' "$T/log" > "$T/cpu"
echo 'HRE_EGL26_CPU_BLIT_PASS covered=16 rectangles=1 (CPU texture blit, no native submission)' >> "$T/cpu"
bash "$D/tools/check-evidence.sh" "$T/cpu" desktop 1
if bash "$D/tools/check-evidence.sh" "$T/cpu" desktop 0; then exit 1; fi
echo EGL26_CPU_NATIVE_EVIDENCE_SEPARATION_PASS
echo EGL19_EVIDENCE_FIXTURE_PASS
