#!/usr/bin/env bash
# Require V11.6c2 kernel identity; never run a graph rebind against old kernel.
set -euo pipefail
[[ $EUID == 0 ]] || { echo 'Run sudo from isolated SSH/TTY'; exit 2; }
K=$(uname -r); P=/sys/module/remesa_gma500gfx/parameters
[[ -d $P && ! -d /sys/module/gma500_gfx && $(cat "$P/noirq") == Y ]] || { echo 'Expected private noirq module only'; exit 2; }
T=$(mktemp -d);trap 'rm -rf "$T"' EXIT
if grep -qw 'remesa_boot=egl34-desktop' /proc/cmdline; then
 note="/boot/remesa-desktop-$K.build-id"
elif grep -qw 'remesa_boot=egl14-linear' /proc/cmdline; then
 note="/boot/remesa-egl14-linear-$K.build-id"
else echo 'Boot the authenticated experimental reMESA entry first'; exit 2; fi
[[ -f $note && ! -L $note && $(stat -c '%u:%a' "$note") == 0:600 ]] || exit 2
cp "$note" "$T/expected"
[[ -s $T/expected ]] && cmp -s "$T/expected" /sys/module/remesa_gma500gfx/notes/.note.gnu.build-id || { echo 'Module build ID mismatch'; exit 2; }
if pgrep -x 'Xorg|Xwayland|labwc|sway|weston|kwin_wayland|slimski' >/dev/null; then echo 'Stop graphics first (antiX runit: sudo sv down slimski)'; exit 2; fi
nodes=();for d in /sys/class/drm/renderD*; do
 [[ -r $d/device/vendor && -r $d/device/device ]] || continue
 [[ $(cat "$d/device/vendor") == 0x8086 && $(cat "$d/device/device") == 0x8108 && $(basename "$(readlink -f "$d/device/driver/module")") == remesa_gma500gfx ]] || continue
 [[ -c /dev/dri/${d##*/} ]] && nodes+=("/dev/dri/${d##*/}")
done
[[ ${#nodes[@]} == 1 ]] || { echo 'Expected one authenticated render node';exit 2; }
for gate in memory hre_dynamic matrix_submit texture_graph texture_qualify twod_copy; do [[ -w $P/remesa_${gate}_enabled ]] || exit 2; done
for gate in memory hre_dynamic matrix_submit texture_graph texture_qualify twod_copy; do echo Y > "$P/remesa_${gate}_enabled"; done
printf 'HRE_GATES_ENABLED node=%s (root-only; no GPU job submitted)\n' "${nodes[0]}"
