#!/usr/bin/env python3
"""Release-mode smoke evidence. Does not certify GPU execution or frame rate."""
import re,sys,pathlib
import runpy
# Check the original log once, without duplicate per-operation processing.
watch=runpy.run_path(str(pathlib.Path(__file__).with_name('watch-errors.py')))['watch']
p,stage=sys.argv[1:3]
if watch(p,True): sys.exit('EGL33_RELEASE_FAIL driver/compositor error')
text=pathlib.Path(p).read_text(errors='replace')
patterns=[r'GL renderer: reMESA .*SGX535',rf'^EGL19_CLIENTS_READY stage={stage} uid=[1-9][0-9]*$',r'^EGL19_CLIENT_START name=foot .*uid=[1-9][0-9]*$',r'^EGL15_KMS_FB_CHANGE ',r'^EGL19_CLEAN_SHUTDOWN$']
if stage!='foot': patterns.append(r'^EGL19_CLIENT_START name=waybar .*uid=[1-9][0-9]*$')
if stage=='desktop': patterns.append(r'^EGL19_CLIENT_START name=thunar .*uid=[1-9][0-9]*$')
for x in patterns:
    if not re.search(x,text,re.M): sys.exit('EGL33_RELEASE_MISSING '+x)
rows=[line for line in text.splitlines() if line.startswith('HRE_EGL33_SUMMARY ')]
if not rows: sys.exit('EGL33_RELEASE_MISSING summary')
# Report last cumulative snapshot per live context; final snapshots mark a lifetime.
last={}; finished=[]
for line in rows:
    d=dict(x.split('=',1) for x in line.split()[1:]); key=d['context']; last[key]=d
    if d['final']=='1': finished.append(last.pop(key))
allrows=finished+list(last.values())
counts=[0]*9
for d in allrows:
    h=list(map(int,d['hist'].split(',')))
    if len(h)!=9 or sum(h)!=int(d['batches']): sys.exit('EGL33_RELEASE_FAIL histogram')
    counts=[x+y for x,y in zip(counts,h)]
n=sum(counts)
if not n: sys.exit('EGL33_RELEASE_FAIL zero batches')
print('EGL33_RELEASE_SUMMARY batches=%d gpu2d_rects=%d native_tiles=%d cpu_blit=%d solid=%d final_contexts=%d unfinished_contexts=%d' % (n,*[sum(int(d[k]) for d in allrows) for k in ['gpu2d_rects','native_tiles','cpu_blit','solid']],len(finished),len(last)))
print('EGL33_RELEASE_LATENCY <=15ms=%d/%d >100ms=%d max_us=%d histogram=%s' %(sum(counts[:5]),n,counts[8],max(int(d['max_us']) for d in allrows),','.join(map(str,counts))))
print('EGL33_RELEASE_PASS (smoke only; batch histogram, not frame FPS; route counts not independent physical receipts)')
