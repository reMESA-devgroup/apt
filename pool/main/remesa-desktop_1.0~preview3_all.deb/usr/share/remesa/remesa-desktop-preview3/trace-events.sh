#!/usr/bin/env bash
# Opt-in, bounded independent tracefs instance; no global event/filter changes.
set -Eeuo pipefail
[[ $EUID == 0 ]] || { echo 'Use sudo bash trace-events.sh [seconds]'; exit 2; }
S=${1:-10}; [[ $S =~ ^[0-9]{1,2}$ ]] && ((10#$S>=1 && 10#$S<=30)) || exit 2
S=$((10#$S))
[[ -d /sys/module/remesa_gma500gfx && ! -d /sys/module/gma500_gfx ]] || { echo 'Expected experimental module'; exit 2; }
T=/sys/kernel/tracing; [[ -d $T/instances ]] || T=/sys/kernel/debug/tracing
[[ -d $T/instances ]] || { echo 'Tracefs instances unavailable; no tracefs mounted or changed'; exit 3; }
I=$T/instances/remesa34-$$; mkdir "$I"
cleanup(){ echo 0 > "$I/tracing_on" 2>/dev/null || :; rmdir "$I" || :; }
trap cleanup EXIT; trap 'exit 130' INT; trap 'exit 143' TERM
E=$I/events/drm/drm_vblank_event_delivered
[[ -w $E/enable ]] || { echo 'DRM event unavailable in this kernel'; exit 3; }
echo 0 > "$I/tracing_on"; echo 512 > "$I/buffer_size_kb"
# A globally comparable clock is needed to compare event times across CPUs.
if grep -qw mono "$I/trace_clock"; then echo mono > "$I/trace_clock"; else echo 'Monotonic trace clock unavailable'; exit 3; fi
echo 1 > "$E/enable"; echo 1 > "$I/tracing_on"
echo "Collecting DRM delivery events for $S seconds; drag windows now" >&2
sleep "$S"; echo 0 > "$I/tracing_on"; echo 0 > "$E/enable"
L=$(mktemp /tmp/remesa34-drm-events.XXXXXX); cat "$I/trace" > "$L"
for f in "$I"/per_cpu/cpu*/stats; do [[ -r $f ]] && cat "$f" >> "$L"; done
printf 'DRM_EVENT_TRACE=%s\n' "$L"
python3 "$(dirname "$0")/profile-events.py" "$L"
