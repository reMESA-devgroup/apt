#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "BUILD FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID != 0 ]] || { echo 'Run as normal user'; exit 2; }
for x in i686-linux-gnu-gcc i686-linux-gnu-g++ i686-linux-gnu-ar meson ninja pkg-config python3 dpkg-deb readelf; do command -v "$x" >/dev/null || { echo "Missing: $x"; exit 2; }; done
W=${REMESA_CROSS_WORK:-$HOME/.local/share/remesa/cross-topology2-egl1}; mkdir -p "$W"; W=$(realpath "$W")
[[ -f $W/source.path && -f $W/build-i386/build.ninja ]] || { echo "Existing EGL1 cross-build not found: $W"; exit 2; }
M=$(cat "$W/source.path")
LC_ALL=C grep -Fq "HRE device discovery without second owner" "$M/src/egl/main/egldevice.c" || { echo "Apply EGL2 first"; exit 2; }
LC_ALL=C grep -Fq "HRE GBM offscreen config" "$M/src/egl/drivers/dri2/platform_drm.c" || { echo "Apply EGL3 first"; exit 2; }
python3 "$D/apply.py" "$M"
B="$W/build-i386"
SYS=${REMESA_SYSROOT:-/}; SYS=$(realpath "$SYS")
export PKG_CONFIG_PATH= PKG_CONFIG_LIBDIR="$SYS/usr/lib/i386-linux-gnu/pkgconfig:$SYS/usr/lib/i686-linux-gnu/pkgconfig:$SYS/usr/share/pkgconfig:$SYS/usr/i686-linux-gnu/lib/pkgconfig"
export PKG_CONFIG_SYSROOT_DIR="$SYS"
python3 - "$W/cross.ini" "$SYS" <<'PY'
import sys,pathlib
p,s=sys.argv[1:]; flags=['-march=bonnell','-mtune=bonnell']; link=[]
if s!='/': flags+=['--sysroot='+s];link+=['--sysroot='+s]
text="""[binaries]
c = 'i686-linux-gnu-gcc'
cpp = 'i686-linux-gnu-g++'
ar = 'i686-linux-gnu-ar'
strip = 'i686-linux-gnu-strip'
pkg-config = 'pkg-config'
[host_machine]
system = 'linux'
cpu_family = 'x86'
cpu = 'i686'
endian = 'little'
[properties]
needs_exe_wrapper = true
"""+f"sys_root = {s!r}\npkg_config_libdir = { [s.rstrip('/')+x for x in ['/usr/lib/i386-linux-gnu/pkgconfig','/usr/lib/i686-linux-gnu/pkgconfig','/usr/share/pkgconfig','/usr/i686-linux-gnu/lib/pkgconfig']]!r}\n[built-in options]\nc_args = {flags!r}\ncpp_args = {flags!r}\nc_link_args = {link!r}\ncpp_link_args = {link!r}\n"
f=pathlib.Path(p)
if f.exists() and f.read_text()!=text:sys.exit('Cross configuration changed; choose a new REMESA_CROSS_WORK')
f.write_text(text)
PY
if [[ ! -f $B/build.ninja ]]; then
 meson setup "$B" "$M" --cross-file "$W/cross.ini" --prefix=/opt/remesa/12.3 --libdir=lib -Dgallium-drivers=sgx535 -Dvulkan-drivers=[] -Dplatforms=wayland -Degl=enabled -Dgbm=enabled -Dglx=disabled -Dopengl=false -Dgles1=disabled -Dglvnd=disabled -Dllvm=disabled -Dgles2=enabled -Dbuildtype=release
fi
meson compile -C "$B" -j "${REMESA_BUILD_JOBS:-6}"
S=$(mktemp -d); trap 'rm -rf "$S"' EXIT
DESTDIR="$S" meson install -C "$B" --no-rebuild
R="$S/opt/remesa/12.3"; L="$R/lib"
for f in libEGL.so.1 libGLESv2.so.2 libgbm.so.1 dri/gma500_dri.so libgallium-25.2.0.so; do [[ -e $L/$f ]]; done
LC_ALL=C grep -aFq '[topology-2-lab]' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE device discovery without second owner' "$L/libEGL.so.1"
LC_ALL=C grep -aFq 'HRE_REJECTED_VS_BEGIN' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE GBM offscreen config' "$L/libEGL.so.1"
LC_ALL=C grep -aFq 'HRE_LINK_LAB_VS256_FS64' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL5_XRGB_RT' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_COMPOSITOR_HYBRID_DRAW_OK' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL21B_RESIDENT_UPLOAD' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL21C_SHARED_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL22_REGION_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL22_TIMING' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL23_NATIVE' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL25_AFFINE_TILE' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL31_NATIVE_RESOLVE' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL31_GPU2D_RETIRED' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL33_SUMMARY' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL32_CACHE_SWAP' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL30_SPARSE_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL29B_VIEW_CAPACITY' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL29_LIVE_VIEWS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL29_DIRECT_CLOSE_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL28_DMA' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL28_HOST_SYNC' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL27_HOST_RT' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL27_COMMIT' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL26_CPU_BLIT_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL26_DIRECT_REGION' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL26_NATIVE_CACHE_HIT' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL24_GRAPH_TILE' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL24_GRAPH_REPLAY' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL24_DROP' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL24_SOLID_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL21_ACCOUNT' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL20_TILE_CLOSE_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL18_BATCH_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL17_DIRECT_SAMPLE' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_EGL16_SERIAL_SYNC_PASS' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_TILED_PLAN' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_VA_PROGRAM_GUARD' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_SESSION_RAW' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_COMPOSITOR_SESSION_BOUNDARY' "$L/libgallium-25.2.0.so"
LC_ALL=C grep -aFq 'HRE_GRAPH_ATOMIC_REFUSAL' "$L/libgallium-25.2.0.so"
python3 - "$R" <<'PY'
import pathlib,struct,sys,subprocess
r=pathlib.Path(sys.argv[1]); n=0
for p in r.rglob('*'):
 if p.is_symlink() or not p.is_file():continue
 with p.open('rb') as f:h=f.read(20)
 if h[:4]!=b'\x7fELF':continue
 assert h[4:6]==b'\x01\x01' and struct.unpack_from('<H',h,18)[0]==3,p
 n+=1
 print(p.relative_to(r)); subprocess.run(['readelf','-d',str(p)],check=True)
assert n>0
PY
mkdir -p "$S/DEBIAN"
cat > "$S/DEBIAN/control" <<'CTRL'
Package: remesa-hre-cross
Version: 1.0~topology2.egl34
Architecture: i386
Replaces: remesa-hre-v123 (<= 12.3~rc7)
Breaks: remesa-hre-v123 (<= 12.3~rc7)
Maintainer: reMESA development
Section: graphics
Priority: optional
Description: Private experimental reMESA EGL GLES2 runtime
 Trusted laboratory preview; physical GPU qualification and rootless private IOCTLs pending.
 Runtime dependencies must be checked on target.
CTRL
out="$HOME/remesa-hre-cross_1.0~topology2.egl34_i386.deb"
dpkg-deb --root-owner-group -b "$S" "$out.tmp"; mv "$out.tmp" "$out"
sha256sum "$out"; echo "Built: $out (kernel module not included)"
