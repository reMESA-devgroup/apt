/* SPDX-License-Identifier: MIT */
#ifndef REMESA_COMPOSITOR_GEOMETRY_H
#define REMESA_COMPOSITOR_GEOMETRY_H
#include "remesa_compositor_nir.h"
#include "remesa/texture_draw_domain.h"
/* Scratch planning for the existing native POSITION4/TEX0 contract. No GPU
 * admission: callers must separately qualify scratch clears, state and fences.
 * Coordinates are top-left window space, W=1, depth disabled by caller.
 * Clip to logical damage before mapping into a padded native viewport. */
struct rc_vertex { float x,y,u,v; };
struct rc_native_vertex { float p[4],uv[2]; };
struct rc_scratch { unsigned width,height,x,y,w,h; };
struct rc_triangle { unsigned count; struct rc_native_vertex v[21]; };
static inline int rc_scratch_make(unsigned w,unsigned h,struct rc_scratch *out)
{
 if(!w||!h||w>1792||h>1792||!out)return EINVAL;
 /* Padded width/height with a symmetric >=1/16 screen guard on each side. */
 unsigned gx=(w+13)/14,gy=(h+13)/14;
 /* Match remesa_texture_graph_dynamic_packet_valid: width multiple of 32,
  * height multiple of 16, both strictly less than 2048, unpadded pitch.
  * Align the whole allocation, then center the logical viewport. */
 unsigned sw=(w+2*gx+31u)&~31u,sh=(h+2*gy+15u)&~15u;
 if(sw>=2048||sh>=2048)return ENOTSUP;
 struct rc_scratch t={sw,sh,(sw-w)/2,(sh-h)/2,w,h};
 *out=t;return 0;
}
static inline int rc_window_vertex(const struct rc_program *vs,const void *u,size_t bytes,
 const float input[2],const float scale[2],const float translate[2],struct rc_vertex *out)
{
 if(!vs||vs->stage!=MESA_SHADER_VERTEX||!input||!out)return EINVAL;
 struct rc_io io={.input={input[0],input[1]},.uniforms=u,.bytes=bytes};
 int e=rc_eval(vs,&io);if(e)return e;
 if(io.position[3]!=1.0f||io.position[2]<-1.0f||io.position[2]>1.0f)return ENOTSUP;
 struct rc_vertex t={io.position[0]*scale[0]+translate[0],io.position[1]*scale[1]+translate[1],io.uv[0],io.uv[1]};
 if(!isfinite(t.x)||!isfinite(t.y)||!isfinite(t.u)||!isfinite(t.v)||fabsf(t.x)>65536||fabsf(t.y)>65536)return ERANGE;
 *out=t;return 0;
}
static inline float rc_edge_coord(struct rc_vertex v,unsigned axis){return axis?v.y:v.x;}
static inline struct rc_vertex rc_edge_intersection(struct rc_vertex a,struct rc_vertex b,unsigned axis,float edge)
{
 double t=((double)edge-rc_edge_coord(a,axis))/((double)rc_edge_coord(b,axis)-rc_edge_coord(a,axis));
 struct rc_vertex v={(float)(a.x+t*((double)b.x-a.x)),(float)(a.y+t*((double)b.y-a.y)),(float)(a.u+t*((double)b.u-a.u)),(float)(a.v+t*((double)b.v-a.v))};
 if(axis)v.y=edge;else v.x=edge;return v;
}
static inline int rc_scratch_triangle(const struct rc_scratch *s,const struct rc_vertex in[3],
 unsigned x0,unsigned y0,unsigned x1,unsigned y1,struct rc_triangle *out)
{
 if(!s||!in||!out||x0>x1||y0>y1||x1>s->w||y1>s->h)return EINVAL;
 struct rc_scratch checked; if(rc_scratch_make(s->w,s->h,&checked)||memcmp(s,&checked,sizeof checked))return EINVAL;
 struct rc_triangle t={0};if(x0==x1||y0==y1){*out=t;return 0;}
 struct rc_vertex a[8],b[8];memcpy(a,in,3*sizeof(*a));unsigned n=3;
 for(unsigned i=0;i<3;i++)if(!isfinite(a[i].x)||!isfinite(a[i].y)||!isfinite(a[i].u)||!isfinite(a[i].v))return EINVAL;
 const float edges[4]={x0,x1,y0,y1};
 for(unsigned k=0;k<4&&n;k++){
  unsigned axis=k/2,m=0;bool upper=k&1;float edge=edges[k];
  for(unsigned i=0;i<n;i++){
   struct rc_vertex p=a[(i+n-1)%n],q=a[i];float pc=rc_edge_coord(p,axis),qc=rc_edge_coord(q,axis);
   bool pin=upper?pc<=edge:pc>=edge,qin=upper?qc<=edge:qc>=edge;
   if(pin!=qin){if(m>=8)return EOVERFLOW;b[m++]=rc_edge_intersection(p,q,axis,edge);}
   if(qin){if(m>=8)return EOVERFLOW;b[m++]=q;}
  }
  memcpy(a,b,m*sizeof(*a));n=m;
 }
 for(unsigned j=1;j+1<n;j++){
  unsigned ids[3]={0,j,j+1};
  double area=((double)a[j].x-a[0].x)*((double)a[j+1].y-a[0].y)-((double)a[j].y-a[0].y)*((double)a[j+1].x-a[0].x);
  if(area==0)continue;
  for(unsigned k=0;k<3;k++){
   if(t.count>=21)return EOVERFLOW;struct rc_vertex v=a[ids[k]];
   struct rc_native_vertex *d=&t.v[t.count++];
   d->p[0]=(float)(2.0*((double)v.x+s->x)/s->width-1.0);
   d->p[1]=(float)(1.0-2.0*((double)v.y+s->y)/s->height);
   d->p[2]=.25f;d->p[3]=1;d->uv[0]=v.u;d->uv[1]=v.v;
  }
 }
 _Static_assert(sizeof(struct rc_native_vertex)==24,"native packed vertex");
 if(t.count){int e=remesa_texture_draw_values(t.v,t.count*sizeof(t.v[0]),t.count);if(e)return e;}
 *out=t;return 0;
}
/* Reference resolve of a premultiplied source-over sample; RGBA normalized.
 * Used to qualify a future scratch resolve, never to claim native blending.
 * Opaque target alpha is always one. */
static inline int rc_source_over(const float src[4],const float dst[4],bool opaque,float out[4])
{
 float v[4];for(unsigned i=0;i<4;i++)if(!isfinite(src[i])||!isfinite(dst[i])||src[i]<0||src[i]>1||dst[i]<0||dst[i]>1)return EINVAL;
 for(unsigned i=0;i<4;i++)v[i]=fminf(1.0f,src[i]+dst[i]*(1.0f-src[3]));
 if(opaque)v[3]=1;memcpy(out,v,sizeof v);return 0;
}
#endif
