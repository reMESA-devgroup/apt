# reMESA EGL24 — Operation Dragon

Incremental update from exact EGL23. Kernel and 40-slot limit unchanged. No stock system component, GRUB or USSE compiler modification. Source provenance: existing reMESA EGL23 and EGL14 source; design research only, no imported third-party code.

## Modes and rationale

- `--graph-reuse --reuse-four`: within one synchronous Gallium composition batch, keep authenticated graph attached for up to four tiles; retain immutable sampled view, reuse resident texture and host vertex buffer. Reuse calls existing checked managed draw, vertex-update ABI, exact state key, and transactional DROP/BIND on changed topology. Every native tile still physically retires and reads COLOR/Z24; exact coverage and solid pixel oracles remain. A successful group ends with DROP and CLOSE. No cross-batch attached graph. Default remains legacy DROP (four tiles per session) until physical qualification. `--reuse-two` and `--reuse-eight` available; `--serial` closes each tile.
- `--wide`: independent experimental 448x448 maximum logical tiles (512x512 padded in the full case), versus 224x224. Fewer submissions; larger scratch may increase memory and runtime per tile. The existing allocation and coverage guards remain. No physical qualification yet.
- `--solid-fast`: optional CPU 2D exact rectangle fill for already admitted constant fragment colors, no GPU submission; preserve blending order and opaque-alpha semantics; explicitly logs CPU only. All sampled draws still take physical native raster path. It is not a generic software fallback.
- `--compact`: existing EGL23 optional compact scratch. `--hardware-cursor` default now allows wlroots to attempt KMS cursor; `--software-cursor` restores previous override. No kernel cursor implementation change.
- Fixed stale version guard in native/run.sh; all launchers require EGL24.

Profiling separates backend DROP callback vs local collection, graph replay decisions vs rebuild, resident input, physical receipts, CPU-only rectangles and clean shutdown. Do not use composition-batch timings as FPS. The actual DROP callback may include kernel-side work; the split does not prove which exact kernel function takes the time.

## Build and test

On Tab S7, normal user, existing EGL23 cross work: `REMESA_BUILD_JOBS=6 bash build-cross.sh`. The incremental overlay requires exact EGL23 file hashes and is idempotent. Transfer the generated DEB to Mini 12; install only on experimental boot. First run `sudo bash run.sh --preflight` to verify version/device/scanout. Test one change at a time:

```
sudo bash desktop/run.sh --stage foot --seconds 60 --reuse-four --graph-reuse --hardware-cursor
sudo bash desktop/run.sh --stage foot --seconds 60 --reuse-four --graph-reuse --wide --hardware-cursor
sudo bash desktop/run.sh --stage foot --seconds 60 --reuse-four --graph-reuse --wide --solid-fast --hardware-cursor
```

Only proceed if the previous run shows clean shutdown and no native or KMS errors. On failure, preserve log; do not automatically retry EOWNERDEAD or a poisoned device. A conclusive ordinary refusal can be compared with `--legacy-drop` at original tile size. If graph mode fails, stop first and verify clean shutdown/ownership before another run. No forced hardware reset.

```
L=$(ls -t /tmp/remesa-egl19-desktop.* | head -1)
sudo python3 profile24.py "$L"
```

Validation: see TEST-RESULTS.txt. Host harness compiles production batch planner and solid routine with mocked native scratch and ownership; it does not compile or validate actual Mesa GPU transport. Full Mesa cross-build and physical qualification require original development environment and Mini 12. Cross-frame session persistence is intentionally not implemented because single global native owner freezes unrelated allocations while attached; further transport/kernel lifecycle work is required. No guaranteed FPS improvement.

## Design references

- Mesa Gallium context: https://docs.mesa3d.org/gallium/context.html — resource and fence semantics; deferred work requires completion guarantees.
- Linux dma-buf documentation: https://dri.freedesktop.org/docs/drm/driver-api/dma-buf.html — buffer ownership and synchronization.
- wlroots output documentation: https://wlroots-38153e.pages.freedesktop.org/wlr/types/wlr_output.h.html — damage and software cursor render pass concepts.
