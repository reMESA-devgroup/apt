#!/usr/bin/env python3
"""Summarize successful composition batches, not display FPS."""
import re, sys, statistics
from collections import Counter
if len(sys.argv)!=2: sys.exit('Usage: python3 profile22.py LOG')
rows=[]; counts=Counter(); region=Counter()
with open(sys.argv[1],errors='replace') as f:
 for l in f:
  if 'HRE_EGL22_TIMING ' in l:
   d={k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',l)}
   if all(k in d for k in ('tiles','total_us','import_us','native_us','close_us','publish_us')): rows.append(d)
  for tag in ('HRE_NATIVE_RETIRED','HRE_EGL22_DPM_REUSE','HRE_COMPOSITOR_SESSION_BOUNDARY','EGL15_KMS_FB_CHANGE','HRE_TILE_FAIL','HRE_EGL22_REGION_FAIL','HRE_EGL21C_SHARED_FAIL','EGL19_DRAW_FAILED','EGL19_CLEAN_SHUTDOWN'):
   if tag in l: counts[tag]+=1
  if 'HRE_EGL22_REGION_PASS ' in l or 'HRE_EGL21C_SHARED_PASS ' in l:
   d=dict(re.findall(r'(\w+)=([0-9]+)',l));
   if 'publish' in d and 'bytes' in d:region['publish' if d['publish']=='1' else 'import']+=int(d['bytes'])
print('Successful composition batches:',len(rows),'tiles:',sum(r['tiles'] for r in rows))
for k in ('total_us','import_us','native_us','close_us','publish_us'):
 if rows:
  v=[r[k]/1000 for r in rows]; a=sorted(v); print(f'{k[:-3]}: median={statistics.median(v):.2f} ms p95={a[(95*len(a)+99)//100-1]:.2f} ms sum={sum(v):.2f} ms')
for k,v in counts.items(): print(k,v)
for k,v in region.items(): print(f'{k} transferred bytes (logged):',v)
