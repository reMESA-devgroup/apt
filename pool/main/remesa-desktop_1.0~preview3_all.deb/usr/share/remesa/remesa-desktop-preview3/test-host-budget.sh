#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
python3 - "$D" "$T" <<'PY'
from pathlib import Path
import sys
p,t=map(Path,sys.argv[1:]);s=next((p/'overlay').rglob('remesa_screen.c')).read_text();(t/'budget.inc').write_text(s[s.index('static size_t host_buffer_limit'):s.index('/* Fixed-size metadata slab')])
PY
cat > "$T/test.c" <<'C'
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct screen {size_t host_buffer_bytes;struct {struct {uint64_t max_resource_bytes;} resource_limits;} device;};
#include "budget.inc"
int main(void){
 struct screen sc={.device.resource_limits.max_resource_bytes=16*1024*1024};
 unsetenv("REMESA_HRE_COMPOSITOR_RESIDENCY");
 assert(host_buffer_limit(&sc)==16*1024*1024);
 assert(!host_buffer_reserve(&sc,16391312+4096000));assert(sc.host_buffer_bytes==0);
 setenv("REMESA_HRE_COMPOSITOR_RESIDENCY","1",1);
 assert(host_buffer_limit(&sc)==64*1024*1024);
 assert(host_buffer_reserve(&sc,16391312));assert(host_buffer_reserve(&sc,4096000));
 __atomic_sub_fetch(&sc.host_buffer_bytes,4096000,__ATOMIC_RELAXED);
 assert(host_buffer_reserve(&sc,4096000+524288));
 __atomic_sub_fetch(&sc.host_buffer_bytes,4096000+524288,__ATOMIC_RELAXED);
 assert(sc.host_buffer_bytes==16391312);assert(!host_buffer_reserve(&sc,SIZE_MAX));
 assert(host_buffer_reserve(&sc,host_buffer_limit(&sc)-sc.host_buffer_bytes));assert(!host_buffer_reserve(&sc,1));
 assert(sc.host_buffer_bytes==64*1024*1024);puts("EGL21C_HOST_BUDGET_PASS");
}
C
cc -std=gnu11 -Wall -Wextra -Werror -O2 -I"$T" "$T/test.c" -o "$T/test"
"$T/test"
