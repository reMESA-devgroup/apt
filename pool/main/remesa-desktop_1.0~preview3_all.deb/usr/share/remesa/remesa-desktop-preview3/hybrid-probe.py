"""Two exact depthless EGLImage draws: physical qualification, not desktop scanout."""
import ctypes as C, mmap

def run(gl,base,shared,size,pitch,sync,W,H):
    P,I,U,S,PI=base.P,base.I,base.U,base.S,base.PI
    F=C.c_float; PU=C.POINTER(U)
    def call(name,ret,*types):
        base.bind(gl,name,ret,*types)
        def f(*args):
            result=getattr(gl,name)(*args)
            err=gl.glGetError()
            if err:raise RuntimeError(f'{name} GL error {err:#x}')
            return result
        return f
    create=call('glCreateShader',U,U);source=call('glShaderSource',None,U,I,C.POINTER(S),PI);compile=call('glCompileShader',None,U);status=call('glGetShaderiv',None,U,U,PI)
    def shader(kind,code):
        sh=create(kind);s=S(code);source(sh,1,C.byref(s),None);compile(sh);v=I();status(sh,0x8b81,C.byref(v))
        if not v.value:raise RuntimeError('shader compile failed')
        return sh
    vs=shader(0x8b31,b'attribute vec2 pos; uniform mat3 proj; void main(){gl_Position=vec4(vec3(pos,1.0)*proj,1.0);}')
    fs=shader(0x8b30,b'precision mediump float; uniform vec4 color; void main(){gl_FragColor=color;}')
    pr=call('glCreateProgram',U)();attach=call('glAttachShader',None,U,U);attach(pr,vs);attach(pr,fs)
    call('glBindAttribLocation',None,U,U,S)(pr,0,b'pos');call('glLinkProgram',None,U)(pr)
    v=I();call('glGetProgramiv',None,U,U,PI)(pr,0x8b82,C.byref(v))
    if not v.value:raise RuntimeError('program link failed')
    call('glUseProgram',None,U)(pr);loc=call('glGetUniformLocation',I,U,S);a,b=loc(pr,b'proj'),loc(pr,b'color')
    if min(a,b)<0:raise RuntimeError('uniform missing')
    call('glUniformMatrix3fv',None,I,I,C.c_ubyte,C.POINTER(F))(a,1,0,(F*9)(1,0,0,0,1,0,0,0,1))
    call('glUniform4f',None,I,F,F,F,F)(b,32/255,64/255,96/255,128/255)
    # A symmetric Y rectangle makes this witness independent of GL-vs-storage
    # row order. Two draws exercise the same owner and DROP/BIND replacement.
    vertices=(F*8)(-.75,-.5,.5,-.5,-.75,.5,.5,.5)
    bo=U();call('glGenBuffers',None,I,PU)(1,C.byref(bo));call('glBindBuffer',None,U,U)(0x8892,bo)
    call('glBufferData',None,U,C.c_ssize_t,P,U)(0x8892,C.sizeof(vertices),vertices,0x88e4)
    call('glVertexAttribPointer',None,U,I,U,C.c_ubyte,I,P)(0,2,0x1406,0,8,None);call('glEnableVertexAttribArray',None,U)(0)
    disable=call('glDisable',None,U)
    for cap in (0x0bd0,0x0b71,0x0be2,0x0c11,0x0b44):disable(cap)
    call('glViewport',None,I,I,I,I)(0,0,W,H);draw=call('glDrawArrays',None,U,I,I);finish=call('glFinish',None)
    def witness(expected):
        pixels=(C.c_ubyte*(W*H*4))();gl.glReadPixels(0,0,W,H,0x1908,0x1401,pixels)
        if gl.glGetError():raise RuntimeError('readback failed')
        for y in range(H):
            for x in range(W):
                exp=expected if 8<=x<48 and 16<=y<48 else (255,0,0,255)
                i=(y*W+x)*4
                if tuple(pixels[i:i+4])!=exp:raise RuntimeError(f'GL pixel {x},{y}: {tuple(pixels[i:i+4])} != {exp}')
        with mmap.mmap(shared,size,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ) as buf:
            sync(shared,1)
            try:
                for y in range(H):
                    for x in range(W):
                        exp=expected if 8<=x<48 and 16<=y<48 else (255,0,0,255)
                        if buf[y*pitch+4*x:y*pitch+4*x+4]!=bytes((exp[2],exp[1],exp[0],exp[3])):raise RuntimeError(f'DMA-BUF pixel {x},{y} mismatch')
            finally:sync(shared,5)
    draw(5,0,4);finish();witness((32,64,96,128));print('HYBRID_PHYSICAL_DRAW1_PIXELS_PASS',flush=True)
    call('glEnable',None,U)(0x0be2);call('glBlendFuncSeparate',None,U,U,U,U)(1,0x0303,1,0x0303)
    draw(5,0,4);finish();witness((48,96,144,192));print('HYBRID_PHYSICAL_DRAW2_BLEND_PASS',flush=True)
    call('glDisableVertexAttribArray',None,U)(0);call('glBindBuffer',None,U,U)(0x8892,0);call('glDeleteBuffers',None,I,PU)(1,C.byref(bo));call('glUseProgram',None,U)(0);call('glDeleteProgram',None,U)(pr);call('glDeleteShader',None,U)(vs);call('glDeleteShader',None,U)(fs)
