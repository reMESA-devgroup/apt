#include <assert.h>
#include <stdio.h>
#include "remesa_texture_binding.c"
static int query(void *p,struct pipe_resource *r,unsigned level,struct remesa_texture_storage *out){(void)p;(void)r;if(level)return EINVAL;*out=(struct remesa_texture_storage){.resource_cookie=1,.content_epoch=1,.bytes=64,.stride=16,.width=4,.height=4,.levels=1};return 0;}
int main(void){
 struct pipe_screen sc={0};struct pipe_resource r={.reference={1},.screen=&sc,.target=PIPE_TEXTURE_2D,.width0=4,.height0=4,.depth0=1,.array_size=1,.format=PIPE_FORMAT_B8G8R8A8_UNORM};
 struct pipe_sampler_view t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM},*v=NULL;
 struct remesa_texture_binding_bank *b=remesa_texture_binding_create(&sc,query,NULL,NULL,NULL,NULL);assert(b);
 assert(!remesa_texture_binding_gallium_live_only(b));
 for(unsigned i=0;i<20000;i++){
  assert(!remesa_texture_view_create(b,&r,&t,&v));assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,1,0,&v));
  const struct pipe_sampler_view *actual=NULL;assert(!remesa_texture_fragment0_view(b,&actual)&&actual==v);
  v->context->sampler_view_release(v->context,v);assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,0,1,NULL));assert(b->count==0&&b->live==0&&r.reference.count==1);
 }
 puts("EGL29_20000_VIEW_LIFECYCLES_PASS");
 assert(!remesa_texture_view_create(b,&r,&t,&v));assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,1,0,&v));
 remesa_texture_binding_close(b);assert(r.reference.count==2);v->context->sampler_view_release(v->context,v);assert(r.reference.count==1);
 puts("EGL29_LATE_FRONTEND_RELEASE_PASS");
 b=remesa_texture_binding_create(&sc,query,NULL,NULL,NULL,NULL);assert(b);
 for(unsigned i=0;i<1024;i++){assert(!remesa_texture_view_create(b,&r,&t,&v));v->context->sampler_view_release(v->context,v);}
 assert(remesa_texture_view_create(b,&r,&t,&v)==ENOSPC);assert(b->count==1024&&b->live==0);remesa_texture_binding_close(b);
 puts("EGL29_STRICT_LAB_TOMBSTONES_PRESERVED_PASS");return 0;
}
