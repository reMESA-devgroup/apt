#include <assert.h>
#include <stdio.h>
#include "remesa_texture_binding.c"
/* Minimal stand-in for Mesa state tracker objects. Actual cache functions
 * are extracted verbatim by test-frontend-view.sh from the patched source. */
typedef unsigned GLuint;
struct st_context {struct pipe_context *pipe;};
struct st_sampler_view {struct pipe_sampler_view *view;struct st_context *st;bool glsl130_or_later,srgb_skip_decode;};
struct st_sampler_views {unsigned count,max;struct st_sampler_views *next;struct st_sampler_view views[];};
struct gl_texture_object {int validate_mutex;struct st_sampler_views *sampler_views,*sampler_views_old;};
#define simple_mtx_lock(p) ((void)(p))
#define simple_mtx_unlock(p) ((void)(p))
#define p_atomic_set(p,v) (*(p)=(v))
#define p_atomic_read(p) (*(p))
static void pipe_sampler_view_release_ptr(struct pipe_sampler_view **v){if(*v){struct pipe_sampler_view *p=*v;*v=NULL;p->context->sampler_view_release(p->context,p);}}
#include "frontend-extracted.inc"
static int query(void *p,struct pipe_resource *r,unsigned level,struct remesa_texture_storage *out){(void)p;(void)r;if(level)return EINVAL;*out=(struct remesa_texture_storage){.resource_cookie=1,.content_epoch=1,.bytes=64,.stride=16,.width=4,.height=4,.levels=1};return 0;}
static void frontend_release(struct pipe_context *p,struct pipe_sampler_view *v){(void)p;v->context->sampler_view_release(v->context,v);}
int main(void){
 struct pipe_screen sc={0};struct pipe_resource r={.reference={1},.screen=&sc,.target=PIPE_TEXTURE_2D,.width0=4,.height0=4,.depth0=1,.array_size=1,.format=PIPE_FORMAT_B8G8R8A8_UNORM};
 struct pipe_sampler_view t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM},*v=NULL;
 struct remesa_texture_binding_bank *b=remesa_texture_binding_create(&sc,query,NULL,NULL,NULL,NULL),*b2=remesa_texture_binding_create(&sc,query,NULL,NULL,NULL,NULL);assert(b&&b2);
 assert(!remesa_texture_binding_gallium_live_only(b));assert(!remesa_texture_binding_gallium_live_only(b2));
 struct pipe_context p={.screen=&sc,.sampler_view_release=frontend_release},p2={.screen=&sc,.sampler_view_release=frontend_release};struct st_context st={&p},st2={&p2};
 struct gl_texture_object tex={0};tex.sampler_views=calloc(1,sizeof(*tex.sampler_views)+sizeof(struct st_sampler_view));assert(tex.sampler_views);tex.sampler_views->max=1;
 assert(!remesa_texture_view_create(b,&r,&t,&v));assert(v->context!=st.pipe);assert(st_texture_set_sampler_view(&st,&tex,v,false,false,false)==v);
 for(unsigned i=0;i<20000;i++){struct st_sampler_view *sv=st_texture_get_current_sampler_view(&st,&tex);assert(sv&&sv->view==v);assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,1,0,&sv->view));assert(b->count==1);}
 puts("EGL29B_20000_FRONTEND_CACHE_HITS_PASS");
 struct pipe_sampler_view *other=NULL;assert(!remesa_texture_view_create(b2,&r,&t,&other));assert(st_texture_set_sampler_view(&st2,&tex,other,false,false,false)==other);assert(st_texture_get_current_sampler_view(&st2,&tex)->view==other);
 for(unsigned i=0;i<20000;i++){assert(!remesa_texture_view_create(b,&r,&t,&v));assert(st_texture_set_sampler_view(&st,&tex,v,false,false,false)==v);assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,1,0,&v));assert(b->count==1&&b2->count==1&&tex.sampler_views->count==2);}
 puts("EGL29B_20000_FRONTEND_REPLACEMENTS_TWO_CONTEXTS_PASS");
 st_texture_release_context_sampler_view(&st,&tex);assert(!st_texture_get_current_sampler_view(&st,&tex));assert(st_texture_get_current_sampler_view(&st2,&tex)->view==other);assert(!remesa_texture_views_bind(b,PIPE_SHADER_FRAGMENT,0,0,1,NULL));assert(!b->count);
 st_texture_release_context_sampler_view(&st2,&tex);assert(!b2->count);assert(r.reference.count==1);remesa_texture_binding_close(b);remesa_texture_binding_close(b2);
 free(tex.sampler_views);while(tex.sampler_views_old){struct st_sampler_views *s=tex.sampler_views_old;tex.sampler_views_old=s->next;free(s);}puts("EGL29B_FRONTEND_CONTEXT_RELEASE_PASS");return 0;
}
