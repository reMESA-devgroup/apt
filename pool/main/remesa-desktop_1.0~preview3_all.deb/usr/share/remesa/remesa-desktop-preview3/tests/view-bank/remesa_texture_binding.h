#pragma once
#include "pipe/p_context.h"
#define REMESA_TEXTURE_STORAGE_LEVELS 16
struct remesa_texture_storage { uint64_t resource_cookie,content_epoch; size_t bytes,offset; unsigned stride,width,height,levels; };
struct remesa_texture_binding_bank;
typedef int (*remesa_texture_storage_query)(void*,struct pipe_resource*,unsigned,struct remesa_texture_storage*);
typedef void *(*remesa_texture_binding_alloc)(void*,size_t);
typedef void (*remesa_texture_binding_free)(void*,void*);
int remesa_texture_view_destroy(struct remesa_texture_binding_bank*,struct pipe_sampler_view*);
