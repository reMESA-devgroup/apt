#pragma once
#include "pipe/p_context.h"
static inline void remesa_resource_reference(struct pipe_resource **dst,struct pipe_resource *src){ if(src)++src->reference.count;if(*dst)--(*dst)->reference.count;*dst=src; }
