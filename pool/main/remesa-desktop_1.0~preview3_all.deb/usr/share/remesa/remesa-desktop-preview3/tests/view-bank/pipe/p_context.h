#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#define PIPE_SHADER_TYPES 6
#define PIPE_MAX_SHADER_SAMPLER_VIEWS 32
#define PIPE_SHADER_FRAGMENT 1
#define PIPE_TEXTURE_2D 2
#define PIPE_FORMAT_R8G8B8A8_UNORM 1
#define PIPE_FORMAT_B8G8R8A8_UNORM 2
#define PIPE_FORMAT_B8G8R8X8_UNORM 3
#define PIPE_SWIZZLE_1 5
struct pipe_screen { int dummy; };
struct pipe_reference { int count; };
struct pipe_resource { struct pipe_reference reference; struct pipe_screen *screen; unsigned target,width0,height0,depth0,array_size,last_level,nr_samples,nr_storage_samples,flags,format; };
struct pipe_context;
struct pipe_sampler_view { struct pipe_reference reference; struct pipe_resource *texture; struct pipe_context *context; unsigned target,format,astc_decode_format,is_tex2d_from_buf,swizzle_r,swizzle_g,swizzle_b,swizzle_a; union { struct { unsigned first_layer,last_layer,first_level,last_level; } tex; } u; };
struct pipe_context { struct pipe_screen *screen; void (*sampler_view_destroy)(struct pipe_context*,struct pipe_sampler_view*); void (*sampler_view_release)(struct pipe_context*,struct pipe_sampler_view*); };
