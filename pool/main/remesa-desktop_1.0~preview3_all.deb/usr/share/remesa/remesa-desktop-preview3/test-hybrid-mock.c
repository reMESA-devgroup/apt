/* Native request transport simulated; no hardware claim. */
#define REMESA_FACTORY_BACKING_SLOTS 128u
#define main original_2d_factory_main
#define __wrap_ioctl fixture_ioctl
#include "test_native_2d_factory.c"
#undef main
#undef __wrap_ioctl
#define main reference_main
#include "test.c"
#undef main
#include "remesa_resource_ref.h"
void nir_print_shader(nir_shader *s,FILE *f){(void)s;(void)f;abort();} /* test-only: diagnostic must remain unused */
static unsigned submissions,session_color,session_depth,session_closes,session_drops,session_binds;
static bool corrupt;
static unsigned session_sequence,session_opens;
static bool session_active,graph_attached;
static bool inject_refusal,inject_poison,refusal_seen;
static unsigned w=56,h=56,sw=64,shh=64,ox=4,oy=4,x0p=7,x1p=41,y0p=6,y1p=38;
static unsigned tiles_per_draw=1,fail_at=0;
static struct remesa_scene_packet_window mesh_window;
static unsigned scratch_color_first,scratch_depth_first;
static unsigned tile_width,tile_height;
static bool large,sampled_fixture;
static struct remesa_scene_packet packet_current;
static struct backing *texture_mock;
static bool triangle_hit(double px,double py,const float a[6],const float b[6],const float c[6]){
 double x[3]={(a[0]+1.)*sw/2.,(b[0]+1.)*sw/2.,(c[0]+1.)*sw/2.};
 double y[3]={(1.-a[1])*shh/2.,(1.-b[1])*shh/2.,(1.-c[1])*shh/2.};
 double z[3];for(unsigned i=0;i<3;i++){unsigned j=(i+1)%3;z[i]=(x[j]-x[i])*(py-y[i])-(y[j]-y[i])*(px-x[i]);}
 return (z[0]>=-1e-6&&z[1]>=-1e-6&&z[2]>=-1e-6)||(z[0]<=1e-6&&z[1]<=1e-6&&z[2]<=1e-6);
}
int __wrap_ioctl(int fd,unsigned long cmd,...){
 va_list ap;va_start(ap,cmd);void *arg=va_arg(ap,void*);va_end(ap);
 if(cmd!=DRM_IOCTL_REMESA_TEXTURE_SESSION)return fixture_ioctl(fd,cmd,arg);
 struct remesa_texture_session_request *r=arg;assert(fd==owned&&remesa_texture_graph_request_valid(r));
 if(r->action==REMESA_TEXTURE_SESSION_OPEN||r->action==REMESA_TEXTURE_GRAPH_BIND){if(r->action==REMESA_TEXTURE_GRAPH_BIND){assert(session_active&&!graph_attached&&r->sequence==session_sequence);if((inject_refusal||inject_poison)&&!refusal_seen){refusal_seen=true;if(inject_poison){r->state=REMESA_TEXTURE_SESSION_POISONED;r->error=-EIO;return 0;}errno=ENOSPC;return -1;}session_binds++;}else{assert(!session_active&&!r->sequence);session_active=true;session_sequence=0;session_opens++;}graph_attached=true;assert(r->packet.controls.width==sw&&r->packet.controls.height==shh&&r->packet.controls.color_pitch==sw&&r->packet.controls.depth_pitch==sw);session_color=r->packet.controls.color_id;session_depth=r->packet.controls.depth_id;
  if(!scratch_color_first){scratch_color_first=session_color;scratch_depth_first=session_depth;}
  assert(scratch_color_first==session_color&&scratch_depth_first==session_depth);
  mesh_window=r->packet.windows[1];packet_current=r->packet;
  if(sampled_fixture){texture_mock=NULL;for(unsigned i=0;i<packet_current.binding_count;i++){struct backing *candidate=find(packet_current.bindings[i].id);if(candidate->bytes>=250*250*4&&candidate->data[0]==96&&candidate->data[1]==64&&candidate->data[2]==32&&candidate->data[3]==17){assert(!texture_mock);texture_mock=candidate;}}assert(texture_mock);}
  r->session=77;r->state=REMESA_TEXTURE_SESSION_ACTIVE;}
 else if(r->action==REMESA_TEXTURE_GRAPH_DROP){assert(session_active&&graph_attached&&r->sequence==session_sequence);graph_attached=false;session_drops++;r->state=REMESA_TEXTURE_GRAPH_DETACHED;}
 else if(r->action==REMESA_TEXTURE_SESSION_SUBMIT){
  assert(session_active&&graph_attached&&r->sequence==++session_sequence);struct backing *c=find(session_color),*z=find(session_depth);assert(c->bytes>=sw*shh*4&&z->bytes>=sw*shh*4);
  unsigned a=x0p,b=y0p,xe=x1p,ye=y1p,tx=0,ty=0;
  if(large){unsigned nx=(x1p-x0p+tile_width-1)/tile_width,idx=submissions%tiles_per_draw;tx=x0p+(idx%nx)*tile_width;ty=y0p+(idx/nx)*tile_height;a=b=0;xe=MIN2(tile_width,x1p-tx);ye=MIN2(tile_height,y1p-ty);}
  struct backing *vb=find(mesh_window.vertex_id),*ib=find(mesh_window.index_id);
  assert(mesh_window.vertex_bytes==mesh_window.vertex_count*24&&mesh_window.vertex_offset+mesh_window.vertex_bytes<=vb->bytes&&mesh_window.index_offset+mesh_window.index_bytes<=ib->bytes);
  const uint8_t *vertices=vb->data+mesh_window.vertex_offset,*indices=ib->data+mesh_window.index_offset;
  float tris[14][3][6];unsigned ntri=mesh_window.index_bytes/6;assert(ntri&&ntri<=14);
  for(unsigned j=0;j<ntri;j++)for(unsigned k=0;k<3;k++){unsigned off=(j*3+k)*2,id=indices[off]|((unsigned)indices[off+1]<<8);assert(id<mesh_window.vertex_count);memcpy(tris[j][k],vertices+id*24,24);
   if(sampled_fixture){double global_x=(tris[j][k][0]+1.)*sw/2.-ox+tx;assert(fabs(tris[j][k][4]-global_x/w)<1e-5);assert(fabs(tris[j][k][5]-.5)<1e-5);}
  }
  for(unsigned y=0;y<shh;y++)for(unsigned x=0;x<sw;x++){
   bool hit=x>=ox+a&&x<ox+xe&&y>=oy+b&&y<oy+ye, raster=false;
   for(unsigned j=0;j<ntri;j++)if(triangle_hit(x+.5,y+.5,tris[j][0],tris[j][1],tris[j][2]))raster=true;
   assert(hit==raster);
   size_t i=(y*sw+x)*4;const uint8_t *sample=(uint8_t[]){96,64,32,128};
   if(raster&&sampled_fixture){unsigned pixel=(unsigned)(((double)(tx+x-ox)+.5)*250/w);assert(pixel<250);sample=texture_mock->data+4*pixel;assert(!memcmp(sample,pixel<125?(uint8_t[]){96,64,32,17}:(uint8_t[]){16,32,64,5},4));}
   memcpy(c->data+i,raster?sample:(uint8_t[]){0,0,0,0},4);memcpy(z->data+i,raster?(uint8_t[]){0,0,0xa0,0}:(uint8_t[]){255,255,255,0},4);
  }
  if(corrupt&&submissions+1==fail_at)z->data[0]=0;
  r->operation=r->cookie=200+(++submissions);r->state=REMESA_TEXTURE_SESSION_ACTIVE;r->retired=1;r->phase=9;r->ledger=7;
 }else{assert(r->action==REMESA_TEXTURE_SESSION_CLOSE);assert(session_active&&r->sequence==session_sequence);session_active=graph_attached=false;session_closes++;r->state=REMESA_TEXTURE_SESSION_CLOSED;}return 0;
}
static void check_pixels(const uint8_t *ptr,unsigned stride,unsigned draws){
 static const uint8_t colors[][4]={{40,80,120,255},{116,104,92,255},{154,116,78,255},{68,72,76,255},{82,68,54,255},{28,56,92,255},{22,44,78,255}};
 for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){
  const uint8_t *expected=colors[0];
  if(x>=x0p&&x<x1p&&y>=y0p&&y<y1p){
   if(!sampled_fixture)expected=colors[draws==1?1:2];
   else if(x<w/2)expected=colors[draws==1?3:4];
   else expected=colors[draws==1?5:6];
  }
  if(memcmp(ptr+y*stride+x*4,expected,4)){fprintf(stderr,"PIXEL_MISMATCH %u,%u draw=%u got=%u/%u/%u/%u expected=%u/%u/%u/%u\n",x,y,draws,ptr[y*stride+x*4],ptr[y*stride+x*4+1],ptr[y*stride+x*4+2],ptr[y*stride+x*4+3],expected[0],expected[1],expected[2],expected[3]);abort();}
 }
}
int main(int argc,char **argv){
 if(argc>1){w=h=64;sw=96;shh=80;ox=16;oy=8;x0p=8;x1p=48;y0p=16;y1p=48;}
 if(argc>1&&(!strcmp(argv[1],"desktop")||!strcmp(argv[1],"refusal")||!strcmp(argv[1],"poison"))){large=true;w=1280;h=720;sw=shh=256;ox=oy=16;x0p=7;x1p=1280;y0p=11;y1p=720;tile_width=tile_height=224;tiles_per_draw=((x1p-x0p+223)/224)*((y1p-y0p+223)/224);assert(tiles_per_draw==24);}
 if(argc>1&&!strcmp(argv[1],"sampled")){large=sampled_fixture=true;w=512;h=256;sw=shh=256;ox=oy=16;x0p=y0p=0;x1p=w;y1p=h;tile_width=tile_height=224;tiles_per_draw=6;}
 inject_refusal=argc>1&&!strcmp(argv[1],"refusal");inject_poison=argc>1&&!strcmp(argv[1],"poison");
 setenv("REMESA_HRE_DYNAMIC","1",1);setenv("REMESA_HRE_GLES_LAB","1",1);setenv("MESA_GLES_VERSION_OVERRIDE","2.0",1);setenv("REMESA_HRE_EGL_DMABUF_LAB","1",1);setenv("REMESA_HRE_COMPOSITOR_HYBRID","1",1);setenv("REMESA_DRI_TRACE","1",1);
 mode=100;borrowed=open("/dev/null",O_RDWR|O_CLOEXEC);struct remesa_native_report report;struct pipe_screen *s=remesa_loader_hre_screen(borrowed,&report);assert(s&&!report.error);assert(!remesa_screen_enable_hre_headless(s));close(borrowed);glsl_type_singleton_init_or_ref();
 struct pipe_context *p=s->context_create(s,NULL,0);assert(p);
 struct pipe_resource *pressure=NULL,*import_shadow=NULL;
 /* EGLImage imports a full-size sampling shadow before any native scene. */
 if(large&&!sampled_fixture){struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,.width0=w,.height0=h,.depth0=1,.array_size=1,.bind=PIPE_BIND_SAMPLER_VIEW};import_shadow=s->resource_create(s,&t);assert(import_shadow);}
 if(large&&!sampled_fixture){struct pipe_resource pressure_template={.target=PIPE_BUFFER,.format=PIPE_FORMAT_R8_UNORM,.width0=9*1024*1024,.height0=1,.depth0=1,.array_size=1,.bind=PIPE_BIND_VERTEX_BUFFER};pressure=s->resource_create(s,&pressure_template);assert(pressure);}struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,.width0=w,.height0=h,.depth0=1,.array_size=1,.bind=PIPE_BIND_RENDER_TARGET};struct pipe_resource *rt=s->resource_create(s,&t);assert(rt);
 struct pipe_framebuffer_state fb={.width=w,.height=h,.nr_cbufs=1,.cbufs={{.texture=rt,.format=t.format}}};p->set_framebuffer_state(p,&fb);assert(!remesa_context_error(p));
 union pipe_color_union initial={.f={120/255.f,80/255.f,40/255.f,1}};p->clear(p,PIPE_CLEAR_COLOR0,NULL,&initial,1,0);assert(!remesa_context_error(p));
 struct pipe_shader_state sh={.type=PIPE_SHADER_IR_NIR,.ir.nir=vs(sampled_fixture)};void *v=p->create_vs_state(p,&sh);assert(v);p->bind_vs_state(p,v);sh.ir.nir=fs(sampled_fixture?1:0);void *f=p->create_fs_state(p,&sh);assert(f);p->bind_fs_state(p,f);
 struct pipe_blend_state blend={.rt={{.colormask=PIPE_MASK_RGBA,.blend_enable=true,.rgb_func=PIPE_BLEND_ADD,.alpha_func=PIPE_BLEND_ADD,.rgb_src_factor=PIPE_BLENDFACTOR_ONE,.alpha_src_factor=PIPE_BLENDFACTOR_ONE,.rgb_dst_factor=PIPE_BLENDFACTOR_INV_SRC_ALPHA,.alpha_dst_factor=PIPE_BLENDFACTOR_INV_SRC_ALPHA}}};
 struct pipe_depth_stencil_alpha_state dsa={0};struct pipe_rasterizer_state rast={.depth_clip_near=true,.depth_clip_far=true,.half_pixel_center=true,.bottom_edge_rule=true};
 void *b=p->create_blend_state(p,&blend),*ds=p->create_depth_stencil_alpha_state(p,&dsa),*rs=p->create_rasterizer_state(p,&rast);assert(b&&ds&&rs);p->bind_blend_state(p,b);p->bind_depth_stencil_alpha_state(p,ds);p->bind_rasterizer_state(p,rs);
 struct pipe_viewport_state vp={.scale={w*.5f,-(float)h*.5f,.5},.translate={w*.5f,h*.5f,.5}};p->set_viewport_states(p,0,1,&vp);assert(!remesa_context_error(p));
 float u[24]={1,0,0,0,0,1,0,0,0,0,.25,0, .5,0,.5,0,0,0,.5,0,0,0,1,0},color[4]={32/255.f,64/255.f,96/255.f,128/255.f};if(sampled_fixture)color[0]=.5f;struct pipe_constant_buffer cb={.user_buffer=u,.buffer_size=sampled_fixture?96:48};p->set_constant_buffer(p,PIPE_SHADER_VERTEX,0,false,&cb);assert(!remesa_context_error(p));cb.user_buffer=color;cb.buffer_size=16;p->set_constant_buffer(p,PIPE_SHADER_FRAGMENT,0,false,&cb);assert(!remesa_context_error(p));
 float x0=2.f*x0p/w-1,x1=2.f*x1p/w-1,y0=1-2.f*y0p/h,y1=1-2.f*y1p/h;float pos[8]={x0,y0,x1,y0,x0,y1,x1,y1};t=(struct pipe_resource){.target=PIPE_BUFFER,.format=PIPE_FORMAT_R8_UNORM,.width0=sizeof(pos),.height0=1,.depth0=1,.array_size=1,.bind=PIPE_BIND_VERTEX_BUFFER};struct pipe_resource *vb=s->resource_create(s,&t);assert(vb);p->buffer_subdata(p,vb,0,0,sizeof pos,pos);struct pipe_vertex_buffer buffer={0};remesa_resource_reference(&buffer.buffer.resource,vb);p->set_vertex_buffers(p,1,&buffer);struct pipe_vertex_element el={.src_format=PIPE_FORMAT_R32G32_FLOAT,.src_stride=8};void *els=p->create_vertex_elements_state(p,1,&el);assert(els);p->bind_vertex_elements_state(p,els);
 struct pipe_resource *sample_tex=NULL;struct pipe_sampler_view *sample_view=NULL;
 if(sampled_fixture){
  t=(struct pipe_resource){.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8X8_UNORM,.width0=250,.height0=250,.depth0=1,.array_size=1,.bind=PIPE_BIND_SAMPLER_VIEW};sample_tex=s->resource_create(s,&t);assert(sample_tex);
  uint8_t *data=malloc(250*250*4);assert(data);for(unsigned y=0;y<250;y++)for(unsigned x=0;x<250;x++)memcpy(data+(y*250+x)*4,x<125?(uint8_t[]){96,64,32,17}:(uint8_t[]){16,32,64,5},4);
  const struct pipe_box texbox={.width=250,.height=250,.depth=1};p->texture_subdata(p,sample_tex,0,PIPE_MAP_WRITE,&texbox,data,1000,250000);free(data);assert(!remesa_context_error(p));
  struct pipe_sampler_view temp={.target=PIPE_TEXTURE_2D,.format=t.format,.swizzle_r=PIPE_SWIZZLE_X,.swizzle_g=PIPE_SWIZZLE_Y,.swizzle_b=PIPE_SWIZZLE_Z,.swizzle_a=PIPE_SWIZZLE_1};sample_view=p->create_sampler_view(p,sample_tex,&temp);assert(sample_view);p->set_sampler_views(p,PIPE_SHADER_FRAGMENT,0,1,0,&sample_view);assert(!remesa_context_error(p));
  struct pipe_sampler_state samp={.wrap_s=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.wrap_t=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.wrap_r=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.min_img_filter=PIPE_TEX_FILTER_NEAREST,.mag_img_filter=PIPE_TEX_FILTER_NEAREST,.min_mip_filter=PIPE_TEX_MIPFILTER_NONE};void *ss=p->create_sampler_state(p,&samp);assert(ss);p->bind_sampler_states(p,PIPE_SHADER_FRAGMENT,0,1,&ss);assert(!remesa_context_error(p));
 }
 struct pipe_draw_info info={.mode=MESA_PRIM_TRIANGLE_STRIP,.instance_count=1};struct pipe_draw_start_count_bias draw={.count=4};p->draw_vbo(p,&info,0,NULL,&draw,1);
 if(inject_refusal||inject_poison){
  assert(refusal_seen&&submissions==1&&session_drops==1&&!session_closes);
  assert(remesa_context_error(p)==(inject_poison?EOWNERDEAD:ENOSPC));
  if(inject_poison){puts("GRAPH_POISON_FAIL_CLOSED_MOCK_PASS");return 0;}
  struct pipe_box unchanged={.width=w,.height=h,.depth=1};struct pipe_transfer *tr=NULL;
  uint8_t *px=p->texture_map(p,rt,0,PIPE_MAP_READ,&unchanged,&tr);assert(px);for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++)assert(!memcmp(px+y*tr->stride+x*4,(uint8_t[]){40,80,120,255},4));p->texture_unmap(p,tr);
  p->destroy(p);assert(session_closes==1&&!session_active);drop(vb);drop(rt);drop(pressure);drop(import_shadow);s->destroy(s);glsl_type_singleton_decref();puts("GRAPH_ATOMIC_REFUSAL_NO_PUBLICATION_MOCK_PASS");return 0;
 }
 fprintf(stderr,"hybrid mock draw error=%d submissions=%u closes=%u\n",remesa_context_error(p),submissions,session_closes);assert(!remesa_context_error(p)&&submissions==tiles_per_draw&&session_closes==1);
 struct pipe_box box={.width=w,.height=h,.depth=1};struct pipe_transfer *tr=NULL;uint8_t *ptr=p->texture_map(p,rt,0,PIPE_MAP_READ,&box,&tr);assert(ptr);check_pixels(ptr,tr->stride,1);p->texture_unmap(p,tr);
 p->draw_vbo(p,&info,0,NULL,&draw,1);assert(!remesa_context_error(p)&&submissions==2*tiles_per_draw&&session_closes==2&&session_drops==submissions&&session_binds==submissions-session_opens);
 ptr=p->texture_map(p,rt,0,PIPE_MAP_READ,&box,&tr);assert(ptr);check_pixels(ptr,tr->stride,2);p->texture_unmap(p,tr);
 corrupt=true;fail_at=3*tiles_per_draw;p->draw_vbo(p,&info,0,NULL,&draw,1);assert(remesa_context_error(p)==EPROTO&&submissions==3*tiles_per_draw&&session_closes==2&&session_drops==submissions&&session_binds==submissions-session_opens);ptr=p->texture_map(p,rt,0,PIPE_MAP_READ,&box,&tr);assert(ptr);check_pixels(ptr,tr->stride,2);p->texture_unmap(p,tr);
 if(sample_view&&!--sample_view->reference.count)sample_view->context->sampler_view_destroy(sample_view->context,sample_view);
 p->destroy(p);assert(session_closes==3&&session_opens==3&&!session_active);drop(sample_tex);drop(vb);drop(rt);drop(pressure);drop(import_shadow);s->destroy(s);glsl_type_singleton_decref();if(sampled_fixture)printf("HYBRID_NPOT_XRGB_SAMPLED_TILED_MOCK_PASS %u submits\n",submissions);else if(large)printf("HYBRID_DESKTOP_TILED_MOCK_PASS %u submits, 9 MiB host pressure, late tile failure no publication\n",submissions);puts("HYBRID_GALLIUM_MOCK_PASS exact blended pixels and invalid coverage no-publication");return 0;
}
