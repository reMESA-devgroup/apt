#!/bin/bash
# Isolated root-only headless test; not a native desktop install.
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); P=${1:-$HOME/remesa-egl}
[[ $EUID == 0 ]] || exit 2
case $(dpkg-query -W -f='${Version}' remesa-hre-cross) in
 1.0~topology2.egl13) ;; *) echo 'Install EGL13 before Labwc diagnostic'; exit 2;;
esac
bash "$D/test-egl.sh" "$P" patched
bash "$P/tools/activate-v116c2.sh"
R=/opt/remesa/12.3; L=$(mktemp /tmp/remesa-labwc-egl13.XXXXXX)
export XDG_RUNTIME_DIR=$(mktemp -d /run/remesa-labwc.XXXXXX); chmod 700 "$XDG_RUNTIME_DIR"
trap 'rmdir "$XDG_RUNTIME_DIR" 2>/dev/null || :' EXIT
unset LD_PRELOAD GALLIUM_DRIVER LIBGL_ALWAYS_SOFTWARE MESA_GL_VERSION_OVERRIDE MESA_GLSL_VERSION_OVERRIDE MESA_EXTENSION_OVERRIDE MESA_NO_ERROR GBM_BACKENDS_PATH GBM_BACKEND EGL_PLATFORM DISPLAY WAYLAND_DISPLAY WLR_DRM_DEVICES
export LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 EGL_LOG_LEVEL=debug
export REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_DRI_TRACE=1 REMESA_HRE_GLES_LAB=1 MESA_GLES_VERSION_OVERRIDE=2.0 REMESA_HRE_EGL_DMABUF_LAB=1 REMESA_HRE_DUMP_REJECTED_NIR=1
export WLR_RENDERER=gles2 WLR_BACKENDS=headless WLR_HEADLESS_OUTPUTS=1
export REMESA_HRE_COMPOSITOR_PLAN=1 REMESA_HRE_COMPOSITOR_HYBRID=1 REMESA_HRE_RECEIPTS=1 REMESA_HRE_UPLOAD_REBIND=1
export REMESA_LABWC_LOG="$L"
printf 'Labwc headless diagnostic (not scanout): %s\n' "$L"
# Preserve stderr and exit status; a timeout is not automatically a pass.
set +e
timeout --signal=TERM --kill-after=5s 180s dbus-run-session -- bash "$D/run-labwc-session.sh" 2>&1 | tee "$L"
rc=${PIPESTATUS[0]}
set -e
printf 'LABWC_DIAGNOSTIC_EXIT=%s LOG=%s\n' "$rc" "$L"
grep -E 'GL_RENDERER|GL renderer|GLES2|HRE_GLES_DRAW_RESULT|HRE_NATIVE_RETIRED|compile_errno|failed|Failed|error|ERROR' "$L" | tail -60 || :
if grep -q '^HRE_NATIVE_RETIRED .*phase=9 ledger=0x7 retired=1$' "$L" && grep -q '^HRE_COMPOSITOR_HYBRID_DRAW_OK ' "$L"; then
 echo 'LABWC_GPU_SUBMISSION_EVIDENCE_PRESENT (inspect pixels and full log; not scanout qualification)'
else
 echo 'LABWC_GPU_SUBMISSION_NOT_PROVEN'
fi
[[ $rc == 0 ]] || exit "$rc"
grep -q "^LABWC_SERVER_ALIVE" "$L" || exit 1

grep -q '^HRE_COMPOSITOR_HYBRID_DRAW_OK ' "$L" || exit 1
if grep -q '^HRE_COMPOSITOR_HYBRID_REJECT ' "$L"; then echo LABWC_PARTIAL_DRAW_ONLY; exit 1; fi
if grep -Eq '^HRE_GLES_DRAW_RESULT errno=[1-9]|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO' "$L"; then echo LABWC_RENDER_ERRORS; exit 1; fi
grep -q '^HRE_COMPOSITOR_SESSION_BOUNDARY .*closed=1$' "$L" || exit 1
grep -q '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$L" || { echo LABWC_TEXTURE_DRAW_NOT_PROVEN; exit 1; }
grep -q '^LABWC_SHM_CLIENT_ALIVE' "$L" || exit 1
echo LABWC_HYBRID_DRAW_EVIDENCE_ONLY
