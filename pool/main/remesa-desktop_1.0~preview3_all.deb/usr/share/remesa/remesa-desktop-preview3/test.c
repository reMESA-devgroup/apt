/* SPDX-License-Identifier: MIT */
#include "nir_builder.h"
#include "remesa_compositor_nir.h"
#include "remesa_compositor_geometry.h"
#include <assert.h>
#include <stdio.h>
static const nir_shader_compiler_options opts={0};
static nir_shader *vs(bool uv)
{
 nir_builder b=nir_builder_init_simple_shader(MESA_SHADER_VERTEX,&opts,"wlroots matrix fixture");
 nir_def *z=nir_imm_int(&b,0),*one=nir_imm_float(&b,1.0f);
 nir_def *p=nir_load_input(&b,2,32,z,.base=0,.dest_type=nir_type_float32,.io_semantics={.location=VERT_ATTRIB_GENERIC0,.num_slots=1});
 nir_def *v=nir_vec3(&b,nir_channel(&b,p,0),nir_channel(&b,p,1),one),*dots[5];
 /* nir_channel is mov; use direct swizzles for exact captured vec3. */
 for(unsigned j=0;j<(uv?5:3);j++){
  unsigned base=j<3?0:3,off=j<3?j:j-3;
  nir_def *a=nir_load_uniform(&b,3,32,nir_iadd(&b,z,nir_imm_int(&b,off)),.base=base,.range=3,.dest_type=nir_type_float32);
  dots[j]=nir_fdot3(&b,v,a);
 }
 nir_store_output(&b,nir_vec4(&b,dots[0],dots[1],dots[2],one),z,.write_mask=15,.src_type=nir_type_float32,.io_semantics={.location=VARYING_SLOT_POS,.num_slots=1});
 if(uv)nir_store_output(&b,nir_vec2(&b,dots[3],dots[4]),z,.base=1,.write_mask=3,.src_type=nir_type_float32,.io_semantics={.location=VARYING_SLOT_VAR0,.num_slots=1});
 b.shader->info.io_lowered=true;return b.shader;
}
static nir_shader *fs(unsigned mode)
{
 nir_builder b=nir_builder_init_simple_shader(MESA_SHADER_FRAGMENT,&opts,"wlroots fragment fixture");
 nir_variable *out=nir_variable_create(b.shader,nir_var_shader_out,glsl_vec4_type(),"gl_FragColor");out->data.location=FRAG_RESULT_COLOR;
 nir_def *z=nir_imm_int(&b,0),*color;
 if(!mode)color=nir_load_uniform(&b,4,32,z,.base=0,.range=1,.dest_type=nir_type_float32);
 else{
  nir_variable *uv=nir_variable_create(b.shader,nir_var_shader_in,glsl_vec2_type(),"v_texcoord");uv->data.location=VARYING_SLOT_VAR0;
  nir_def *coord=nir_load_var(&b,uv);
  nir_tex_instr *t=nir_tex_instr_create(b.shader,1);t->op=nir_texop_tex;t->sampler_dim=mode==3?GLSL_SAMPLER_DIM_EXTERNAL:GLSL_SAMPLER_DIM_2D;t->coord_components=2;t->dest_type=nir_type_float32;t->src[0]=nir_tex_src_for_ssa(nir_tex_src_coord,coord);nir_def_init(&t->instr,&t->def,4,32);nir_builder_instr_insert(&b,&t->instr);color=&t->def;
  if(mode==2)color=nir_vec4(&b,nir_channel(&b,color,0),nir_channel(&b,color,1),nir_channel(&b,color,2),nir_imm_float(&b,1));
  nir_def *alpha=nir_load_uniform(&b,1,32,z,.base=0,.range=1,.dest_type=nir_type_float32);
  color=nir_fmul(&b,color,alpha);
  b.shader->info.num_textures=1;
 }
 nir_store_var(&b,out,color,15);return b.shader;
}
static int sample(void *opaque,const float uv[2],float rgba[4]){(void)opaque;assert(uv[0]==.25f&&uv[1]==.75f);memcpy(rgba,(float[]){.5f,.25f,.125f,.25f},16);return 0;}
int main(void)
{
 glsl_type_singleton_init_or_ref();
 struct rc_program p;float uniforms[24]={2,0,1,0,0,3,-1,0,0,0,.25f,0, .5f,0,.125f,0,0,.5f,.25f,0,0,0,1,0};
 for(unsigned t=0;t<2;t++){
  nir_shader *s=vs(t);int e=rc_compile(s,&p);printf("VS plan=%d\n",e);assert(!e);ralloc_free(s);
  struct rc_io io={.input={.25f,.5f},.uniforms=uniforms,.bytes=sizeof uniforms};assert(!rc_eval(&p,&io));assert(io.position[0]==1.5f&&io.position[1]==.5f&&io.position[2]==.25f&&io.position[3]==1);
  if(t)assert(io.uv[0]==.25f&&io.uv[1]==.5f);io.bytes=4;assert(rc_eval(&p,&io)==ERANGE);
 }
 for(unsigned t=0;t<4;t++){
  nir_shader *s=fs(t);int e=rc_compile(s,&p);printf("FS%u plan=%d\n",t,e);assert(!e);ralloc_free(s);
  float u[]={.5f,.25f,.125f,.75f};struct rc_io io={.varying={.25f,.75f},.uniforms=u,.bytes=sizeof u,.sample=sample};assert(!rc_eval(&p,&io));
  assert(io.color[0]==(t?.25f:.5f)&&io.color[1]==(t?.125f:.25f)&&io.color[2]==(t?.0625f:.125f)&&io.color[3]==(t==2?.5f:t?.125f:.75f));
 }
 nir_shader *s=vs(false);s->info.writes_memory=true;assert(rc_compile(s,&p)==ENOTSUP);ralloc_free(s);
 /* Full-output triangle and damage scissor, with affine UV interpolation. */
 struct rc_scratch scratch;assert(!rc_scratch_make(1280,720,&scratch));
 struct rc_vertex a[3]={{0,0,0,0},{1280,0,1,0},{0,720,0,1}};
 struct rc_triangle tri;assert(!rc_scratch_triangle(&scratch,a,100,100,900,600,&tri));assert(tri.count>=3&&tri.count%3==0);
 for(unsigned j=0;j<tri.count;j++){struct rc_native_vertex v=tri.v[j];double x=(v.p[0]+1)*scratch.width/2-scratch.x,y=(1-v.p[1])*scratch.height/2-scratch.y;assert(x>=99.99&&x<=900.01&&y>=99.99&&y<=600.01);assert(fabs(v.uv[0]-x/1280)<1e-5&&fabs(v.uv[1]-y/720)<1e-5);}
 assert(!rc_scratch_triangle(&scratch,a,1270,710,1280,720,&tri)&&!tri.count);
 assert(!rc_scratch_triangle(&scratch,a,0,0,1280,720,&tri)&&tri.count==3);
 assert(rc_scratch_make(2048,2048,&scratch));assert(rc_scratch_make(1792,1792,&scratch)==ENOTSUP);
 assert(!rc_scratch_make(64,64,&scratch)&&scratch.width==96&&scratch.height==80&&scratch.x==16&&scratch.y==8);
 assert(!rc_scratch_make(1280,720,&scratch)&&scratch.width==1472&&scratch.height==832);
 /* Exact physical fixture: clipped 56x56 logical area in a 64x64 scratch. */
 assert(!rc_scratch_make(56,56,&scratch)&&scratch.width==64&&scratch.height==64&&scratch.x==4&&scratch.y==4);
 struct rc_vertex q[3]={{3,5,.25,.25},{52,5,.25,.25},{52,50,.25,.25}};
 assert(!rc_scratch_triangle(&scratch,q,7,6,41,38,&tri)&&tri.count>=3);
 for(unsigned j=0;j<tri.count;j++){const struct rc_native_vertex *v=&tri.v[j];double x=(v->p[0]+1)*32,y=(1-v->p[1])*32;assert(x>=10.999&&x<=45.001&&y>=9.999&&y<=42.001&&v->uv[0]==.25f&&v->uv[1]==.25f);}
 float blend[4];assert(!rc_source_over((float[]){.25,.125,0,.5},(float[]){.5,.5,.5,1},true,blend));assert(blend[0]==.5&&blend[1]==.375&&blend[2]==.25&&blend[3]==1);
 nir_shader *vsh=vs(true);assert(!rc_compile(vsh,&p));ralloc_free(vsh);struct rc_vertex win;
 assert(!rc_window_vertex(&p,uniforms,sizeof uniforms,(float[]){.25,.5},(float[]){640,-360},(float[]){640,360},&win));assert(win.x==1600&&win.y==180&&win.u==.25&&win.v==.5);
 puts("COMPOSITOR_PADDED_GEOMETRY_AND_BLEND_REFERENCE_PASS (no GPU)");
 glsl_type_singleton_decref();puts("COMPOSITOR_NIR_CPU_ORACLE_PASS (2 VS, 4 FS, invalid ranges and side effects refused; no GPU)");return 0;
}
