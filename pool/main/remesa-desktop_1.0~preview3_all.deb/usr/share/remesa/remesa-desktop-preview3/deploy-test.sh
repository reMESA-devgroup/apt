#!/usr/bin/env bash
# Run as the ordinary user inside the existing ARM Linux cross-build environment.
set -Eeuo pipefail
trap 'echo "EGL34 DEPLOY FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd)
HOST=${REMESA_TEST_HOST:-gama@192.168.18.90}
PKG=remesa-desktop-preview2
ARCHIVE=${REMESA_ARCHIVE:-/sdcard/Download/$PKG.tar.gz}
DEB=remesa-hre-cross_1.0~topology2.egl34_i386.deb
MODE=${1:-release}; [[ $MODE == release || $MODE == mixed || $MODE == window || $MODE == compare || $MODE == native || $MODE == full || $MODE == candidate ]] || { echo 'Usage: bash deploy-test.sh [release|mixed|window|compare|native|full|candidate]'; exit 2; }
[[ -f $ARCHIVE ]] || { echo "Archive not found: $ARCHIVE"; exit 2; }
REMESA_BUILD_JOBS=${REMESA_BUILD_JOBS:-6} bash "$D/build-cross.sh" 2>&1 | tee "$HOME/egl34-build.log"
[[ -s $HOME/$DEB ]]
scp -O "$ARCHIVE" "$HOST:/home/gama/$PKG.tar.gz"
scp -O "$HOME/$DEB" "$HOST:/home/gama/"
# A tty is required for interactive sudo; remote commands are fixed literals.
ssh -t "$HOST" "cd \$HOME && tar -xzf $PKG.tar.gz && cd $PKG && bash qualify34.sh $MODE"
