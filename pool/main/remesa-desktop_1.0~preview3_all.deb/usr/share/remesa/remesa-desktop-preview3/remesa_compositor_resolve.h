/* SPDX-License-Identifier: MIT */
#ifndef REMESA_COMPOSITOR_RESOLVE_H
#define REMESA_COMPOSITOR_RESOLVE_H
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
/* Hybrid resolve only: COLOR and Z24X8 must be from the same authenticated,
 * retired native scratch submission. The caller owns all mappings and fences.
 * Never derives coverage from color or alpha. No triangle rasterization here. */
struct rc_resolve_plane { void *data; size_t bytes,stride; };
struct rc_resolve_desc {
 unsigned sw,sh,x,y,w,h;
 uint32_t z_hit,z_clear; /* raw low 24 bits, experimentally qualify first */
 uint8_t opacity;
 bool force_source_opaque,force_dest_opaque,blend;
};
static inline unsigned rc_mul255(unsigned a,unsigned b){return (a*b+127u)/255u;}
static inline unsigned rc_z24(const uint8_t *p){return p[0]|((unsigned)p[1]<<8)|((unsigned)p[2]<<16);}
static inline bool rc_plane_valid(struct rc_resolve_plane p,unsigned w,unsigned h){
 if(!p.data||!w||!h||w>2048||h>2048||p.stride<(size_t)w*4||p.stride>SIZE_MAX/h)return false;
 size_t n=(h-1)*p.stride+(size_t)w*4;
 return n<=p.bytes&&p.bytes<=UINTPTR_MAX-(uintptr_t)p.data;
}
static inline bool rc_plane_overlap(struct rc_resolve_plane a,struct rc_resolve_plane b){
 uintptr_t x=(uintptr_t)a.data,y=(uintptr_t)b.data;
 return x<y+b.bytes&&y<x+a.bytes;
}
static inline int rc_resolve_bgra(const struct rc_resolve_desc *d,struct rc_resolve_plane color,struct rc_resolve_plane depth,struct rc_resolve_plane dst,size_t *covered){
 if(!d||!covered||d->x>d->sw||d->w>d->sw-d->x||d->y>d->sh||d->h>d->sh-d->y||d->z_hit>0xffffffu||d->z_clear>0xffffffu||d->z_hit==d->z_clear||
    !rc_plane_valid(color,d->sw,d->sh)||!rc_plane_valid(depth,d->sw,d->sh)||!rc_plane_valid(dst,d->w,d->h)||rc_plane_overlap(color,dst)||rc_plane_overlap(depth,dst)||rc_plane_overlap(color,depth))return EINVAL;
 /* Reject unknown depth before changing any destination bytes. */
 size_t n=0;
 for(unsigned y=0;y<d->sh;y++)for(unsigned x=0;x<d->sw;x++){
  const uint8_t *z=(const uint8_t*)depth.data+(size_t)y*depth.stride+4*x;
  unsigned value=rc_z24(z);if(value==d->z_clear)continue;
  if(value!=d->z_hit||x<d->x||x-d->x>=d->w||y<d->y||y-d->y>=d->h)return EPROTO;
  n++;
 }
 for(unsigned y=0;y<d->h;y++)for(unsigned x=0;x<d->w;x++){
  const uint8_t *z=(const uint8_t*)depth.data+(size_t)(y+d->y)*depth.stride+4*(x+d->x);
  if(rc_z24(z)==d->z_clear)continue;
  const uint8_t *src=(const uint8_t*)color.data+(size_t)(y+d->y)*color.stride+4*(x+d->x);
  uint8_t *out=(uint8_t*)dst.data+(size_t)y*dst.stride+4*x;
  unsigned a=rc_mul255(d->force_source_opaque?255:src[3],d->opacity);
  for(unsigned k=0;k<4;k++){
   unsigned v=k==3?a:rc_mul255(src[k],d->opacity);
   if(d->blend)v+=rc_mul255(k==3&&d->force_dest_opaque?255:out[k],255-a);
   out[k]=(uint8_t)(v>255?255:v);
  }
  if(d->force_dest_opaque)out[3]=255;
 }
 *covered=n;return 0;
}
#endif
