# reMESA EGL34 — trusted laboratory release candidate

Incremental private Mesa 25.2.0 overlay on EGL33, i386/Bonnell, experimental EGL14 kernel only. This is **not a public production driver**. Does not replace stock Mesa, stock gma500_gfx, GRUB or the USSE compiler. The existing EGL1 cross-build tree and separately installed authenticated kernel are required. A fresh public installation is not supported by this archive.

## Build/test
From the existing normal-user cross-build environment, with archive in `/sdcard/Download`:
```
cd ~
tar -xzf /sdcard/Download/remesa-egl34-preview.tar.gz
cd remesa-egl34-preview
REMESA_BUILD_JOBS=6 bash deploy-test.sh release
```
`release` is a 120-second interactive desktop smoke test. Stop existing graphics on the target first (`sudo sv down slimski` from SSH/TTY on antiX, only if slimski is the active service); the installer refuses if a competing compositor is detected. To resume without building again on the target, run `bash qualify34.sh release` from the extracted directory. `candidate` runs 30 minutes of release desktop plus separate physical 2D and native 3D debug evidence, then attempts the nonroot probe. It does not certify a public release. Keep the same apps and drag workload for comparable measurements. Closing the panel or compositor early can fail qualification. No automatic reboot or GRUB edits.

## Changes
- Read GPU mapping once per row into cached staging, compare there before alpha normalization. Retains every existing byte oracle and retirement check. No zero-copy claim.
- Linear BGRA replacement copies whole rows, with SSE2 alpha normalization on x86 with SSE2 and scalar fallback. All noncompatible paths unchanged. 40 slots unchanged.
- Explicit minimize/maximize bindings, Super+M, Waybar taskbar; square corners to reduce decorative complexity. Compatibility depends on installed Labwc/Waybar versions; visual validation pending.
- Existing summary-only release logging retained. Optional `sudo bash trace-events.sh 10` from a second SSH session during dragging captures an independent bounded tracefs instance if supported. `profile-events.py` reports delivery-event intervals per DRM file/CRTC; these events are not necessarily page flips or visible frames. Do not infer FPS from them. No global tracing changes.
- `sudo bash render-access.sh status|enable|revoke`: access only the authenticated experimental render node. Enable explicitly replaces existing ACLs on this node and sets group `remesa-render`, mode 0660 and invoking-user ACL. No primary KMS/input changes. Rule retained from EGL33; recheck effective access on each boot (udev/seat ACL ordering may vary). Revoke removes the explicit grant, not existing FDs or previously granted group access. Do not use for untrusted accounts.
- `bash render-probe.sh` independently tests opening and EGL/GBM admission without root. A successful probe does not grant private IOCTL access, submit GPU commands, or demonstrate hardware rendering.

## Rootless status
On experimental GRUB entry only, edit existing `remesa_gma500gfx.render_probe_unprivileged=0` to `=1` temporarily; boot with Ctrl-X/F10, then `sudo bash render-access.sh enable` and `bash render-probe.sh`. Parameter is immutable during runtime. Historical EGL14 base guards all private render-client commands with CAP_SYS_ADMIN, even via transferred FDs. Some IOCTLs also have DRM_ROOT_ONLY. Do not disable these protections. Root compositor and single-owner experimental GPU contract remain. See RELEASE-GATE.md for unresolved requirements.

## Recovery
Keep EGL33 .deb and tarball, and a known-good stock boot entry. Stop the experimental session first; if GPU completion is uncertain, reboot into known-good stock entry rather than force cleanup. After booting safe state, reinstall the previously saved private EGL33 .deb if necessary. This is not a qualified automatic rollback. Do not replace the system Mesa or enable this at login. For rootless revoke, use the explicit command above after stopping clients. No tested automatic rollback of kernel or boot configuration.

Full i386 compilation, target runs, rootless admission, tracefs availability and visual test pending. Host tests in EGL34-TEST-RESULTS.txt are mocks or isolated host checks only.
