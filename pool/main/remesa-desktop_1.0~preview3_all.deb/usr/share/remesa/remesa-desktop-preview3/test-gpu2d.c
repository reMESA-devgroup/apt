/* Host simulation of the actual compositor GPU2D orchestration.
 * The mock copies memory; it cannot attest physical execution. */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#define PIPE_TEXTURE_2D 1
#define PIPE_FORMAT_B8G8R8A8_UNORM 2
#define PIPE_MAP_WRITE 1
#define PIPE_MAP_READ 2
struct pipe_screen {int dummy;};
struct pipe_resource {unsigned target,format,width0,height0,depth0,array_size;};
struct resource {struct pipe_resource base;struct {uint64_t resource_cookie,content_epoch;} pass;size_t bytes;bool has_contents;uint8_t *data;};
struct pipe_context {struct pipe_screen *screen;};
struct context {struct pipe_context base;struct pipe_context *compositor_scratch;struct {void *owner;} owned_texture_scene;bool failed_submission,egl31_copy_active;struct pipe_resource *egl31_src,*egl31_dst;uint64_t egl31_cookie,egl31_epoch,native_copies;struct pipe_resource *egl32_spare;uint64_t egl32_spare_cookie,egl32_spare_epoch;int error;};
struct screen {struct pipe_screen base;bool native_copy;};
struct pipe_box {int x,y,width,height,depth;};
struct pipe_transfer {size_t stride;struct resource *res;bool write;};
struct egl26_blit_plan {double u,v,du,dv;bool unit;};
static struct context *c(struct pipe_context *p){return (struct context*)p;}
static struct screen *s(struct pipe_screen *p){return (struct screen*)p;}
static struct resource *r(struct pipe_resource *p){return (struct resource*)p;}
static unsigned uploads,requests,corrupt,refuse,uncertain;static uint64_t clk;
static uint64_t egl22_now_us(void){return ++clk;}
static struct pipe_resource *create_resource_impl(struct pipe_screen *p,const struct pipe_resource *t,bool force,bool host){(void)p;(void)force;(void)host;struct resource *b=calloc(1,sizeof(*b));assert(b);b->base=*t;b->bytes=(size_t)t->width0*t->height0*4;b->data=calloc(1,b->bytes);assert(b->data);return &b->base;}
static void remesa_resource_reference(struct pipe_resource **p,struct pipe_resource *v){assert(!v);if(*p){free(r(*p)->data);free(*p);}*p=NULL;}
static void texture_subdata(struct pipe_context *p,struct pipe_resource *b,unsigned l,unsigned usage,const struct pipe_box *box,const void *data,unsigned stride,uintptr_t layer){(void)l;(void)usage;(void)layer;for(int y=0;y<box->height;y++)memcpy(r(b)->data+(size_t)y*b->width0*4,(const uint8_t*)data+(size_t)y*stride,(size_t)box->width*4);r(b)->has_contents=true;c(p)->error=0;uploads++;}
static void *map(struct pipe_context *p,struct pipe_resource *b,unsigned l,unsigned flags,const struct pipe_box *box,struct pipe_transfer **out){(void)l;struct pipe_transfer *t=malloc(sizeof(*t));assert(t);*t=(struct pipe_transfer){b->width0*4,r(b),flags==PIPE_MAP_WRITE};*out=t;c(p)->error=0;return r(b)->data+(size_t)box->y*t->stride+(size_t)box->x*4;}
static void unmap(struct pipe_context *p,struct pipe_transfer *t){if(t->write)t->res->has_contents=true;free(t);c(p)->error=0;}
static void copy_region(struct pipe_context *p,struct pipe_resource *dst,unsigned dl,unsigned dx,unsigned dy,unsigned dz,struct pipe_resource *src,unsigned sl,const struct pipe_box *b){(void)dl;(void)dz;(void)sl;assert(c(p)->egl31_copy_active);requests++;if(uncertain){c(p)->error=EOWNERDEAD;c(p)->failed_submission=true;return;}c(p)->error=0;if(refuse)return;for(int y=0;y<b->height;y++)memcpy(r(dst)->data+((size_t)(dy+y)*dst->width0+dx)*4,r(src)->data+((size_t)(b->y+y)*src->width0+b->x)*4,(size_t)b->width*4);if(corrupt)r(dst)->data[0]^=1;c(p)->native_copies++;}
#include "remesa_egl34_rows.h"
#include "gpu2d.inc"
int main(void){
 struct screen sc={.native_copy=true};struct context ctx={.base.screen=&sc.base};struct resource in={.base={.width0=128,.height0=128},.pass={7,1},.bytes=128*128*4};in.data=malloc(in.bytes);assert(in.data);for(size_t i=0;i<in.bytes;i++)in.data[i]=(uint8_t)(i*7+i/17);
 uint8_t dst[64*64*4];struct egl26_blit_plan plan={.u=3.5,.v=4.5,.du=1,.dv=1,.unit=true};bool used;unsigned x,y;
 assert(egl31_copy_coords(&plan,128,128,64,64,&x,&y)&&x==3&&y==4);assert(!egl31_copy_coords(&plan,128,128,8,512,&x,&y));struct egl26_blit_plan bad=plan;bad.u=3.25;assert(!egl31_copy_coords(&bad,128,128,64,64,&x,&y));bad=plan;bad.dv=-1;assert(!egl31_copy_coords(&bad,128,128,64,64,&x,&y));
 assert(!setenv("REMESA_HRE_EGL31_GPU2D","1",1));
 #define RUN(rgba,opaque,dest,blend,opacity) egl31_gpu2d(&ctx.base,&in.base,&plan,in.data,512,dst,256,64,64,rgba,opaque,dest,blend,opacity,&used)
 assert(!RUN(false,true,true,true,255)&&used&&uploads==1&&requests==1);for(unsigned j=0;j<64;j++)for(unsigned i=0;i<64;i++){assert(!memcmp(dst+(j*64+i)*4,in.data+((j+4)*128+i+3)*4,3));assert(dst[(j*64+i)*4+3]==255);}
 assert(!RUN(false,true,true,true,255)&&used&&uploads==1&&requests==2);in.pass.content_epoch++;assert(!RUN(false,true,true,true,255)&&used&&uploads==2&&requests==3);
 assert(!RUN(true,true,true,true,255)&&!used&&requests==3);assert(!RUN(false,false,true,true,255)&&!used&&requests==3);assert(!RUN(false,true,true,true,128)&&!used&&requests==3);
 refuse=1;assert(!RUN(false,true,true,true,255)&&!used&&requests==4);refuse=0;corrupt=1;assert(RUN(false,true,true,true,255)==EPROTO&&!used);corrupt=0;uncertain=1;assert(RUN(false,true,true,true,255)==EOWNERDEAD&&!used&&ctx.failed_submission&&!ctx.egl31_copy_active);assert(!RUN(false,true,true,true,255)&&!used);
 /* Recover only the mock after checking the poison guard; actual context
  * remains quarantined. Alternate two distinct textures and change epoch. */
 ctx.failed_submission=false;ctx.error=0;uncertain=0;
 assert(!setenv("REMESA_HRE_EGL32_CACHE2","1",1));
 unsigned u0=uploads;in.pass.resource_cookie=8;
 assert(!RUN(false,true,true,true,255)&&used&&uploads==u0+1);
 in.pass.resource_cookie=7;assert(!RUN(false,true,true,true,255)&&used&&uploads==u0+1);
 in.pass.resource_cookie=8;assert(!RUN(false,true,true,true,255)&&used&&uploads==u0+1);
 in.pass.content_epoch++;assert(!RUN(false,true,true,true,255)&&used&&uploads==u0+2);
 remesa_resource_reference(&ctx.egl32_spare,NULL);
 remesa_resource_reference(&ctx.egl31_src,NULL);remesa_resource_reference(&ctx.egl31_dst,NULL);free(in.data);puts("EGL32_CACHE2_ALTERNATE_EPOCH_PASS");puts("EGL31_GPU2D_COORDS_CACHE_ORACLE_REFUSAL_POISON_MOCK_PASS");return 0;
}
