# EGL31 — GPU HYBRID qualification
Based on EGL30. This is an incremental private i386 Mesa overlay, not a kernel release. Existing stock components, permissions, USSE subset and 40-slot cap are unchanged.

## Actual physical 2D route (experimental)
The existing native copy callback accepts typed, synchronous requests with authenticated retirement. The compositor previously never used it for its host textures. `--gpu-mixed` allows a single rectangle of at least 4096 pixels, exact positive 1:1 UV mapping, no clamping, BGRA storage, full opacity, and replacement semantics. Width/height 8 are excluded by the typed ABI. A maximum of two additional private GEMs (each limited to 4 MiB of source pixel data, plus alignment) are retained per context, with source epoch and resource cookie invalidation. The existing checked copy_region path is admitted only for this private pair; arbitrary transfer resources are not newly admitted. CPU readback verifies every copied byte before writing the staging target. Alpha normalization retains the existing semantics. A known unsupported copy may use CPU, but is not a 2D receipt. An uncertain copy fails closed and retains the context/GEMs; no replay or partial external publication. This staged experiment still needs upload/readback and is not zero-copy scanout or a performance guarantee. Kernel ABI limits and simultaneous 3D owner exclusion are unchanged.

## Native 3D
Existing physical SGX535 raster, persistent graph, DPM reuse, native texture cache, adaptive scratch, wide tiles, and exact COLOR/Z24 guard validation are preserved. New fast replacement resolve copies rows directly after that complete oracle and avoids the second Z scan. For a single fully replacing rectangle with opacity 255, direct staging does not import old destination pixels. Translucent blending retains the old import/resolve path. Host-sync DMA transfer is enabled in --native3d. No new general shaders or unprivileged EGL admission. Terminal direct CLOSE is still a separate physical experiment.

## Run
From the existing ARM cross-build environment:
    REMESA_BUILD_JOBS=6 bash deploy-test.sh full
Full: EGL30-compatible window baseline, experimental mixed desktop, native-only Foot, native-only Foot + terminal direct CLOSE. Stops on first failure. Modes mixed, native, window, compare are also available. Drag/resize opaque windows during mixed test. Mixed success requires a physical 2D receipt plus publication, not a CPU fallback. Native success requires a physical 3D retirement and sampled hybrid draw. No guarantee that the mixed desktop will itself exercise 3D; the separate native test qualifies it.

On Mini 12 after installing:
    sudo bash desktop/run.sh --stage desktop --seconds 120 --gpu-mixed --hardware-cursor
    sudo bash desktop/run.sh --stage foot --seconds 60 --native3d --hardware-cursor
    sudo python3 profile31.py /tmp/remesa-egl19-desktop.<log>

Return to --window-turbo if staging is slower; do not continue after uncertain GPU work. Physical 2D/3D counters are separate. All timers exclude KMS frame presentation. The staged route is a qualification step towards direct GPU scanout; not a claim of 60 FPS. Full Mesa i386 compilation and physical validation remain pending.
