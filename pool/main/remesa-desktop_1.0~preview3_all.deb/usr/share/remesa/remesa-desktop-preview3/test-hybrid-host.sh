#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); M=$(realpath "$1"); B=$M/build-native-probe-v116; G=$B/generated; A=$M/src/gallium/drivers/sgx535; O=$D/overlay/src/gallium/drivers/sgx535
C=(-std=c11 -D_GNU_SOURCE -DHAVE_ENDIAN_H -DHAVE_SECURE_GETENV -DHAVE_PTHREAD -DHAVE_STRUCT_TIMESPEC -DREMESA_WITH_MESA_HEADERS -DREMESA_WITH_NIR -I"$O" -I"$D" -I"$A" -I"$A/include" -I"$A/tests" -I"$M/include" -I"$M/src" -I"$M/src/gallium/include" -I"$M/src/gallium/auxiliary" -I"$M/src/compiler" -I"$M/src/compiler/nir" -I"$G/compiler/nir" -I"$G/compiler" -I"$G" -I"$M/include/drm-uapi" -O1 -g -ffunction-sections -fdata-sections)
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cc "${C[@]}" -c "$O/remesa_screen.c" -o "$T/screen.o"
cc "${C[@]}" -c "$O/remesa_persistent.c" -o "$T/persistent.o"
cp "$A/remesa_linux_memory.c" "$T/linux-memory.c"
cc "${C[@]}" -c "$T/linux-memory.c" -o "$T/linux-memory.o"
cc "${C[@]}" -Wl,--gc-sections -Wl,--wrap=ioctl -Wl,--wrap=remesa_dri_probe_fd "$D/test-hybrid-mock.c" "$T/screen.o" "$T/persistent.o" "$T/linux-memory.o" "$B/lib.a" -lm -pthread -o "$T/test"
"$T/test"

"$T/test" physical64

"$T/test" desktop

"$T/test" sampled

"$T/test" refusal
"$T/test" poison
