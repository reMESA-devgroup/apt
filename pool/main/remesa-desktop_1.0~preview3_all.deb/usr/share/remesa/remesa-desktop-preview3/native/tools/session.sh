#!/bin/bash
set -euo pipefail
D=${1:?}; B=${2:?}; CARD=${3:?}; L=${REMESA_LABWC_LOG:?}
compositor='' client='' watcher=''
stop(){ local p=${1:-}; [[ -n $p ]] || return 0; kill -TERM "$p" 2>/dev/null || :; wait "$p" 2>/dev/null || :; }
cleanup(){ stop "$client"; stop "$watcher"; stop "$compositor"; }
trap cleanup EXIT
trap 'exit 143' TERM INT
labwc -C "$D/config" -d & compositor=$!
socket=''
for i in $(seq 1 120); do
 kill -0 "$compositor" 2>/dev/null || { echo EGL15_COMPOSITOR_EXITED; wait "$compositor" || exit $?; exit 1; }
 for f in "$XDG_RUNTIME_DIR"/wayland-*; do [[ -S $f ]] && { socket=${f##*/}; break; }; done
 [[ -n $socket ]] && break; sleep .5
done
[[ -n $socket ]] || { echo EGL15_SOCKET_TIMEOUT; exit 1; }
export WAYLAND_DISPLAY="$socket"
echo "EGL15_NATIVE_SOCKET $socket"
grep -Eq 'GL renderer: reMESA .*SGX535' "$L" || { echo EGL15_HRE_RENDERER_NOT_SELECTED; exit 1; }
"$B/kms-probe" watch "$CARD" & watcher=$!
sleep .5
kill -0 "$watcher" 2>/dev/null || { echo EGL15_WATCH_FAILED; exit 1; }
# Use the same trusted local SHM client as the qualified EGL14 path.
# Do not launch general desktop applications with elevated privileges.
weston-simple-shm & client=$!
for i in $(seq 1 300); do
 kill -0 "$compositor" 2>/dev/null || { echo EGL15_COMPOSITOR_EXITED; exit 1; }
 kill -0 "$watcher" 2>/dev/null || { echo EGL15_WATCH_FAILED; exit 1; }
 kill -0 "$client" 2>/dev/null || { echo EGL15_CLIENT_EXITED; exit 1; }
 if grep -Eqi '^HRE_TILE_FAIL |^HRE_COMPOSITOR_HYBRID_REJECT |^HRE_COMPOSITOR_SESSION_CLOSE_FAIL |^HRE_GLES_DRAW_RESULT errno=[1-9]|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO|step=hre-native-owner errno=16' "$L"; then echo EGL15_DRAW_FAILED; exit 1; fi
 if [[ $(grep -c '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$L" || :) -ge 2 && $(grep -c '^EGL15_KMS_FB_CHANGE ' "$L" || :) -ge 2 ]]; then
  echo "EGL15_CLIENT_ALIVE pid=$client"; echo 'EGL15_OBSERVE_PANEL: animated SHM window should be visible';
  # Leave a short observation window; keep the KMS watcher running.
  sleep 5
  kill -0 "$compositor" && kill -0 "$client" && kill -0 "$watcher" || exit 1
  stop "$client"; client=''; stop "$watcher"; watcher=''
  kill -TERM "$compositor"; rc=0; wait "$compositor" || rc=$?; compositor=''
  [[ $rc == 0 ]] || { echo "EGL15_COMPOSITOR_SHUTDOWN_ERROR rc=$rc"; exit 1; }
  echo EGL15_CLEAN_SHUTDOWN; exit 0
 fi
 sleep .5
done
echo EGL15_NATIVE_EVIDENCE_TIMEOUT; exit 1
