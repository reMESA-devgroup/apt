#!/bin/bash
# EGL15 stage 1: use authenticated EGL14 boot, same Mesa EGL13 runtime.
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID == 0 ]] || { echo 'Run sudo bash run.sh on the EGL14 experimental boot'; exit 2; }
case ${1:-native} in native|--preflight) ;; *) echo 'Usage: sudo bash run.sh [--preflight]'; exit 2;; esac
[[ $(dpkg-query -W -f='${Version}' remesa-hre-cross) == '1.0~topology2.egl34' ]] || { echo 'Expected EGL34 runtime'; exit 2; }
R=/opt/remesa/12.3
for f in "$R/lib/libEGL.so.1" "$R/lib/libgbm.so.1"; do [[ -e $f ]] || { echo "Missing $f"; exit 2; }; done
for cmd in cc labwc dbus-run-session timeout weston-simple-shm; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 2; }; done
# Never choose a different GPU or module.
cards=(); for d in /sys/class/drm/card[0-9]*; do
 [[ ${d##*/} =~ ^card[0-9]+$ && -r $d/device/vendor && -r $d/device/device ]] || continue
 [[ $(cat "$d/device/vendor") == 0x8086 && $(cat "$d/device/device") == 0x8108 && $(basename "$(readlink -f "$d/device/driver/module")") == remesa_gma500gfx && -c /dev/dri/${d##*/} ]] && cards+=("/dev/dri/${d##*/}")
done
[[ ${#cards[@]} == 1 ]] || { echo 'Expected exactly one reMESA primary DRM node'; exit 2; }
CARD=${cards[0]}
# Capture the six lab gates before activation; restore only after a normal
# process exit, never turn them off while Labwc is still running.
P=/sys/module/remesa_gma500gfx/parameters
GATES=(memory hre_dynamic matrix_submit texture_graph texture_qualify twod_copy)
old=(); for gate in "${GATES[@]}"; do old+=("$(cat "$P/remesa_${gate}_enabled")"); done
B=''; RT=''; activated=0
cleanup(){
 if [[ $activated == 1 ]] && ! pgrep -x 'labwc|Xwayland' >/dev/null; then
  for i in "${!GATES[@]}"; do printf '%s\n' "${old[i]}" > "$P/remesa_${GATES[i]}_enabled" || :; done
 fi
 [[ -z $B ]] || rm -rf -- "$B"
 [[ -z $RT ]] || rm -rf -- "$RT"
}
trap cleanup EXIT
bash "$D/tools/activate.sh"
activated=1
B=$(mktemp -d /tmp/remesa-egl15-bin.XXXXXX); RT=$(mktemp -d /run/remesa-egl15.XXXXXX)
chmod 700 "$RT"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 -fPIC -shared -fvisibility=hidden "$D/allocator/allocator.c" -o "$B/remesa_alloc_gbm.so"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/tools/kms-probe.c" -o "$B/kms-probe"
for v in ${!REMESA_@}; do unset "$v"; done
unset LD_PRELOAD GALLIUM_DRIVER LIBGL_ALWAYS_SOFTWARE MESA_GL_VERSION_OVERRIDE MESA_GLSL_VERSION_OVERRIDE MESA_EXTENSION_OVERRIDE MESA_NO_ERROR GBM_BACKENDS_PATH GBM_BACKEND EGL_PLATFORM DISPLAY WAYLAND_DISPLAY WLR_DRM_DEVICES WLR_RENDERER_ALLOW_SOFTWARE WLR_HEADLESS_OUTPUTS WLR_RENDERER WLR_BACKENDS LIBSEAT_BACKEND
export REMESA_GBM_ALLOCATOR_ONLY=1 REMESA_GBM_NATIVE_SCANOUT=1
PL=$(mktemp /tmp/remesa-egl15-preflight.XXXXXX)
echo "EGL15 preflight: $PL"
"$B/kms-probe" preflight "$CARD" 2>&1 | tee "$PL"
[[ $(grep -c '^EGL15_ADDFB2_PASS ' "$PL" || :) == 2 ]] || exit 1
echo EGL15_PUBLIC_SCANOUT_BUFFER_PREFLIGHT_PASS
[[ ${1:-native} != --preflight ]] || exit 0
export XDG_RUNTIME_DIR="$RT" XDG_CONFIG_HOME="$RT/config" XDG_CONFIG_DIRS="$RT/config" XDG_SESSION_TYPE=wayland
mkdir -p "$XDG_CONFIG_HOME"
export LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 EGL_LOG_LEVEL=debug
export GBM_BACKEND=remesa_alloc GBM_BACKENDS_PATH="$B:$R/lib/gbm"
export REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_DRI_TRACE=1 REMESA_HRE_GLES_LAB=1 MESA_GLES_VERSION_OVERRIDE=2.0 REMESA_HRE_EGL_DMABUF_LAB=1
export REMESA_HRE_COMPOSITOR_PLAN=1 REMESA_HRE_COMPOSITOR_HYBRID=1 REMESA_HRE_RECEIPTS=1 REMESA_HRE_UPLOAD_REBIND=1
export WLR_RENDERER=gles2 WLR_BACKENDS=drm,libinput WLR_DRM_DEVICES="$CARD" WLR_DRM_NO_ATOMIC=1 WLR_DRM_NO_MODIFIERS=1 WLR_NO_HARDWARE_CURSORS=1 WLR_SCENE_DISABLE_DIRECT_SCANOUT=1
if [[ -S /run/seatd.sock ]]; then export LIBSEAT_BACKEND=seatd; fi
L=$(mktemp /tmp/remesa-egl15-native.XXXXXX); export REMESA_LABWC_LOG="$L"
echo "EGL15 native diagnostic: $L ($CARD)"
set +e
timeout --signal=TERM --kill-after=10s 240s dbus-run-session -- bash "$D/tools/session.sh" "$D" "$B" "$CARD" 2>&1 | tee "$L"
rc=${PIPESTATUS[0]}
set -e
echo "EGL15_NATIVE_EXIT=$rc LOG=$L"
[[ $rc == 0 ]] || exit "$rc"
bash "$D/tools/check-evidence.sh" "$L"
