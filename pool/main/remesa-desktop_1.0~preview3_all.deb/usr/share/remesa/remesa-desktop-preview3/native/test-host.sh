#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 -fPIC -shared -fvisibility=hidden "$D/allocator/allocator.c" -o "$T/remesa_alloc_gbm.so"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/allocator/test-mock.c" -Wl,--wrap=ioctl -o "$T/mock"
"$T/mock"
cc -I"$D/allocator/include" -Wall -Wextra -Werror -O2 "$D/tools/kms-probe.c" -o "$T/kms-probe"
echo EGL15_HOST_BUILD_PASS
cat > "$T/log" <<'LOG'
GL renderer: reMESA 12.3 / PowerVR SGX535
HRE_GBM_ALLOCATOR_ONLY primary=5
HRE_GBM_PUBLIC_BO 1280x800 scanout=1
HRE_NATIVE_RETIRED sequence=1 phase=9 ledger=0x7 retired=1
HRE_COMPOSITOR_SESSION_BOUNDARY tiles=1 closed=1
HRE_COMPOSITOR_HYBRID_DRAW_OK covered=576 sampled=1 blend=1 tiles=1 (native raster, CPU resolve)
HRE_COMPOSITOR_HYBRID_DRAW_OK covered=62500 sampled=1 blend=0 tiles=4 (native raster, CPU resolve)
EGL15_KMS_FB_CHANGE crtc=1 from=2 to=3
EGL15_KMS_FB_CHANGE crtc=1 from=3 to=2
EGL15_CLIENT_ALIVE pid=10
EGL15_CLEAN_SHUTDOWN
LOG
bash "$D/tools/check-evidence.sh" "$T/log" | grep -q '^EGL15_NATIVE_HRE_KMS_EVIDENCE'
sed '/^EGL15_KMS_FB_CHANGE/d' "$T/log" > "$T/no-kms"
if bash "$D/tools/check-evidence.sh" "$T/no-kms"; then exit 1; fi
printf 'HRE_GLES_DRAW_RESULT errno=22\n' >> "$T/log"
if bash "$D/tools/check-evidence.sh" "$T/log"; then exit 1; fi
for f in "$D"/*.sh "$D"/tools/*.sh; do bash -n "$f"; done
echo EGL15_EVIDENCE_FIXTURE_PASS
