#!/bin/bash
set -euo pipefail
L=${1:?log required}
if grep -Eqi '^HRE_TILE_FAIL |^HRE_COMPOSITOR_HYBRID_REJECT |^HRE_COMPOSITOR_SESSION_CLOSE_FAIL |^HRE_GLES_DRAW_RESULT errno=[1-9]|Failed to commit frame|GL_INVALID_|GL_OUT_OF_MEMORY|Failed to create FBO|step=hre-native-owner errno=16|EGL15_WATCH_FAILED|Failed to create allocator|Failed to create backend' "$L"; then echo EGL15_RENDER_OR_KMS_FAILURE; exit 1; fi
for pattern in 'GL renderer: reMESA .*SGX535' '^HRE_GBM_ALLOCATOR_ONLY ' '^HRE_GBM_PUBLIC_BO .*scanout=1$' '^HRE_NATIVE_RETIRED .*phase=9 ledger=0x7 retired=1$' '^HRE_COMPOSITOR_SESSION_BOUNDARY .*closed=1$' '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 .*native raster, CPU resolve' '^EGL15_KMS_FB_CHANGE ' '^EGL15_CLIENT_ALIVE ' '^EGL15_CLEAN_SHUTDOWN$'; do
 grep -Eq "$pattern" "$L" || { printf 'EGL15_MISSING_EVIDENCE %s\n' "$pattern"; exit 1; }
done
[[ $(grep -c '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$L" || :) -ge 2 ]] || { echo EGL15_NEED_TWO_TEXTURE_DRAWS; exit 1; }
[[ $(grep -c '^EGL15_KMS_FB_CHANGE ' "$L" || :) -ge 2 ]] || { echo EGL15_NEED_TWO_FB_CHANGES; exit 1; }
echo 'EGL15_NATIVE_HRE_KMS_EVIDENCE (root-only; CPU resolve; noirq; physical image confirmation pending)'
