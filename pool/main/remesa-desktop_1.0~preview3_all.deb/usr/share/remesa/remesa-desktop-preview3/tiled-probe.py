"""Exact XR24 desktop-size solid and NPOT sampled draw. Hardware only."""
import ctypes as C, mmap

def run(gl,base,shared,size,pitch,sync,W,H):
    P,I,U,S,PI=base.P,base.I,base.U,base.S,base.PI
    F=C.c_float; PU=C.POINTER(U)
    assert (W,H)==(1280,720)
    def call(name,ret,*types):
        base.bind(gl,name,ret,*types)
        def f(*args):
            result=getattr(gl,name)(*args);err=gl.glGetError()
            if err:raise RuntimeError(f'{name} GL error {err:#x}')
            return result
        return f
    def shader(kind,code):
        sh=call('glCreateShader',U,U)(kind);s=S(code)
        call('glShaderSource',None,U,I,C.POINTER(S),PI)(sh,1,C.byref(s),None);call('glCompileShader',None,U)(sh)
        v=I();call('glGetShaderiv',None,U,U,PI)(sh,0x8b81,C.byref(v))
        if not v.value:raise RuntimeError('tiled shader compile failed')
        return sh
    def program(vs,fs):
        v,f=shader(0x8b31,vs),shader(0x8b30,fs);pr=call('glCreateProgram',U)()
        attach=call('glAttachShader',None,U,U);attach(pr,v);attach(pr,f)
        call('glBindAttribLocation',None,U,U,S)(pr,0,b'pos');call('glLinkProgram',None,U)(pr)
        ok=I();call('glGetProgramiv',None,U,U,PI)(pr,0x8b82,C.byref(ok))
        if not ok.value:raise RuntimeError('tiled link failed')
        call('glDeleteShader',None,U)(v);call('glDeleteShader',None,U)(f)
        call('glUseProgram',None,U)(pr);return pr
    def loc(pr,name):
        a=call('glGetUniformLocation',I,U,S)(pr,name)
        if a<0:raise RuntimeError('missing uniform '+str(name))
        return a
    def matrix(pr,name,values):call('glUniformMatrix3fv',None,I,I,C.c_ubyte,C.POINTER(F))(loc(pr,name),1,0,(F*9)(*values))
    def witness(sampled):
        pixels=(C.c_ubyte*(W*H*4))();gl.glReadPixels(0,0,W,H,0x1908,0x1401,pixels)
        if gl.glGetError():raise RuntimeError('tiled readback failed')
        bg=bytes([120,80,40,255]);left=bytes([76,72,68,255]);right=bytes([92,56,28,255]);raw=bytes(pixels)
        with mmap.mmap(shared,size,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ) as buf:
            sync(shared,1)
            try:
                for y in range(H):
                    row=bg*W if not sampled or not 232<=y<488 else bg*384+left*256+right*256+bg*384
                    bgr=bytes([40,80,120,255])*W if not sampled or not 232<=y<488 else bytes([40,80,120,255])*384+bytes([68,72,76,255])*256+bytes([28,56,92,255])*256+bytes([40,80,120,255])*384
                    if raw[y*W*4:(y+1)*W*4]!=row:raise RuntimeError(f'tiled GL row mismatch y={y} sampled={sampled}')
                    if buf[y*pitch:y*pitch+W*4]!=bgr:raise RuntimeError(f'tiled DMA-BUF row mismatch y={y} sampled={sampled}')
            finally:sync(shared,5)
    bo=U();vertices=(F*8)(-1,-1,1,-1,-1,1,1,1)
    call('glGenBuffers',None,I,PU)(1,C.byref(bo));call('glBindBuffer',None,U,U)(0x8892,bo)
    call('glBufferData',None,U,C.c_ssize_t,P,U)(0x8892,C.sizeof(vertices),vertices,0x88e4)
    call('glVertexAttribPointer',None,U,I,U,C.c_ubyte,I,P)(0,2,0x1406,0,8,None);call('glEnableVertexAttribArray',None,U)(0)
    for cap in (0x0bd0,0x0b71,0x0be2,0x0c11,0x0b44):call('glDisable',None,U)(cap)
    call('glViewport',None,I,I,I,I)(0,0,W,H);draw=call('glDrawArrays',None,U,I,I);finish=call('glFinish',None)
    pr=program(b'attribute vec2 pos; uniform mat3 proj; void main(){gl_Position=vec4(vec3(pos,1.0)*proj,1.0);}',b'precision mediump float; uniform vec4 color; void main(){gl_FragColor=color;}')
    matrix(pr,b'proj',[1,0,0,0,1,0,0,0,1]);call('glUniform4f',None,I,F,F,F,F)(loc(pr,b'color'),120/255,80/255,40/255,1)
    draw(5,0,4);finish();witness(False);print('HYBRID_TILED_DESKTOP_PIXELS_PASS',flush=True)
    call('glUseProgram',None,U)(0);call('glDeleteProgram',None,U)(pr)
    tex=U();call('glGenTextures',None,I,PU)(1,C.byref(tex));call('glActiveTexture',None,U)(0x84c0);call('glBindTexture',None,U,U)(0x0de1,tex)
    for key,value in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:call('glTexParameteri',None,U,U,I)(0x0de1,key,value)
    raw=(bytes([32,64,96,17])*125+bytes([64,32,16,5])*125)*250;data=C.create_string_buffer(raw)
    call('glTexImage2D',None,U,I,I,I,I,I,U,U,P)(0x0de1,0,0x1908,250,250,0,0x1908,0x1401,data)
    pr=program(b'attribute vec2 pos; uniform mat3 proj; uniform mat3 tex_proj; varying vec2 v_texcoord; void main(){vec3 p=vec3(pos,1.0);gl_Position=vec4(p*proj,1.0);v_texcoord=(p*tex_proj).xy;}',b'precision mediump float; varying vec2 v_texcoord; uniform sampler2D tex; uniform float alpha; void main(){gl_FragColor=vec4(texture2D(tex,v_texcoord).rgb,1.0)*alpha;}')
    matrix(pr,b'proj',[512/W,0,0,0,256/H,0,0,0,1]);matrix(pr,b'tex_proj',[.5,0,.5,0,0,.5,0,0,1]);call('glUniform1i',None,I,I)(loc(pr,b'tex'),0);call('glUniform1f',None,I,F)(loc(pr,b'alpha'),.5)
    call('glEnable',None,U)(0x0be2);call('glBlendFuncSeparate',None,U,U,U,U)(1,0x0303,1,0x0303)
    draw(5,0,4);finish();witness(True);print('HYBRID_TILED_NPOT_TEXTURE_BLEND_PASS',flush=True)
    call('glDisableVertexAttribArray',None,U)(0);call('glBindBuffer',None,U,U)(0x8892,0);call('glDeleteBuffers',None,I,PU)(1,C.byref(bo));call('glUseProgram',None,U)(0);call('glDeleteProgram',None,U)(pr);call('glDeleteTextures',None,I,PU)(1,C.byref(tex))
