# EGL26 CLOUD — hybrid compositor architecture experiment

Requires the exact EGL25 overlay on the existing Mesa 25.2.0 source tree. No kernel installation or change. The package is incremental, not a complete Mesa tree. No slot-count or USSE change. The default launcher remains conservative; new paths are opt-in.

## Modes
- `--god-mode`: original EGL25 behavior for A/B reference.
- `--native-cache`: one immutable sampled upload (at most 4 MiB) per scratch context across closed sessions, keyed by screen-wide unique resource cookie, content epoch, dimensions and format. The original checked CLOSE still runs; no cross-frame native ownership. Shared CPU snapshots are compared row-by-row after synchronized read; unchanged contents do not generate new epochs. The cache occupies an existing allocator slot, not a new slot limit. It may add pressure on a full allocator; disable this mode if ENOMEM appears.
- `--blit`: explicitly CPU 2D path for host-resident level-zero textures, proven axis-aligned rectangle/UV continuity, clamp-to-edge, supported blend and swizzle, nearest scale or linear at texel centers (unit scale only). Uses normal Gallium map/unmap. Incompatible draws retain SGX535 native path. No invented GPU retirement.
- `--direct-region`: direct packed DMA-BUF read and publication for initialized uncached shared RTs (CPU or native draw). The normal destination map/unmap still commits the backing/epoch before external publication. External and GEM mappings remain disjoint. One rectangle replacing its entire damage union without blend on the CPU path skips the external read. Discarded, cached or otherwise incompatible targets fall back. A failed source/draw never publishes staged pixels; uncertain DMA-BUF END poisons the resource, just as in the existing path. External publication is not claimed atomic in the presence of an I/O failure.
- `--cloud`: God Mode + all three options above. Hardware cursor allowed as before. `--direct-scanout` is an independent wlroots request, off by default, not qualified.

## Build/test
`REMESA_BUILD_JOBS=6 bash build-cross.sh` then transfer archive and DEB. Or `bash deploy-test.sh` from this directory on Tab S7 (archive in /sdcard/Download). `bash deploy-test.sh compare` tests baseline, native cache/direct region, then cloud with the same nominal 60s foot workload. Interactive SSH/sudo passwords may be requested. No physical visual oracle is automated. Use `sudo bash desktop/run.sh --stage desktop --seconds 120 --cloud --hardware-cursor` only after foot qualification.

`sudo python3 profile26.py /tmp/remesa-egl19-desktop.XXXXXX` separates CPU texture blit, physical receipts, native cache hits, uploads, direct region transfers and timings. Draw batches are not display frames. KMS framebuffer change counts are not an FPS measurement. Configuration line is printed outside the internal log by the inherited launcher; qualification run log contains it. Use a fixed workload and identical display settings for A/B comparison.

## Validation limits
Host tests compile the actual batch planner and pixel routines using mock Gallium/native operations; direct-region helper is compiled against a real file mapping with simulated DMA-BUF sync. They do not compile the full Mesa driver or validate native-cache lifecycle on physical hardware. The full i386 build, SGX sampling/CPU equivalence, allocator pressure and actual performance remain unverified. Kernel callback ~190 ms and cross-frame persistent graph ownership are not solved in this package; it reduces how often they are needed. No 60 FPS guarantee.
