#!/usr/bin/env bash
# Opt-in only: trusted local user, experimental render node, never primary KMS.
set -Eeuo pipefail
[[ $EUID == 0 && -n ${SUDO_USER:-} && $SUDO_USER != root && $(id -u "$SUDO_USER") != 0 ]] || { echo 'Run sudo bash render-access.sh enable|revoke|status from your normal account'; exit 2; }
U=$SUDO_USER; GROUP=remesa-render; RULE=/etc/udev/rules.d/99-remesa-render.rules
case ${1:-} in enable|revoke|status) ;; *) exit 2;; esac
for cmd in setfacl getfacl groupadd usermod gpasswd udevadm runuser readlink python3; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 2; }; done
[[ -d /sys/module/remesa_gma500gfx && ! -d /sys/module/gma500_gfx ]] || { echo 'Refusing: not exclusive experimental kernel module'; exit 2; }
[[ $(cat /sys/module/remesa_gma500gfx/parameters/noirq) == Y ]] || exit 2
if grep -qw 'remesa_boot=egl34-desktop' /proc/cmdline; then
 NOTE=/boot/remesa-desktop-$(uname -r).build-id
elif grep -qw 'remesa_boot=egl14-linear' /proc/cmdline; then
 NOTE=/boot/remesa-egl14-linear-$(uname -r).build-id
else echo 'Expected authenticated experimental boot'; exit 2; fi
[[ -f $NOTE && ! -L $NOTE && $(stat -c '%u:%a' "$NOTE") == 0:600 ]] && cmp -s "$NOTE" /sys/module/remesa_gma500gfx/notes/.note.gnu.build-id || { echo 'Module build ID mismatch'; exit 2; }
nodes=(); for d in /sys/class/drm/renderD*; do
 [[ ${d##*/} =~ ^renderD[0-9]+$ && -r $d/device/vendor && -r $d/device/device ]] || continue
 [[ $(cat "$d/device/vendor") == 0x8086 && $(cat "$d/device/device") == 0x8108 && $(readlink -f "$d/device/driver/module") == /sys/module/remesa_gma500gfx && -c /dev/dri/${d##*/} && ! -L /dev/dri/${d##*/} ]] && nodes+=("/dev/dri/${d##*/}")
done
[[ ${#nodes[@]} == 1 ]] || { echo 'Expected one private render node'; exit 2; }
NODE=${nodes[0]}
if [[ $1 == status ]]; then
 printf 'node=%s boot_probe=%s\n' "$NODE" "$(cat /sys/module/remesa_gma500gfx/parameters/render_probe_unprivileged)"
 getfacl -p "$NODE"; exit 0
fi
if [[ $1 == revoke ]]; then
 setfacl -x "u:$U" "$NODE" 2>/dev/null || :
 if getent group "$GROUP" >/dev/null && id -nG "$U" | tr ' ' '\n' | grep -qx "$GROUP"; then gpasswd -d "$U" "$GROUP"; fi
 echo 'Access revoked for new sessions via this grant; existing FDs or other group/ACL access are not revoked.'
 exit 0
fi
# Refuse to replace any differently configured rule. No world-write, no KMS or input node access.
READLINK=$(command -v readlink)
[[ $READLINK == /usr/bin/readlink || $READLINK == /bin/readlink ]] || exit 2
T=$(mktemp); trap 'rm -f "$T"' EXIT
printf '%s\n' '# reMESA EGL33: trusted-user experimental render node only' \
 "SUBSYSTEM==\"drm\", KERNEL==\"renderD[0-9]*\", ATTRS{vendor}==\"0x8086\", ATTRS{device}==\"0x8108\", PROGRAM==\"$READLINK -f /sys%p/device/driver/module\", RESULT==\"/sys/module/remesa_gma500gfx\", GROUP=\"$GROUP\", MODE=\"0660\"" > "$T"
[[ ! -L $RULE ]] && { [[ ! -e $RULE ]] || cmp -s "$T" "$RULE"; } || { echo 'Existing render rule differs; inspect manually'; exit 2; }
getent group "$GROUP" >/dev/null || groupadd --system "$GROUP"
usermod -aG "$GROUP" "$U"
install -o root -g root -m 0644 "$T" "$RULE"
udevadm control --reload-rules || echo "Warning: udev reload failed; ACL still applies to current boot" >&2
# ACL provides immediate access to this node only; new group membership persists for new logins.
# Deliberately replace broad inherited ACLs on this identified lab node.
# This is an explicit opt-in; other existing clients may need reauthorization.
setfacl -b "$NODE"
chown root:"$GROUP" "$NODE"
chmod 0660 "$NODE"
setfacl -m "u:$U:rw-,o::---" "$NODE"
[[ $(stat -c '%a:%G' "$NODE") == "660:$GROUP" ]] || { echo 'Render node permissions not restricted'; exit 2; }
getfacl -p "$NODE"
P=/sys/module/remesa_gma500gfx/parameters/render_probe_unprivileged
if [[ ! -r $P || $(cat "$P") != Y ]]; then
 printf '%s\n' 'EGL34_NONROOT_OPEN_PENDING: kernel parameter is not enabled.' 'On the experimental GRUB entry only, replace remesa_gma500gfx.render_probe_unprivileged=0 with =1; reboot and run this command again.' 'This enables standard DRM admission only; private render commands are still protected.' >&2
 exit 3
fi
runuser -u "$U" -- python3 - "$NODE" <<'PY'
import os,sys
assert os.geteuid()!=0
fd=os.open(sys.argv[1],os.O_RDWR|os.O_CLOEXEC|os.O_NOFOLLOW);os.close(fd)
print('EGL34_NONROOT_OPEN_PASS',sys.argv[1], 'uid=',os.geteuid(), '(no GPU submission)')
PY
printf '%s\n' 'Experimental trusted user only. Log in again for persistent group membership.' 'IOCTL authorization and EGL/3D admission are still governed by the kernel; no checks removed.'
