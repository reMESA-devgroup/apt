#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "EGL34 QUALIFICATION FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd); cd "$D"
MODE=${1:-full}; [[ $MODE =~ ^(release|mixed|window|compare|native|full|candidate)$ ]] || exit 2
OUT=$(mktemp -d "$HOME/egl34-results.XXXXXX"); echo "RESULTS=$OUT"
sudo -v
if pgrep -x 'Xorg|Xwayland|labwc|sway|weston|kwin_wayland|slimski' >/dev/null; then echo "Stop graphics first: sudo sv down slimski (then retry qualify34.sh $MODE)"; exit 2; fi
sudo dpkg -i "$HOME/remesa-hre-cross_1.0~topology2.egl34_i386.deb"
sudo bash run.sh --preflight
if [[ $MODE == release ]]; then
 echo '=== EGL34 RELEASE (drag windows during 120 seconds) ==='
 sudo bash desktop/run.sh --stage desktop --seconds 120 --gpu-mixed --hardware-cursor --release 2>&1 | tee "$OUT/release-run.log"
 printf 'Results: %s\n' "$OUT"
 exit 0
fi
run_test(){
 local name=$1; shift; local rc=0 log
 echo "=== EGL33 TEST: $name ==="
 sudo bash desktop/run.sh "$@" 2>&1 | tee "$OUT/$name-run.log" || rc=$?
 log=$(sed -n 's/^EGL19_DESKTOP_EXIT=[0-9]* LOG=\(\/tmp\/remesa-egl19-desktop\.[[:alnum:]]*\)$/\1/p' "$OUT/$name-run.log" | tail -1)
 if [[ -n $log ]]; then sudo python3 profile32.py "$log" | tee "$OUT/$name-profile.log"; fi
 [[ $rc == 0 && -n $log ]] || { echo "FAILED $name rc=$rc (no qualification)"; return 1; }
 sudo grep -q '^EGL19_CLEAN_SHUTDOWN$' "$log"
 sudo grep -q '^HRE_EGL29_LIVE_VIEWS enabled=1$' "$log"
 if sudo grep -Eq '^HRE_EGL29B_VIEW_CAPACITY |^HRE_EGL29_VIEW_CREATE_FAIL |^HRE_EGL29_VIEW_BIND_FAIL |^HRE_EGL29_ADMISSION_FAIL ' "$log"; then echo 'View lifecycle error; qualification refused'; return 1; fi
 if [[ $name == window ]]; then
  sudo grep -q '^HRE_EGL30_SPARSE_PASS ' "$log" || { echo "No sparse batch evidence; drag/resize windows and retry"; return 1; }
 fi
 if [[ $name == cloudtail || $name == window ]]; then
  sudo grep -Eq '^HRE_EGL28_DMA .*errno=0$' "$log" || { echo 'No CLOUDTAIL DMA evidence'; return 1; }
  if sudo grep -Eq '^HRE_EGL28_DMA .*errno=[1-9][0-9]*$' "$log"; then echo 'DMA error'; return 1; fi
 fi
 if [[ $name == mixed ]]; then
  sudo grep -q "^HRE_EGL31_GPU2D_RETIRED " "$log" || { echo "No physical 2D receipt; use an opaque, unscaled window and retry"; return 1; }
  sudo grep -q "^HRE_EGL31_GPU2D_PASS " "$log"
 fi
 if [[ $name == native* ]]; then
  sudo grep -Eq '^HRE_NATIVE_RETIRED .*retired=1' "$log"
  sudo grep -Eq '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$log"
  if [[ $name == nativeclose ]]; then sudo grep -q '^HRE_EGL29_DIRECT_CLOSE_PASS ' "$log"; fi
 fi
 echo "EGL33 TEST PASS $name (not a frame-rate certification)"
}
if [[ $MODE == candidate ]]; then
 echo '=== EGL34 30-minute interactive release soak ==='
 sudo bash desktop/run.sh --stage desktop --seconds 1800 --gpu-mixed --hardware-cursor --release 2>&1 | tee "$OUT/release-run.log"
 grep -q '^EGL33_RELEASE_PASS ' "$OUT/release-run.log"
 grep -Eq '^EGL33_RELEASE_SUMMARY .*gpu2d_rects=[1-9][0-9]* ' "$OUT/release-run.log"
 run_test mixed --stage desktop --seconds 120 --gpu-mixed --hardware-cursor --debug
 run_test native --stage foot --seconds 60 --native3d --hardware-cursor --debug
 probe_rc=0; bash render-probe.sh 2>&1 | tee "$OUT/nonroot-probe.log" || probe_rc=$?
 echo "EGL34_NONROOT_PROBE_RC=$probe_rc (opening/configs only; no GPU work)"
 echo 'EGL34_TRUSTED_LAB_QUALIFICATION_PASS (visual review pending; not public release clearance)'
 echo 'PUBLIC_RELEASE_BLOCKED: unprivileged private IOCTL isolation, real frame timing, clean install and rollback qualification pending.'
 printf 'Results: %s\n' "$OUT"
 exit 0
fi
if [[ $MODE == compare ]]; then run_test cloudtail --stage desktop --seconds 120 --cloudtail --hardware-cursor; fi
if [[ $MODE == window || $MODE == compare || $MODE == full ]]; then run_test window --stage desktop --seconds 120 --window-turbo --hardware-cursor; fi
if [[ $MODE == mixed || $MODE == full ]]; then
 run_test mixed --stage desktop --seconds 120 --gpu-mixed --hardware-cursor
fi
if [[ $MODE == native || $MODE == full ]]; then
 run_test native --stage foot --seconds 60 --native3d --hardware-cursor
 run_test nativeclose --stage foot --seconds 60 --native3d --direct-close --hardware-cursor
fi
printf 'Results: %s\n' "$OUT"
