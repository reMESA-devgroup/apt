#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
python3 - "$D" "$T" <<'PY'
from pathlib import Path
import sys
p,t=map(Path,sys.argv[1:]); s=next((p/'overlay').rglob('remesa_compositor_live.inc')).read_text(); a=s.index('static bool egl31_copy_coords');b=s.index('/* EGL31_GPU2D_END */');(t/'gpu2d.inc').write_text(s[a:b])
PY
cc -std=c11 -D_POSIX_C_SOURCE=200809L -O2 -Wall -Wextra -Werror -I"$T" -I"$D/overlay/src/gallium/drivers/sgx535" "$D/test-gpu2d.c" -lm -o "$T/test"
"$T/test"
