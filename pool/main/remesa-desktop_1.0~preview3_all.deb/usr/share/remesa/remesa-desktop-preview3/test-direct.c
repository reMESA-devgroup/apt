#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <assert.h>
#define RC_MAX 96
#define RC_NONE 255
/* Four lanes per register. Explicit component/swizzle references. */
enum rc_op { RC_CONST,RC_INPUT,RC_UNIFORM,RC_ADD_I,RC_ADD_F,RC_MUL,RC_DOT3,RC_MOV,RC_VEC,RC_TEX,RC_STORE };
struct rc_ref { uint8_t reg,lane; };
struct rc_ins { enum rc_op op; uint8_t dst,n,slot; struct rc_ref a[4],b[4]; uint32_t bits[4]; };
struct rc_program { unsigned count,regs,stage,outputs; struct rc_ins ins[RC_MAX]; };
struct rc_io { float input[4],varying[2],position[4],uv[2],color[4]; const void *uniforms; size_t bytes; int (*sample)(void *,const float[2],float[4]); void *opaque; };

static int rc_eval(const struct rc_program *p,struct rc_io *io){(void)p;(void)io;return ENOTSUP;}
static const struct rc_ins *hybrid_def(const struct rc_program *p,struct rc_ref ref)
{
 for(unsigned j=0;j<p->count;j++)if(p->ins[j].dst==ref.reg&&ref.lane<p->ins[j].n)return &p->ins[j];
 return NULL;
}
static struct rc_ref hybrid_unmov(const struct rc_program *p,struct rc_ref ref)
{ for(unsigned j=0;j<RC_MAX;j++){const struct rc_ins *i=hybrid_def(p,ref);if(!i||i->op!=RC_MOV)break;ref=i->a[ref.lane];}return ref;}
static bool hybrid_ref_equal(struct rc_ref a,struct rc_ref b){return a.reg==b.reg&&a.lane==b.lane;}
/* Recognize only the observed sampled FS expression: tex(UV) * alpha, or
 * vec4(tex.rgb,1) * alpha. The proof uses SSA dependencies, not shader names,
 * a hash, or numerical probes of an arbitrary expression. */
static int hybrid_fragment(const struct rc_program *p,const void *u,size_t n,
 uint8_t rgba[4],bool *sampled,bool *opaque,uint8_t *opacity)
{
 const struct rc_ins *store=NULL,*tex=NULL;unsigned textures=0;
 for(unsigned j=0;j<p->count;j++){
  if(p->ins[j].op==RC_TEX){tex=&p->ins[j];textures++;}
  if(p->ins[j].op==RC_STORE)store=&p->ins[j];
 }
 if(!store||store->n!=4||textures>1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=1\n"),ENOTSUP);
 *sampled=!!textures;*opaque=false;*opacity=255;
 if(!textures){
  for(unsigned j=0;j<p->count;j++)if(p->ins[j].op==RC_INPUT)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=2\n"),ENOTSUP);
  struct rc_io io={.uniforms=u,.bytes=n};int e=rc_eval(p,&io);if(e)return e;
  for(unsigned k=0;k<4;k++){if(io.color[k]<0||io.color[k]>1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=3\n"),ENOTSUP);rgba[k]=(uint8_t)lroundf(io.color[k]*255);}
  return 0;
 }
 const struct rc_ins *in=hybrid_def(p,tex->a[0]);
 if(!in||in->op!=RC_INPUT||tex->a[0].lane!=0||tex->a[1].reg!=in->dst||tex->a[1].lane!=1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=4\n"),ENOTSUP);
 /* A direct sample (or RGB sample with constant alpha one) is the
  * same carrier operation with unit opacity. Prove each output lane. */
 bool direct=true, direct_opaque=false;
 for(unsigned k=0;k<4;k++){
  struct rc_ref a=hybrid_unmov(p,store->a[k]);
  const struct rc_ins *v=hybrid_def(p,a);
  if(v&&v->op==RC_VEC){a=hybrid_unmov(p,v->a[a.lane]);v=hybrid_def(p,a);}
  if(v==tex&&a.lane==k)continue;
  if(k==3&&v&&v->op==RC_CONST&&v->bits[a.lane]==0x3f800000u){direct_opaque=true;continue;}
  direct=false;break;
 }
 if(direct){*opaque=direct_opaque;*opacity=255;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL17_DIRECT_SAMPLE opaque=%u\n",(unsigned)direct_opaque);
  return 0;}
 const struct rc_ins *mul=hybrid_def(p,store->a[0]);
 if(!mul||mul->op!=RC_MUL||mul->n!=4)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=5\n"),ENOTSUP);
 for(unsigned k=0;k<4;k++)if(store->a[k].reg!=mul->dst||store->a[k].lane!=k)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=6\n"),ENOTSUP);
 for(unsigned swap=0;swap<2;swap++){
  const struct rc_ref *src=swap?mul->b:mul->a,*factor=swap?mul->a:mul->b;
  const struct rc_ins *f=hybrid_def(p,factor[0]);
  if(!f||f->op!=RC_UNIFORM||f->n!=1||factor[0].lane)continue;
  bool ok=true;for(unsigned k=1;k<4;k++)if(!hybrid_ref_equal(factor[k],factor[0]))ok=false;
  const struct rc_ins *off=hybrid_def(p,f->a[0]);
  if(!ok||!off||off->op!=RC_CONST||off->bits[f->a[0].lane]>=f->bits[0])continue;
  uint64_t pos=((uint64_t)f->slot+off->bits[f->a[0].lane])*16;
  if(pos>n||n-pos<4)continue;
  float alpha;memcpy(&alpha,(const uint8_t*)u+pos,4);if(!isfinite(alpha)||alpha<0||alpha>1)continue;
  const struct rc_ins *v=hybrid_def(p,src[0]);if(!v)continue;
  bool opq=v->op==RC_VEC;
  for(unsigned k=0;k<4;k++){
   if(src[k].reg!=v->dst||src[k].lane!=k){ok=false;break;}
   if(!opq){if(v!=tex)ok=false;}
   else if(k<3){struct rc_ref a=hybrid_unmov(p,v->a[k]);if(a.reg!=tex->dst||a.lane!=k)ok=false;}
   else {const struct rc_ins *one=hybrid_def(p,v->a[k]);if(!one||one->op!=RC_CONST||one->bits[v->a[k].lane]!=0x3f800000u)ok=false;}
  }
  if(ok){*opaque=opq;*opacity=(uint8_t)lroundf(alpha*255);return 0;}
 }
 return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=7\n"),ENOTSUP);
}

int main(void){struct rc_program p={.count=3};p.ins[0]=(struct rc_ins){.op=RC_INPUT,.dst=0,.n=2};p.ins[1]=(struct rc_ins){.op=RC_TEX,.dst=1,.n=4,.a={{0,0},{0,1}}};p.ins[2]=(struct rc_ins){.op=RC_STORE,.dst=RC_NONE,.n=4,.a={{1,0},{1,1},{1,2},{1,3}}};uint8_t rgba[4],opacity;bool sampled,opaque;assert(!hybrid_fragment(&p,NULL,0,rgba,&sampled,&opaque,&opacity)&&sampled&&!opaque&&opacity==255);p.ins[2].a[0].lane=1;assert(hybrid_fragment(&p,NULL,0,rgba,&sampled,&opaque,&opacity)==ENOTSUP);p.ins[2].a[0].lane=0;p.ins[3]=p.ins[2];p.ins[2]=(struct rc_ins){.op=RC_CONST,.dst=2,.n=1,.bits={0x3f800000}};p.ins[3].a[3]=(struct rc_ref){2,0};p.count=4;assert(!hybrid_fragment(&p,NULL,0,rgba,&sampled,&opaque,&opacity)&&opaque&&opacity==255);p.ins[2].bits[0]=0;assert(hybrid_fragment(&p,NULL,0,rgba,&sampled,&opaque,&opacity)==ENOTSUP);puts("EGL17_DIRECT_SAMPLE_TEST_PASS");}
