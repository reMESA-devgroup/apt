#include "remesa_compositor_resolve.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned char color[6*32],depth[6*36],dst[4*24],before[sizeof dst];
 memset(color,0,sizeof color);memset(depth,255,sizeof depth);memset(dst,0xa5,sizeof dst);
 struct rc_resolve_desc d={.sw=6,.sh=6,.x=1,.y=1,.w=4,.h=4,.z_hit=0xa00000,.z_clear=0xffffff,.opacity=128,.force_dest_opaque=true,.blend=true};
 struct rc_resolve_plane c={color,sizeof color,32},z={depth,sizeof depth,36},o={dst,sizeof dst,24};
 unsigned char *sample=color+2*32+2*4,*hit=depth+2*36+2*4,*out=dst+24+4;
 memcpy(sample,(unsigned char[]){32,64,96,128},4);memcpy(hit,(unsigned char[]){0,0,160,42},4);memcpy(out,(unsigned char[]){40,80,120,255},4);
 memcpy(before,dst,sizeof dst);size_t n=99;
 assert(!rc_resolve_bgra(&d,c,z,o,&n)&&n==1);assert(!memcmp(out,(unsigned char[]){46,92,138,255},4));
 for(size_t i=0;i<sizeof dst;i++)if(i<28||i>=32)assert(dst[i]==before[i]);
 d.force_source_opaque=true;d.blend=false;d.force_dest_opaque=false;
 assert(!rc_resolve_bgra(&d,c,z,o,&n)&&!memcmp(out,(unsigned char[]){16,32,48,128},4));
 memcpy(before,dst,sizeof dst);depth[0]=0;assert(rc_resolve_bgra(&d,c,z,o,&n)==EPROTO);assert(!memcmp(before,dst,sizeof dst));depth[0]=255;
 memcpy(depth,(unsigned char[]){0,0,160,0},4);assert(rc_resolve_bgra(&d,c,z,o,&n)==EPROTO);assert(!memcmp(before,dst,sizeof dst));memset(depth,255,4);
 assert(rc_resolve_bgra(&d,c,z,c,&n)==EINVAL);
 assert(rc_resolve_bgra(&d,c,z,(struct rc_resolve_plane){dst,8,24},&n)==EINVAL);
 puts("HRE_SCRATCH_RESOLVE_HOST_PASS (strides, opacity, source-over, XRGB, coverage, transactional refusal; no GPU)");
}
