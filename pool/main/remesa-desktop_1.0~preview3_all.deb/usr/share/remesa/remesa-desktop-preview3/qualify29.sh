#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "EGL29 QUALIFICATION FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd); cd "$D"
MODE=${1:-cloud}; [[ $MODE =~ ^(cloud|compare|native|full)$ ]] || exit 2
OUT=$(mktemp -d "$HOME/egl29-results.XXXXXX"); echo "RESULTS=$OUT"
sudo -v
sudo dpkg -i "$HOME/remesa-hre-cross_1.0~topology2.egl30_i386.deb"
sudo bash run.sh --preflight
run_test(){
 local name=$1; shift; local rc=0 log
 echo "=== EGL29 TEST: $name ==="
 sudo bash desktop/run.sh "$@" 2>&1 | tee "$OUT/$name-run.log" || rc=$?
 log=$(sed -n 's/^EGL19_DESKTOP_EXIT=[0-9]* LOG=\(\/tmp\/remesa-egl19-desktop\.[[:alnum:]]*\)$/\1/p' "$OUT/$name-run.log" | tail -1)
 if [[ -n $log ]]; then sudo python3 profile29.py "$log" | tee "$OUT/$name-profile.log"; fi
 [[ $rc == 0 && -n $log ]] || { echo "FAILED $name rc=$rc (no qualification)"; return 1; }
 sudo grep -q '^EGL19_CLEAN_SHUTDOWN$' "$log"
 sudo grep -q '^HRE_EGL29_LIVE_VIEWS enabled=1$' "$log"
 if sudo grep -Eq '^HRE_EGL29B_VIEW_CAPACITY |^HRE_EGL29_VIEW_CREATE_FAIL |^HRE_EGL29_VIEW_BIND_FAIL |^HRE_EGL29_ADMISSION_FAIL ' "$log"; then echo 'View lifecycle error; qualification refused'; return 1; fi
 if [[ $name == cloudtail ]]; then
  sudo grep -Eq '^HRE_EGL28_DMA .*errno=0$' "$log" || { echo 'No CLOUDTAIL DMA evidence'; return 1; }
  if sudo grep -Eq '^HRE_EGL28_DMA .*errno=[1-9][0-9]*$' "$log"; then echo 'DMA error'; return 1; fi
 fi
 if [[ $name == native* ]]; then
  sudo grep -Eq '^HRE_NATIVE_RETIRED .*retired=1' "$log"
  sudo grep -Eq '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$log"
  if [[ $name == nativeclose ]]; then sudo grep -q '^HRE_EGL29_DIRECT_CLOSE_PASS ' "$log"; fi
 fi
 echo "EGL29 TEST PASS $name (not a frame-rate certification)"
}
if [[ $MODE == compare || $MODE == full ]]; then run_test baseline --stage desktop --seconds 120 --cloud15 --hardware-cursor; fi
if [[ $MODE != native ]]; then run_test cloudtail --stage desktop --seconds 120 --cloudtail --hardware-cursor; fi
if [[ $MODE == native || $MODE == full ]]; then
 run_test native --stage foot --seconds 60 --native3d --hardware-cursor
 run_test nativeclose --stage foot --seconds 60 --native3d --direct-close --hardware-cursor
fi
printf 'Results: %s\n' "$OUT"
