/* SPDX-License-Identifier: MIT */
/* Explicit experimental hybrid draw: CPU vertex evaluation, existing native
 * sampled raster, CPU resolve. Never substitutes a native program silently. */
static int hybrid_constants(struct context *ctx,bool vs,uint8_t *data,size_t *n)
{
 struct pipe_resource *b=vs?ctx->vertex_constants:ctx->fragment_constants;
 unsigned bytes=vs?ctx->vertex_constant_size:ctx->constant_size;
 unsigned offset=vs?ctx->vertex_constant_offset:ctx->constant_offset;
 void *snapshot=vs?ctx->vertex_constant_snapshot:ctx->constant_snapshot;
 *n=bytes;if(bytes>(vs?256u:64u))return ENOTSUP;
 if(!bytes)return 0;
 if(snapshot&&!b){memcpy(data,snapshot,bytes);return 0;}
 if(!b||offset>r(b)->bytes||bytes>r(b)->bytes-offset)return EINVAL;
 struct pipe_box box={.x=offset,.width=bytes,.height=1,.depth=1};struct pipe_transfer *tr=NULL;
 void *ptr=map(&ctx->base,b,0,PIPE_MAP_READ,&box,&tr);if(!ptr)return ctx->error?ctx->error:EIO;
 memcpy(data,ptr,bytes);unmap(&ctx->base,tr);return r(b)->write_error;
}
static const struct rc_ins *hybrid_def(const struct rc_program *p,struct rc_ref ref)
{
 for(unsigned j=0;j<p->count;j++)if(p->ins[j].dst==ref.reg&&ref.lane<p->ins[j].n)return &p->ins[j];
 return NULL;
}
static struct rc_ref hybrid_unmov(const struct rc_program *p,struct rc_ref ref)
{ for(unsigned j=0;j<RC_MAX;j++){const struct rc_ins *i=hybrid_def(p,ref);if(!i||i->op!=RC_MOV)break;ref=i->a[ref.lane];}return ref;}
static bool hybrid_ref_equal(struct rc_ref a,struct rc_ref b){return a.reg==b.reg&&a.lane==b.lane;}
/* Recognize only the observed sampled FS expression: tex(UV) * alpha, or
 * vec4(tex.rgb,1) * alpha. The proof uses SSA dependencies, not shader names,
 * a hash, or numerical probes of an arbitrary expression. */
static int hybrid_fragment(const struct rc_program *p,const void *u,size_t n,
 uint8_t rgba[4],bool *sampled,bool *opaque,uint8_t *opacity)
{
 const struct rc_ins *store=NULL,*tex=NULL;unsigned textures=0;
 for(unsigned j=0;j<p->count;j++){
  if(p->ins[j].op==RC_TEX){tex=&p->ins[j];textures++;}
  if(p->ins[j].op==RC_STORE)store=&p->ins[j];
 }
 if(!store||store->n!=4||textures>1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=1\n"),ENOTSUP);
 *sampled=!!textures;*opaque=false;*opacity=255;
 if(!textures){
  for(unsigned j=0;j<p->count;j++)if(p->ins[j].op==RC_INPUT)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=2\n"),ENOTSUP);
  struct rc_io io={.uniforms=u,.bytes=n};int e=rc_eval(p,&io);if(e)return e;
  for(unsigned k=0;k<4;k++){if(io.color[k]<0||io.color[k]>1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=3\n"),ENOTSUP);rgba[k]=(uint8_t)lroundf(io.color[k]*255);}
  return 0;
 }
 const struct rc_ins *in=hybrid_def(p,tex->a[0]);
 if(!in||in->op!=RC_INPUT||tex->a[0].lane!=0||tex->a[1].reg!=in->dst||tex->a[1].lane!=1)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=4\n"),ENOTSUP);
 /* A direct sample (or RGB sample with constant alpha one) is the
  * same carrier operation with unit opacity. Prove each output lane. */
 bool direct=true, direct_opaque=false;
 for(unsigned k=0;k<4;k++){
  struct rc_ref a=hybrid_unmov(p,store->a[k]);
  const struct rc_ins *v=hybrid_def(p,a);
  if(v&&v->op==RC_VEC){a=hybrid_unmov(p,v->a[a.lane]);v=hybrid_def(p,a);}
  if(v==tex&&a.lane==k)continue;
  if(k==3&&v&&v->op==RC_CONST&&v->bits[a.lane]==0x3f800000u){direct_opaque=true;continue;}
  direct=false;break;
 }
 if(direct){*opaque=direct_opaque;*opacity=255;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL17_DIRECT_SAMPLE opaque=%u\n",(unsigned)direct_opaque);
  return 0;}
 const struct rc_ins *mul=hybrid_def(p,store->a[0]);
 if(!mul||mul->op!=RC_MUL||mul->n!=4)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=5\n"),ENOTSUP);
 for(unsigned k=0;k<4;k++)if(store->a[k].reg!=mul->dst||store->a[k].lane!=k)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=6\n"),ENOTSUP);
 for(unsigned swap=0;swap<2;swap++){
  const struct rc_ref *src=swap?mul->b:mul->a,*factor=swap?mul->a:mul->b;
  const struct rc_ins *f=hybrid_def(p,factor[0]);
  if(!f||f->op!=RC_UNIFORM||f->n!=1||factor[0].lane)continue;
  bool ok=true;for(unsigned k=1;k<4;k++)if(!hybrid_ref_equal(factor[k],factor[0]))ok=false;
  const struct rc_ins *off=hybrid_def(p,f->a[0]);
  if(!ok||!off||off->op!=RC_CONST||off->bits[f->a[0].lane]>=f->bits[0])continue;
  uint64_t pos=((uint64_t)f->slot+off->bits[f->a[0].lane])*16;
  if(pos>n||n-pos<4)continue;
  float alpha;memcpy(&alpha,(const uint8_t*)u+pos,4);if(!isfinite(alpha)||alpha<0||alpha>1)continue;
  const struct rc_ins *v=hybrid_def(p,src[0]);if(!v)continue;
  bool opq=v->op==RC_VEC;
  for(unsigned k=0;k<4;k++){
   if(src[k].reg!=v->dst||src[k].lane!=k){ok=false;break;}
   if(!opq){if(v!=tex)ok=false;}
   else if(k<3){struct rc_ref a=hybrid_unmov(p,v->a[k]);if(a.reg!=tex->dst||a.lane!=k)ok=false;}
   else {const struct rc_ins *one=hybrid_def(p,v->a[k]);if(!one||one->op!=RC_CONST||one->bits[v->a[k].lane]!=0x3f800000u)ok=false;}
  }
  if(ok){*opaque=opq;*opacity=(uint8_t)lroundf(alpha*255);return 0;}
 }
 return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=fragment predicate=7\n"),ENOTSUP);
}
static nir_shader *hybrid_native_shader(bool fs)
{
 static const nir_shader_compiler_options options={0};
 nir_builder b=nir_builder_init_simple_shader(fs?MESA_SHADER_FRAGMENT:MESA_SHADER_VERTEX,&options,"HRE scratch carrier");
 if(fs){
  nir_variable *uv=nir_variable_create(b.shader,nir_var_shader_in,glsl_vec2_type(),"uv");uv->data.location=VARYING_SLOT_TEX0;
  nir_variable *sampler=nir_variable_create(b.shader,nir_var_uniform,glsl_sampler_type(GLSL_SAMPLER_DIM_2D,false,false,GLSL_TYPE_FLOAT),"image");sampler->data.binding=0;
  nir_variable *out=nir_variable_create(b.shader,nir_var_shader_out,glsl_vec4_type(),"color");out->data.location=FRAG_RESULT_DATA0;
  nir_deref_instr *ds=nir_build_deref_var(&b,sampler);
  nir_store_deref(&b,nir_build_deref_var(&b,out),nir_tex_deref(&b,ds,ds,nir_load_deref(&b,nir_build_deref_var(&b,uv))),15);
 }else{
  nir_variable *pos=nir_variable_create(b.shader,nir_var_shader_in,glsl_vec4_type(),"pos");pos->data.location=VERT_ATTRIB_GENERIC0;
  nir_variable *uv=nir_variable_create(b.shader,nir_var_shader_in,glsl_vec2_type(),"uv");uv->data.location=VERT_ATTRIB_GENERIC1;
  nir_variable *out=nir_variable_create(b.shader,nir_var_shader_out,glsl_vec4_type(),"position");out->data.location=VARYING_SLOT_POS;
  nir_variable *vary=nir_variable_create(b.shader,nir_var_shader_out,glsl_vec2_type(),"uv_out");vary->data.location=VARYING_SLOT_TEX0;
  nir_store_deref(&b,nir_build_deref_var(&b,out),nir_load_deref(&b,nir_build_deref_var(&b,pos)),15);
  nir_store_deref(&b,nir_build_deref_var(&b,vary),nir_load_deref(&b,nir_build_deref_var(&b,uv)),3);
 }
 return b.shader;
}
static int hybrid_copy_read(struct pipe_context *p,struct pipe_resource *res,uint8_t *dst)
{
 struct pipe_box box={.width=res->width0,.height=res->height0,.depth=1};struct pipe_transfer *tr=NULL;
 const uint8_t *ptr=map(p,res,0,PIPE_MAP_READ,&box,&tr);if(!ptr)return c(p)->error?c(p)->error:EIO;
 for(unsigned y=0;y<res->height0;y++)memcpy(dst+(size_t)y*res->width0*4,ptr+(size_t)y*tr->stride,(size_t)res->width0*4);
 unmap(p,tr);return r(res)->write_error;
}
static uint64_t egl22_now_us(void);
static int hybrid_native_scratch(struct pipe_context *p,const struct rc_scratch *sz,
 const struct rc_native_vertex *mesh,unsigned vertices,const uint8_t rgba[4],bool sampled,
 uint8_t *pixels,uint8_t *depth,bool reuse_input,bool keep_graph)
{
 uint64_t native_start=egl22_now_us(),prepare_end=0,draw_end=0,read_end=0,drop_end=0;
 struct pipe_screen *screen=p->screen;struct pipe_context *q=c(p)->compositor_scratch;
 if(!q){q=screen->context_create(screen,NULL,0);if(!q)return ENOMEM;c(p)->compositor_scratch=q;c(q)->compositor_carrier=true;}
 struct context *qc=c(q);int e=ENOTSUP;bool staged=false;struct pipe_resource *color=NULL,*z=NULL,*vb=NULL,*tex=NULL;
 struct pipe_sampler_view *view=NULL;void *vs=NULL,*fs=NULL,*bs=NULL,*ds=NULL,*rs=NULL,*el=NULL,*ss=NULL;
 struct pipe_sampler_state sampler={.wrap_s=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.wrap_t=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.wrap_r=PIPE_TEX_WRAP_CLAMP_TO_EDGE,.min_img_filter=PIPE_TEX_FILTER_NEAREST,.mag_img_filter=PIPE_TEX_FILTER_NEAREST,.min_mip_filter=PIPE_TEX_MIPFILTER_NONE};
 /* Reuse scratch attachments; detach the retired graph before any new
  * allocation or texture upload. The graph retains its authenticated refs. */
 if(qc->target&&qc->depth_target&&qc->target->width0==sz->width&&qc->target->height0==sz->height){
  remesa_resource_reference(&color,qc->target);remesa_resource_reference(&z,qc->depth_target);
 }
 /* Reuse only inside this synchronous Gallium draw, never across clients,
  * texture epochs, or framebuffer publication. The previous tile has retired
  * and released both attachment leases; its immutable sampled input stays held. */
 if(reuse_input){
  if(!color||!z||!qc->owned_texture_scene.owner||qc->texture_graph_detached||
     qc->failed_submission||!qc->compositor_views[sampled?1:0]){e=EPROTO;goto out;}
  staged=sampled; /* release private sampled view at the group boundary */
  goto vertex_input;
 }
 if(qc->owned_texture_scene.owner){const struct pipe_framebuffer_state empty={0};framebuffer(q,&empty);if((e=qc->error))goto out;}
 struct pipe_sampler_view vt={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_R8G8B8A8_UNORM,.swizzle_r=PIPE_SWIZZLE_X,.swizzle_g=PIPE_SWIZZLE_Y,.swizzle_b=PIPE_SWIZZLE_Z,.swizzle_a=PIPE_SWIZZLE_W};
 struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,.width0=sz->width,.height0=sz->height,.depth0=1,.array_size=1,.bind=PIPE_BIND_RENDER_TARGET};
 if(!color)color=screen->resource_create(screen,&t);t.format=PIPE_FORMAT_Z24X8_UNORM;t.bind=PIPE_BIND_DEPTH_STENCIL;if(!z)z=screen->resource_create(screen,&t);
 if(!color||!z){e=ENOMEM;goto out;}
 struct pipe_framebuffer_state fb={.width=sz->width,.height=sz->height,.nr_cbufs=1,.cbufs={{.texture=color,.format=PIPE_FORMAT_B8G8R8A8_UNORM}},.zsbuf={.texture=z,.format=PIPE_FORMAT_Z24X8_UNORM}};
 framebuffer(q,&fb);if((e=qc->error))goto out;
 if(!qc->bound_vertex||!qc->bound_fragment){struct pipe_shader_state sh={.type=PIPE_SHADER_IR_NIR,.ir.nir=hybrid_native_shader(false)};
 vs=create_vertex(q,&sh);sh.ir.nir=hybrid_native_shader(true);fs=create_fragment(q,&sh);if(!vs||!fs){e=ENOTSUP;goto out;}bind_vertex(q,vs);bind_fragment(q,fs);}
 const struct pipe_blend_state blend={.rt={{.colormask=PIPE_MASK_RGBA}}};
 const struct pipe_depth_stencil_alpha_state dsa={.depth_enabled=true,.depth_writemask=true,.depth_func=PIPE_FUNC_LESS};
 const struct pipe_rasterizer_state rast={.depth_clip_near=true,.depth_clip_far=true,.half_pixel_center=true,.bottom_edge_rule=true};
 if(!qc->bound_fixed[FIXED_BLEND]||!qc->bound_fixed[FIXED_DSA]||!qc->bound_fixed[FIXED_RASTER]){bs=create_blend(q,&blend);ds=create_dsa(q,&dsa);rs=create_raster(q,&rast);if(!bs||!ds||!rs){e=ENOTSUP;goto out;}bind_blend(q,bs);bind_dsa(q,ds);bind_raster(q,rs);}
 const struct pipe_viewport_state vp={.scale={sz->width*.5f,-(float)sz->height*.5f,.5f},.translate={sz->width*.5f,sz->height*.5f,.5f}};
 viewport_state(q,0,1,&vp);if((e=qc->error))goto out;
 if(sampled){
  const struct pipe_sampler_view *src=NULL;e=remesa_texture_fragment0_view(c(p)->textures,&src);if(e)goto out;
  if(src->texture==c(p)->target){e=ENOTSUP;goto out;}
  e=remesa_sampler_fragment0_snapshot(c(p)->samplers,&sampler);if(e)goto out;
  remesa_resource_reference(&tex,src->texture);vt=*src;
  /* Resolve handles forced alpha explicitly. Native carrier samples raw
   * four channels; never advertise the untrusted X byte as GL alpha. */
  vt.swizzle_a=PIPE_SWIZZLE_W;
  if(r(tex)->shared_sampler){e=hre_refresh_sampler(p,tex);if(e)goto out;}
  struct resource *source=sample_backing(tex);
  if(source->compositor_host_texture){
   /* The CPU snapshot is authoritative. Only the private immutable copy
    * is exposed to the native descriptor; GPU references stay in the
    * ordinary scene ownership ledger until authenticated CLOSE. */
   if(source->maps||source->writer||source->write_error||!source->has_contents||
      !source->host_data||source->base.last_level){e=source->write_error?source->write_error:EBUSY;goto out;}
   struct pipe_resource upload={.target=PIPE_TEXTURE_2D,.format=tex->format,
    .width0=tex->width0,.height0=tex->height0,.depth0=1,.array_size=1,.bind=PIPE_BIND_SAMPLER_VIEW};
   struct pipe_resource *resident=NULL;
   bool cache=getenv("REMESA_HRE_EGL26_NATIVE_CACHE")&&!qc->owned_texture_scene.owner&&
     source->pass.content_epoch&&source->bytes<=4u*1024u*1024u;
   if(cache&&qc->compositor_upload_cache&&qc->compositor_upload_cookie==source->pass.resource_cookie&&
      qc->compositor_upload_epoch==source->pass.content_epoch&&qc->compositor_upload_cache->format==upload.format&&
      qc->compositor_upload_cache->width0==upload.width0&&qc->compositor_upload_cache->height0==upload.height0&&
      !r(qc->compositor_upload_cache)->write_error&&!r(qc->compositor_upload_cache)->maps&&
      !r(qc->compositor_upload_cache)->writer&&r(qc->compositor_upload_cache)->has_contents&&
      !r(qc->compositor_upload_cache)->native_clear_owner){
    remesa_resource_reference(&resident,qc->compositor_upload_cache);
    if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_NATIVE_CACHE_HIT bytes=%zu\n",source->bytes);
   }else{
    remesa_resource_reference(&qc->compositor_upload_cache,NULL);
    qc->compositor_upload_cookie=qc->compositor_upload_epoch=0;
    resident=create_resource_impl(screen,&upload,true,false);
    if(!resident){e=ENOMEM;goto out;}
    const struct pipe_box whole={.width=upload.width0,.height=upload.height0,.depth=1};
    texture_subdata(q,resident,0,PIPE_MAP_WRITE,&whole,source->host_data,source->stride,source->bytes);
    e=qc->error;
    if(e){remesa_resource_reference(&resident,NULL);goto out;}
    if(cache){remesa_resource_reference(&qc->compositor_upload_cache,resident);
     qc->compositor_upload_cookie=source->pass.resource_cookie;qc->compositor_upload_epoch=source->pass.content_epoch;}
    if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL21B_RESIDENT_UPLOAD source=%llu epoch=%llu resident=%llu bytes=%zu\n",(unsigned long long)source->pass.resource_cookie,(unsigned long long)source->pass.content_epoch,(unsigned long long)r(resident)->pass.resource_cookie,source->bytes);
   }
   remesa_resource_reference(&tex,NULL);tex=resident;staged=true;
  }else{remesa_resource_reference(&qc->compositor_upload_cache,NULL);qc->compositor_upload_cookie=qc->compositor_upload_epoch=0;}
 }else{
  remesa_resource_reference(&qc->compositor_upload_cache,NULL);qc->compositor_upload_cookie=qc->compositor_upload_epoch=0;
  t=(struct pipe_resource){.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_R8G8B8A8_UNORM,.width0=2,.height0=2,.depth0=1,.array_size=1,.bind=PIPE_BIND_SAMPLER_VIEW};
  if(qc->compositor_views[0])remesa_resource_reference(&tex,qc->compositor_views[0]->texture);
  else tex=create_resource_impl(screen,&t,true,false);
  if(!tex){e=ENOMEM;goto out;}
  uint8_t data[16];for(unsigned i=0;i<4;i++)memcpy(data+i*4,rgba,4);
  const struct pipe_box box={.width=2,.height=2,.depth=1};texture_subdata(q,tex,0,PIPE_MAP_WRITE,&box,data,8,16);if((e=qc->error))goto out;
 }
 /* Canonical sampler key: the validated native subset only consumes these
  * five bits. Other accepted fields have no effect in the native encoder. */
 e=remesa_sampler_state_validate(&sampler);if(e)goto out;
 unsigned key=(sampler.min_img_filter==PIPE_TEX_FILTER_LINEAR)|((sampler.mag_img_filter==PIPE_TEX_FILTER_LINEAR)<<1)|((sampler.wrap_s==PIPE_TEX_WRAP_REPEAT)<<2)|((sampler.wrap_t==PIPE_TEX_WRAP_REPEAT)<<3)|((sampler.wrap_r==PIPE_TEX_WRAP_REPEAT)<<4);
 ss=qc->compositor_samplers[key];if(!ss){ss=create_sampler(q,&sampler);if(!ss){e=qc->error?qc->error:ENOTSUP;goto out;}qc->compositor_samplers[key]=ss;}
 bind_samplers(q,PIPE_SHADER_FRAGMENT,0,1,&ss);if((e=qc->error))goto out;
 /* Hold a private reference as well as the binding's reference. A view
  * is immutable; reuse only an exact descriptor for the same resource. */
 unsigned slot=sampled?1:0;struct pipe_sampler_view *cached=qc->compositor_views[slot];
 if(!cached||cached->texture!=tex||cached->target!=vt.target||cached->format!=vt.format||cached->swizzle_r!=vt.swizzle_r||cached->swizzle_g!=vt.swizzle_g||cached->swizzle_b!=vt.swizzle_b||cached->swizzle_a!=vt.swizzle_a||cached->astc_decode_format!=vt.astc_decode_format||cached->is_tex2d_from_buf!=vt.is_tex2d_from_buf||memcmp(&cached->u,&vt.u,sizeof(vt.u))){
  /* This bank is exclusively scratch-owned; no frontend ever receives its
   * pointers. Retire the detached graph, then replace the private bank
   * before its bounded tombstone registry fills. The current texture has a
   * local reference; the old graph retains every backing until BIND. */
  if(qc->compositor_view_creations>=64){
   struct remesa_texture_binding_bank *fresh=remesa_texture_binding_create(screen,texture_storage,screen,NULL,NULL,NULL);
   if(!fresh){e=ENOMEM;goto out;}
   for(unsigned i=0;i<2;i++){if(qc->compositor_views[i])release_sampler_view(q,qc->compositor_views[i]);qc->compositor_views[i]=NULL;}
   remesa_texture_binding_close(qc->textures);qc->textures=fresh;qc->compositor_view_creations=0;cached=NULL;
  }
  view=create_sampler_view(q,tex,&vt);if(!view){e=qc->error?qc->error:ENOTSUP;goto out;}
  if(cached)release_sampler_view(q,cached);
  qc->compositor_views[slot]=view;qc->compositor_view_creations++;cached=view;view=NULL;
 }
 set_sampler_views(q,PIPE_SHADER_FRAGMENT,0,1,0,&cached);if((e=qc->error))goto out;
 vertex_input:;
 struct pipe_resource vertex_template=(struct pipe_resource){.target=PIPE_BUFFER,.format=PIPE_FORMAT_R8_UNORM,.width0=42u*24u,.height0=1,.depth0=1,.array_size=1,.bind=PIPE_BIND_VERTEX_BUFFER};
 if(qc->vb_count==1&&qc->vb.buffer.resource&&r(qc->vb.buffer.resource)->host_data&&qc->vb.buffer.resource->width0>=vertices*24u)
  remesa_resource_reference(&vb,qc->vb.buffer.resource);
 else vb=screen->resource_create(screen,&vertex_template);if(!vb){e=ENOMEM;goto out;}buffer_subdata(q,vb,0,0,vertices*24,mesh);if((e=qc->error))goto out;
 struct pipe_vertex_buffer vbuf={0};remesa_resource_reference(&vbuf.buffer.resource,vb);set_vb(q,1,&vbuf);if((e=qc->error))goto out;
 const struct pipe_vertex_element elems[2]={{.src_format=PIPE_FORMAT_R32G32B32A32_FLOAT,.src_stride=24},{.src_format=PIPE_FORMAT_R32G32_FLOAT,.src_stride=24,.src_offset=16}};
 if(!qc->bound_elements){el=create_elements(q,2,elems);if(!el){e=ENOTSUP;goto out;}bind_elements(q,el);}
 const struct pipe_draw_info info={.mode=MESA_PRIM_TRIANGLES,.instance_count=1};const struct pipe_draw_start_count_bias draw_info={.count=vertices};
 prepare_end=egl22_now_us();
 draw(q,&info,0,NULL,&draw_info,1);draw_end=egl22_now_us();e=qc->error;if(e)goto out;
 /* Both reads wait for authenticated retirement using the existing paired
  * attachment leases. Copy sequentially rather than assuming simultaneous leases. */
 e=hybrid_copy_read(q,color,pixels);if(!e)e=hybrid_copy_read(q,z,depth);read_end=egl22_now_us();
 /* Only retain an attached graph while another tile from this same draw
  * is guaranteed to follow. The existing managed_texture_draw state key,
  * vertex update validation, and transactional replacement still decide
  * whether the next packet can reuse the actual native graph. */
 if(!e&&!keep_graph)e=framebuffer_leave(q);drop_end=egl22_now_us();
 if(!e&&keep_graph&&(!qc->owned_texture_scene.owner||qc->texture_graph_detached))e=EPROTO;
 /* DROP alone is not permission to recycle a VA. Release the frontend
  * view only after successful readback and detach; backend graph refs keep
  * the physical BO alive until the existing per-tile CLOSE. */
 if(!e&&!keep_graph&&staged&&qc->compositor_views[1]){
  set_sampler_views(q,PIPE_SHADER_FRAGMENT,0,0,1,NULL);e=qc->error;
  if(!e){release_sampler_view(q,qc->compositor_views[1]);qc->compositor_views[1]=NULL;}
 }
 if(e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_SCRATCH_READ_OR_DROP_FAIL errno=%d\n",e);
 out:
 if(qc->failed_submission){c(p)->failed_submission=true;e=EOWNERDEAD;}
 if(view)release_sampler_view(q,view);
 remesa_resource_reference(&vb,NULL);remesa_resource_reference(&tex,NULL);remesa_resource_reference(&color,NULL);remesa_resource_reference(&z,NULL);
 /* The batch owns the bounded lifetime; never publish with an attached graph. */
 if(!e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL24_GRAPH_TILE reuse_input=%u keep=%u\n",(unsigned)reuse_input,(unsigned)keep_graph);
 if(!e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL23_NATIVE setup_us=%llu draw_us=%llu read_us=%llu drop_us=%llu tail_us=%llu\n",(unsigned long long)(prepare_end-native_start),(unsigned long long)(draw_end-prepare_end),(unsigned long long)(read_end-draw_end),(unsigned long long)(drop_end-read_end),(unsigned long long)(egl22_now_us()-drop_end));
 return e;
}
/* EGL18: bounded rectangle batches. Preserve triangle order and UVs. A
 * pair must cover exactly one axis-aligned rectangle; do not silently admit
 * arbitrary geometry or merge overlapping rectangles (blending is ordered). */
/* EGL26: select CPU-resident, level-zero inputs for an explicit 2D path.
 * The normal transfer_map path owns synchronization, including shared refresh.
 * Do not take raw pointers to GEM or silently classify a GPU draw as retired. */
static bool egl26_source_candidate(struct pipe_context *p,struct pipe_resource **out,
 bool *rgba,bool *nearest)
{
 const struct pipe_sampler_view *v=NULL;struct pipe_sampler_state sampler;
 if(remesa_texture_fragment0_view(c(p)->textures,&v)||!v||!v->texture||
    v->texture==c(p)->target||v->target!=PIPE_TEXTURE_2D||v->u.tex.first_level||
    v->u.tex.last_level||v->u.tex.first_layer||v->u.tex.last_layer||
    remesa_sampler_fragment0_snapshot(c(p)->samplers,&sampler)||
    remesa_sampler_state_validate(&sampler))return false;
 if(sampler.wrap_s!=PIPE_TEX_WRAP_CLAMP_TO_EDGE||sampler.wrap_t!=PIPE_TEX_WRAP_CLAMP_TO_EDGE||
    sampler.min_mip_filter!=PIPE_TEX_MIPFILTER_NONE)return false;
 struct resource *b=sample_backing(v->texture);
 if(b==r(c(p)->target)||!b->compositor_host_texture||!b->host_data||
    b->base.last_level||!b->has_contents||b->maps||b->writer||b->write_error||
    b->native_clear_owner||!b->pass.content_epoch||b->shared_rt||b->base.width0!=v->texture->width0||
    b->base.height0!=v->texture->height0)return false;
 if(v->format!=b->base.format&&!(v->format==PIPE_FORMAT_B8G8R8X8_UNORM&&
    b->base.format==PIPE_FORMAT_B8G8R8A8_UNORM))return false;
 *rgba=v->format==PIPE_FORMAT_R8G8B8A8_UNORM;
 *nearest=sampler.min_img_filter==PIPE_TEX_FILTER_NEAREST&&sampler.mag_img_filter==PIPE_TEX_FILTER_NEAREST;
 *out=&b->base;return true;
}
/* Direct packed DMA-BUF staging for initialized uncached scanout. The caller
 * still commits the ordinary backing through map/unmap before publication.
 * Keep the existing disjoint GEM and external CPU lease contract. */
static bool egl26_direct_target(struct resource *b)
{
 return b->shared_rt&&b->shared_sampler&&!b->shared_sampler->poisoned&&b->shared_writable&&b->has_contents&&
    !b->shared_discard&&!b->shared_cache&&!b->maps&&!b->native_clear_owner&&!b->write_error;
}
static int egl26_external_region(struct pipe_screen *p,struct resource *b,bool publish,
 unsigned x,unsigned y,unsigned w,unsigned h,uint8_t *pixels)
{
 struct remesa_shared_image *sh=b->shared_sampler;
 if(!egl26_direct_target(b)||!pixels||!w||!h||x>=sh->width||y>=sh->height||
    w>sh->width-x||h>sh->height-y)return EINVAL;
 if(sh->poisoned)return EOWNERDEAD;
 int e=resource_sync(p,b,UINT64_MAX);if(e)return e;
 if(getenv("REMESA_HRE_EGL28_HOST_SYNC")){
  e=egl28_external_copy(sh,publish,x,y,w,h,pixels,(size_t)w*4,!publish&&b->shared_opaque);
  if(e==EOWNERDEAD)b->write_error=e;
  if(!e){b->shared_cache_valid=false;if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_DIRECT_REGION publish=%u bytes=%zu\n",(unsigned)publish,(size_t)w*h*4);}
  return e;
 }
 void *external=mmap(NULL,sh->end,PROT_READ|(publish?PROT_WRITE:0),MAP_SHARED,sh->fd,0);
 if(external==MAP_FAILED)return errno;
 const uint64_t mode=publish?DMA_BUF_SYNC_WRITE:DMA_BUF_SYNC_READ;
 size_t row=(size_t)w*4;
 e=remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_START|mode);
 if(!e){
  for(unsigned j=0;j<h;j++){
   uint8_t *a=(uint8_t *)external+sh->offset+(size_t)(y+j)*sh->pitch+(size_t)x*4;
   uint8_t *z=pixels+(size_t)j*row;
   if(publish)memcpy(a,z,row);else memcpy(z,a,row);
  }
  if(remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_END|mode))e=EOWNERDEAD;
 }
 if(munmap(external,sh->end))e=EOWNERDEAD;
 if(e==EOWNERDEAD){sh->poisoned=true;b->write_error=e;}
 if(!e){
  if(!publish&&b->shared_opaque)for(size_t i=3;i<row*h;i+=4)pixels[i]=255;
  b->shared_cache_valid=false;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_DIRECT_REGION publish=%u bytes=%zu\n",(unsigned)publish,row*h);
 }
 return e;
}
#define RC_EGL18_MAX_RECTS 128u
#define RC_EGL18_MAX_VERTICES (6u * RC_EGL18_MAX_RECTS)
struct rc_egl18_rect { struct rc_vertex v[6]; unsigned x0,y0,x1,y1; };
static int rc_egl18_pair_count(unsigned mode,unsigned n,unsigned *pairs)
{
 if(n>RC_EGL18_MAX_VERTICES)return ENOTSUP;
 if(mode==MESA_PRIM_TRIANGLES){if(n<6||n%6)return ENOTSUP;*pairs=n/6;}
 else if(mode==MESA_PRIM_TRIANGLE_STRIP||mode==MESA_PRIM_TRIANGLE_FAN){
  if(n<4||(n-2)%2)return ENOTSUP;
  *pairs=(n-2)/2;
 }else return ENOTSUP;
 return *pairs<=RC_EGL18_MAX_RECTS?0:ENOTSUP;
}
static int rc_egl18_rect_make(const struct rc_vertex *v,unsigned mode,unsigned pair,
 unsigned w,unsigned h,unsigned sx0,unsigned sy0,unsigned sx1,unsigned sy1,
 struct rc_egl18_rect *out)
{
 unsigned i=pair*2,ids[6];
 if(mode==MESA_PRIM_TRIANGLES){for(unsigned k=0;k<6;k++)ids[k]=pair*6+k;}
 else if(mode==MESA_PRIM_TRIANGLE_STRIP){unsigned a[6]={i,i+1,i+2,i+2,i+1,i+3};memcpy(ids,a,sizeof ids);}
 else {unsigned a[6]={0,i+1,i+2,0,i+2,i+3};memcpy(ids,a,sizeof ids);}
 struct rc_egl18_rect t={0};
 for(unsigned k=0;k<6;k++)t.v[k]=v[ids[k]];
 float minx=t.v[0].x,maxx=minx,miny=t.v[0].y,maxy=miny;
 for(unsigned k=0;k<6;k++){
  struct rc_vertex a=t.v[k];
  if(!isfinite(a.x)||!isfinite(a.y)||!isfinite(a.u)||!isfinite(a.v))return EINVAL;
  minx=fminf(minx,a.x);maxx=fmaxf(maxx,a.x);miny=fminf(miny,a.y);maxy=fmaxf(maxy,a.y);
 }
 if(minx==maxx||miny==maxy){*out=t;return 0;}
 if(fabsf(minx-roundf(minx))>.001f||fabsf(maxx-roundf(maxx))>.001f||fabsf(miny-roundf(miny))>.001f||fabsf(maxy-roundf(maxy))>.001f)return ENOTSUP;
 minx=roundf(minx);maxx=roundf(maxx);miny=roundf(miny);maxy=roundf(maxy);
 if(minx==maxx||miny==maxy)return ENOTSUP;
 unsigned masks[2]={0};
 for(unsigned k=0;k<6;k++){
  struct rc_vertex *a=&t.v[k];
  if(fabsf(a->x-minx)<.001f)a->x=minx;else if(fabsf(a->x-maxx)<.001f)a->x=maxx;else return ENOTSUP;
  if(fabsf(a->y-miny)<.001f)a->y=miny;else if(fabsf(a->y-maxy)<.001f)a->y=maxy;else return ENOTSUP;
  unsigned corner=(a->x==maxx)|((a->y==maxy)<<1);masks[k/3]|=1u<<corner;
 }
 unsigned diagonal=masks[0]&masks[1];
 if(__builtin_popcount(masks[0])!=3||__builtin_popcount(masks[1])!=3||(masks[0]|masks[1])!=15||(diagonal!=6&&diagonal!=9))return ENOTSUP;
 t.x0=(unsigned)fminf(w,fmaxf(0,minx));t.x1=(unsigned)fminf(w,fmaxf(0,maxx));
 t.y0=(unsigned)fminf(h,fmaxf(0,miny));t.y1=(unsigned)fminf(h,fmaxf(0,maxy));
 if(t.x0<sx0)t.x0=sx0;
 if(t.y0<sy0)t.y0=sy0;
 if(t.x1>sx1)t.x1=sx1;
 if(t.y1>sy1)t.y1=sy1;
 *out=t;return 0;
}
/* EGL25: canonical six-vertex tiles for exactly affine rectangle UVs.
 * Non-affine or discontinuous UVs retain the original triangle clipping. */
static bool egl25_affine_tile(const struct rc_egl18_rect *r,const struct rc_scratch *sz,
 unsigned tx,unsigned ty,unsigned ax,unsigned ay,unsigned bx,unsigned by,
 struct rc_native_vertex mesh[42],unsigned *nv)
{
 float lx=r->v[0].x,hx=lx,ly=r->v[0].y,hy=ly;
 for(unsigned i=1;i<6;i++){lx=fminf(lx,r->v[i].x);hx=fmaxf(hx,r->v[i].x);ly=fminf(ly,r->v[i].y);hy=fmaxf(hy,r->v[i].y);}
 if(!(hx>lx&&hy>ly))return false;
 struct rc_vertex corners[4]={0};unsigned seen=0;
 for(unsigned i=0;i<6;i++){
  struct rc_vertex v=r->v[i];unsigned k=(v.x==hx)|((v.y==hy)<<1);
  if((seen&(1u<<k))&&(corners[k].u!=v.u||corners[k].v!=v.v))return false;
  corners[k]=v;seen|=1u<<k;
 }
 if(seen!=15||(double)corners[0].u+corners[3].u!=(double)corners[1].u+corners[2].u||
    (double)corners[0].v+corners[3].v!=(double)corners[1].v+corners[2].v)return false;
 const unsigned order[6]={0,1,2,2,1,3};
 for(unsigned i=0;i<6;i++){
  unsigned k=order[i];double x=k&1?bx:ax,y=k&2?by:ay;
  double fx=(x+tx-lx)/(hx-lx),fy=(y+ty-ly)/(hy-ly);
  if(fx<0||fx>1||fy<0||fy>1)return false;
  struct rc_native_vertex *d=&mesh[i];
  d->p[0]=(float)(2.0*(x+sz->x)/sz->width-1.0);
  d->p[1]=(float)(1.0-2.0*(y+sz->y)/sz->height);
  d->p[2]=.25f;d->p[3]=1;
  d->uv[0]=(float)(corners[0].u+fx*((double)corners[1].u-corners[0].u)+fy*((double)corners[2].u-corners[0].u));
  d->uv[1]=(float)(corners[0].v+fx*((double)corners[1].v-corners[0].v)+fy*((double)corners[2].v-corners[0].v));
 }
 if(remesa_texture_draw_values(mesh,6*sizeof(*mesh),6))return false;
 *nv=6;return true;
}
static uint64_t egl22_now_us(void)
{
 struct timespec ts;if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (uint64_t)ts.tv_sec*1000000u+(uint64_t)ts.tv_nsec/1000u;
}
/* Exact solid-color 2D fast path. The caller has already validated rectangle
 * geometry, shader expression, color mask, and supported blend state. This
 * is CPU work, not a native retirement, and is opt-in for qualification. */
static void egl24_solid_rect(uint8_t *dst,unsigned stride,unsigned w,unsigned h,
 const uint8_t rgba[4],bool blend,bool opaque)
{
 uint8_t pixel[4]={rgba[2],rgba[1],rgba[0],rgba[3]};
 unsigned inv=255u-pixel[3];
 if(!blend||!inv){if(opaque)pixel[3]=255;
  if(!w||!h)return;
  /* Seed one row by non-overlapping exponential copies; repeat it.
   * Avoid unaligned typed stores and preserve row padding. */
  size_t bytes=(size_t)w*4,filled=4;
  memcpy(dst,pixel,4);
  while(filled<bytes){size_t n=filled<bytes-filled?filled:bytes-filled;
   memcpy(dst+filled,dst,n);filled+=n;}
  for(unsigned y=1;y<h;y++)memcpy(dst+(size_t)y*stride,dst,bytes);
 }else{
  for(unsigned y=0;y<h;y++){uint8_t *row=dst+(size_t)y*stride;
   for(unsigned x=0;x<w;x++){uint8_t *d=row+4*x;
    for(unsigned k=0;k<4;k++){unsigned v=pixel[k]+rc_mul255(k==3&&opaque?255:d[k],inv);d[k]=(uint8_t)(v>255?255:v);}
    if(opaque)d[3]=255;
   }
  }
 }
}
/* Exact affine, axis-aligned texture mapping. Nearest may scale; linear
 * is admitted only at texel centers (unit scale, integer texel edges).
 * Preflight ALL rectangles before touching the destination. */
struct egl26_blit_plan { double u,v,du,dv; bool unit; };
static bool egl26_plan(const struct rc_egl18_rect *rect,unsigned sw,unsigned sh,bool nearest,
 struct egl26_blit_plan *out)
{
 double lx=rect->v[0].x,hx=lx,ly=rect->v[0].y,hy=ly;
 for(unsigned i=1;i<6;i++){lx=fmin(lx,rect->v[i].x);hx=fmax(hx,rect->v[i].x);ly=fmin(ly,rect->v[i].y);hy=fmax(hy,rect->v[i].y);}
 if(!(hx>lx&&hy>ly)||!sw||!sh||sw>2048||sh>2048)return false;
 struct rc_vertex c[4]={0};unsigned seen=0;
 for(unsigned i=0;i<6;i++){
  struct rc_vertex v=rect->v[i];unsigned k=(v.x==hx)|((v.y==hy)<<1);
  if((seen&(1u<<k))&&(c[k].u!=v.u||c[k].v!=v.v))return false;
  c[k]=v;seen|=1u<<k;
 }
 if(seen!=15||c[0].u!=c[2].u||c[1].u!=c[3].u||c[0].v!=c[1].v||c[2].v!=c[3].v)return false;
 double u0=(double)c[0].u*sw,u1=(double)c[1].u*sw,v0=(double)c[0].v*sh,v1=(double)c[2].v*sh;
 if(!isfinite(u0)||!isfinite(u1)||!isfinite(v0)||!isfinite(v1)||
    fabs(u0)>65536||fabs(u1)>65536||fabs(v0)>65536||fabs(v1)>65536)return false;
 double du=(u1-u0)/(hx-lx),dv=(v1-v0)/(hy-ly);
 const double eps=.00025;
 bool unit=fabs(u0-round(u0))<=eps&&fabs(u1-round(u1))<=eps&&
    fabs(v0-round(v0))<=eps&&fabs(v1-round(v1))<=eps&&
    fabs(fabs(round(u1)-round(u0))-(hx-lx))<eps&&fabs(fabs(round(v1)-round(v0))-(hy-ly))<eps;
 if(!unit&&!nearest)return false;
 if(unit){u0=round(u0);v0=round(v0);du=du<0?-1:1;dv=dv<0?-1:1;}
 *out=(struct egl26_blit_plan){u0+((double)rect->x0+.5-lx)*du,v0+((double)rect->y0+.5-ly)*dv,du,dv,unit};
 return true;
}
static unsigned egl26_texel(double a,unsigned n)
{ return a<=0?0:a>=n?n-1:(unsigned)a; }
#include "remesa_egl34_rows.h"
static void egl26_blit(const struct egl26_blit_plan *b,const uint8_t *src,size_t stride,
 unsigned sw,unsigned sh,uint8_t *dst,size_t ds,unsigned w,unsigned h,
 bool rgba,bool opaque,bool dest_opaque,bool blend,uint8_t opacity)
{
 /* All dimensions were bounded by the existing rectangle validator. */
 unsigned xs[1792];for(unsigned x=0;x<w;x++)xs[x]=egl26_texel(b->u+x*b->du,sw);
 bool row_copy=!rgba&&(!blend||opaque)&&opacity==255&&b->unit&&b->du==1&&
    b->u>=0&&b->u+w-1<sw;
 for(unsigned y=0;y<h;y++){
  const uint8_t *s=src+(size_t)egl26_texel(b->v+y*b->dv,sh)*stride;
  uint8_t *d=dst+(size_t)y*ds;
  if(row_copy){memcpy(d,s+4*xs[0],(size_t)w*4);if(opaque||dest_opaque)egl34_force_alpha(d,w);continue;}
  for(unsigned x=0;x<w;x++){
   const uint8_t *q=s+4*xs[x];uint8_t *o=d+4*x;
   if(opacity==255&&(!blend||opaque)){
    uint32_t v;memcpy(&v,q,4);
    if(rgba)v=(v&0xff00ff00u)|((v&0xffu)<<16)|((v>>16)&0xffu);
    if(opaque||dest_opaque)v|=0xff000000u;
    memcpy(o,&v,4);continue;
   }
   unsigned a=rc_mul255(opaque?255:q[3],opacity),inv=255-a;
   for(unsigned k=0;k<4;k++){
    unsigned v=k==3?a:rc_mul255(q[rgba&&k!=1?2-k:k],opacity);
    if(blend)v+=rc_mul255(k==3&&dest_opaque?255:o[k],inv);
    o[k]=(uint8_t)(v>255?255:v);
   }
   if(dest_opaque)o[3]=255;
  }
 }
}
/* EGL31 physical copy qualification: only exact, positive unit copies.
 * Reject clamping, scale, channel swizzle, opacity and fractional origins.
 * Size 8 is rejected by the historical typed 2D command grammar. */
static bool egl31_copy_coords(const struct egl26_blit_plan *b,unsigned sw,unsigned sh,
 unsigned w,unsigned h,unsigned *sx,unsigned *sy)
{
 if(!b->unit||b->du!=1||b->dv!=1||w==8||h==8||!w||!h||
    (uint64_t)w*h<4096||!isfinite(b->u)||!isfinite(b->v)||
    b->u<.5||b->v<.5||b->u>(double)sw||b->v>(double)sh)return false;
 double x=b->u-.5,y=b->v-.5;
 if(fabs(x-round(x))>0.000001||fabs(y-round(y))>0.000001)return false;
 *sx=(unsigned)round(x);*sy=(unsigned)round(y);
 return *sx<sw&&*sy<sh&&w<=sw-*sx&&h<=sh-*sy;
}
/* EGL31_GPU2D_BEGIN */
/* Staged hardware path: cache one immutable source and one destination GEM.
 * This is NOT direct scanout. The typed native callback owns completion.
 * The ordinary pass/map APIs own content and publication. No fallback after
 * an uncertain submission; output is compared before external publication. */
static int egl31_gpu2d(struct pipe_context *p,struct pipe_resource *input,
 const struct egl26_blit_plan *plan,const uint8_t *src,size_t stride,
 uint8_t *dst,size_t ds,unsigned w,unsigned h,bool rgba,bool opaque,
 bool dest_opaque,bool blend,uint8_t opacity,bool *used)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);unsigned sx,sy;
 *used=false;
 if(!getenv("REMESA_HRE_EGL31_GPU2D")||!sc->native_copy||rgba||opacity!=255||
    (blend&&!opaque)||ctx->owned_texture_scene.owner||ctx->failed_submission||
    (ctx->compositor_scratch&&c(ctx->compositor_scratch)->owned_texture_scene.owner)||
    !egl31_copy_coords(plan,input->width0,input->height0,w,h,&sx,&sy))return 0;
 struct resource *in=r(input);
 if(!in->pass.content_epoch||!in->pass.resource_cookie||in->bytes>4u*1024u*1024u)return 0;
 uint64_t begin=egl22_now_us();
 struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,
   .width0=input->width0,.height0=input->height0,.depth0=1,.array_size=1};
 /* Optional second source: keep the most recently used distinct cookie.
  * Swapping only transfers ownership of existing references. The active
  * source remains the one checked by copy_region. Epoch changes still upload.
  * Never evict after an uncertain submission (guard above). */
 if(getenv("REMESA_HRE_EGL32_CACHE2")&&ctx->egl31_src&&ctx->egl31_cookie&&
    ctx->egl31_cookie!=in->pass.resource_cookie){
  struct pipe_resource *tmp=ctx->egl31_src;ctx->egl31_src=ctx->egl32_spare;ctx->egl32_spare=tmp;
  uint64_t cookie=ctx->egl31_cookie,epoch=ctx->egl31_epoch;
  ctx->egl31_cookie=ctx->egl32_spare_cookie;ctx->egl31_epoch=ctx->egl32_spare_epoch;
  ctx->egl32_spare_cookie=cookie;ctx->egl32_spare_epoch=epoch;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL32_CACHE_SWAP resident=%u\n",(unsigned)(ctx->egl31_cookie==in->pass.resource_cookie&&ctx->egl31_epoch==in->pass.content_epoch));
 }
 if(!ctx->egl31_src||ctx->egl31_src->width0!=t.width0||ctx->egl31_src->height0!=t.height0){
  remesa_resource_reference(&ctx->egl31_src,NULL);ctx->egl31_cookie=ctx->egl31_epoch=0;
  ctx->egl31_src=create_resource_impl(p->screen,&t,true,false);
  if(!ctx->egl31_src)return 0;
 }
 if(!ctx->egl31_dst||ctx->egl31_dst->width0!=t.width0||ctx->egl31_dst->height0!=t.height0){
  remesa_resource_reference(&ctx->egl31_dst,NULL);
  ctx->egl31_dst=create_resource_impl(p->screen,&t,true,false);
  if(!ctx->egl31_dst)return 0;
 }
 struct pipe_box full={.width=t.width0,.height=t.height0,.depth=1};
 bool hit=ctx->egl31_cookie==in->pass.resource_cookie&&ctx->egl31_epoch==in->pass.content_epoch;
 if(!hit){
  texture_subdata(p,ctx->egl31_src,0,PIPE_MAP_WRITE,&full,src,stride,0);
  if(ctx->error)return ctx->error;
  ctx->egl31_cookie=in->pass.resource_cookie;ctx->egl31_epoch=in->pass.content_epoch;
 }
 if(!r(ctx->egl31_dst)->has_contents){
  struct pipe_transfer *mt=NULL;uint8_t *z=map(p,ctx->egl31_dst,0,PIPE_MAP_WRITE,&full,&mt);
  if(!z)return ctx->error?ctx->error:EIO;
  for(unsigned y=0;y<t.height0;y++)memset(z+(size_t)y*mt->stride,0,(size_t)t.width0*4);
  unmap(p,mt);if(ctx->error)return ctx->error;
 }
 uint64_t before=ctx->native_copies,issue=egl22_now_us();
 struct pipe_box from={.x=sx,.y=sy,.width=w,.height=h,.depth=1};
 ctx->egl31_copy_active=true;
 copy_region(p,ctx->egl31_dst,0,0,0,0,ctx->egl31_src,0,&from);
 ctx->egl31_copy_active=false;
 if(ctx->error)return ctx->error;
 /* EOPNOTSUPP may have selected the normal CPU copy. Never count that as GPU. */
 if(ctx->native_copies==before){if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL31_GPU2D_FALLBACK\n");return 0;}
 if(ctx->native_copies!=before+1)return EPROTO;
 uint64_t retired=egl22_now_us();
 struct pipe_transfer *mt=NULL;struct pipe_box to={.width=w,.height=h,.depth=1};
 const uint8_t *z=map(p,ctx->egl31_dst,0,PIPE_MAP_READ,&to,&mt);
 if(!z)return ctx->error?ctx->error:EIO;
 int e=0;
 for(unsigned y=0;y<h;y++){
  const uint8_t *row=z+(size_t)y*mt->stride;
  uint8_t *out=dst+(size_t)y*ds;
  if(egl34_readback_row(out,row,src+(size_t)(sy+y)*stride+(size_t)sx*4,w,opaque||dest_opaque)){e=EPROTO;break;}
 }
 unmap(p,mt);if(ctx->error)return ctx->error;
 if(e){fprintf(stderr,"HRE_EGL31_GPU2D_ORACLE_FAIL errno=%d\n",e);return e;}
 *used=true;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL31_GPU2D_RETIRED pixels=%zu cache_hit=%u setup_us=%llu copy_us=%llu read_us=%llu total_us=%llu\n",
  (size_t)w*h,(unsigned)hit,(unsigned long long)(issue-begin),(unsigned long long)(retired-issue),
  (unsigned long long)(egl22_now_us()-retired),(unsigned long long)(egl22_now_us()-begin));
 return 0;
}
/* EGL31_GPU2D_END */
/* Called only after the full exact COLOR/Z guard oracle has passed.
 * For opacity 255 and replacement semantics, every covered output pixel
 * is written exactly once. Do not rescan Z or fetch old destination pixels. */
static int egl31_resolve_replace(const struct rc_resolve_desc *d,
 struct rc_resolve_plane color,struct rc_resolve_plane dst,size_t *covered)
{
 if(!d||!covered||d->opacity!=255||(d->blend&&!d->force_source_opaque)||
    d->x>d->sw||d->w>d->sw-d->x||d->y>d->sh||d->h>d->sh-d->y||
    !rc_plane_valid(color,d->sw,d->sh)||!rc_plane_valid(dst,d->w,d->h)||
    rc_plane_overlap(color,dst))return EINVAL;
 for(unsigned y=0;y<d->h;y++){
  const uint8_t *src=(const uint8_t *)color.data+(size_t)(d->y+y)*color.stride+(size_t)d->x*4;
  uint8_t *out=(uint8_t *)dst.data+(size_t)y*dst.stride;
  memcpy(out,src,(size_t)d->w*4);
  if(d->force_source_opaque||d->force_dest_opaque)for(unsigned x=0;x<d->w;x++)out[4*x+3]=255;
 }
 *covered=(size_t)d->w*d->h;return 0;
}
/* EGL30: exact union of clipped rectangle coverage, without changing the
 * original primitive order. Sort only the transfer plan. Each y band has
 * the same set of active rectangles, so merge horizontal spans once/band.
 * Coordinates are absolute; source and destination start at the bbox origin.
 * The staging allocation stays rectangular, but holes are never read/written. */
struct egl30_damage {
 unsigned n,ny,x0,y0,x1,y1;
 unsigned order[RC_EGL18_MAX_RECTS],ys[2*RC_EGL18_MAX_RECTS];
 const struct rc_egl18_rect *rects;
};
static void egl30_damage_make(struct egl30_damage *d,const struct rc_egl18_rect *rects,
 unsigned n,unsigned x0,unsigned y0,unsigned x1,unsigned y1)
{
 *d=(struct egl30_damage){.n=n,.x0=x0,.y0=y0,.x1=x1,.y1=y1,.rects=rects};
 for(unsigned i=0;i<n;i++){
  unsigned j=i;
  while(j&&rects[d->order[j-1]].x0>rects[i].x0){d->order[j]=d->order[j-1];j--;}
  d->order[j]=i;
  unsigned edges[2]={rects[i].y0,rects[i].y1};
  for(unsigned k=0;k<2;k++){
   unsigned q=0;while(q<d->ny&&d->ys[q]<edges[k])q++;
   if(q<d->ny&&d->ys[q]==edges[k])continue;
   memmove(d->ys+q+1,d->ys+q,(d->ny-q)*sizeof(d->ys[0]));
   d->ys[q]=edges[k];d->ny++;
  }
 }
}
static size_t egl30_damage_span(const struct egl30_damage *d,unsigned x0,unsigned x1,
 unsigned y0,unsigned y1,uint8_t *dst,size_t ds,const uint8_t *src,size_t ss,bool normalize)
{
 size_t row=(size_t)(x1-x0)*4,offset=(size_t)(x0-d->x0)*4;
 if(dst&&src)for(unsigned y=y0;y<y1;y++){
  uint8_t *out=dst+(size_t)(y-d->y0)*ds+offset;
  const uint8_t *in=src+(size_t)(y-d->y0)*ss+offset;
  memcpy(out,in,row);
  /* Normalize XRGB only after copying into ordinary RAM; avoid individual
   * reads from a potentially uncached/write-combined external mapping. */
  if(normalize)for(size_t x=3;x<row;x+=4)out[x]=255;
 }
 return row*(y1-y0);
}
static size_t egl30_damage_copy(const struct egl30_damage *d,uint8_t *dst,size_t ds,
 const uint8_t *src,size_t ss,bool normalize)
{
 size_t bytes=0;
 for(unsigned b=0;b+1<d->ny;b++){
  unsigned y0=d->ys[b],y1=d->ys[b+1],a=0,z=0;bool active=false;
  for(unsigned i=0;i<d->n;i++){
   const struct rc_egl18_rect *r=&d->rects[d->order[i]];
   if(r->y0>y0||r->y1<y1)continue;
   if(!active){a=r->x0;z=r->x1;active=true;}
   else if(r->x0<=z){if(r->x1>z)z=r->x1;}
   else {bytes+=egl30_damage_span(d,a,z,y0,y1,dst,ds,src,ss,normalize);a=r->x0;z=r->x1;}
  }
  if(active)bytes+=egl30_damage_span(d,a,z,y0,y1,dst,ds,src,ss,normalize);
 }
 return bytes;
}
/* EGL30_EXTERNAL_BEGIN: one authenticated DMA-BUF lease per direction. */
static int egl30_external_damage(struct pipe_screen *p,struct resource *b,bool publish,
 const struct egl30_damage *d,uint8_t *pixels,size_t stride,size_t bytes)
{
 struct remesa_shared_image *sh=b->shared_sampler;
 if(!egl26_direct_target(b)||!pixels||!d->n||d->x1>sh->width||d->y1>sh->height||
    d->x0>=d->x1||d->y0>=d->y1||stride<(size_t)(d->x1-d->x0)*4)return EINVAL;
 int e=resource_sync(p,b,UINT64_MAX);if(e)return e;
 uint64_t a=egl28_clock();
 void *external=mmap(NULL,sh->end,PROT_READ|(publish?PROT_WRITE:0),MAP_SHARED,sh->fd,0);
 if(external==MAP_FAILED)return errno;
 uint64_t m=egl28_clock();const uint64_t mode=publish?DMA_BUF_SYNC_WRITE:DMA_BUF_SYNC_READ;
 e=remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_START|mode);
 uint64_t st=egl28_clock(),cp=st,en=st;
 if(!e){
  uint8_t *ext=(uint8_t*)external+sh->offset+(size_t)d->y0*sh->pitch+(size_t)d->x0*4;
  if(publish)egl30_damage_copy(d,ext,sh->pitch,pixels,stride,false);
  else egl30_damage_copy(d,pixels,stride,ext,sh->pitch,b->shared_opaque);
  cp=egl28_clock();if(remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_END|mode))e=EOWNERDEAD;en=egl28_clock();
 }
 if(munmap(external,sh->end))e=EOWNERDEAD;
 if(e==EOWNERDEAD){sh->poisoned=true;b->write_error=e;}
 if(!e){b->shared_cache_valid=false;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_DIRECT_REGION publish=%u bytes=%zu\n",(unsigned)publish,bytes);}
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL28_DMA publish=%u bytes=%zu map_us=%llu start_us=%llu copy_us=%llu end_us=%llu unmap_us=%llu errno=%d\n",(unsigned)publish,bytes,(unsigned long long)(m-a),(unsigned long long)(st-m),(unsigned long long)(cp-st),(unsigned long long)(en-cp),(unsigned long long)(egl28_clock()-en),e);
 return e;
}
/* EGL30_EXTERNAL_END */
static int hybrid_draw(struct pipe_context *p,const struct pipe_draw_info *info,unsigned drawid,
 const struct pipe_draw_indirect_info *indirect,const struct pipe_draw_start_count_bias *d,unsigned count)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);int e=ENOTSUP;
 if(!d||count!=1||drawid||indirect||info->index_size||info->instance_count!=1||info->start_instance||info->primitive_restart||ctx->failed_submission||ctx->owned_texture_scene.owner||!ctx->target||ctx->depth_target||!ctx->viewport_set||ctx->invalid_viewport||ctx->invalid_elements||ctx->invalid_constants||ctx->constant_rejections[0]||ctx->constant_rejections[1])return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=1\n"),ENOTSUP);
 if(!ctx->sample_enabled||d->count<3)return 0;
 for(unsigned i=0;i<FIXED_COUNT;i++)if(!ctx->bound_fixed[i]||ctx->invalid_fixed[i]||ctx->bound_fixed[i]->deleted)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=2\n"),ENOTSUP);
 const struct fixed *blend=ctx->bound_fixed[FIXED_BLEND],*ds=ctx->bound_fixed[FIXED_DSA],*rast=ctx->bound_fixed[FIXED_RASTER];
 if(ds->depth_enabled||rast->cull_face||rast->flat||blend->colormask!=PIPE_MASK_RGBA)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=3\n"),ENOTSUP);
 if(rast->scissor&&(!ctx->scissor_set||ctx->invalid_scissor))return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=4\n"),ENOTSUP);
 if(!ctx->bound_elements||ctx->bound_elements->count!=1||ctx->vb_count!=1||!ctx->vb.buffer.resource||ctx->position.src_format!=PIPE_FORMAT_R32G32_FLOAT||ctx->position.vertex_buffer_index||!ctx->position.src_stride)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=5\n"),ENOTSUP);
 unsigned pairs=0;
 if(rc_egl18_pair_count(info->mode,d->count,&pairs)){
  fprintf(stderr,"HRE_EGL18_REFUSAL stage=topology mode=%u vertices=%u start=%u\n",(unsigned)info->mode,d->count,d->start);return ENOTSUP;}
 struct resource *target=r(ctx->target);unsigned w=ctx->target->width0,h=ctx->target->height0;
 if(!target->shared_rt&&!target->has_contents)return ENODATA;
 if(!color_rt_format(p->screen,ctx->target->format)||!w||!h||w>1792||h>1792)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=8\n"),ENOTSUP);
 if(p->stream_uploader)u_upload_unmap(p->stream_uploader);if(p->const_uploader)u_upload_unmap(p->const_uploader);
 uint8_t vu[256],fu[64],rgba[4]={0};size_t vn,fn;bool sampled,opaque;uint8_t opacity;
 if((e=hybrid_constants(ctx,true,vu,&vn))){fprintf(stderr,"HRE_EGL29_ADMISSION_FAIL stage=vertex_constants errno=%d\n",e);return e;}
 if((e=hybrid_constants(ctx,false,fu,&fn))){fprintf(stderr,"HRE_EGL29_ADMISSION_FAIL stage=fragment_constants errno=%d\n",e);return e;}
 if((e=hybrid_fragment(&ctx->bound_fragment->compositor,fu,fn,rgba,&sampled,&opaque,&opacity))){fprintf(stderr,"HRE_EGL17_FAIL stage=fragment errno=%d\n",e);return e;}
 if(sampled){
  if(!(ctx->bound_vertex->compositor.outputs&2))return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=9\n"),ENOTSUP);
  const struct pipe_sampler_view *source=NULL;e=remesa_texture_fragment0_view(ctx->textures,&source);if(e){fprintf(stderr,"HRE_EGL29_ADMISSION_FAIL stage=fragment_view errno=%d\n",e);return e;}
  if(source->format!=PIPE_FORMAT_R8G8B8A8_UNORM&&source->format!=PIPE_FORMAT_B8G8R8A8_UNORM&&source->format!=PIPE_FORMAT_B8G8R8X8_UNORM)return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=10\n"),ENOTSUP);
  if(source->swizzle_r!=PIPE_SWIZZLE_X||source->swizzle_g!=PIPE_SWIZZLE_Y||source->swizzle_b!=PIPE_SWIZZLE_Z||(source->swizzle_a!=PIPE_SWIZZLE_W&&source->swizzle_a!=PIPE_SWIZZLE_1))return (fprintf(stderr,"HRE_EGL17_REFUSAL stage=draw predicate=11\n"),ENOTSUP);
  if(source->format==PIPE_FORMAT_B8G8R8X8_UNORM||source->swizzle_a==PIPE_SWIZZLE_1)opaque=true;
 }
 struct resource *input=r(ctx->vb.buffer.resource);if(input->maps)return EBUSY;
 struct rc_vertex v[RC_EGL18_MAX_VERTICES];void *ptr=NULL;
 uint64_t base=(uint64_t)ctx->vb.buffer_offset+ctx->position.src_offset;
 uint64_t advance=(uint64_t)d->start*ctx->position.src_stride;
 if(base>INT32_MAX||advance>(uint64_t)INT32_MAX-base)return EINVAL;
 uint64_t first=base+advance;
 uint64_t end=first+(uint64_t)(d->count-1)*ctx->position.src_stride+8;
 if(end<first||end>input->bytes||end>INT32_MAX)return EINVAL;
 struct pipe_box vbbox={.x=first,.width=end-first,.height=1,.depth=1};struct pipe_transfer *tr=NULL;
 ptr=map(p,&input->base,0,PIPE_MAP_READ,&vbbox,&tr);if(!ptr){e=ctx->error?ctx->error:EIO;fprintf(stderr,"HRE_EGL29_ADMISSION_FAIL stage=vertex_map errno=%d\n",e);return e;}
 for(unsigned i=0;i<d->count;i++){
  float pos[2];memcpy(pos,(const uint8_t*)ptr+(size_t)i*ctx->position.src_stride,8);
  e=rc_window_vertex(&ctx->bound_vertex->compositor,vu,vn,pos,ctx->viewport.scale,ctx->viewport.translate,&v[i]);
  if(e)break;if(!sampled)v[i].u=v[i].v=.25f;
 }
 unmap(p,tr);if(e)return e;if(input->write_error)return input->write_error;
 /* Validate every rectangle before any native submission. Stage the union
  * once; execute overlapping rectangles in original primitive order. */
 struct rc_egl18_rect rects[RC_EGL18_MAX_RECTS];
 unsigned x0=w,y0=h,x1=0,y1=0,nrects=0;size_t expected=0;
 for(unsigned j=0;j<pairs;j++){
  struct rc_egl18_rect rect;
  e=rc_egl18_rect_make(v,info->mode,j,w,h,
   rast->scissor?ctx->compositor_scissor.minx:0,rast->scissor?ctx->compositor_scissor.miny:0,
   rast->scissor?ctx->compositor_scissor.maxx:w,rast->scissor?ctx->compositor_scissor.maxy:h,&rect);
  if(e){fprintf(stderr,"HRE_EGL18_REFUSAL stage=rectangle mode=%u vertices=%u pair=%u errno=%d\n",(unsigned)info->mode,d->count,j,e);return e;}
  if(rect.x0>=rect.x1||rect.y0>=rect.y1)continue;
  x0=MIN2(x0,rect.x0);y0=MIN2(y0,rect.y0);x1=MAX2(x1,rect.x1);y1=MAX2(y1,rect.y1);
  expected+=(size_t)(rect.x1-rect.x0)*(rect.y1-rect.y0);rects[nrects++]=rect;
 }
 if(!nrects)return 0;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL18_BATCH_PLAN mode=%u vertices=%u rectangles=%u visible=%u\n",(unsigned)info->mode,d->count,pairs,nrects);
 /* Stage the affected rectangle once. All tiles must retire and pass the
  * coverage oracle before the destination is mapped for writing. No partial
  * framebuffer publication on a rejected tile. A small draw on a small
  * framebuffer preserves the physically qualified EGL9 layout. */
 unsigned rw=x1-x0,rh=y1-y0;
 const bool wide=getenv("REMESA_HRE_EGL24_WIDE")!=NULL;
 unsigned tile_max=wide?448u:224u;
 unsigned tw=MIN2(w,tile_max),th=MIN2(h,tile_max);
 if(getenv("REMESA_HRE_EGL29_ADAPTIVE")){
  unsigned mw=0,mh=0;for(unsigned i=0;i<nrects;i++){mw=MAX2(mw,rects[i].x1-rects[i].x0);mh=MAX2(mh,rects[i].y1-rects[i].y0);}
  unsigned bw=64,bh=64;while(bw<mw&&bw<tile_max)bw*=2;while(bh<mh&&bh<tile_max)bh*=2;
  tw=MIN2(w,MIN2(bw,tile_max));th=MIN2(h,MIN2(bh,tile_max));
 }else if(getenv("REMESA_HRE_EGL23_COMPACT")){
  unsigned mw=0,mh=0;for(unsigned i=0;i<nrects;i++){mw=MAX2(mw,rects[i].x1-rects[i].x0);mh=MAX2(mh,rects[i].y1-rects[i].y0);}
  tw=MIN2(tile_max,MAX2(32u,mw));th=MIN2(tile_max,MAX2(32u,mh));
  tw=MIN2(w,tw);th=MIN2(h,th);
 }
 bool tiled=w>tw||h>th;
 struct rc_scratch sz;if((e=rc_scratch_make(tw,th,&sz)))return e;
 const bool cpu_solid=!sampled&&opacity==255&&getenv("REMESA_HRE_EGL24_SOLID")!=NULL;
 struct pipe_resource *cpu_input=NULL;bool cpu_rgba=false,cpu_nearest=false;
 struct egl26_blit_plan plans[RC_EGL18_MAX_RECTS];
 bool cpu_blit=sampled&&getenv("REMESA_HRE_EGL26_BLIT")&&egl26_source_candidate(p,&cpu_input,&cpu_rgba,&cpu_nearest);
 if(cpu_blit)for(unsigned i=0;i<nrects;i++)if(!egl26_plan(&rects[i],cpu_input->width0,cpu_input->height0,cpu_nearest,&plans[i])){cpu_blit=false;break;}
 if(sampled&&getenv("REMESA_HRE_EGL26_BLIT")&&!cpu_blit&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_BLIT_FALLBACK\n");
 bool cpu_path=cpu_solid||cpu_blit;
 size_t sb=cpu_path?0:(size_t)sz.width*sz.height*4,db=(size_t)rw*rh*4;
 size_t reserve=sb*2+db;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_TILED_PLAN logical=%ux%u damage=%u,%u-%u,%u native=%ux%u staging=%zu scratch=%zu\n",w,h,x0,y0,x1,y1,sz.width,sz.height,db,sb*2);
 /* Import before reserving the draw workspace: shared sync has its own
  * full-frame allocation. Do not nest the two reservations. */
 uint64_t started=egl22_now_us(),native_us=0,close_us=0,mark=started;
 bool shared_target=target->shared_rt;
 bool direct=shared_target&&getenv("REMESA_HRE_EGL26_DIRECT")&&egl26_direct_target(target);
 const bool cloudtail=getenv("REMESA_HRE_EGL28_HOST_SYNC")!=NULL;
 const bool opaque_replace=cloudtail&&((cpu_blit&&opaque&&opacity==255)||(cpu_solid&&rgba[3]==255));
 /* Sparse mode is deliberately opt-in and CPU-only. Native tiles retain
  * their existing coverage oracle and publication contract. */
 struct egl30_damage damage;
 bool sparse=direct&&cpu_path&&nrects>1&&getenv("REMESA_HRE_EGL30_SPARSE");
 size_t damage_bytes=db;
 if(sparse){egl30_damage_make(&damage,rects,nrects,x0,y0,x1,y1);damage_bytes=egl30_damage_copy(&damage,NULL,0,NULL,0,false);
  /* Dense batches use the old path; avoid span iteration without savings. */
  /* Dense opaque replacement must still avoid a destination read: exact
   * union publication preserves holes. For a full union there are no holes. */
  if(!damage_bytes||(damage_bytes>=db-db/4&&
     !(getenv("REMESA_HRE_EGL32_DENSE_DISCARD")&&(!blend->compositor_blend||opaque_replace)))){sparse=false;damage_bytes=db;}
 }
 const bool native_replace=!cpu_path&&getenv("REMESA_HRE_EGL31_NATIVE_RESOLVE")&&opacity==255&&(!blend->compositor_blend||opaque);
 bool overwrite=(cpu_path&&(!blend->compositor_blend||opaque_replace)&&(nrects==1||sparse))||(native_replace&&nrects==1);
 if(sparse&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL30_SPARSE_PLAN rectangles=%u bbox_bytes=%zu union_bytes=%zu discard=%u\n",nrects,db,damage_bytes,(unsigned)overwrite);
 if(shared_target&&!direct){e=hre_shared_rt_region(p->screen,target,false,x0,y0,rw,rh);if(e){fprintf(stderr,"HRE_EGL16_FAIL stage=import errno=%d\n",e);return e;}}
 uint64_t import_us=egl22_now_us()-started;
 if(!host_buffer_reserve(sc,reserve)){fprintf(stderr,"HRE_TILE_FAIL stage=host_budget request=%zu used=%zu limit=%llu\n",reserve,__atomic_load_n(&sc->host_buffer_bytes,__ATOMIC_RELAXED),(unsigned long long)host_buffer_limit(sc));return ENOMEM;}
 uint8_t *mem=malloc(reserve);if(!mem){e=ENOMEM;fprintf(stderr,"HRE_EGL16_FAIL stage=workspace errno=%d\n",e);goto done;}
 uint8_t *color=mem,*depth=mem+sb,*dst=mem+2*sb;
 /* Snapshot only damage, not the complete framebuffer. The existing shared_target
  * RT synchronization still authenticates and imports the external storage. */
 struct pipe_box box={.x=x0,.y=y0,.width=rw,.height=rh,.depth=1};
 struct pipe_transfer *rt=NULL;
 if(direct){
  if(overwrite){if(!cloudtail&&!sparse)memset(dst,0,db);if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_DISCARD_READ bytes=%zu\n",damage_bytes);}
  else if(sparse){if((e=egl30_external_damage(p->screen,target,false,&damage,dst,(size_t)rw*4,damage_bytes)))goto done;}
  else if((e=egl26_external_region(p->screen,target,false,x0,y0,rw,rh,dst)))goto done;
  import_us=egl22_now_us()-started;
 }else{
 if(shared_target)target->shared_refresh=true;
 const uint8_t *src=map(p,ctx->target,0,PIPE_MAP_READ,&box,&rt);
 if(shared_target)target->shared_refresh=false;
 if(!src){e=ctx->error?ctx->error:EIO;fprintf(stderr,"HRE_EGL16_FAIL stage=read_map errno=%d\n",e);goto done;}
 for(unsigned y=0;y<rh;y++)memcpy(dst+(size_t)y*rw*4,src+(size_t)y*rt->stride,(size_t)rw*4);
 unmap(p,rt);if(target->write_error){e=target->write_error;goto done;}
 }
 size_t total=0;unsigned tiles=0,session_tiles=0,gpu2d_count=0;
 const char *reuse=getenv("REMESA_HRE_EGL22_REUSE");
 unsigned session_limit=reuse&&!strcmp(reuse,"4")?4u:reuse&&!strcmp(reuse,"8")?8u:reuse&&!strcmp(reuse,"2")?2u:1u;
 const bool graph_reuse=getenv("REMESA_HRE_EGL24_GRAPH")!=NULL&&session_limit>1;
 if(cpu_blit){
  uint64_t begin=egl22_now_us();
  const struct pipe_box full={.width=cpu_input->width0,.height=cpu_input->height0,.depth=1};
  struct pipe_transfer *st=NULL;
  const uint8_t *texture=map(p,cpu_input,0,PIPE_MAP_READ,&full,&st);
  if(!texture){e=ctx->error?ctx->error:EIO;goto done;}
  if(st->stride<(size_t)cpu_input->width0*4){unmap(p,st);e=EPROTO;goto done;}
  bool dest_opaque=target->shared_opaque||ctx->target->format==PIPE_FORMAT_B8G8R8X8_UNORM;
  for(unsigned i=0;i<nrects;i++){
   const struct rc_egl18_rect *a=&rects[i];unsigned width=a->x1-a->x0,height=a->y1-a->y0;
   size_t offset=((size_t)(a->y0-y0)*rw+a->x0-x0)*4;
   bool used=false;
   /* The input is host-mapped, not a live GEM lease. Only single-rectangle
    * batches are eligible, preserving all existing sparse and blend paths. */
   if(nrects==1){e=egl31_gpu2d(p,cpu_input,&plans[i],texture,st->stride,dst+offset,(size_t)rw*4,width,height,cpu_rgba,opaque,dest_opaque,blend->compositor_blend,opacity,&used);
    if(e){unmap(p,st);goto done;}}
   if(used)gpu2d_count++;
   else egl26_blit(&plans[i],texture,st->stride,cpu_input->width0,cpu_input->height0,dst+offset,(size_t)rw*4,width,height,cpu_rgba,opaque,dest_opaque,blend->compositor_blend,opacity);
   total+=(size_t)width*height;
  }
  unmap(p,st);if(r(cpu_input)->write_error||ctx->error){e=r(cpu_input)->write_error?r(cpu_input)->write_error:ctx->error;goto done;}
  if(!gpu2d_count&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_CPU_BLIT_WORK pixels=%zu us=%llu\n",total,(unsigned long long)(egl22_now_us()-begin));
 }else if(cpu_solid){
  bool dest_opaque=target->shared_opaque||ctx->target->format==PIPE_FORMAT_B8G8R8X8_UNORM;
  for(unsigned i=0;i<nrects;i++){
   const struct rc_egl18_rect *rect=&rects[i];
   unsigned width=rect->x1-rect->x0,height=rect->y1-rect->y0;
   size_t offset=((size_t)(rect->y0-y0)*rw+rect->x0-x0)*4;
   size_t span=(size_t)(height-1)*rw*4+(size_t)width*4;
   if(offset>db||span>db-offset){e=EPROTO;goto done;}
   egl24_solid_rect(dst+offset,rw*4,width,height,rgba,blend->compositor_blend,dest_opaque);
   total+=(size_t)width*height;
  }
 }else{
 for(unsigned rect_index=0;rect_index<nrects;rect_index++){
 const struct rc_egl18_rect *rect=&rects[rect_index];
 for(unsigned ty=tiled?rect->y0:0;ty<rect->y1;ty+=th)for(unsigned tx=tiled?rect->x0:0;tx<rect->x1;tx+=tw){
  unsigned ax=MAX2(rect->x0,tx)-tx,ay=MAX2(rect->y0,ty)-ty,bx=MIN2(rect->x1,tx+tw)-tx,by=MIN2(rect->y1,ty+th)-ty;
  struct rc_native_vertex mesh[42];unsigned nv=0;
  bool canonical=getenv("REMESA_HRE_EGL25_AFFINE")&&egl25_affine_tile(rect,&sz,tx,ty,ax,ay,bx,by,mesh,&nv);
  if(canonical&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL25_AFFINE_TILE vertices=6\n");
  if(!canonical)for(unsigned j=0;j<2;j++){
   struct rc_vertex tri[3]={rect->v[3*j],rect->v[3*j+1],rect->v[3*j+2]};struct rc_triangle t;
   for(unsigned k=0;k<3;k++){tri[k].x-=tx;tri[k].y-=ty;}
   if((e=rc_scratch_triangle(&sz,tri,ax,ay,bx,by,&t)))goto tile_fail;
   if(t.count>42-nv){e=EOVERFLOW;goto tile_fail;}
   memcpy(mesh+nv,t.v,t.count*sizeof(*mesh));nv+=t.count;
  }
  if(!nv){e=EPROTO;goto tile_fail;}
  bool close_now=session_tiles+1>=session_limit||
   (rect_index+1==nrects&&tx+tw>=rect->x1&&ty+th>=rect->y1);
  /* At a group boundary CLOSE can authenticate and release the still-attached
   * retired graph. DROP is needed only for reuse/replacement, not for terminal
   * teardown; keep this experimental until the actual kernel accepts CLOSE. */
  bool direct_close=close_now&&getenv("REMESA_HRE_EGL29_DIRECT_CLOSE");
  bool keep_graph=(graph_reuse&&!close_now)||direct_close;
  mark=egl22_now_us();e=hybrid_native_scratch(p,&sz,mesh,nv,rgba,sampled,color,depth,graph_reuse&&session_tiles>0,keep_graph);native_us+=egl22_now_us()-mark;if(e)goto tile_fail;
  /* Exact rectangle coverage, including guard band, for every tile. */
  for(unsigned y=0;y<sz.height;y++)for(unsigned x=0;x<sz.width;x++){
   bool hit=x>=sz.x+ax&&x<sz.x+bx&&y>=sz.y+ay&&y<sz.y+by;
   if(rc_z24(depth+((size_t)y*sz.width+x)*4)!=(hit?0xa00000u:0xffffffu)){e=EPROTO;goto tile_fail;}
   if(hit&&!sampled&&memcmp(color+((size_t)y*sz.width+x)*4,(uint8_t[]){rgba[2],rgba[1],rgba[0],rgba[3]},4)){e=EPROTO;goto tile_fail;}
  }
  unsigned dx=tx+ax-x0,dy=ty+ay-y0;
  size_t offset=((size_t)dy*rw+dx)*4;
  size_t plane_bytes=(size_t)(by-ay-1)*rw*4+(size_t)(bx-ax)*4;
  if(offset>db||plane_bytes>db-offset){e=EPROTO;goto tile_fail;}
  struct rc_resolve_desc desc={.sw=sz.width,.sh=sz.height,.x=sz.x+ax,.y=sz.y+ay,.w=bx-ax,.h=by-ay,.z_hit=0xa00000,.z_clear=0xffffff,.opacity=opacity,.force_source_opaque=opaque,.force_dest_opaque=target->shared_opaque||ctx->target->format==PIPE_FORMAT_B8G8R8X8_UNORM,.blend=blend->compositor_blend};
  size_t covered=0;
  if(native_replace){
   uint64_t rb=egl22_now_us();
   e=egl31_resolve_replace(&desc,(struct rc_resolve_plane){color,sb,sz.width*4},(struct rc_resolve_plane){dst+offset,plane_bytes,rw*4},&covered);
   if(!e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL31_NATIVE_RESOLVE pixels=%zu discard=%u us=%llu\n",covered,(unsigned)(direct&&overwrite),(unsigned long long)(egl22_now_us()-rb));
  }else e=rc_resolve_bgra(&desc,(struct rc_resolve_plane){color,sb,sz.width*4},(struct rc_resolve_plane){depth,sb,sz.width*4},(struct rc_resolve_plane){dst+offset,plane_bytes,rw*4},&covered);
  if(e)goto tile_fail;
  if(covered!=(size_t)(bx-ax)*(by-ay)){e=EPROTO;goto tile_fail;}
 /* EGL20: close each retired tile before preparing another graph. */
 struct pipe_context *q=ctx->compositor_scratch;
 if(!q||c(q)->texture_graph_detached==keep_graph){e=EPROTO;goto tile_fail;}
 session_tiles++;
 if(close_now){
 mark=egl22_now_us();e=remesa_context_release_texture_scene(q);close_us+=egl22_now_us()-mark;
 if(e){if(c(q)->failed_submission||e==EOWNERDEAD)ctx->failed_submission=true;
  fprintf(stderr,"HRE_COMPOSITOR_SESSION_CLOSE_FAIL errno=%d\n",e);goto tile_fail;}
 /* The private scratch is deliberately discard-only. Invalidate through
  * the normal retired-pass API, never by clearing has_contents alone. */
 invalidate_resource(q,c(q)->target);if((e=c(q)->error))goto tile_fail;
 invalidate_resource(q,c(q)->depth_target);if((e=c(q)->error))goto tile_fail;
 if(direct_close&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL29_DIRECT_CLOSE_PASS tiles=%u\n",session_tiles);
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_COMPOSITOR_SESSION_BOUNDARY tiles=%u closed=1\n",session_tiles);
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL20_TILE_CLOSE_PASS\n");
 session_tiles=0;
 }
  total+=covered;tiles++;continue;
 tile_fail:fprintf(stderr,"HRE_TILE_FAIL stage=draw_or_resolve origin=%u,%u completed=%u errno=%d\n",tx,ty,tiles,e);
 /* On a conclusive refusal, close through the existing checked owner API.
  * It refuses live writers/maps; never pretend an uncertain close succeeded. */
 if((session_limit>1||getenv("REMESA_HRE_EGL29_DIRECT_CLOSE"))&&ctx->compositor_scratch&&!ctx->failed_submission){
  struct pipe_context *sq=ctx->compositor_scratch;
  if(!c(sq)->failed_submission&&(c(sq)->texture_graph_detached||
     ((graph_reuse||getenv("REMESA_HRE_EGL29_DIRECT_CLOSE"))&&c(sq)->owned_texture_scene.owner))){
   int ce=remesa_context_release_texture_scene(sq);
   if(ce){e=ce;if(c(sq)->failed_submission||ce==EOWNERDEAD)ctx->failed_submission=true;}
  }
 }
 goto done;
 }


 }
 }
 if(total!=expected||session_tiles){e=EPROTO;goto done;}
 uint64_t commit_begin=egl22_now_us();
 struct pipe_transfer *wt=NULL;
 if(shared_target)target->shared_refresh=true;
 uint8_t *out=map(p,ctx->target,0,PIPE_MAP_WRITE,&box,&wt);
 if(!out){if(shared_target)target->shared_refresh=false;e=ctx->error?ctx->error:EIO;fprintf(stderr,"HRE_EGL16_FAIL stage=write_map errno=%d\n",e);goto done;}
 uint64_t commit_mapped=egl22_now_us();
 if(sparse)egl30_damage_copy(&damage,out,wt->stride,dst,(size_t)rw*4,false);
 else for(unsigned y=0;y<rh;y++)memcpy(out+(size_t)y*wt->stride,dst+(size_t)y*rw*4,(size_t)rw*4);
 uint64_t commit_copied=egl22_now_us();
 unmap(p,wt);
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL27_COMMIT map_us=%llu copy_us=%llu unmap_us=%llu bytes=%zu\n",(unsigned long long)(commit_mapped-commit_begin),(unsigned long long)(commit_copied-commit_mapped),(unsigned long long)(egl22_now_us()-commit_copied),damage_bytes);if(shared_target)target->shared_refresh=false;
 e=target->write_error?target->write_error:ctx->publication_error;
 if(!e&&ctx->error)e=ctx->error;
 /* Release workspace before publication; preserve the original fail-closed
  * shared_target sync and resource lease checks. */
 if(!direct){free(mem);mem=NULL;__atomic_sub_fetch(&sc->host_buffer_bytes,reserve,__ATOMIC_RELAXED);reserve=0;}
 mark=egl22_now_us();
 if(!e&&shared_target){
  if(direct){e=sparse?egl30_external_damage(p->screen,target,true,&damage,dst,(size_t)rw*4,damage_bytes):egl26_external_region(p->screen,target,true,x0,y0,rw,rh,dst);if(e)target->write_error=e;}
  else e=hre_shared_rt_region(p->screen,target,true,x0,y0,rw,rh);
  if(e)ctx->publication_error=e;
 }
 if(e)fprintf(stderr,"HRE_EGL16_FAIL stage=publish errno=%d\n",e);
 else if(shared_target&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL16_SERIAL_SYNC_PASS\n");
 if(!e&&sparse&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL30_SPARSE_PASS bbox_bytes=%zu union_bytes=%zu import_bytes=%zu publish_bytes=%zu\n",db,damage_bytes,overwrite?0:damage_bytes,damage_bytes);
 if(!e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL18_BATCH_PASS rectangles=%u tiles=%u\n",nrects,tiles);
 if(!e&&getenv("REMESA_DRI_TRACE")){
  if(gpu2d_count)fprintf(stderr,"HRE_EGL31_GPU2D_PASS covered=%zu rectangles=%u\n",total,gpu2d_count);
  else if(cpu_blit)fprintf(stderr,"HRE_EGL26_CPU_BLIT_PASS covered=%zu rectangles=%u (CPU texture blit, no native submission)\n",total,nrects);
  else if(cpu_solid)fprintf(stderr,"HRE_EGL24_SOLID_PASS covered=%zu rectangles=%u (CPU 2D, no native submission)\n",total,nrects);
  else fprintf(stderr,"HRE_COMPOSITOR_HYBRID_DRAW_OK covered=%zu sampled=%u blend=%u tiles=%u (native raster, CPU resolve)\n",total,(unsigned)sampled,(unsigned)blend->compositor_blend,tiles);
 }
 if(!e&&ctx->egl33_release){
  egl33_record(&ctx->egl33,egl22_now_us()-started,cpu_blit,cpu_solid,gpu2d_count,tiles);
  if((ctx->egl33.batches&255u)==0)egl33_report(&ctx->egl33,ctx,false);
 }
 if(!e&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL22_TIMING tiles=%u total_us=%llu import_us=%llu native_us=%llu close_us=%llu publish_us=%llu\n",tiles,(unsigned long long)(egl22_now_us()-started),(unsigned long long)import_us,(unsigned long long)native_us,(unsigned long long)close_us,(unsigned long long)(egl22_now_us()-mark));
 done:free(mem);__atomic_sub_fetch(&sc->host_buffer_bytes,reserve,__ATOMIC_RELAXED);return e;
}
