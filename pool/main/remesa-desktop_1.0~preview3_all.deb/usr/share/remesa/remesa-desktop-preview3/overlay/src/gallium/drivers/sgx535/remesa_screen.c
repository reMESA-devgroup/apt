/* SPDX-License-Identifier: MIT */
#include "remesa_screen.h"
#include <errno.h>
#ifdef REMESA_WITH_MESA_HEADERS
#include "remesa_resource_ref.h"
#include "remesa_egl33_stats.h"
#include "remesa_dmabuf_snapshot.h"
#include "remesa_dmabuf_texture.h"
#include "remesa_dmabuf_shared.h"
#include "frontend/winsys_handle.h"
#include <drm_fourcc.h>
#include <drm.h>
#include <limits.h>
#include "remesa_device.h"
#include "remesa_persistent.h"
#include "remesa_gears_runtime.h"
#include <stdio.h>
#include "remesa_resource_layout.h"
#include "remesa_draw.h"
#include "remesa_fixed_state.h"
#include "remesa_depth_cpu.h"
#include "remesa_cpu_fill.h"
#include "remesa_render_pass.h"
#include "remesa_ta_scene.h"
#include "remesa_sampler_state.h"
#include "remesa_texture_binding.h"
int remesa_texture_binding_gallium_live_only(struct remesa_texture_binding_bank *);
#include "remesa_texture_descriptor.h"
#include "remesa_nir_uniform.h"
#include "remesa_pds_structure.h"
#include "remesa/matrix_draw_domain.h"
#include "remesa/texture_draw_domain.h"
#ifdef REMESA_WITH_NIR
#include "remesa_nir.h"
#include "remesa_compositor_nir.h"
#include "remesa_compositor_geometry.h"
#include "remesa_compositor_resolve.h"
#include "nir_builder.h"
#include "remesa_usse_ssa.h"
#include "remesa_shader_ir.h"
#include "remesa_shader_program.h"
#include "nir.h"
#include "util/ralloc.h"
#include "gallium/auxiliary/util/u_upload_mgr.h"
#endif
#include "pipe/p_screen.h"
#include "pipe/p_context.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
static void draw(struct pipe_context *,const struct pipe_draw_info *,unsigned,
 const struct pipe_draw_indirect_info *,const struct pipe_draw_start_count_bias *,unsigned);
static void destroy_screen(struct pipe_screen *);
struct resource;
/* Serialized API entry; children retain the backend until final teardown. */
struct screen {
 struct pipe_screen base; struct remesa_device device; unsigned refs; bool closing;
 int (*release_device)(struct remesa_device *);int release_error;bool release_pending;
 uint64_t resource_cookie;bool cpu_depth24_lab,gears_runtime,linked_attachment_storage,linked_scene_experiment;
 bool homogeneous_frontend_lab,native_draws,native_preserve_candidate,hybrid_2d,texture_qualification,hre,hre_headless;
 uint32_t homogeneous_frontend_dimension;
 size_t host_buffer_bytes;
 bool buffer_renaming,egl_dmabuf_lab;
 struct remesa_frontbuffer_sink frontbuffer;bool frontbuffer_busy;
 struct remesa_drm_display *display;struct remesa_display_access display_access;
 struct resource *display_resources;int display_error;
 remesa_copy_region_fn native_copy;
 remesa_fill_region_fn native_fill;
};
static void screen_hold(struct screen *sc)
{ __atomic_add_fetch(&sc->refs,1,__ATOMIC_RELAXED); }
static int release_screen_backend(struct screen *sc)
{
 if(sc->display_error)return sc->display_error;
 if(sc->display){int error=remesa_drm_display_close(&sc->display);if(error)return error;}
 return sc->release_device?sc->release_device(&sc->device):0;
}
static void screen_drop(struct screen *sc)
{
 if(!__atomic_sub_fetch(&sc->refs,1,__ATOMIC_ACQ_REL)) {
  int error=release_screen_backend(sc);
  if(error) {
   /* Backend still owns pending/quarantined resources. Retain the owner. */
   __atomic_store_n(&sc->refs,1,__ATOMIC_RELEASE);
   sc->release_pending=true;sc->release_error=error;return;
  }
  free(sc);
 }
}
/* Screen-wide identities must remain unique across independent contexts.
 * Saturation refuses allocation rather than reusing an old pass identity. */
static bool screen_next_resource_cookie(struct screen *sc,uint64_t *cookie)
{
 uint64_t previous=__atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED);
 do {
  if(previous==UINT64_MAX)return false;
 }while(!__atomic_compare_exchange_n(&sc->resource_cookie,&previous,previous+1,
                                   true,__ATOMIC_RELAXED,__ATOMIC_RELAXED));
 *cookie=previous+1;return true;
}
/* CPU input backing has its own bounded, screen-wide allocation ledger. */
static size_t host_buffer_limit(struct screen *sc)
{
 uint64_t budget=sc->device.resource_limits.max_resource_bytes;
 const char *residency=getenv("REMESA_HRE_COMPOSITOR_RESIDENCY");
 /* The compositor's CPU staging is not GPU VA. Keep its own finite budget.
  * Preserve the original limit for all other clients. */
 if(residency&&!strcmp(residency,"1"))budget=UINT64_C(64)*1024*1024;
 if(!budget)budget=UINT64_C(64)*1024*1024;
 return budget>SIZE_MAX?SIZE_MAX:(size_t)budget;
}
static bool host_buffer_reserve(struct screen *sc,size_t bytes)
{
 size_t limit=host_buffer_limit(sc);
 size_t previous=__atomic_load_n(&sc->host_buffer_bytes,__ATOMIC_RELAXED);
 do {
  if(previous>limit||bytes>limit-previous){
   if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL21C_HOST_LIMIT request=%zu used=%zu limit=%zu\n",bytes,previous,limit);
   return false;
  }
 }while(!__atomic_compare_exchange_n(&sc->host_buffer_bytes,&previous,previous+bytes,
                                    true,__ATOMIC_RELAXED,__ATOMIC_RELAXED));
 return true;
}
/* Fixed-size metadata slab: at most three backing versions per resource.
 * Old versions retain their exact pass/ticket/fence until authenticated CPU
 * publication and retirement. No allocation on the collection/reuse path. */
struct renamed_backing {
 void *bo;struct pipe_fence_handle *writer;
 struct remesa_render_pass pass;struct remesa_pass_ticket ticket;
};
struct resource {
 struct pipe_resource base; void *bo; size_t bytes; unsigned maps;unsigned stride;
 bool persistent_attachment, compositor_host_texture;
 struct remesa_shared_image *shared_sampler;
 unsigned char *shared_cache;
 bool shared_refresh,shared_cache_valid,shared_opaque,shared_writable,shared_rt,shared_discard;
 struct pipe_resource *sample_shadow;
 void *host_data; /* CPU input storage; copied to owned GEM at scene preparation. */
 struct remesa_texture_layout layout;
 struct pipe_fence_handle *writer; int write_error; bool has_contents;
 bool retired_color_map;
 bool retired_depth_map;
 struct context *native_clear_owner; /* Unissued clear; never CPU-readable. */
 struct remesa_render_pass pass;struct remesa_pass_ticket ticket;
 struct renamed_backing renamed[2];
 struct remesa_display_token display;uint32_t display_name;
 uint64_t display_epoch;
 struct resource *display_next;
};
enum fixed_kind { FIXED_BLEND,FIXED_DSA,FIXED_RASTER,FIXED_COUNT };
struct fixed { struct fixed *next; enum fixed_kind kind; bool deleted,compositor_blend,compositor_only,scissor,depth_clip,full_clip,recording_edge_proof,native_raster_pending,native_w2_raster;
 unsigned cull_face,depth_func,colormask;bool bottom_edge_rule,front_ccw,depth_clip_near,depth_clip_far,flat,flat_first,clamp_vertex_color,depth_enabled,depth_write; };
struct elements { struct elements *next; struct pipe_vertex_element position,normal,light; unsigned count; bool deleted; };
struct vertex { struct vertex *next; unsigned input_slot; bool deleted;
#ifdef REMESA_WITH_NIR
 struct remesa_shader_program program;
 struct remesa_ssa_vertex_shader ssa;bool ssa_only;
 bool compositor_live;struct rc_program compositor;
#endif
};
struct fragment { struct fragment *next; uint32_t argb; bool deleted,uses_uniform;
#ifdef REMESA_WITH_NIR
 struct remesa_shader_program program;
 bool compositor_live;struct rc_program compositor;
#endif
 struct remesa_uniform_color uniform; };
struct transfer;
struct context {
 struct pipe_context base; struct pipe_vertex_buffer vb,second_vb,third_vb; unsigned vb_count; struct pipe_vertex_element position;
 struct pipe_resource *target,*depth_target; bool position_bound,pipeline_bound,diagnostic_discard; uint32_t argb;
 int error,publication_error; struct pipe_fence_handle *last; uint64_t cpu_clears,cpu_copies,native_copies,native_fills;
 bool failed_submission;
 bool egl33_release;struct egl33_stats egl33;
 struct pipe_context *compositor_scratch;
 /* Private scratch-context cache: caller refs, released before bank close. */
 struct pipe_sampler_view *compositor_views[2];void *compositor_samplers[32];
 unsigned compositor_view_creations;bool compositor_carrier;
 /* One immutable resident upload per scratch context, not an owned scene. */
 struct pipe_resource *compositor_upload_cache;
 uint64_t compositor_upload_cookie,compositor_upload_epoch;
 /* Private transfer-only 2D GEMs, never imported scanout or 3D attachments. */
 struct pipe_resource *egl31_src,*egl31_dst;
 uint64_t egl31_cookie,egl31_epoch;
 struct pipe_resource *egl32_spare;
 uint64_t egl32_spare_cookie,egl32_spare_epoch;
 bool egl31_copy_active;
 bool presenting;
 struct remesa_scene_capture owned_texture_scene;
 struct pipe_resource *hre_graph_color,*hre_graph_depth;
 uint64_t texture_draw_state[32];bool texture_draw_state_valid,texture_draw_started;
 bool texture_replacement_pending,texture_graph_detached; /* V3 replacement may retry after DROP. */
 bool homogeneous_draw_lab;
 enum remesa_homogeneous_api_lab_profile homogeneous_api_lab;
 struct pipe_resource *native_clear_color,*native_clear_depth;
 /* Expected identities AFTER verified retirement, never completion proof.
  * Cookies prevent ABA; epochs invalidate CPU/foreign writer interference. */
 struct remesa_pass_snapshot native_color_expected,native_depth_expected;
 bool native_content_expected;
 bool gears_pending,gears_poisoned,gears_bottom_left,gears_origin_valid;unsigned gears_clear_mask;
 struct pipe_resource *gears_target,*gears_depth;
 struct remesa_draw_rejection_status draw_rejections;
 struct remesa_shader_compile_status shader_compile[2];
 struct fragment *fragments,*bound_fragment;
 bool invalid_viewport,invalid_scissor,invalid_constants,sample_enabled; uint32_t constant_rejections[2];
 void *ssa_code;struct vertex *ssa_vertex;struct fragment *ssa_fragment;
 struct vertex *vertices,*bound_vertex; bool vertex_required,viewport_set;
 struct elements *elements,*bound_elements;bool invalid_elements;
 struct pipe_viewport_state viewport;
 struct pipe_scissor_state compositor_scissor;
 struct fixed *fixed_states,*bound_fixed[FIXED_COUNT];bool invalid_fixed[FIXED_COUNT],scissor_set;
 struct remesa_sampler_bank *samplers;
 struct remesa_texture_binding_bank *textures;
 struct pipe_resource *fragment_constants;unsigned constant_offset,constant_size;
 void *constant_snapshot;
 struct pipe_resource *vertex_constants;unsigned vertex_constant_offset,vertex_constant_size;
 void *vertex_constant_snapshot;
 struct transfer *transfers;
};
struct pipe_fence_handle { unsigned refs; struct screen *screen; void *backend; };
struct transfer {
 struct pipe_transfer base; struct transfer *next;
 unsigned char *backing,*staging; bool write,dirty;
 void *mapping;size_t mapping_bytes,staging_bytes;
};
static struct screen *s(struct pipe_screen *p) { return (struct screen *)p; }
static struct context *c(struct pipe_context *p) { return (struct context *)p; }
static struct resource *r(struct pipe_resource *p) { return (struct resource *)p; }
static unsigned resource_bind(const struct pipe_resource *p)
{
 unsigned hints=PIPE_BIND_SHARED|PIPE_BIND_SCANOUT|PIPE_BIND_DISPLAY_TARGET;
 /* Mesa's image frontend adds SAMPLER_VIEW to display attachments as a
  * storage request. Bare sampler/combined texture capabilities stay closed;
  * actual sampling still passes the independent shader/session validators. */
 if((p->bind&(PIPE_BIND_SHARED|PIPE_BIND_RENDER_TARGET))==(PIPE_BIND_SHARED|PIPE_BIND_RENDER_TARGET))hints|=PIPE_BIND_SAMPLER_VIEW;
 if((p->bind&(PIPE_BIND_DISPLAY_TARGET|PIPE_BIND_RENDER_TARGET))==
    (PIPE_BIND_DISPLAY_TARGET|PIPE_BIND_RENDER_TARGET))hints|=PIPE_BIND_SAMPLER_VIEW;
 return p->bind&~hints;
}
static int resource_map_backing(struct pipe_screen *p,struct resource *b,bool write,void **out)
{
 if(b->host_data){*out=b->host_data;return 0;}
 struct screen *sc=s(p);
 /* A bound attachment retained by a kept scene is refused by map_bo; both
  * explicit READ-lease pairs (COLOR/DEPTH) resolve the owning scene from
  * the BO itself. ENODATA alone falls through to the ordinary map path. */
 bool color_route=!write&&sc->linked_attachment_storage&&
  b->base.format==PIPE_FORMAT_B8G8R8A8_UNORM&&
  resource_bind(&b->base)==PIPE_BIND_RENDER_TARGET&&sc->device.ops->map_retired_color;
 bool depth_route=!write&&sc->linked_attachment_storage&&
  b->base.format==PIPE_FORMAT_Z24X8_UNORM&&
  resource_bind(&b->base)==PIPE_BIND_DEPTH_STENCIL&&sc->device.ops->map_retired_depth;
 if(color_route||depth_route){
  int error=color_route?sc->device.ops->map_retired_color(&sc->device,b->bo,out):
   sc->device.ops->map_retired_depth(&sc->device,b->bo,out);
  if(!error||*out){b->retired_color_map=color_route;b->retired_depth_map=depth_route;}
  if(error!=ENODATA||*out){if(error==EOWNERDEAD)b->write_error=error;return error;}
 }
 return s(p)->device.ops->map(s(p)->device.priv,b->bo,write,out);
}
static void resource_unmap_backing(struct pipe_screen *p,struct resource *b,bool write)
{
 if(b->retired_color_map){
  int error=write?EOWNERDEAD:s(p)->device.ops->unmap_retired_color(&s(p)->device,b->bo);
  if(error)b->write_error=EOWNERDEAD; /* retain uncertain lease; never normal-unmap */
  else b->retired_color_map=false;
 }else if(b->retired_depth_map){
  int error=write?EOWNERDEAD:s(p)->device.ops->unmap_retired_depth(&s(p)->device,b->bo);
  if(error)b->write_error=EOWNERDEAD; /* retain uncertain lease; never normal-unmap */
  else b->retired_depth_map=false;
 }else if(!b->host_data){
  struct screen *sc=s(p);
  if(sc->device.ops->unmap_checked){
   int error=sc->device.ops->unmap_checked(sc->device.priv,b->bo,write);
   if(error)b->write_error=error;
  }else sc->device.ops->unmap(sc->device.priv,b->bo,write);
 }
}

/* New host inspection/build APIs must not publish into their own owner or
 * immutable shader handles. Validate the whole output range before any write
 * (including the constructor's output-reference read). */
static bool context_output_valid(struct context *ctx,const void *out,size_t bytes)
{
 uintptr_t start=(uintptr_t)out;
 if(!out||bytes>UINTPTR_MAX-start)return false;
 uintptr_t end=start+bytes;
#define OUTPUT_OVERLAPS(object) (start<(uintptr_t)(object)+sizeof(*(object))&&end>(uintptr_t)(object))
 if(OUTPUT_OVERLAPS(ctx)||OUTPUT_OVERLAPS(s(ctx->base.screen)))return false;
 for(struct vertex *v=ctx->vertices;v;v=v->next)if(OUTPUT_OVERLAPS(v))return false;
 for(struct fragment *f=ctx->fragments;f;f=f->next)if(OUTPUT_OVERLAPS(f))return false;
 for(struct elements *e=ctx->elements;e;e=e->next)if(OUTPUT_OVERLAPS(e))return false;
 for(struct fixed *f=ctx->fixed_states;f;f=f->next)if(OUTPUT_OVERLAPS(f))return false;
 for(struct transfer *t=ctx->transfers;t;t=t->next){
  if(OUTPUT_OVERLAPS(t))return false;
  const void *views[]={t->mapping,t->staging};
  const size_t lengths[]={t->mapping_bytes,t->staging_bytes};
  for(unsigned i=0;i<2;i++)if(views[i]&&lengths[i]){
   uintptr_t at=(uintptr_t)views[i];
   if(lengths[i]>UINTPTR_MAX-at||(start<at+lengths[i]&&at<end))return false;
  }
 }
#undef OUTPUT_OVERLAPS
 return true;
}
static bool context_state_output_valid(struct context *ctx,const void *out,size_t bytes)
{
 if(!context_output_valid(ctx,out,bytes))return false;
 struct pipe_resource *owners[]={ctx->target,ctx->depth_target,ctx->hre_graph_color,ctx->hre_graph_depth,ctx->vb.buffer.resource,
  ctx->second_vb.buffer.resource,ctx->third_vb.buffer.resource,
  ctx->vertex_constants,ctx->fragment_constants};
 uintptr_t at=(uintptr_t)out;
 for(unsigned i=0;i<sizeof(owners)/sizeof(owners[0]);i++)if(owners[i]){
  uintptr_t base=(uintptr_t)owners[i];
  if(at<base+sizeof(struct resource)&&base<at+bytes)return false;
 }
 return true;
}
static void fence_ref(struct pipe_screen *,struct pipe_fence_handle **,struct pipe_fence_handle *);
static bool hre_gles_lab(const struct screen *sc)
{
 const char *lab=getenv("REMESA_HRE_GLES_LAB");
 const char *override=getenv("MESA_GLES_VERSION_OVERRIDE");
 return sc->hre_headless&&sc->hre&&lab&&!strcmp(lab,"1")&&override&&!strcmp(override,"2.0");
}
static bool hybrid_enabled(const struct screen *sc)
{
 const char *v=getenv("REMESA_HRE_COMPOSITOR_HYBRID");
 return hre_gles_lab(sc)&&sc->egl_dmabuf_lab&&v&&!strcmp(v,"1");
}
static void set_capabilities(struct screen *sc)
{
 struct pipe_caps caps={0}; struct pipe_shader_caps shader={0};
 const bool scene_frontend=sc->homogeneous_frontend_lab||sc->native_draws||sc->linked_scene_experiment;
 /* Narrow Gallium contract only; this does not advertise an OpenGL version. */
 caps.graphics=!sc->device.resource_only_backend||scene_frontend||sc->hre_headless;
 caps.accelerated=!sc->device.resource_only_backend&&!sc->device.retained_fragment_carrier&&sc->device.qualified_hardware_backend ? 1 : 0;
 caps.max_render_targets=1; caps.max_texture_2d_size=sc->cpu_depth24_lab?4096:(sc->linked_scene_experiment||sc->hre_headless)?2048:32;
 if(sc->homogeneous_frontend_lab||sc->native_draws)caps.max_texture_2d_size=sc->homogeneous_frontend_dimension;
 /* Binding/storage limits; the legacy draw admission below remains one
  * element/one VB. The complete gears capture has separate validation. */
 caps.max_vertex_buffers=2; caps.max_vertex_attrib_stride=2048;
 /* Mesa copies this hint over its 512-KiB core default. Zero leaves the
  * immediate-mode VBO without storage before shader/draw validation. This
  * bounds CPU stream allocation; it adds no vertex instruction support. */
 caps.gl_begin_end_buffer_size=512*1024;
 caps.constant_buffer_offset_alignment=16;
 caps.max_viewports=1; caps.supported_prim_modes=1u<<MESA_PRIM_TRIANGLES;
 /* Whole-resource invalidation keeps backing stable and synchronizes the
  * authenticated writer. This is a storage contract, not GPU clear support. */
 caps.invalidate_buffer=true;
 if(sc->egl_dmabuf_lab){
  caps.dmabuf=DRM_PRIME_CAP_IMPORT;
  /* Experimental level-zero NPOT storage and upload; draw validation still
   * rejects unqualified sampler/shader combinations. Not GLES conformance. */
  caps.npot_textures=true;
 }
 /* clear() clips and validates a rectangular CPU write after synchronizing
  * the resource writer. Let Mesa use that callback instead of lowering a
  * scissored clear to an unsupported shader draw. This is not a GPU clear. */
 caps.clear_scissored=!scene_frontend; /* Native cold clear is full-target only. */
 /* Position is a built-in VS output, not an interpolated user varying.
  * Fragment coordinates/interpolation are rejected by the NIR recognizer;
  * their convention flags must not advertise unqualified GPU semantics. */
 caps.max_varyings=0; caps.vendor_id=0x8086; caps.device_id=0x8108;
 if(scene_frontend)caps.max_varyings=1; /* COLOR0, alongside POSITION. */
 /* Mesa uses this historical hint for gl_Position transform-feedback
  * preservation. It does not insert nir_lower_viewport_transform here;
  * this driver never calls that pass. Stream output remains unsupported. */
 caps.viewport_transform_lowered=true;
 const bool gles_lab=hre_gles_lab(sc);
 if(gles_lab){caps.essl_feature_level=100;caps.max_varyings=1;
  /* HRE's indexed TA builder already expands strips and fans to triangle
   * lists, with exact winding and provoking-vertex rules. Advertise only
   * these modes, and only on the explicit dynamic GLES lab path. */
  const char *dynamic=getenv("REMESA_HRE_DYNAMIC");
  if(dynamic&&!strcmp(dynamic,"1"))
   caps.supported_prim_modes|=(1u<<MESA_PRIM_TRIANGLE_STRIP)|(1u<<MESA_PRIM_TRIANGLE_FAN);
  /* Triangle-only: do not inject a synthetic point-size uniform/output. */
  caps.point_size_fixed=PIPE_POINT_SIZE_LOWER_NEVER;
 } /* GLSL ES parser target, not conformance. */
#ifdef REMESA_WITH_NIR
 if(!sc->device.resource_only_backend) {
  shader.max_instructions=1; shader.max_inputs=1; shader.max_outputs=1;
  shader.supported_irs=1u<<PIPE_SHADER_IR_NIR;
 }
 if(scene_frontend){
  /* Canonical vertex program: CODE320/8, or COLOR clamp CODE344/8; P/N inputs,
   * POSITION+COLOR0 outputs and nine float4 coefficient vectors. This is
   * an opt-in frontend for the existing strict recognizer, not general GLSL. */
  shader.max_instructions=43;shader.max_inputs=2;shader.max_outputs=2;
  shader.max_const_buffer0_size=144;shader.max_const_buffers=1;
  shader.supported_irs=1u<<PIPE_SHADER_IR_NIR;
 }
 if(gles_lab){
  /* Bound snapshot storage only: 256 bytes includes state tracker reserved
   * clip-plane/point-size constants. No new executable shader contract.
   * Two vertex attributes (position4/uv2), position and one varying.
   * These are link limits for the sampled recognizer, not ES2 conformance. */
  shader=(struct pipe_shader_caps){.max_instructions=43,.max_alu_instructions=43,
   .max_inputs=2,.max_outputs=2,.max_temps=8,.max_const_buffers=1,
   .max_const_buffer0_size=256,.supported_irs=1u<<PIPE_SHADER_IR_NIR};
 }
#endif
 /* Gallium places tessellation and geometry stages between VS and FS.
  * Advertising those stages makes Mesa call unsupported lifecycle hooks. */
 memcpy((void *)&sc->base.shader_caps[PIPE_SHADER_VERTEX],&shader,sizeof(shader));
 shader.max_inputs=0;
 if(scene_frontend){
  shader.max_instructions=1;shader.max_inputs=1;shader.max_outputs=1;
  shader.max_const_buffer0_size=0;shader.max_const_buffers=0;
  if(gles_lab){
   shader.max_texture_samplers=1;shader.max_sampler_views=1;
   shader.max_tex_instructions=1;shader.max_tex_indirections=1;
   /* One float4 uniform color descriptor is implemented. */
   shader.max_const_buffer0_size=16;shader.max_const_buffers=1;
  }
 }
#ifdef REMESA_WITH_NIR
 if(gles_lab){
  /* 64 bytes includes the 16-byte state tracker alpha-test reservation.
   * Uniform snapshots are already bounded by REMESA_UNIFORM_BYTES_MAX. */
  shader=(struct pipe_shader_caps){.max_instructions=8,.max_alu_instructions=8,
   .max_tex_instructions=1,.max_tex_indirections=1,.max_inputs=1,.max_outputs=1,
   .max_temps=8,.max_const_buffer0_size=64,.max_const_buffers=1,
   .max_texture_samplers=1,.max_sampler_views=1,.supported_irs=1u<<PIPE_SHADER_IR_NIR};
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GLES_CAPS VS_inputs=2 VS_outputs=2 FS_inputs=1 FS_outputs=1 samplers=1 varying=1 HRE_LINK_LAB_VS256_FS64\n");
 }
#endif
 memcpy((void *)&sc->base.shader_caps[PIPE_SHADER_FRAGMENT],&shader,sizeof(shader));
 memcpy((void *)&sc->base.caps,&caps,sizeof(caps));
}
static const char *name(struct pipe_screen *p) { return s(p)->hre ? "reMESA 12.3 RC7 HRE / PowerVR SGX535 (experimental) [topology-1] [topology-2-lab]" : s(p)->linked_scene_experiment ? "reMESA SGX535 linked scene qualification (EXPERIMENTAL)" : s(p)->native_draws ? "reMESA SGX535 native draw subset (UNQUALIFIED)" : s(p)->homogeneous_frontend_lab ? "reMESA SGX535 homogeneous scene (LAB)" : s(p)->device.retained_fragment_carrier ? "reMESA original FS + retained VS/PDS (LAB)" : s(p)->device.resource_only_backend ? "reMESA GEM resources (DRAW DISABLED)" : s(p)->device.offline_test_backend ? "reMESA recording backend (NO SGX)" : "reMESA SGX535"; }
static const char *vendor(struct pipe_screen *p) { (void)p;return "reMESA"; }
#ifdef REMESA_WITH_NIR
static const struct nir_shader_compiler_options *compiler_options(struct pipe_screen *p,enum pipe_shader_type stage)
{
 /* No general opcode lowering or shader capability is claimed. Keep NIR in
  * its original form for the strict semantic recognizers; unsupported IR is
  * rejected by create_vs/fs_state, not silently rewritten into a profile. */
 static const nir_shader_compiler_options options={0};
 if(s(p)->closing||(stage!=PIPE_SHADER_VERTEX&&stage!=PIPE_SHADER_FRAGMENT))return NULL;
 /* Keep VS IO intrinsics in the explicitly bounded GLES frontend. */
 static const nir_shader_compiler_options gles_vs={.io_options=nir_io_has_intrinsics};
 return hre_gles_lab(s(p))&&stage==PIPE_SHADER_VERTEX?&gles_vs:&options;
}
#endif

/* Renderbuffers use PIPE_TEXTURE_RECT on Mesa screens without NPOT
 * sampling. Its single-level pixel storage and attachment coordinates are
 * identical to 2D here; this helper does not admit rectangle samplers. */
static bool color_storage_target(enum pipe_texture_target target)
{ return target==PIPE_TEXTURE_2D||target==PIPE_TEXTURE_RECT; }
static bool color_rt_format(struct pipe_screen *p,enum pipe_format f)
{ return f==PIPE_FORMAT_B8G8R8A8_UNORM || (s(p)->egl_dmabuf_lab&&f==PIPE_FORMAT_B8G8R8X8_UNORM); }
static bool format(struct pipe_screen *p,enum pipe_format f,enum pipe_texture_target t,unsigned samples,unsigned storage,unsigned bind)
{
 if(samples>1 || storage>1) return false;
 /* Single-level sampled storage is available only in the explicit linked
  * experiment. The existing view, shader, PDS and scene validators still
  * decide execution independently. No general GL sampler caps are added. */
 if((s(p)->linked_scene_experiment||s(p)->hre)&&s(p)->texture_qualification&&
    t==PIPE_TEXTURE_2D&&bind==PIPE_BIND_SAMPLER_VIEW)
  return f==PIPE_FORMAT_R8G8B8A8_UNORM||f==PIPE_FORMAT_B8G8R8A8_UNORM||
   (s(p)->egl_dmabuf_lab&&f==PIPE_FORMAT_B8G8R8X8_UNORM);
 if(color_storage_target(t)&&f==PIPE_FORMAT_B8G8R8A8_UNORM){
  if((s(p)->frontbuffer.publish||s(p)->display)&&(bind&PIPE_BIND_DISPLAY_TARGET)&&(bind&PIPE_BIND_RENDER_TARGET))
   bind&=~PIPE_BIND_SAMPLER_VIEW;
  if(s(p)->display)bind&=~(PIPE_BIND_SHARED|PIPE_BIND_SCANOUT|PIPE_BIND_DISPLAY_TARGET);
  else if(s(p)->frontbuffer.publish)bind&=~PIPE_BIND_DISPLAY_TARGET;
 }
 if((s(p)->cpu_depth24_lab||s(p)->linked_attachment_storage)&&color_storage_target(t)&&f==PIPE_FORMAT_Z24X8_UNORM)
  return bind==PIPE_BIND_DEPTH_STENCIL;
 /* Mesa's display-list VBO allocator adds VERTEX_STATE to index storage
  * even when HasDrawVertexState is false and playback uses ordinary VAOs.
  * It is a storage hint here, not permission to execute a new draw class.
  * Require an actual vertex/index role and byte storage for this hint. */
 if(t==PIPE_BUFFER && (bind&PIPE_BIND_VERTEX_STATE) &&
    (!(bind&(PIPE_BIND_VERTEX_BUFFER|PIPE_BIND_INDEX_BUFFER)) ||
     f!=PIPE_FORMAT_R8_UNORM))return false;
 if(t==PIPE_BUFFER) return !(bind & ~(PIPE_BIND_VERTEX_BUFFER|PIPE_BIND_INDEX_BUFFER|PIPE_BIND_CONSTANT_BUFFER|PIPE_BIND_VERTEX_STATE)) &&
  (f==PIPE_FORMAT_R8_UNORM || (!(bind&PIPE_BIND_CONSTANT_BUFFER)&&remesa_position_format_bytes(f)));
 if(!color_storage_target(t))return false;
 if(t==PIPE_TEXTURE_RECT)return color_rt_format(p,f)&&bind==PIPE_BIND_RENDER_TARGET;
 /* Transfer-only storage is not sampler or render capability. Real SGX render
  * attachments remain the exact BGRA32 profile; sampler binds are unsupported. */
 if(!bind)return f==PIPE_FORMAT_B8G8R8A8_UNORM||f==PIPE_FORMAT_R8G8B8A8_UNORM;
 return color_rt_format(p,f) && bind==PIPE_BIND_RENDER_TARGET;
}
static struct pipe_resource *create_resource_impl(struct pipe_screen *p,const struct pipe_resource *t,bool force_resident,bool host_rt)
{
 struct resource *b;size_t bytes;uint64_t cookie;unsigned stride=0;bool persistent_attachment=false;struct remesa_texture_layout layout={0};
 if(!t)return NULL;
 const bool sampled_hint=hre_gles_lab(s(p))&&t->target==PIPE_TEXTURE_2D&&
   t->bind==PIPE_BIND_SAMPLER_VIEW;
 const unsigned allowed_flags=t->target==PIPE_BUFFER?PIPE_RESOURCE_FLAG_SINGLE_THREAD_USE:
   sampled_hint?PIPE_RESOURCE_FLAG_TEXTURING_MORE_LIKELY:0;
 if(s(p)->closing || s(p)->frontbuffer_busy || !format(p,t->format,t->target,t->nr_samples,t->nr_storage_samples,t->bind) ||
    t->array_size!=1 || t->depth0!=1 || (t->flags&~allowed_flags)) {
  if(hre_gles_lab(s(p))&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_RESOURCE_REJECT target=%u format=%u bind=%#x flags=%#x size=%ux%u depth=%u layers=%u levels=%u samples=%u/%u\n",t->target,t->format,t->bind,t->flags,t->width0,t->height0,t->depth0,t->array_size,t->last_level,t->nr_samples,t->nr_storage_samples);
  return NULL;
 }
 if(t->target==PIPE_BUFFER) {
  uint64_t budget=s(p)->device.resource_limits.max_resource_bytes;
  if(!budget)budget=UINT64_C(64)*1024*1024;
  if(!t->width0 || t->height0!=1 || t->last_level || t->width0>budget) return NULL;
  bytes=t->width0;
  layout.count=1;layout.bytes=bytes;
  layout.levels[0]=(struct remesa_texture_level){t->width0,1,0,0,bytes};
 }
 else {
  if(t->bind) { if((!s(p)->cpu_depth24_lab&&!s(p)->linked_attachment_storage&&!((s(p)->native_fill||s(p)->hybrid_2d)&&s(p)->device.resource_only_backend&&resource_bind(t)==PIPE_BIND_RENDER_TARGET&&t->format==PIPE_FORMAT_B8G8R8A8_UNORM)&&(t->width0!=32||t->height0!=32))||t->last_level)return NULL; }
  /* The exact physical profile requires tight rows; transfer-only storage
   * follows explicit backend alignment and independently bounded capacity. */
  struct remesa_resource_limits limits=s(p)->device.resource_limits;
  if(t->bind&&!s(p)->linked_attachment_storage&&limits.row_alignment>1&&
     !(s(p)->frontbuffer.publish&&(t->bind&PIPE_BIND_DISPLAY_TARGET))) {
   if((limits.row_alignment&(limits.row_alignment-1))||
      (((uint64_t)t->width0*4)&(limits.row_alignment-1)))return NULL;
  }
  if(remesa_texture_layout(&limits,t->width0,t->height0,4,t->last_level,&layout))return NULL;
  bytes=layout.bytes;stride=layout.levels[0].stride;
 }
 b=calloc(1,sizeof(*b));if(!b) return NULL;b->base=*t;b->base.screen=p;
 /* Layout is unchanged; consume the benign hint at allocation so downstream
  * texture metadata checks still see the exact validated storage flags. */
 if(sampled_hint)b->base.flags&=~PIPE_RESOURCE_FLAG_TEXTURING_MORE_LIKELY;
 if(!screen_next_resource_cookie(s(p),&cookie)){free(b);return NULL;}
 remesa_render_pass_init(&b->pass,cookie);
 b->base.reference.count=1;b->bytes=bytes;b->stride=stride;b->layout=layout;
 /* Native scene preparation already copies raw VBO/IBO/CB data into its
  * immutable GEM owners. Mesa's idle immediate-mode VBO can stay mapped in
  * host storage without acquiring a GPU backing lease. Bound source maps are
  * still refused by the existing snapshot guards. */
 /* HRE vertex/index/constant bytes are snapshotted into validated GPU
  * scene owners, never consumed from this raw Gallium storage by SGX.
  * Use the existing bounded host-input allocator to avoid redundant GEM
  * allocation/map/lease traffic for ordinary vertex updates. */
 const char *residency=getenv("REMESA_HRE_COMPOSITOR_RESIDENCY");
 b->compositor_host_texture=!force_resident&&sampled_hint&&!t->last_level&&hybrid_enabled(s(p))&&residency&&!strcmp(residency,"1");
 if(host_rt||b->compositor_host_texture||((s(p)->homogeneous_frontend_lab||s(p)->native_draws||s(p)->hre)&&t->target==PIPE_BUFFER)){
  if(!host_buffer_reserve(s(p),bytes)){free(b);return NULL;}
  b->host_data=calloc(1,bytes);
  if(!b->host_data){__atomic_sub_fetch(&s(p)->host_buffer_bytes,bytes,__ATOMIC_RELAXED);free(b);return NULL;}
  if(b->compositor_host_texture&&getenv("REMESA_DRI_TRACE")&&!getenv("REMESA_HRE_QUIET_ALLOC"))fprintf(stderr,"HRE_EGL21B_HOST_TEXTURE cookie=%llu bytes=%zu host_total=%zu\n",(unsigned long long)cookie,bytes,__atomic_load_n(&s(p)->host_buffer_bytes,__ATOMIC_RELAXED));
  if(s(p)->hre&&getenv("REMESA_DRI_TRACE")&&!getenv("REMESA_HRE_QUIET_ALLOC"))fprintf(stderr,"HRE_EGL21_GALLIUM event=create device=%p resource=%p bo=%p cookie=%llu bytes=%zu bind=%#x target=%u width=%u height=%u\n",s(p)->device.priv,(void *)&b->base,b->bo,(unsigned long long)b->pass.resource_cookie,b->bytes,(unsigned)b->base.bind,(unsigned)b->base.target,b->base.width0,b->base.height0);
 screen_hold(s(p));return &b->base;
 }
 int allocation_error;
 /* Sample-only backing is a regular persistent BO, never a typed COLOR/Z
  * attachment. Keep display-hinted render targets on their existing route. */
 if(s(p)->linked_attachment_storage&&color_storage_target(t->target)&&
    (resource_bind(t)==PIPE_BIND_RENDER_TARGET||resource_bind(t)==PIPE_BIND_DEPTH_STENCIL)){
  persistent_attachment=true;
  if(t->format==PIPE_FORMAT_Z24X8_UNORM)
   allocation_error=s(p)->device.ops->allocate_depth_attachment(&s(p)->device,t->width0,t->height0,4,&b->bo);
  else allocation_error=s(p)->device.ops->allocate_color_attachment(&s(p)->device,t->width0,t->height0,&b->bo);
 }else allocation_error=s(p)->device.ops->allocate(s(p)->device.priv,bytes,&b->bo);
 if(allocation_error || !b->bo) {
  if(hre_gles_lab(s(p))&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_RESOURCE_ALLOC_FAIL errno=%d bind=%#x bytes=%zu\n",allocation_error,t->bind,bytes);
  if(b->bo) {
   if(persistent_attachment)s(p)->device.ops->destroy_attachment(&s(p)->device,b->bo);
   else s(p)->device.ops->destroy_bo(s(p)->device.priv,b->bo);
  }
  free(b);return NULL;
 }
 b->persistent_attachment=persistent_attachment;
 if(s(p)->hre&&getenv("REMESA_DRI_TRACE")&&!getenv("REMESA_HRE_QUIET_ALLOC"))fprintf(stderr,"HRE_EGL21_GALLIUM event=create device=%p resource=%p bo=%p cookie=%llu bytes=%zu bind=%#x target=%u width=%u height=%u\n",s(p)->device.priv,(void *)&b->base,b->bo,(unsigned long long)b->pass.resource_cookie,b->bytes,(unsigned)b->base.bind,(unsigned)b->base.target,b->base.width0,b->base.height0);
 screen_hold(s(p));return &b->base;
}
static struct pipe_resource *create_resource(struct pipe_screen *p,const struct pipe_resource *t)
{ return create_resource_impl(p,t,false,false); }
static void destroy_resource(struct pipe_screen *p,struct pipe_resource *b)
{
 if(s(p)->hre&&getenv("REMESA_DRI_TRACE")&&!getenv("REMESA_HRE_QUIET_ALLOC"))fprintf(stderr,"HRE_EGL21_GALLIUM event=destroy device=%p resource=%p bo=%p cookie=%llu bytes=%zu bind=%#x target=%u width=%u height=%u\n",s(p)->device.priv,(void *)b,r(b)->bo,(unsigned long long)r(b)->pass.resource_cookie,r(b)->bytes,(unsigned)b->bind,(unsigned)b->target,b->width0,b->height0);
 if(r(b)->display.serial){
  struct screen *sc=s(p);
  if(sc->display_error){sc->release_error=sc->display_error;return;}
  int error=remesa_drm_display_destroy(sc->display,r(b)->display);
  if(error){sc->display_error=sc->release_error=EOWNERDEAD;return;}
  struct resource **link=&sc->display_resources;
  while(*link&&*link!=r(b))link=&(*link)->display_next;
  if(*link)*link=r(b)->display_next;
 }
 for(unsigned i=0;i<2;i++)if(r(b)->renamed[i].bo){
  /* The backend destruction contract defers actual backing release while
   * jobs remain pending or quarantined. Dropping a frontend ref is not a
   * retirement assertion, nor permission to recycle this old BO. */
  fence_ref(p,&r(b)->renamed[i].writer,NULL);
  s(p)->device.ops->destroy_bo(s(p)->device.priv,r(b)->renamed[i].bo);
 }
 fence_ref(p,&r(b)->writer,NULL);
 remesa_resource_reference(&r(b)->sample_shadow,NULL);
 if(r(b)->shared_sampler){
  if(r(b)->shared_cache)__atomic_sub_fetch(&s(p)->host_buffer_bytes,r(b)->shared_sampler->packed,__ATOMIC_RELAXED);
  remesa_shared_close(r(b)->shared_sampler);free(r(b)->shared_sampler);free(r(b)->shared_cache);
 }
 if(r(b)->host_data){__atomic_sub_fetch(&s(p)->host_buffer_bytes,r(b)->bytes,__ATOMIC_RELAXED);free(r(b)->host_data);}
 else if(r(b)->persistent_attachment)s(p)->device.ops->destroy_attachment(&s(p)->device,r(b)->bo);
 else s(p)->device.ops->destroy_bo(s(p)->device.priv,r(b)->bo);
 free(b);screen_drop(s(p));
}
/* Private, producer-complete snapshot. This is deliberately NOT the
 * Gallium resource_from_handle callback: EGLImage requires shared storage,
 * while this operation creates an independent immutable texture snapshot.
 * Callers must retain the input fd and producer ownership until return. */
int remesa_screen_snapshot_texture(struct pipe_screen *p, int fd,
 uint32_t width,uint32_t height,uint32_t pitch,uint32_t offset,
 bool rgba,bool opaque,struct pipe_resource **out)
{
 if(!p||p->resource_create!=create_resource||!out||*out)return EINVAL;
 if(!s(p)->hre||!s(p)->texture_qualification)return ENOTSUP;
 size_t end,packed;
 int error=remesa_dmabuf_layout(width,height,pitch,offset,
                               REMESA_PRIME_STAGING_MAX,&end,&packed);
 if(error)return error;
 struct screen *sc=s(p);
 if(!host_buffer_reserve(sc,packed))return ENOMEM;
 unsigned char *pixels=malloc(packed);if(!pixels){__atomic_sub_fetch(&sc->host_buffer_bytes,packed,__ATOMIC_RELAXED);return ENOMEM;}
 error=remesa_dmabuf_read(fd,width,height,pitch,offset,rgba,opaque,pixels,packed);
 if(error){free(pixels);__atomic_sub_fetch(&sc->host_buffer_bytes,packed,__ATOMIC_RELAXED);return error;}
 struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,
  .width0=width,.height0=height,.depth0=1,.array_size=1,.bind=PIPE_BIND_SAMPLER_VIEW};
 struct pipe_resource *res=create_resource(p,&t);
 if(!res){free(pixels);__atomic_sub_fetch(&sc->host_buffer_bytes,packed,__ATOMIC_RELAXED);return ENOTSUP;}
 struct resource *b=r(res);void *ptr=NULL;
 if(b->stride<(size_t)width*4||(uint64_t)b->stride*(height-1)+(uint64_t)width*4>b->bytes)
  error=EOVERFLOW;
 if(!error)error=remesa_render_pass_admit_cpu_write(&b->pass);
 if(!error){
  error=resource_map_backing(p,b,true,&ptr);
  if(!error&&ptr){
   for(uint32_t y=0;y<height;y++)memcpy((unsigned char *)ptr+(size_t)y*b->stride,
                                      pixels+(size_t)y*width*4,(size_t)width*4);
  }else if(!error)error=EPROTO;
  if(ptr)resource_unmap_backing(p,b,true);
  if(b->write_error)error=b->write_error;
 }
 free(pixels);__atomic_sub_fetch(&sc->host_buffer_bytes,packed,__ATOMIC_RELAXED);
 if(!error)error=remesa_render_pass_cpu_write(&b->pass);
 if(error){destroy_resource(p,res);return error;}
 b->has_contents=true;*out=res;return 0;
}
static void fence_ref(struct pipe_screen *p,struct pipe_fence_handle **dst,struct pipe_fence_handle *src)
{
 struct pipe_fence_handle *old=*dst;(void)p;
 if(src) __atomic_add_fetch(&src->refs,1,__ATOMIC_RELAXED);
 *dst=src;
 if(old && !__atomic_sub_fetch(&old->refs,1,__ATOMIC_ACQ_REL)) {
  struct screen *owner=old->screen;
  owner->device.ops->destroy_fence(owner->device.priv,old->backend);free(old);screen_drop(owner);
 }
}
static bool finish(struct pipe_screen *p,struct pipe_context *ctx,struct pipe_fence_handle *f,uint64_t ns)
{ (void)ctx;return f && f->screen==s(p) && !s(p)->device.ops->wait(s(p)->device.priv,f->backend,ns,true); }
/* Contexts sharing a screen/resource must be externally serialized. A pending
 * writer belongs to the resource, not whichever context currently binds it.
 * Conservatively require CPU publication for both host access and reuse; no
 * inferred GPU-only visibility or implicit failure recovery is permitted. */
static int resource_sync_writer(struct pipe_screen *p,struct resource *b,uint64_t timeout)
{
 int error;
 if(b->write_error) return b->write_error;
 if(!b->writer) return 0;
 error=s(p)->device.ops->wait(s(p)->device.priv,b->writer->backend,timeout,true);
 if(!error) {
  /* wait(cpu_visible=true) must authenticate this backend fence and attest
   * retirement/publication. These are not independently synthesized events. */
  const struct remesa_pass_completion proof={true,true,true};
  error=remesa_render_pass_finish(&b->pass,&b->ticket,&proof);
  if(!error)fence_ref(p,&b->writer,NULL);
 }
 if(error && error!=EAGAIN && error!=ETIMEDOUT && error!=EBUSY&&error!=EINTR) {
  b->write_error=error;remesa_render_pass_fail(&b->pass,&b->ticket,error);
 }
 return error;
}
/* A queued clear has no published pixels or hardware fence yet. All other
 * contexts and CPU/native transfer paths must wait for the owning draw. */
static int resource_collect_renamed(struct pipe_screen *,struct resource *);
static int resource_sync(struct pipe_screen *p,struct resource *b,uint64_t timeout)
{
 if(b->write_error)return b->write_error;
 if(b->native_clear_owner)return EBUSY;
 if(s(p)->buffer_renaming){int error=resource_collect_renamed(p,b);if(error)return error;}
 return resource_sync_writer(p,b,timeout);
}
#include "remesa_screen_display.inc"
/* Restricted imported sampler. Producer must finish before access. No shared
 * render target or implicit GPU synchronization is claimed. */
static void texture_subdata(struct pipe_context *,struct pipe_resource *,unsigned,unsigned,
 const struct pipe_box *,const void *,unsigned,uintptr_t);
/* EGL28: direct host-RT synchronization. No GEM mapping and no packed
 * temporary. Keep the external DMA-BUF lease and fail closed on an uncertain
 * END; a failed import may have changed private RAM, so poison the resource. */
static uint64_t egl28_clock(void)
{
 struct timespec ts;if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (uint64_t)ts.tv_sec*1000000u+(uint64_t)ts.tv_nsec/1000u;
}
static int egl28_external_copy(struct remesa_shared_image *sh,bool publish,
 unsigned x,unsigned y,unsigned w,unsigned h,uint8_t *pixels,size_t stride,bool normalize)
{
 if(!sh||sh->poisoned)return EOWNERDEAD;
 if(!pixels||!w||!h||x>=sh->width||y>=sh->height||w>sh->width-x||h>sh->height-y||stride<(size_t)w*4)return EINVAL;
 uint64_t a=egl28_clock();
 void *external=mmap(NULL,sh->end,PROT_READ|(publish?PROT_WRITE:0),MAP_SHARED,sh->fd,0);
 if(external==MAP_FAILED)return errno;
 uint64_t b=egl28_clock();
 const uint64_t mode=publish?DMA_BUF_SYNC_WRITE:DMA_BUF_SYNC_READ;
 int e=remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_START|mode);uint64_t c=egl28_clock(),d=c,f=c;
 if(!e){
  const size_t row=(size_t)w*4;
  for(unsigned j=0;j<h;j++){
   uint8_t *ext=(uint8_t*)external+sh->offset+(size_t)(y+j)*sh->pitch+(size_t)x*4;
   uint8_t *host=pixels+(size_t)j*stride;
   uint8_t *dst=publish?ext:host;const uint8_t *src=publish?host:ext;
   if(!normalize)memcpy(dst,src,row);
   else if(!publish){
    /* EGL32: bulk-read external memory, normalize in cacheable host RAM.
     * Do not read a write-combined scanout a pixel at a time. */
    memcpy(dst,src,row);
    for(size_t i=3;i<row;i+=4)dst[i]=255;
   }else for(size_t i=0;i<row;i+=4){
    /* One read/write per pixel; never read back a write-combined scanout. */
    uint8_t pixel[4];memcpy(pixel,src+i,4);pixel[3]=255;memcpy(dst+i,pixel,4);
   }
  }
  d=egl28_clock();if(remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_END|mode))e=EOWNERDEAD;f=egl28_clock();
 }
 if(munmap(external,sh->end))e=EOWNERDEAD;
 if(e==EOWNERDEAD)sh->poisoned=true;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL28_DMA publish=%u bytes=%zu map_us=%llu start_us=%llu copy_us=%llu end_us=%llu unmap_us=%llu errno=%d\n",(unsigned)publish,(size_t)w*h*4,(unsigned long long)(b-a),(unsigned long long)(c-b),(unsigned long long)(d-c),(unsigned long long)(f-d),(unsigned long long)(egl28_clock()-f),e);
 return e;
}
static bool egl28_host_candidate(struct resource *b)
{
 return getenv("REMESA_HRE_EGL28_HOST_SYNC")&&b->shared_rt&&b->host_data&&!b->bo&&!b->shared_cache;
}
static int egl28_host_sync(struct pipe_screen *p,struct resource *b,bool publish,
 unsigned x,unsigned y,unsigned w,unsigned h)
{
 struct remesa_shared_image *sh=b->shared_sampler;
 if(!sh||!b->shared_writable||b->maps||b->native_clear_owner||!egl28_host_candidate(b))return EBUSY;
 if(!w||!h||x>=sh->width||y>=sh->height||w>sh->width-x||h>sh->height-y||b->stride<(size_t)sh->width*4||
    (uint64_t)b->stride*(sh->height-1)+(uint64_t)sh->width*4>b->bytes)return EINVAL;
 int e=resource_sync(p,b,UINT64_MAX);if(e)return e;
 if(publish&&!b->has_contents)return ENODATA;
 if(!publish){e=remesa_render_pass_admit_cpu_write(&b->pass);if(e)return e;}
 e=egl28_external_copy(sh,publish,x,y,w,h,(uint8_t*)b->host_data+(size_t)y*b->stride+(size_t)x*4,b->stride,b->shared_opaque);
 if(!e&&!publish){e=remesa_render_pass_cpu_write(&b->pass);if(!e)b->has_contents=true;else e=EOWNERDEAD;}
 if(e){if(e==EOWNERDEAD)sh->poisoned=true;if(e==EOWNERDEAD||publish)b->write_error=e;return e;}
 b->shared_cache_valid=false;
 if(x==0&&y==0&&w==sh->width&&h==sh->height)b->shared_discard=false;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL28_HOST_SYNC publish=%u bytes=%zu\n",(unsigned)publish,(size_t)w*h*4);
 return 0;
}
static int hre_shared_rt_sync(struct pipe_screen *p,struct resource *b,bool publish)
{
 struct remesa_shared_image *sh=b->shared_sampler;struct screen *sc=s(p);
 if(!sh||!b->shared_writable||b->maps||b->native_clear_owner)return EBUSY;
 if(egl28_host_candidate(b))return egl28_host_sync(p,b,publish,0,0,sh->width,sh->height);
 const char *stage="sync";
 int error=resource_sync(p,b,UINT64_MAX);if(error){fprintf(stderr,"HRE_EGL21C_SHARED_FAIL stage=sync publish=%u errno=%d\n",(unsigned)publish,error);return error;}
 if(!host_buffer_reserve(sc,sh->packed)){fprintf(stderr,"HRE_EGL21C_SHARED_FAIL stage=host_budget publish=%u errno=%d bytes=%zu\n",(unsigned)publish,ENOMEM,sh->packed);if(publish)b->write_error=ENOMEM;return ENOMEM;}
 stage="malloc";
 unsigned char *pixels=malloc(sh->packed);void *ptr=NULL;bool mapped=false;
 if(!pixels){error=ENOMEM;goto done;}
 if(!publish){
  stage="dmabuf_read";error=remesa_shared_transfer(sh,pixels,sh->packed,false);if(error)goto done;
  if(b->shared_opaque)for(size_t i=3;i<sh->packed;i+=4)pixels[i]=255;
  if(b->shared_cache&&b->shared_cache_valid&&b->has_contents&&!memcmp(pixels,b->shared_cache,sh->packed))goto done;
  stage="admit";error=remesa_render_pass_admit_cpu_write(&b->pass);if(error)goto done;
 }else if(!b->has_contents){error=ENODATA;goto done;}
 stage="map_backing";error=resource_map_backing(p,b,!publish,&ptr);mapped=!error||ptr;
 if(!error&&!ptr)error=EPROTO;
 if(!error)for(unsigned y=0;y<sh->height;y++){
  unsigned char *a=(unsigned char *)ptr+(size_t)y*b->stride;
  unsigned char *z=pixels+(size_t)y*sh->width*4;
  if(publish)memcpy(z,a,(size_t)sh->width*4);else memcpy(a,z,(size_t)sh->width*4);
 }
 if(mapped)resource_unmap_backing(p,b,!publish);
 if(b->write_error){stage="unmap_backing";error=b->write_error;}
 if(!error&&publish){
  if(b->shared_opaque)for(size_t i=3;i<sh->packed;i+=4)pixels[i]=255;
  stage="dmabuf_write";error=remesa_shared_transfer(sh,pixels,sh->packed,true);
 }else if(!error){stage="commit";error=remesa_render_pass_cpu_write(&b->pass);if(!error)b->has_contents=true;}
 if(!error){if(b->shared_cache)memcpy(b->shared_cache,pixels,sh->packed);b->shared_cache_valid=b->shared_cache!=NULL;b->shared_discard=false;}
 done:
 if(error)fprintf(stderr,"HRE_EGL21C_SHARED_FAIL stage=%s publish=%u errno=%d bytes=%zu used=%zu limit=%zu cookie=%llu\n",stage,(unsigned)publish,error,sh->packed,__atomic_load_n(&sc->host_buffer_bytes,__ATOMIC_RELAXED),host_buffer_limit(sc),(unsigned long long)b->pass.resource_cookie);
 else if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL21C_SHARED_PASS publish=%u bytes=%zu used=%zu limit=%zu\n",(unsigned)publish,sh->packed,__atomic_load_n(&sc->host_buffer_bytes,__ATOMIC_RELAXED),host_buffer_limit(sc));
 if(error==EOWNERDEAD||(publish&&error))b->write_error=error;
 free(pixels);__atomic_sub_fetch(&sc->host_buffer_bytes,sh->packed,__ATOMIC_RELAXED);
 return error;
}
/* EGL22: transfer only the authenticated damage rectangle. No external
 * writes occur until all native tiles have retired and coverage was checked.
 * Keep whole-image synchronization for uninitialized/discarded storage. */
static int hre_shared_rt_region(struct pipe_screen *p,struct resource *b,bool publish,
 unsigned x,unsigned y,unsigned w,unsigned h)
{
 struct remesa_shared_image *sh=b->shared_sampler;struct screen *sc=s(p);
 if(!sh||!b->shared_writable||b->maps||b->native_clear_owner)return EBUSY;
 if(!w||!h||x>=sh->width||y>=sh->height||w>sh->width-x||h>sh->height-y)return EINVAL;
 if(!b->has_contents||b->shared_discard||b->shared_cache||
    (x==0&&y==0&&w==sh->width&&h==sh->height))return hre_shared_rt_sync(p,b,publish);
 if(sh->poisoned)return EOWNERDEAD;
 if(egl28_host_candidate(b))return egl28_host_sync(p,b,publish,x,y,w,h);
 size_t row=(size_t)w*4,bytes=row*h;
 int e=resource_sync(p,b,UINT64_MAX);if(e)return e;
 if(!host_buffer_reserve(sc,bytes))return ENOMEM;
 unsigned char *pixels=malloc(bytes);void *ptr=NULL;bool mapped=false;
 if(!pixels){e=ENOMEM;goto done;}
 /* A packed temporary keeps the GEM and DMA-BUF CPU leases disjoint. */
 if(publish){
  e=resource_map_backing(p,b,false,&ptr);mapped=!e||ptr;
  if(!e&&!ptr)e=EPROTO;
  if(!e)for(unsigned j=0;j<h;j++)memcpy(pixels+(size_t)j*row,
   (unsigned char *)ptr+(size_t)(y+j)*b->stride+(size_t)x*4,row);
  if(mapped)resource_unmap_backing(p,b,false);
  if(b->write_error)e=b->write_error;
  if(e)goto done;
  if(b->shared_opaque)for(size_t i=3;i<bytes;i+=4)pixels[i]=255;
 }
 void *external=mmap(NULL,sh->end,PROT_READ|(publish?PROT_WRITE:0),MAP_SHARED,sh->fd,0);
 if(external==MAP_FAILED){e=errno;goto done;}
 uint64_t mode=publish?DMA_BUF_SYNC_WRITE:DMA_BUF_SYNC_READ;
 e=remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_START|mode);
 if(!e){
  for(unsigned j=0;j<h;j++){
   unsigned char *a=(unsigned char *)external+sh->offset+(size_t)(y+j)*sh->pitch+(size_t)x*4;
   unsigned char *z=pixels+(size_t)j*row;
   if(publish)memcpy(a,z,row);else memcpy(z,a,row);
  }
  if(remesa_dmabuf_sync(sh->fd,DMA_BUF_SYNC_END|mode))e=EOWNERDEAD;
 }
 if(munmap(external,sh->end))e=EOWNERDEAD;
 if(e==EOWNERDEAD)sh->poisoned=true;
 if(e)goto done;
 if(!publish){
  if(b->shared_opaque)for(size_t i=3;i<bytes;i+=4)pixels[i]=255;
  e=remesa_render_pass_admit_cpu_write(&b->pass);if(e)goto done;
  ptr=NULL;e=resource_map_backing(p,b,true,&ptr);mapped=!e||ptr;
  if(!e&&!ptr)e=EPROTO;
  if(!e)for(unsigned j=0;j<h;j++)memcpy((unsigned char *)ptr+(size_t)(y+j)*b->stride+(size_t)x*4,
   pixels+(size_t)j*row,row);
  if(mapped)resource_unmap_backing(p,b,true);
  if(b->write_error)e=b->write_error;
  if(!e)e=remesa_render_pass_cpu_write(&b->pass);
 }
 b->shared_cache_valid=false;
 done:
 free(pixels);__atomic_sub_fetch(&sc->host_buffer_bytes,bytes,__ATOMIC_RELAXED);
 if(e){if(publish||e==EOWNERDEAD)b->write_error=e;
  fprintf(stderr,"HRE_EGL22_REGION_FAIL publish=%u errno=%d\n",(unsigned)publish,e);}
 else if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL22_REGION_PASS publish=%u x=%u y=%u w=%u h=%u bytes=%zu\n",(unsigned)publish,x,y,w,h,bytes);
 return e;
}
static struct pipe_resource *hre_import_sampler(struct pipe_screen *p,const struct pipe_resource *t,
 struct winsys_handle *h,unsigned usage)
{
 struct screen *sc=s(p);struct pipe_resource *out=NULL;
 if(!t||!h)return NULL;
 const bool opaque=t->format==PIPE_FORMAT_B8G8R8X8_UNORM;
 const bool rt=sc->egl_dmabuf_lab&&(t->bind&PIPE_BIND_RENDER_TARGET);
 const bool writable=sc->egl_dmabuf_lab;
 const uint64_t fourcc=opaque?DRM_FORMAT_XRGB8888:DRM_FORMAT_ARGB8888;
 if(sc->closing||sc->frontbuffer_busy||!sc->hre_headless||!t||!h||
    t->target!=PIPE_TEXTURE_2D||(!opaque&&t->format!=PIPE_FORMAT_B8G8R8A8_UNORM)||
    (rt?(t->bind&~(PIPE_BIND_RENDER_TARGET|PIPE_BIND_SAMPLER_VIEW))!=0:t->bind!=PIPE_BIND_SAMPLER_VIEW)||t->flags||t->next||
    t->depth0!=1||t->array_size!=1||t->last_level||t->nr_samples>1||t->nr_storage_samples>1||
    h->type!=WINSYS_HANDLE_TYPE_FD||h->handle>INT_MAX||h->plane||h->layer||h->array_stride||h->image_stride||h->com_obj||
    /* DRI2 passes enum pipe_format; standalone PRIME callers pass FourCC. */
    (h->format&&h->format!=fourcc&&h->format!=(uint64_t)t->format)||
    (h->modifier!=DRM_FORMAT_MOD_LINEAR&&h->modifier!=DRM_FORMAT_MOD_INVALID)||
    (usage&~(PIPE_HANDLE_USAGE_EXPLICIT_FLUSH|(rt?PIPE_HANDLE_USAGE_FRAMEBUFFER_WRITE:0))))return NULL;
 struct remesa_shared_image *sh=calloc(1,sizeof(*sh));if(!sh)return NULL;
 sh->fd=-1;
 int error=remesa_shared_open(sh,(int)h->handle,t->width0,t->height0,h->stride,h->offset);
 if(error){free(sh);return NULL;}
 if(writable){void *probe=mmap(NULL,sh->end,PROT_READ|PROT_WRITE,MAP_SHARED,sh->fd,0);
  if(probe==MAP_FAILED){remesa_shared_close(sh);free(sh);return NULL;}
  if(munmap(probe,sh->end)){remesa_shared_close(sh);free(sh);return NULL;}
 }
 const bool keep_cache=!rt||sh->packed<=1024u*1024u;
 if(keep_cache&&!host_buffer_reserve(sc,sh->packed)){remesa_shared_close(sh);free(sh);return NULL;}
 unsigned char *cache=keep_cache?malloc(sh->packed):NULL;
 if(keep_cache&&!cache)goto fail;
 if(!keep_cache&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_SHARED_RT_UNCACHED %ux%u\n",t->width0,t->height0);
 if(rt){struct pipe_resource templ=*t;templ.bind=PIPE_BIND_RENDER_TARGET;templ.format=PIPE_FORMAT_B8G8R8A8_UNORM;
  /* EGL27: imported compositor RT is a CPU resolve destination, not a
   * native attachment. Scratch COLOR/Z and ordinary RTs remain GEM-backed.
   * Do not admit this storage in a native-only or renaming configuration. */
  const bool host_rt=getenv("REMESA_HRE_EGL27_HOST_RT")&&hybrid_enabled(sc)&&
   !sc->native_fill&&!sc->native_draws&&!sc->homogeneous_frontend_lab&&!sc->gears_runtime&&!sc->buffer_renaming;
  out=create_resource_impl(p,&templ,false,host_rt);if(!out)goto fail;
  if(host_rt&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL27_HOST_RT bytes=%zu\n",r(out)->bytes);
 }else{
  error=remesa_screen_snapshot_texture(p,sh->fd,t->width0,t->height0,h->stride,h->offset,false,opaque,&out);
  if(error)goto fail;
 }
 if(r(out)->compositor_host_texture&&cache){
  free(cache);cache=NULL;__atomic_sub_fetch(&sc->host_buffer_bytes,sh->packed,__ATOMIC_RELAXED);
 }
 r(out)->shared_sampler=sh;r(out)->shared_cache=cache;r(out)->shared_opaque=opaque;
 r(out)->shared_rt=rt;r(out)->shared_writable=writable;
 if(rt){
  if(hre_shared_rt_sync(p,r(out),false)){destroy_resource(p,out);return NULL;}
  if(t->bind&PIPE_BIND_SAMPLER_VIEW){struct pipe_resource sampler=*t;sampler.bind=PIPE_BIND_SAMPLER_VIEW;
   r(out)->sample_shadow=hre_import_sampler(p,&sampler,h,0);
   if(!r(out)->sample_shadow){destroy_resource(p,out);return NULL;}
  }
  out->bind=t->bind|PIPE_BIND_SHARED;
 }
 /* Preserve the public XRGB format. The staging BO stores forced opaque BGRA. */
 out->format=t->format;
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_SHARED_IMPORT_OK %ux%u\n",t->width0,t->height0);
 if(rt&&opaque&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL5_XRGB_RT %ux%u\n",t->width0,t->height0);
 return out;
fail:
 free(cache);if(keep_cache)__atomic_sub_fetch(&sc->host_buffer_bytes,sh->packed,__ATOMIC_RELAXED);
 remesa_shared_close(sh);free(sh);return NULL;
}
static bool hre_get_sampler_handle(struct pipe_screen *p,struct pipe_context *ctx,
 struct pipe_resource *res,struct winsys_handle *h,unsigned usage)
{
 if(!res||res->screen!=p||(ctx&&ctx->screen!=p)||!h||s(p)->closing||
    h->type!=WINSYS_HANDLE_TYPE_FD||h->plane||h->layer||h->com_obj||
    (usage&~(PIPE_HANDLE_USAGE_EXPLICIT_FLUSH|(s(p)->egl_dmabuf_lab?PIPE_HANDLE_USAGE_FRAMEBUFFER_WRITE:0))))return false;
 struct resource *b=r(res);struct remesa_shared_image *sh=b->shared_sampler;
 if(!sh||sh->poisoned||b->write_error||b->maps)return false;
 int fd=fcntl(sh->fd,F_DUPFD_CLOEXEC,0);if(fd<0)return false;
 h->handle=(unsigned)fd;h->stride=sh->pitch;h->offset=sh->offset;
 h->format=b->shared_opaque?DRM_FORMAT_XRGB8888:DRM_FORMAT_ARGB8888;
 h->modifier=DRM_FORMAT_MOD_LINEAR;h->size=sh->length;return true;
}
static bool hre_shared_param(struct pipe_screen *p,struct pipe_context *ctx,struct pipe_resource *res,
 unsigned plane,unsigned layer,unsigned level,enum pipe_resource_param param,unsigned usage,uint64_t *value)
{
 if(!res||res->screen!=p||(ctx&&ctx->screen!=p)||plane||layer||level||!value||s(p)->closing)return false;
 struct resource *b=r(res);struct remesa_shared_image *sh=b->shared_sampler;
 if(!sh||sh->poisoned||b->write_error||b->maps)return false;
 switch(param){
 case PIPE_RESOURCE_PARAM_NPLANES:*value=1;return true;
 case PIPE_RESOURCE_PARAM_STRIDE:*value=sh->pitch;return true;
 case PIPE_RESOURCE_PARAM_OFFSET:*value=sh->offset;return true;
 case PIPE_RESOURCE_PARAM_MODIFIER:*value=DRM_FORMAT_MOD_LINEAR;return true;
 case PIPE_RESOURCE_PARAM_HANDLE_TYPE_FD:{struct winsys_handle h={.type=WINSYS_HANDLE_TYPE_FD};
  if(!hre_get_sampler_handle(p,ctx,res,&h,usage))return false;*value=h.handle;return true;}
 default:return false;
 }
}
static void hre_shared_modifiers(struct pipe_screen *p,enum pipe_format fmt,int max,
 uint64_t *mods,unsigned *external,int *count)
{
 *count=0;if(!s(p)->egl_dmabuf_lab||(fmt!=PIPE_FORMAT_B8G8R8A8_UNORM&&fmt!=PIPE_FORMAT_B8G8R8X8_UNORM))return;
 if(max==0){*count=1;return;}if(max<0||!mods)return;
 mods[0]=DRM_FORMAT_MOD_LINEAR;if(external)external[0]=0;*count=1;
}
static int hre_refresh_sampler(struct pipe_context *p,struct pipe_resource *res)
{
 struct resource *b=r(res);struct remesa_shared_image *sh=b->shared_sampler;
 if(!sh)return 0;
 if(b->sample_shadow)return hre_refresh_sampler(p,b->sample_shadow);
 if(b->shared_rt)return ENOTSUP;
 if(b->shared_refresh||b->maps)return EBUSY;
 if(b->write_error)return b->write_error;
 if(!host_buffer_reserve(s(p->screen),sh->packed))return ENOMEM;
 unsigned char *pixels=malloc(sh->packed);int error=pixels?0:ENOMEM;
 if(!error)error=remesa_shared_transfer(sh,pixels,sh->packed,false);
 if(!error&&b->shared_opaque)for(size_t i=3;i<sh->packed;i+=4)pixels[i]=255;
 bool host_unchanged=false;
 if(!error&&getenv("REMESA_HRE_EGL26_NATIVE_CACHE")&&b->compositor_host_texture&&
    b->host_data&&b->has_contents&&!b->writer&&!b->native_clear_owner&&!b->maps&&
    b->pass.content_epoch&&b->stride>=(size_t)sh->width*4&&sh->height&&
    (uint64_t)b->stride*(sh->height-1)+(uint64_t)sh->width*4<=b->bytes){
  host_unchanged=true;
  for(unsigned y=0;y<sh->height;y++)if(memcmp(pixels+(size_t)y*sh->width*4,
     (const uint8_t*)b->host_data+(size_t)y*b->stride,(size_t)sh->width*4)){host_unchanged=false;break;}
  if(host_unchanged&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL26_SHARED_UNCHANGED\n");
 }
 if(!error&&!host_unchanged&&(!b->shared_cache||!b->shared_cache_valid||memcmp(pixels,b->shared_cache,sh->packed))){
  struct pipe_box box={.width=sh->width,.height=sh->height,.depth=1};
  b->shared_refresh=true;
  texture_subdata(p,res,0,PIPE_MAP_WRITE|PIPE_MAP_DONTBLOCK,&box,pixels,sh->width*4,sh->packed);
  b->shared_refresh=false;error=c(p)->error;
  if(!error){if(b->shared_cache)memcpy(b->shared_cache,pixels,sh->packed);b->shared_cache_valid=b->shared_cache!=NULL;if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_SHARED_REFRESH_OK\n");}
 }
 if(error==EOWNERDEAD)b->write_error=error;
 free(pixels);__atomic_sub_fetch(&s(p->screen)->host_buffer_bytes,sh->packed,__ATOMIC_RELAXED);return error;
}

static int resource_collect_renamed(struct pipe_screen *p,struct resource *b)
{
 for(unsigned i=0;i<2;i++){
  struct renamed_backing *old=&b->renamed[i];if(!old->writer)continue;
  int error=s(p)->device.ops->wait(s(p)->device.priv,old->writer->backend,0,true);
  if(error==EAGAIN||error==ETIMEDOUT||error==EBUSY||error==EINTR)continue;
  if(!error){
   const struct remesa_pass_completion proof={true,true,true};
   error=remesa_render_pass_finish(&old->pass,&old->ticket,&proof);
  }
  if(error){
   (void)remesa_render_pass_fail(&old->pass,&old->ticket,error);
   b->write_error=EOWNERDEAD;return EOWNERDEAD;
  }
  fence_ref(p,&old->writer,NULL);
 }
 return 0;
}
static int resource_rename_discard(struct pipe_screen *p,struct resource *b)
{
 /* Linked attachments, host VBOs and queued native clears are never renamed.
  * Only this explicit resource-only hybrid2D opt-in changes backing identity.
  * The backend allocator/map still enforce all memory, MMU and lease bounds. */
 struct screen *sc=s(p);
 if(!sc->buffer_renaming||b->host_data||sc->linked_attachment_storage||
    b->native_clear_owner||b->maps||b->write_error||!b->writer)return EBUSY;
 if(b->pass.phase!=REMESA_PASS_PENDING)return EBUSY;
 int error;
 struct renamed_backing *slot=NULL;
 /* Reuse a retired exact-size BO before considering another allocation. All
  * slab entries belong to this resource and have the same immutable layout. */
 for(unsigned i=0;i<2;i++)if(b->renamed[i].bo&&!b->renamed[i].writer){slot=&b->renamed[i];break;}
 if(!slot)for(unsigned i=0;i<2;i++)if(!b->renamed[i].bo){slot=&b->renamed[i];break;}
 if(!slot)return EAGAIN;
 uint64_t cookie;if(!screen_next_resource_cookie(sc,&cookie))return EOVERFLOW;
 void *next=slot->bo;
 if(!next){
  error=sc->device.ops->allocate(sc->device.priv,b->bytes,&next);
  /* An alias must never be independently destroyed on an allocation error. */
  if(next&&(next==b->bo||next==b->renamed[0].bo||next==b->renamed[1].bo)){
   b->write_error=EOWNERDEAD;return EOWNERDEAD;
  }
  if(error||!next){
   if(error==EOWNERDEAD||error<0){slot->bo=next;b->write_error=EOWNERDEAD;return EOWNERDEAD;}
   if(next)sc->device.ops->destroy_bo(sc->device.priv,next);
   return error?error:EPROTO;
  }
 }
 *slot=(struct renamed_backing){.bo=b->bo,.writer=b->writer,.pass=b->pass,.ticket=b->ticket};
 b->bo=next;b->writer=NULL;b->has_contents=false;
 memset(&b->ticket,0,sizeof(b->ticket));
 return remesa_render_pass_init(&b->pass,cookie);
}
static void finish_native_clear(struct context *ctx,bool cancelled)
{
 struct pipe_resource **slots[]={&ctx->native_clear_color,&ctx->native_clear_depth};
 for(unsigned i=0;i<2;i++)if(*slots[i]){
  struct resource *b=r(*slots[i]);
  if(b->native_clear_owner==ctx){
   if(cancelled&&!b->write_error)b->write_error=ECANCELED;
   b->native_clear_owner=NULL;
  }
  remesa_resource_reference(slots[i],NULL);
 }
}
static void invalidate_resource(struct pipe_context *p,struct pipe_resource *res)
{
 struct context *ctx=c(p);
 if(s(p->screen)->closing){ctx->error=ESHUTDOWN;return;}
 if(!res||res->screen!=p->screen){ctx->error=EINVAL;return;}
 struct resource *b=r(res);
 if(b->shared_sampler&&(!b->shared_rt||ctx->owned_texture_scene.owner)){ctx->error=ENOTSUP;return;}
 /* Invalidation is not cancellation. Never drop an in-flight writer, change
  * its backing, or turn a failed/uncertain submission into a fresh target. */
 if(b->maps){ctx->error=EBUSY;return;}
 ctx->error=resource_sync(p->screen,b,UINT64_MAX);if(ctx->error)return;
 ctx->error=remesa_render_pass_invalidate(&b->pass);if(ctx->error)return;
 b->has_contents=false;if(b->shared_rt){b->shared_discard=true;b->shared_cache_valid=false;}
}
static int framebuffer_leave(struct pipe_context *p);
static void *map(struct pipe_context *p,struct pipe_resource *b,unsigned level,unsigned usage,const struct pipe_box *box,struct pipe_transfer **out)
{
 struct transfer *t;void *ptr=NULL;size_t offset,row,span;struct screen *sc=s(p->screen);int error=EINVAL;
 bool retained_upload=false;
 const unsigned write_hints=PIPE_MAP_DISCARD_RANGE|PIPE_MAP_DISCARD_WHOLE_RESOURCE|PIPE_MAP_FLUSH_EXPLICIT|PIPE_MAP_UNSYNCHRONIZED;
 if(out) *out=NULL;
 if(sc->closing){error=ESHUTDOWN;goto fail;}
 if((c(p)->presenting||sc->frontbuffer_busy)&&(usage&PIPE_MAP_WRITE)){error=EBUSY;goto fail;}
 if(!b || b->screen!=p->screen || !box || !out || level>=r(b)->layout.count || !(usage & (PIPE_MAP_READ|PIPE_MAP_WRITE)) ||
    usage & ~(PIPE_MAP_READ|PIPE_MAP_WRITE|PIPE_MAP_DONTBLOCK|PIPE_MAP_DIRECTLY|write_hints) ||
    ((usage & write_hints) && (!(usage & PIPE_MAP_WRITE)||(usage & PIPE_MAP_READ))) ||
    ((usage & PIPE_MAP_FLUSH_EXPLICIT)&&(usage & PIPE_MAP_DIRECTLY)) ||
    box->x<0 || box->width<=0) goto fail;
 if(r(b)->maps){error=EBUSY;goto fail;}
 if(r(b)->shared_sampler&&!r(b)->shared_refresh){
  if(((usage&PIPE_MAP_WRITE)&&!r(b)->shared_writable)||(usage&PIPE_MAP_UNSYNCHRONIZED)){error=ENOTSUP;goto fail;}
  error=r(b)->shared_rt?hre_shared_rt_sync(p->screen,r(b),false):hre_refresh_sampler(p,b);if(error)goto fail;
 }
 const struct remesa_texture_level *mip=&r(b)->layout.levels[level];
 if(b->target==PIPE_BUFFER) {
  if(box->y || box->z || box->height!=1 || box->depth!=1 ||
     (uint64_t)box->x+box->width>mip->width) goto fail;
  offset=box->x;row=box->width;
 } else {
  if(box->y<0 || box->z || box->height<=0 || box->depth!=1 ||
     (uint64_t)box->x+box->width>mip->width || (uint64_t)box->y+box->height>mip->height) goto fail;
  offset=(size_t)box->y*mip->stride+(size_t)box->x*4;row=(size_t)box->width*4;
 }
 if(box->height>1 && mip->stride>(SIZE_MAX-row)/(box->height-1))goto fail;
 span=(size_t)(box->height-1)*mip->stride+row;
 if(offset>mip->bytes||span>mip->bytes-offset)goto fail;
 offset+=mip->offset; /* Checked immutable layout keeps this inside the BO. */
 /* RC2: only an explicitly enabled sampled-input write may detach a
  * previously retired graph. Initial uploads and host VBOs are unchanged. */
 const char *dynamic_upload=getenv("REMESA_HRE_UPLOAD_REBIND");
 if(((dynamic_upload&&!strcmp(dynamic_upload,"1"))||r(b)->shared_refresh)&&hre_gles_lab(sc)&&
    (usage&PIPE_MAP_WRITE)&&!r(b)->host_data&&
    (resource_bind(b)&PIPE_BIND_SAMPLER_VIEW)&&c(p)->owned_texture_scene.owner){
  if(b==c(p)->hre_graph_color||b==c(p)->hre_graph_depth){error=EBUSY;goto fail;}
  retained_upload=true;
  error=framebuffer_leave(p);if(error)goto fail;
  fprintf(stderr,"HRE_RC2_UPLOAD_DETACHED\n");
 }

 /* Discard permits replacing backing, never forgetting its old writer. The
  * bounded rename slab retains every old BO/fence/pass and only reuses it
  * after nonblocking authenticated retirement. Partial maps keep old policy. */
 if(sc->buffer_renaming){
  error=resource_collect_renamed(p->screen,r(b));if(error)goto fail;
  bool whole=!level&&!box->x&&!box->y&&box->width==(int)mip->width&&
   box->height==(int)mip->height&&r(b)->layout.count==1;
  if(whole&&(usage&PIPE_MAP_DISCARD_WHOLE_RESOURCE)&&r(b)->writer&&
     !r(b)->native_clear_owner&&!r(b)->write_error){
   /* Poll first so a failed writer can never be hidden by a new BO. Only
    * a still-pending writer permits renaming; a retired one needs no rename. */
   error=resource_sync_writer(p->screen,r(b),0);
   if(error==EAGAIN||error==ETIMEDOUT||error==EBUSY||error==EINTR)
    error=resource_rename_discard(p->screen,r(b));
   if(error)goto fail;
  }
 }
 /* Mesa's upload manager maps fresh/disjoint stream storage unsynchronized.
  * Never wait under that flag and never use it to ignore a retained writer:
  * reject instead, preserving publication, quarantine and backing ownership. */
 if(r(b)->native_clear_owner){error=r(b)->write_error?r(b)->write_error:EBUSY;goto fail;}
 if(usage&PIPE_MAP_UNSYNCHRONIZED) {
  if(r(b)->writer||r(b)->write_error){error=r(b)->write_error?r(b)->write_error:EBUSY;goto fail;}
 } else {
  error=resource_sync(p->screen,r(b),(usage & PIPE_MAP_DONTBLOCK) ? 0 : UINT64_MAX);
  if(error)goto fail;
 }
 if(usage & PIPE_MAP_WRITE){error=remesa_render_pass_admit_cpu_write(&r(b)->pass);if(error)goto fail;}
 t=calloc(1,sizeof(*t));if(!t){error=ENOMEM;goto fail;}
 if(usage & PIPE_MAP_FLUSH_EXPLICIT) {
  t->staging=calloc(1,span);if(!t->staging){free(t);error=ENOMEM;goto fail;}
 }
 int mapped=resource_map_backing(p->screen,r(b),(usage & PIPE_MAP_WRITE)!=0,&ptr);
 if(mapped || !ptr) {
  if(!mapped||ptr)resource_unmap_backing(p->screen,r(b),(usage & PIPE_MAP_WRITE)!=0);
  free(t->staging);free(t);error=mapped?mapped:EPROTO;goto fail;
 }
 remesa_resource_reference(&t->base.resource,b);t->base.level=level;t->base.usage=usage;t->base.box=*box;
 t->base.stride=mip->stride;t->base.layer_stride=t->staging?span:mip->bytes;
 t->backing=(unsigned char *)ptr+offset;t->write=(usage & PIPE_MAP_WRITE)!=0;
 t->mapping=ptr;t->mapping_bytes=r(b)->bytes;t->staging_bytes=t->staging?span:0;
 t->dirty=t->write&&!t->staging;t->next=c(p)->transfers;c(p)->transfers=t;
 ++r(b)->maps;*out=&t->base;c(p)->error=0;return t->staging?t->staging:t->backing;
fail:
 if(error==EOWNERDEAD&&sc->buffer_renaming&&b){
  r(b)->write_error=EOWNERDEAD;c(p)->failed_submission=true;
 }
 /* A failed dynamic write must not be silently followed by a draw using
  * the previous texture. Keep the resource and report the exact failure. */
 if(retained_upload){r(b)->write_error=error;c(p)->publication_error=error;}
 if(hre_gles_lab(sc)&&(usage&PIPE_MAP_WRITE))fprintf(stderr,"HRE_RC2_UPLOAD_FAIL errno=%d\n",error);
 c(p)->error=error;return NULL;
}
/* Transfers are context-private (Mesa 25.2 p_context.h). Membership is checked
 * before dereferencing a supplied handle, including foreign/unmapped handles. */
static struct transfer **transfer_link(struct context *ctx,struct pipe_transfer *pt)
{
 struct transfer **link=&ctx->transfers;
 while(*link && &(*link)->base!=pt)link=&(*link)->next;
 return link;
}
static void flush_region(struct pipe_context *p,struct pipe_transfer *pt,const struct pipe_box *box)
{
 struct context *ctx=c(p);struct transfer *t=*transfer_link(ctx,pt);
 if(!t||!box||!t->write||!t->staging||box->x<0||box->y<0||box->z||
    box->width<0||box->height<0||box->depth!=1||
    (uint64_t)box->x+box->width>(unsigned)t->base.box.width||
    (uint64_t)box->y+box->height>(unsigned)t->base.box.height||
    (t->base.resource->target==PIPE_BUFFER&&(box->y||box->height!=1))) {
  ctx->error=EINVAL;return;
 }
 /* Mesa docs/gallium/context.rst: the flush box is relative to the mapped
  * range, not the resource origin. Unflushed staging bytes never reach BO. */
 if(box->width&&box->height) {
  size_t bpp=t->base.resource->target==PIPE_BUFFER?1:4;
  size_t offset=(size_t)box->y*t->base.stride+(size_t)box->x*bpp;
  size_t row=(size_t)box->width*bpp;
  for(unsigned y=0;y<(unsigned)box->height;y++)
   memcpy(t->backing+offset+(size_t)y*t->base.stride,
          t->staging+offset+(size_t)y*t->base.stride,row);
  t->dirty=true;
 }
 ctx->error=0;
}
static void unmap(struct pipe_context *p,struct pipe_transfer *pt)
{
 struct transfer **link=transfer_link(c(p),pt),*t=*link;
 if(!t){c(p)->error=EINVAL;return;}
 *link=t->next;
 /* Lease mode must match map(), even when an explicit-flush write map
  * committed no ranges. Dirty tracks content epochs, not lease ownership. */
 resource_unmap_backing(p->screen,r(pt->resource),t->write);
 if(r(pt->resource)->write_error){
  c(p)->error=r(pt->resource)->write_error;
  if(c(p)->error==EOWNERDEAD)c(p)->failed_submission=true;
  if(t->write&&s(p->screen)->hre)c(p)->publication_error=c(p)->error;
 }
 if(t->dirty&&!r(pt->resource)->write_error){
  int error=remesa_render_pass_cpu_write(&r(pt->resource)->pass);
  if(error){r(pt->resource)->write_error=error;c(p)->error=error;}
  else r(pt->resource)->has_contents=true;
  if(hre_gles_lab(s(p->screen))&&(error||getenv("REMESA_DRI_TRACE")))
   fprintf(stderr,"HRE_RC3_UPLOAD errno=%d epoch=%llu bind=%x\n",error,(unsigned long long)r(pt->resource)->pass.content_epoch,pt->resource->bind);
 }
 --r(pt->resource)->maps;
 if(t->dirty&&r(pt->resource)->shared_writable&&!r(pt->resource)->shared_refresh&&!r(pt->resource)->write_error){
  int error=hre_shared_rt_sync(p->screen,r(pt->resource),true);
  if(error){c(p)->error=error;c(p)->publication_error=error;}
 }
 remesa_resource_reference(&pt->resource,NULL);free(t->staging);free(t);
}
/* CPU upload into owned backing, not GPU texture sampling or a clear. These
 * entry points use exactly the same writer/lease gate as normal transfers. */
static void buffer_subdata(struct pipe_context *p,struct pipe_resource *b,unsigned usage,
                          unsigned offset,unsigned size,const void *data)
{
 struct context *ctx=c(p);struct pipe_transfer *t=NULL;void *dst;
 if(s(p->screen)->closing){ctx->error=ESHUTDOWN;return;}
 if(!b||b->screen!=p->screen||b->target!=PIPE_BUFFER||offset>b->width0||size>b->width0-offset||
    offset>INT32_MAX||size>INT32_MAX||(size&&!data)||
    usage&~(PIPE_MAP_WRITE|PIPE_MAP_DONTBLOCK|PIPE_MAP_DIRECTLY|PIPE_MAP_DISCARD_RANGE|PIPE_MAP_DISCARD_WHOLE_RESOURCE)) {ctx->error=EINVAL;return;}
 if(!size){ctx->error=0;return;}
 /* map() performs the single writer/lease gate, including bounded renaming
  * for whole-resource discard. A preliminary wait would defeat renaming. */
 struct pipe_box box={.x=offset,.width=size,.height=1,.depth=1};
 dst=map(p,b,0,usage|PIPE_MAP_WRITE,&box,&t);if(!dst)return;
 memmove(dst,data,size);unmap(p,t);
}
static void texture_subdata(struct pipe_context *p,struct pipe_resource *b,unsigned level,unsigned usage,
                           const struct pipe_box *box,const void *data,unsigned stride,uintptr_t layer_stride)
{
 struct context *ctx=c(p);struct pipe_transfer *t=NULL;void *dst;size_t row,span;
 if(s(p->screen)->closing){ctx->error=ESHUTDOWN;return;}
 if(!b||b->screen!=p->screen||!color_storage_target(b->target)||level>=r(b)->layout.count||!box||box->x<0||box->y<0||box->z||
    box->width<0||box->height<0||box->depth!=1||
    (uint64_t)box->x+box->width>r(b)->layout.levels[level].width||
    (uint64_t)box->y+box->height>r(b)->layout.levels[level].height||
    usage&~(PIPE_MAP_WRITE|PIPE_MAP_DONTBLOCK|PIPE_MAP_DIRECTLY|PIPE_MAP_DISCARD_RANGE|PIPE_MAP_DISCARD_WHOLE_RESOURCE)) {ctx->error=EINVAL;return;}
 if(!box->width||!box->height){ctx->error=0;return;}
 row=(size_t)box->width*4;
 if(!data||stride<row||(box->height>1&&stride>(SIZE_MAX-row)/(box->height-1))){ctx->error=EINVAL;return;}
 span=(size_t)(box->height-1)*stride+row;
 if(layer_stride&&layer_stride<span){ctx->error=EINVAL;return;}
 /* map() is the authoritative writer/lease gate. */
 dst=map(p,b,level,usage|PIPE_MAP_WRITE,box,&t);if(!dst)return;
 if(t->stride==row&&stride==row)memcpy(dst,data,span);
 else for(unsigned y=0;y<(unsigned)box->height;y++)memcpy((unsigned char *)dst+y*t->stride,(const unsigned char *)data+y*stride,row);
 unmap(p,t);
}
/* Opt-in native copies authenticate synchronous GPU retirement through the
 * owner/transport callback. The default CPU transfer implementation snapshots
 * first for deterministic overlap. Neither path performs format conversion. */
static void copy_region(struct pipe_context *p,struct pipe_resource *dst,unsigned dst_level,
 unsigned dstx,unsigned dsty,unsigned dstz,struct pipe_resource *src,unsigned src_level,
 const struct pipe_box *box)
{
 struct context *ctx=c(p);struct pipe_transfer *transfer=NULL;
 struct pipe_box dest;void *ptr;unsigned char *snapshot=NULL;size_t row,bytes;
 int error=EINVAL;
 if(s(p->screen)->closing){ctx->error=ESHUTDOWN;return;}
 if(ctx->presenting){ctx->error=EBUSY;return;}
 if(!dst||!src||dst->screen!=p->screen||src->screen!=p->screen||
    dst_level>=r(dst)->layout.count||src_level>=r(src)->layout.count||
    dst->format!=src->format||dst->target!=src->target||
    dst->nr_samples>1||src->nr_samples>1||!box||box->x<0||box->y<0||box->z||
    box->width<0||box->height<0||box->depth!=1||dstz||
    dstx>INT32_MAX||dsty>INT32_MAX)goto done;
 if(src->target==PIPE_BUFFER){
  if(box->y||box->height!=1||dsty)goto done;
  row=(size_t)box->width;
 }else if(color_storage_target(src->target)){
  if(src->format!=PIPE_FORMAT_B8G8R8A8_UNORM&&src->format!=PIPE_FORMAT_R8G8B8A8_UNORM)goto done;
  if((size_t)box->width>SIZE_MAX/4)goto done;
  row=(size_t)box->width*4;
 }else goto done;
 if((uint64_t)box->x+box->width>r(src)->layout.levels[src_level].width||
    (uint64_t)box->y+box->height>r(src)->layout.levels[src_level].height||
    (uint64_t)dstx+box->width>r(dst)->layout.levels[dst_level].width||
    (uint64_t)dsty+box->height>r(dst)->layout.levels[dst_level].height)goto done;
 if(!box->width||!box->height){error=0;goto done;}
 if((size_t)box->height>SIZE_MAX/row){error=EOVERFLOW;goto done;}
 bytes=row*(size_t)box->height;
 if(r(src)->maps||r(dst)->maps){error=EBUSY;goto done;}
 error=resource_sync(p->screen,r(src),UINT64_MAX);if(error)goto done;
 error=resource_sync(p->screen,r(dst),UINT64_MAX);if(error)goto done;
 if(s(p->screen)->native_copy&&!r(src)->shared_sampler&&!r(dst)->shared_sampler&&!r(src)->compositor_host_texture&&!r(dst)->compositor_host_texture&&!(r(src)->host_data&&r(dst)->host_data)&&
    (!s(p->screen)->hybrid_2d||(src->target==PIPE_TEXTURE_2D&&
     ((resource_bind(src)==PIPE_BIND_RENDER_TARGET&&resource_bind(dst)==PIPE_BIND_RENDER_TARGET)||
      (ctx->egl31_copy_active&&src==ctx->egl31_src&&dst==ctx->egl31_dst&&
       !resource_bind(src)&&!resource_bind(dst)&&r(src)->bo&&r(dst)->bo&&
       !r(src)->host_data&&!r(dst)->host_data&&!ctx->owned_texture_scene.owner))&&!src_level&&!dst_level))){
  if(src->target!=PIPE_TEXTURE_2D||src_level||dst_level||
     r(src)->layout.levels[0].offset||r(dst)->layout.levels[0].offset){error=ENOTSUP;goto done;}
  struct remesa_copy_region request={
   .source={r(src)->bo,r(src)->layout.levels[0].width,r(src)->layout.levels[0].height,r(src)->layout.levels[0].stride},
   .destination={r(dst)->bo,r(dst)->layout.levels[0].width,r(dst)->layout.levels[0].height,r(dst)->layout.levels[0].stride},
   .source_x=box->x,.source_y=box->y,.destination_x=dstx,.destination_y=dsty,.width=box->width,.height=box->height};
  struct remesa_pass_ticket ticket;
  error=remesa_render_pass_begin(&r(dst)->pass,REMESA_PASS_PRESERVE,REMESA_PASS_STORE,true,&ticket);if(error)goto done;
  r(dst)->ticket=ticket;
  /* HRE interleaves only independent 2D resources with the retained V3
   * graph, using the exact detached-copy profile available in this ABI.
   * No DROP on a request that is not eligible; never replay uncertain work. */
  if(s(p->screen)->hre&&ctx->owned_texture_scene.owner){
   if(src==dst||src==ctx->target||dst==ctx->target||
      src==ctx->hre_graph_color||dst==ctx->hre_graph_color||
      src==ctx->hre_graph_depth||dst==ctx->hre_graph_depth||
      request.source.width!=128||request.source.height!=128||request.source.stride!=512||
      request.destination.width!=128||request.destination.height!=128||request.destination.stride!=512||
      request.source_x!=3||request.source_y!=4||request.destination_x!=56||request.destination_y!=56||
      request.width!=16||request.height!=16)error=EOPNOTSUPP;
   else{
    error=remesa_persistent_scene_graph_drop(&s(p->screen)->device,ctx->owned_texture_scene,ctx);
    if(!error){ctx->texture_graph_detached=true;error=s(p->screen)->native_copy(s(p->screen)->device.priv,&request);}
   }
  }else error=s(p->screen)->native_copy(s(p->screen)->device.priv,&request);
  if(error>0&&error!=EOWNERDEAD){
   int cancel=remesa_render_pass_cancel(&r(dst)->pass,&ticket);
   if(cancel)error=EOWNERDEAD;
   else if(error==EOPNOTSUPP&&s(p->screen)->hybrid_2d)goto cpu_copy;
   else goto done;
  }
  if(error<0)error=EOWNERDEAD;
  if(!error){
   const struct remesa_pass_completion proof={true,true,true};
   error=remesa_render_pass_submitted(&r(dst)->pass,&ticket);
   if(!error)error=remesa_render_pass_finish(&r(dst)->pass,&ticket,&proof);
   if(!error){r(dst)->has_contents=true;ctx->native_copies++;goto done;}
   error=EOWNERDEAD;
  }
  if(error==EOWNERDEAD){
   (void)remesa_render_pass_submitted(&r(dst)->pass,&ticket);
   (void)remesa_render_pass_fail(&r(dst)->pass,&ticket,error);
   if(src!=dst){struct remesa_pass_ticket read; if(!remesa_render_pass_import_writer(&r(src)->pass,&read))(void)remesa_render_pass_fail(&r(src)->pass,&read,error);}
   r(src)->write_error=r(dst)->write_error=error;ctx->failed_submission=true;
  }
  goto done;
 }
 cpu_copy:
 snapshot=malloc(bytes);if(!snapshot){error=ENOMEM;goto done;}
 ptr=map(p,src,src_level,PIPE_MAP_READ,box,&transfer);if(!ptr){error=ctx->error;goto done;}
 for(unsigned y=0;y<(unsigned)box->height;y++)
  memcpy(snapshot+(size_t)y*row,(unsigned char *)ptr+(size_t)y*transfer->stride,row);
 unmap(p,transfer);transfer=NULL;
 if(ctx->error){error=ctx->error;goto done;}
 dest=*box;dest.x=dstx;dest.y=dsty;
 ptr=map(p,dst,dst_level,PIPE_MAP_WRITE,&dest,&transfer);if(!ptr){error=ctx->error;goto done;}
 for(unsigned y=0;y<(unsigned)box->height;y++)
  memcpy((unsigned char *)ptr+(size_t)y*transfer->stride,snapshot+(size_t)y*row,row);
 unmap(p,transfer);transfer=NULL;
 error=ctx->error;
 if(!error)++ctx->cpu_copies;
 done:
 free(snapshot);ctx->error=error;
}
/* The native callback may publish only after synchronous authenticated
 * completion/retirement. All clocks/pixel checks stay in external tools. */
static int native_fill(struct pipe_context *p,struct pipe_resource *res,unsigned level,
 unsigned x,unsigned y,unsigned width,unsigned height,const unsigned char pixel[4])
{
 struct context *ctx=c(p);struct resource *b=r(res);int error;
 if(res->target!=PIPE_TEXTURE_2D||level||b->layout.levels[0].offset)return ENOTSUP;
 if(b->maps)return EBUSY;
 if(s(p->screen)->native_draws&&b->native_clear_owner==ctx){
  /* Repeated explicit full black clears are real fills, not a cached clear
   * certificate. Only the same owner may replace this exact pending intent. */
  if(x||y||width!=res->width0||height!=res->height0||pixel[0]||pixel[1]||pixel[2]||pixel[3])return EBUSY;
  error=resource_sync_writer(p->screen,b,UINT64_MAX);
 }else error=resource_sync(p->screen,b,UINT64_MAX);
 if(error)return error;
 struct remesa_fill_region request={.destination={b->bo,b->layout.levels[0].width,b->layout.levels[0].height,b->layout.levels[0].stride},
  .destination_x=x,.destination_y=y,.width=width,.height=height,
  .color=(uint32_t)pixel[0]|(uint32_t)pixel[1]<<8|(uint32_t)pixel[2]<<16|(uint32_t)pixel[3]<<24};
 struct remesa_pass_ticket ticket;
 error=remesa_render_pass_begin(&b->pass,REMESA_PASS_PRESERVE,REMESA_PASS_STORE,true,&ticket);if(error)return error;
 b->ticket=ticket;error=s(p->screen)->native_fill(s(p->screen)->device.priv,&request);
 if(error&&error!=EOWNERDEAD&&error>0){
  if(!remesa_render_pass_cancel(&b->pass,&ticket))return error;
  error=EOWNERDEAD;
 }
 if(error<0)error=EOWNERDEAD;
 if(!error){
  const struct remesa_pass_completion proof={true,true,true};
  error=remesa_render_pass_submitted(&b->pass,&ticket);
  if(!error)error=remesa_render_pass_finish(&b->pass,&ticket,&proof);
  if(!error){b->has_contents=true;ctx->native_fills++;return 0;}
  error=EOWNERDEAD;
 }
 (void)remesa_render_pass_fail(&b->pass,&ticket,EOWNERDEAD);
 b->write_error=EOWNERDEAD;ctx->failed_submission=true;return EOWNERDEAD;
}
/* Raw texel clear: explicit native opt-in or the default CPU transfer. */
static void clear_texture(struct pipe_context *p,struct pipe_resource *res,unsigned level,
 const struct pipe_box *box,const void *data)
{
 struct context *ctx=c(p);struct pipe_transfer *transfer=NULL;void *ptr;
 unsigned char pixel[4];int error=EINVAL;
 if(ctx->presenting){ctx->error=EBUSY;return;}
 if(s(p->screen)->closing){ctx->error=ESHUTDOWN;return;}
 if(!res||res->screen!=p->screen||!color_storage_target(res->target)||level>=r(res)->layout.count||!box||!data||
    (!color_rt_format(p->screen,res->format)&&res->format!=PIPE_FORMAT_R8G8B8A8_UNORM)||
    box->x<0||box->y<0||box->z||box->width<0||box->height<0||box->depth!=1||
    (uint64_t)box->x+box->width>r(res)->layout.levels[level].width||
    (uint64_t)box->y+box->height>r(res)->layout.levels[level].height)goto done;
 if(!box->width||!box->height){error=0;goto done;}
 if(r(res)->maps){error=EBUSY;goto done;}
 memcpy(pixel,data,sizeof(pixel));
 if(res->format==PIPE_FORMAT_B8G8R8X8_UNORM)pixel[3]=255;
 if(s(p->screen)->native_fill&&!r(res)->compositor_host_texture){
  error=resource_sync(p->screen,r(res),UINT64_MAX);if(error)goto done;
  error=native_fill(p,res,level,box->x,box->y,box->width,box->height,pixel);goto done;
 }
 unsigned usage=PIPE_MAP_WRITE;
 if(s(p->screen)->buffer_renaming&&!level&&r(res)->layout.count==1&&!box->x&&!box->y&&
    box->width==(int)res->width0&&box->height==(int)res->height0)
  usage|=PIPE_MAP_DISCARD_WHOLE_RESOURCE;
 /* map() is the single CPU writer gate; a full clear can discard and rename
  * an old pending version instead of waiting before reaching that gate. */
 ptr=map(p,res,level,usage,box,&transfer);if(!ptr){error=ctx->error;goto done;}
 for(unsigned y=0;y<(unsigned)box->height;y++)
  remesa_cpu_fill_pixel32((unsigned char *)ptr+(size_t)y*transfer->stride,(size_t)box->width*4,pixel);
 unmap(p,transfer);error=ctx->error;
 if(!error)++ctx->cpu_clears;
 done:ctx->error=error;
}
static void set_vb(struct pipe_context *p,unsigned count,const struct pipe_vertex_buffer *v)
{
 struct context *ctx=c(p);remesa_resource_reference(&ctx->vb.buffer.resource,NULL);
 remesa_resource_reference(&ctx->second_vb.buffer.resource,NULL);
 remesa_resource_reference(&ctx->third_vb.buffer.resource,NULL);
 memset(&ctx->vb,0,sizeof(ctx->vb));memset(&ctx->second_vb,0,sizeof(ctx->second_vb));
 memset(&ctx->third_vb,0,sizeof(ctx->third_vb));ctx->vb_count=0;
 if(!count) return;
 /* Mesa 25.2 transfers these resource references to the callback. */
 int error=count<=3&&v?0:ENOTSUP;
 if(!error)for(unsigned i=0;i<count;i++) {
  struct pipe_resource *res=v[i].buffer.resource;
  if(v[i].is_user_buffer){error=ENOTSUP;break;}
  /* Pinned Mesa display lists allocate current_bo as ELEMENT_ARRAY_BUFFER
   * + VERTEX_STATE, then use it as the VAO's vertex source. Binding flags
   * describe storage usage, not a distinct allocation format. Accept that
   * raw storage here; legacy GPU admission still requires VERTEX_BUFFER. */
  bool vertex_storage=res&&((res->bind&PIPE_BIND_VERTEX_BUFFER)||
   (res->bind&(PIPE_BIND_INDEX_BUFFER|PIPE_BIND_VERTEX_STATE))==
              (PIPE_BIND_INDEX_BUFFER|PIPE_BIND_VERTEX_STATE));
  if(res&&(res->screen!=p->screen||res->target!=PIPE_BUFFER||!vertex_storage)){
   error=EINVAL;break;
  }
 }
 if(error) {
  ctx->error=error;if(v) for(unsigned i=0;i<count;i++) if(!v[i].is_user_buffer) {
   struct pipe_resource *owned=v[i].buffer.resource;remesa_resource_reference(&owned,NULL);
  }
  return;
 }
 ctx->vb=v[0];if(count>=2)ctx->second_vb=v[1];if(count==3)ctx->third_vb=v[2];
 ctx->vb_count=count;ctx->error=0;
}
static void *create_elements(struct pipe_context *p,unsigned count,const struct pipe_vertex_element *e)
{
 struct context *ctx=c(p);struct elements *out;
 bool valid=(count>=1&&count<=3)&&e;
 if(valid)for(unsigned i=0;i<count;i++)if(!remesa_position_format_bytes(e[i].src_format)||
    (i>=1&&e[i].src_format==PIPE_FORMAT_R32G32_FLOAT&&
     !(count==2&&i==1&&e[0].src_format==PIPE_FORMAT_R32G32B32A32_FLOAT))||e[i].vertex_buffer_index>=3||
    e[i].instance_divisor||e[i].dual_slot)valid=false;
 if(!valid) {
  ctx->invalid_elements=true;ctx->error=ENOTSUP;return NULL;
 }
 out=calloc(1,sizeof(*out));if(!out){ctx->invalid_elements=true;ctx->error=ENOMEM;return NULL;}
 out->position=*e;if(count>=2)out->normal=e[1];if(count==3)out->light=e[2];out->count=count;
 out->next=ctx->elements;ctx->elements=out;ctx->error=0;return out;
}
static struct elements *find_elements(struct context *ctx,void *handle)
{
 for(struct elements *e=ctx->elements;e;e=e->next)if(e==handle&&!e->deleted)return e;
 return NULL;
}
static void bind_elements(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);struct elements *e=find_elements(ctx,handle);
 ctx->bound_elements=e;ctx->position_bound=e!=NULL;ctx->invalid_elements=handle&&!e;
 if(e)ctx->position=e->position;
 ctx->error=ctx->invalid_elements?EINVAL:0;
}
static void delete_elements(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);struct elements *e=find_elements(ctx,handle);
 if(!e){ctx->error=EINVAL;return;}
 if(ctx->bound_elements==e){ctx->bound_elements=NULL;ctx->position_bound=false;}
 e->deleted=true;
}
/* Keep retired HRE graph and its attachment identities alive until BIND. */
static int captured_scene_error(struct context *,int);
static int framebuffer_leave(struct pipe_context *p)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(!sc->hre||!ctx->owned_texture_scene.owner)return remesa_context_release_texture_scene(p);
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!ctx->texture_draw_started||ctx->texture_replacement_pending)return EBUSY;
 if(!ctx->hre_graph_color||!ctx->hre_graph_depth)return captured_scene_error(ctx,EOWNERDEAD);
 if(ctx->texture_graph_detached)return 0;
 struct resource *color=r(ctx->hre_graph_color),*depth=r(ctx->hre_graph_depth);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 int e=resource_sync_writer(p->screen,color,0);
 if(!e)e=resource_sync_writer(p->screen,depth,0);
 if(!e)e=remesa_persistent_scene_capture_validate_attachments(&sc->device,ctx->owned_texture_scene,
  color->bo,depth->bo,ctx->hre_graph_color->width0,ctx->hre_graph_color->height0);
 if(!e)e=remesa_persistent_scene_graph_drop(&sc->device,ctx->owned_texture_scene,ctx);
 if(e)return captured_scene_error(ctx,e);
 ctx->texture_graph_detached=true;return 0;
}
static void framebuffer(struct pipe_context *p,const struct pipe_framebuffer_state *f)
{
 struct context *ctx=c(p);
 /* Validate while the previous binding is live: the incoming texture can
  * be that same resource and the context can own its final reference. */
 if(f&&!f->nr_cbufs&&!f->zsbuf.texture&&!f->resolve&&!f->viewmask){
  int error=framebuffer_leave(p);if(error){ctx->error=error;return;}
  remesa_resource_reference(&ctx->target,NULL);remesa_resource_reference(&ctx->depth_target,NULL);ctx->error=0;return;}
 if(!f || f->nr_cbufs!=1 || (!s(p->screen)->cpu_depth24_lab&&!s(p->screen)->linked_attachment_storage&&!((s(p->screen)->native_fill||s(p->screen)->hybrid_2d)&&s(p->screen)->device.resource_only_backend)&&(f->width!=32||f->height!=32)) || !f->width||!f->height || f->samples>1 || (f->zsbuf.texture&&(!(s(p->screen)->cpu_depth24_lab||s(p->screen)->linked_attachment_storage)||
    f->zsbuf.format!=PIPE_FORMAT_Z24X8_UNORM||f->zsbuf.texture->format!=PIPE_FORMAT_Z24X8_UNORM||
    f->zsbuf.texture->screen!=p->screen||resource_bind(f->zsbuf.texture)!=PIPE_BIND_DEPTH_STENCIL||
    !color_storage_target(f->zsbuf.texture->target)||f->zsbuf.texture->width0!=f->width||f->zsbuf.texture->height0!=f->height||
    f->zsbuf.texture->depth0!=1||f->zsbuf.texture->array_size!=1||f->zsbuf.texture->nr_samples>1||
    f->zsbuf.level||f->zsbuf.first_layer||f->zsbuf.last_layer||f->zsbuf.nr_samples>1)) ||
    f->resolve || f->viewmask || f->cbufs[0].level || f->cbufs[0].first_layer || f->cbufs[0].last_layer ||
    f->cbufs[0].nr_samples>1 ||
    !f->cbufs[0].texture || !color_rt_format(p->screen,f->cbufs[0].format) ||
    f->cbufs[0].texture->screen!=p->screen || !color_storage_target(f->cbufs[0].texture->target) ||
    !(f->cbufs[0].texture->bind&PIPE_BIND_RENDER_TARGET) ||
    f->cbufs[0].texture->format!=f->cbufs[0].format || f->cbufs[0].texture->width0!=f->width || f->cbufs[0].texture->height0!=f->height ||
    f->cbufs[0].texture->depth0!=1 || f->cbufs[0].texture->array_size!=1 || f->cbufs[0].texture->nr_samples>1) {
  /* A rejected bind cannot discard the attachments of a live native session. */
  if(!ctx->owned_texture_scene.owner){remesa_resource_reference(&ctx->target,NULL);remesa_resource_reference(&ctx->depth_target,NULL);}
  ctx->error=ENOTSUP;return; }
 if(ctx->target!=f->cbufs[0].texture||ctx->depth_target!=f->zsbuf.texture){
  int error=framebuffer_leave(p);if(error){ctx->error=error;return;}
 }
 remesa_resource_reference(&ctx->target,f->cbufs[0].texture);
 remesa_resource_reference(&ctx->depth_target,f->zsbuf.texture);
 ctx->error=0;
}
static struct pipe_surface *create_surface(struct pipe_context *p,struct pipe_resource *b,const struct pipe_surface *t)
{
 struct pipe_surface *out;
 if(!b || b->screen!=p->screen || !color_storage_target(b->target) ||
    !((resource_bind(b)==PIPE_BIND_RENDER_TARGET&&color_rt_format(p->screen,b->format))||
      ((s(p->screen)->cpu_depth24_lab||s(p->screen)->linked_attachment_storage)&&resource_bind(b)==PIPE_BIND_DEPTH_STENCIL&&b->format==PIPE_FORMAT_Z24X8_UNORM))||!t ||
    t->format!=b->format || t->level || t->first_layer || t->last_layer || t->nr_samples>1) return NULL;
 out=calloc(1,sizeof(*out));if(!out) return NULL;*out=*t;
 out->reference.count=1;out->texture=NULL;remesa_resource_reference(&out->texture,b);
 out->context=p;return out;
}
static void surface_destroy(struct pipe_context *p,struct pipe_surface *surface)
{ (void)p;remesa_resource_reference(&surface->texture,NULL);free(surface); }
static void *unsupported_shader(struct pipe_context *p,const struct pipe_shader_state *state)
{
#ifdef REMESA_WITH_NIR
 if(state && state->type==PIPE_SHADER_IR_NIR) ralloc_free(state->ir.nir);
#else
 (void)state;
#endif
 c(p)->error=ENOTSUP;return NULL;
}
#ifdef REMESA_WITH_NIR
static void record_shader_compile(struct context *ctx,unsigned stage,int error,
 const struct remesa_shader_program *program,bool uniform)
{
 struct remesa_shader_compile_status *status=&ctx->shader_compile[stage];
 uint64_t attempts=status->attempts==UINT64_MAX?UINT64_MAX:status->attempts+1;
 *status=(struct remesa_shader_compile_status){.attempts=attempts,.error=error,
  .binary_error=ENOTSUP,.launch_error=ENOTSUP,.uniform_specialization=!error&&uniform};
 if(!error&&!uniform) {
  struct remesa_shader_program_report report;
  int err=remesa_shader_program_report(program,&report);
  if(!err) {status->binary_error=report.binary_error;status->binary_bytes=report.binary_bytes;
   status->launch_error=report.launch_error;}
  else status->binary_error=err;
 }
}
static void trace_gles_vs(const nir_shader *n)
{
 if(!n)return;
 fprintf(stderr,"HRE_VS_NIR lowered=%u inputs=%u outputs=%u uniforms=%u in=%llx out=%llx\n",n->info.io_lowered,n->num_inputs,n->num_outputs,n->num_uniforms,(unsigned long long)n->info.inputs_read,(unsigned long long)n->info.outputs_written);
 nir_foreach_variable_in_shader(v,n)fprintf(stderr,"HRE_VS_VAR mode=%u loc=%d driver=%u components=%u interp=%u\n",v->data.mode,v->data.location,v->data.driver_location,v->type->vector_elements,v->data.interpolation);
 nir_foreach_function(fn,n)if(fn->impl){nir_foreach_block(block,fn->impl){nir_foreach_instr(i,block){
  if(i->type==nir_instr_type_intrinsic){nir_intrinsic_instr *in=nir_instr_as_intrinsic(i);
   fprintf(stderr,"HRE_VS_INTR %s components=%u",nir_intrinsic_infos[in->intrinsic].name,in->num_components);
   if(nir_intrinsic_has_io_semantics(in)){nir_io_semantics se=nir_intrinsic_io_semantics(in);fprintf(stderr," loc=%u base=%d component=%d no_varying=%u",se.location,nir_intrinsic_base(in),nir_intrinsic_component(in),se.no_varying);}
   fputc('\n',stderr);
  }else if(i->type==nir_instr_type_alu)fprintf(stderr,"HRE_VS_ALU %s\n",nir_op_infos[nir_instr_as_alu(i)->op].name);
  else fprintf(stderr,"HRE_VS_INSTR type=%u\n",i->type);
 }}}
}
static void *create_vertex(struct pipe_context *p,const struct pipe_shader_state *state)
{
 struct vertex *v=NULL;unsigned slot=0;int err=ENOTSUP;
 struct rc_program plan={0};bool live=false;
 struct remesa_ssa_vertex_shader candidate={0};
 bool ssa_attempt=false;int ssa_error=ENOTSUP;
 struct remesa_shader_ir semantic={0};
 struct remesa_shader_program program={0};
 if(state&&state->type==PIPE_SHADER_IR_NIR) {
  /* Transform feedback is a separate, unsupported API contract. */
  err=state->stream_output.num_outputs ? ENOTSUP : remesa_shader_ir_lower(state->ir.nir,&semantic);
  if(!err)err=remesa_shader_ir_vertex_input(&semantic,&slot);
  if(!err)err=remesa_shader_program_prepare(&semantic,&program);
  if(err==ENOTSUP&&!state->stream_output.num_outputs){
   ssa_attempt=true;ssa_error=remesa_usse_ssa_compile_vertex(state->ir.nir,&candidate);
  }
  if(err&&hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE"))trace_gles_vs(state->ir.nir);
  /* EGL6: compile a reference plan, but never make it a native shader handle. */
  if(err==ENOTSUP&&hre_gles_lab(s(p->screen))&&getenv("REMESA_HRE_COMPOSITOR_PLAN")){
   struct rc_program plan;int pe=rc_compile(state->ir.nir,&plan);
   if(!pe)fprintf(stderr,"HRE_COMPOSITOR_VS_HOST_PLAN_OK instructions=%u registers=%u outputs=%u (native still unsupported)\n",plan.count,plan.regs,plan.outputs);
   else fprintf(stderr,"HRE_COMPOSITOR_VS_HOST_PLAN_REJECT errno=%d\n",pe);
  }
  if(err==ENOTSUP&&!state->stream_output.num_outputs&&hybrid_enabled(s(p->screen))&&!rc_compile(state->ir.nir,&plan)){
   live=true;err=0;fprintf(stderr,"HRE_COMPOSITOR_VS_LIVE_PLAN\n");
  }
  const char *dump_vs=getenv("REMESA_HRE_DUMP_REJECTED_NIR");
  if(err&&hre_gles_lab(s(p->screen))&&dump_vs&&!strcmp(dump_vs,"1")){
   fprintf(stderr,"HRE_REJECTED_VS_BEGIN errno=%d\n",err);
   nir_print_shader(state->ir.nir,stderr);fprintf(stderr,"HRE_REJECTED_VS_END\n");
  }
  ralloc_free(state->ir.nir);
  if(!err) {v=calloc(1,sizeof(*v));if(!v)err=ENOMEM;else {v->input_slot=slot;v->program=program;v->compositor_live=live;if(live)v->compositor=plan;v->next=c(p)->vertices;c(p)->vertices=v;}}
 }
 record_shader_compile(c(p),0,err,&program,false);
 if(hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GLES_VS compile_errno=%d\n",err);
 if(ssa_attempt){
  struct remesa_shader_compile_status *status=&c(p)->shader_compile[0];
  status->ssa_candidate_attempted=true;status->ssa_candidate_error=ssa_error;
  status->ssa_candidate_bytes=ssa_error?0:candidate.program.code_bytes;
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"reMESA SSA vertex candidate errno=%d bytes=%zu launch=unsupported\n",ssa_error,status->ssa_candidate_bytes);
 }
 /* Explicit staging experiment only. Normal DRI capability/admission stays
  * unchanged. Keep exact candidate bytes for the real draw callback. */
 const char *stage=getenv("REMESA_V104_STAGE_SSA");
 if(!v&&ssa_attempt&&!ssa_error&&stage&&!strcmp(stage,"1")&&s(p->screen)->linked_scene_experiment){
  v=calloc(1,sizeof(*v));if(!v)err=ENOMEM;else{
   v->ssa=candidate;v->ssa_only=true;v->next=c(p)->vertices;c(p)->vertices=v;err=0;
  }
 }
 c(p)->error=err;return v;
}
static struct vertex *find_vertex(struct context *ctx,void *handle)
{
 for(struct vertex *v=ctx->vertices;v;v=v->next)if(v==handle&&!v->deleted)return v;
 return NULL;
}
static void bind_vertex(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);ctx->diagnostic_discard=false;ctx->vertex_required=true;ctx->bound_vertex=NULL;
 if(!handle){ctx->error=0;return;}
 struct vertex *v=find_vertex(ctx,handle);if(!v){ctx->error=EINVAL;return;}
 ctx->bound_vertex=v;ctx->error=0;
}
static int release_ssa_code(struct context *ctx)
{
 if(!ctx->ssa_code)return 0;
 int e=remesa_persistent_ssa_code_release(&s(ctx->base.screen)->device,ctx->ssa_code);
 if(e){ctx->failed_submission=true;return e;}
 ctx->ssa_code=NULL;ctx->ssa_vertex=NULL;ctx->ssa_fragment=NULL;return 0;
}
static void delete_vertex(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);struct vertex *v=find_vertex(ctx,handle);
 if(!v){ctx->error=EINVAL;return;}
 if(ctx->ssa_vertex==v){int e=release_ssa_code(ctx);if(e){ctx->error=e;return;}}
 if(ctx->bound_vertex==v)ctx->bound_vertex=NULL;
 remesa_shader_program_finish(&v->program);
 v->deleted=true;
}
static void *create_fragment(struct pipe_context *p,const struct pipe_shader_state *state)
{
 struct fragment *f=NULL;uint32_t argb=0;int err=ENOTSUP;bool uniform=false;
 struct rc_program plan={0};bool live=false;
 struct remesa_uniform_color descriptor={0};
 struct remesa_shader_ir semantic={0};
 struct remesa_shader_program program={0};
 if(state && state->type==PIPE_SHADER_IR_NIR) {
  err=state->stream_output.num_outputs ? ENOTSUP : remesa_shader_ir_lower(state->ir.nir,&semantic);
  if(!err&&remesa_shader_ir_fragment_color_input(&semantic)&&
     remesa_shader_ir_fragment_flat_color_input(&semantic)&&
     remesa_shader_ir_fragment_texture2d(&semantic))
   err=remesa_shader_ir_fragment_color(&semantic,&argb);
  if(!err)err=remesa_shader_program_prepare(&semantic,&program);
  if(err==ENOTSUP&&!state->stream_output.num_outputs) {
   err=remesa_nir_uniform_fragment(state->ir.nir,&descriptor);uniform=!err;
  }
  /* EGL6: compile a reference plan, but never make it a native shader handle. */
  if(err==ENOTSUP&&hre_gles_lab(s(p->screen))&&getenv("REMESA_HRE_COMPOSITOR_PLAN")){
   struct rc_program plan;int pe=rc_compile(state->ir.nir,&plan);
   if(!pe)fprintf(stderr,"HRE_COMPOSITOR_FS_HOST_PLAN_OK instructions=%u registers=%u outputs=%u (native still unsupported)\n",plan.count,plan.regs,plan.outputs);
   else fprintf(stderr,"HRE_COMPOSITOR_FS_HOST_PLAN_REJECT errno=%d\n",pe);
  }
  if((err==ENOTSUP||(!err&&uniform))&&!state->stream_output.num_outputs&&hybrid_enabled(s(p->screen))&&!rc_compile(state->ir.nir,&plan)){
   live=true;err=0;fprintf(stderr,"HRE_COMPOSITOR_FS_LIVE_PLAN\n");
  }
  const char *dump_fs=getenv("REMESA_HRE_DUMP_REJECTED_NIR");
  if(err&&hre_gles_lab(s(p->screen))&&dump_fs&&!strcmp(dump_fs,"1")){
   fprintf(stderr,"HRE_REJECTED_FS_BEGIN errno=%d\n",err);
   nir_print_shader(state->ir.nir,stderr);fprintf(stderr,"HRE_REJECTED_FS_END\n");
  }
  /* Gallium transfers NIR ownership even if compilation is rejected. */
  ralloc_free(state->ir.nir);
  if(!err) {
   f=calloc(1,sizeof(*f));
   if(!f) err=ENOMEM;
   else {f->argb=argb;f->program=program;f->uses_uniform=uniform;f->uniform=descriptor;f->compositor_live=live;if(live)f->compositor=plan;f->next=c(p)->fragments;c(p)->fragments=f;}
  }
 }
 record_shader_compile(c(p),1,err,&program,uniform);
 if(hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GLES_FS compile_errno=%d\n",err);
 c(p)->error=err;return f;
}
static struct fragment *find_fragment(struct context *ctx,void *handle)
{
 for(struct fragment *f=ctx->fragments;f;f=f->next)
  if(f==handle && !f->deleted)return f;
 return NULL;
}
static void bind_fragment(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);ctx->diagnostic_discard=false;struct fragment *f=find_fragment(ctx,handle);
 ctx->pipeline_bound=false;ctx->bound_fragment=NULL;
 if(!handle){ctx->error=0;return;}
 if(!f){ctx->error=EINVAL;return;}
 ctx->bound_fragment=f;ctx->argb=f->argb;ctx->pipeline_bound=true;ctx->error=0;
}
static void delete_fragment(struct pipe_context *p,void *handle)
{
 struct context *ctx=c(p);struct fragment *f=find_fragment(ctx,handle);
 if(!f){ctx->error=EINVAL;return;}
 if(ctx->ssa_fragment==f){int e=release_ssa_code(ctx);if(e){ctx->error=e;return;}}
 if(ctx->bound_fragment==f){ctx->pipeline_bound=false;ctx->bound_fragment=NULL;}
 remesa_shader_program_finish(&f->program);
 /* Keep a tombstone until context teardown so a stale handle cannot alias a
  * freshly allocated shader. No NIR/program allocation is retained. */
 f->deleted=true;
}
int remesa_context_shader_program_report(struct pipe_context *p,unsigned stage,
                                        void *handle,struct remesa_shader_program_report *out)
{
 if(!p||!out||!handle)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 if(stage==PIPE_SHADER_VERTEX) {
  struct vertex *v=find_vertex(c(p),handle);
  return v ? remesa_shader_program_report(&v->program,out) : EINVAL;
 }
 if(stage==PIPE_SHADER_FRAGMENT) {
  struct fragment *f=find_fragment(c(p),handle);
  if(!f)return EINVAL;
  /* CPU uniform snapshot specialization is not a GPU uniform program. */
  return f->uses_uniform ? ENOTSUP : remesa_shader_program_report(&f->program,out);
 }
 return ENOTSUP;
}
int remesa_context_shader_program_encode(struct pipe_context *p,unsigned stage,
                                        void *handle,void *out,size_t capacity,size_t *written)
{
 if(!p||!handle||!written||(!out&&capacity))return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 if(stage==PIPE_SHADER_VERTEX) {
  struct vertex *v=find_vertex(c(p),handle);
  return v ? remesa_shader_program_encode(&v->program,out,capacity,written) : EINVAL;
 }
 if(stage==PIPE_SHADER_FRAGMENT) {
  struct fragment *f=find_fragment(c(p),handle);
  if(!f)return EINVAL;
  return f->uses_uniform ? ENOTSUP : remesa_shader_program_encode(&f->program,out,capacity,written);
 }
 return ENOTSUP;
}
int remesa_context_shader_pds_preview(struct pipe_context *p,unsigned stage,
 void *handle,const struct remesa_pds_candidate_request *request,struct remesa_shader_pds_preview *out)
{
 if(!p||!handle||!request||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 if(stage==PIPE_SHADER_VERTEX) {
  struct vertex *v=find_vertex(c(p),handle);
  return v ? remesa_shader_program_preview_pds(&v->program,request,out) : EINVAL;
 }
 if(stage==PIPE_SHADER_FRAGMENT) {
  struct fragment *f=find_fragment(c(p),handle);if(!f)return EINVAL;
  return f->uses_uniform ? ENOTSUP : remesa_shader_program_preview_pds(&f->program,request,out);
 }
 return ENOTSUP;
}
int remesa_context_shader_pipeline_report(struct pipe_context *p,struct remesa_shader_pipeline *out)
{
 if(!p||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 struct context *ctx=c(p);
 if(!ctx->bound_vertex||!ctx->bound_fragment)return ENODATA;
 struct vertex *v=find_vertex(ctx,ctx->bound_vertex);
 struct fragment *f=find_fragment(ctx,ctx->bound_fragment);
 if(!v||!f)return EINVAL;
 if(f->uses_uniform)return ENOTSUP;
 return remesa_shader_pipeline_prepare(&v->program,&f->program,out);
}
static int context_shader_programs(struct pipe_context *p,struct remesa_shader_draw_programs *out)
{
 if(!p||p->draw_vbo!=draw||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 struct context *ctx=c(p);
 if(!ctx->bound_vertex||!ctx->bound_fragment)return ENODATA;
 struct vertex *v=find_vertex(ctx,ctx->bound_vertex);
 struct fragment *f=find_fragment(ctx,ctx->bound_fragment);
 if(!v||!f)return EINVAL;
 if(f->uses_uniform)return ENOTSUP;
 return remesa_shader_draw_programs_prepare(&v->program,&f->program,out);
}
int remesa_context_prepare_host_shader_pipeline(struct pipe_context *p,
 const struct remesa_shader_host_pipeline_request *request,struct remesa_shader_host_pipeline **out)
{
 if(!p||p->draw_vbo!=draw||!request||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 return remesa_shader_host_pipeline_create(&programs,request,out);
}
int remesa_context_revalidate_host_shader_pipeline(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,const struct remesa_shader_host_pipeline_request *request)
{
 if(!pipeline||!request)return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 return remesa_shader_host_pipeline_revalidate(pipeline,&programs,request);
}
int remesa_context_prepare_shader_contract(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,const struct remesa_shader_host_pipeline_request *current,
 const struct remesa_pds_host_transfer_request *transfers,struct remesa_shader_execution_contract *out)
{
 if(!p||p->draw_vbo!=draw||!current||sizeof(*current)>UINTPTR_MAX-(uintptr_t)current||
    !context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 int error=remesa_context_revalidate_host_shader_pipeline(p,pipeline,current);if(error)return error;
 uintptr_t begin=(uintptr_t)out,end=begin+sizeof(*out);
 if(begin<(uintptr_t)current+sizeof(*current)&&end>(uintptr_t)current)return EINVAL;
 /* Revalidation checked each recipe length/pointer before these range checks.
  * The output must also preserve the fresh caller inputs, not just our copy. */
 for(unsigned i=0;i<2;i++) {
  uintptr_t source=(uintptr_t)current->data[i].cells;
  size_t bytes=current->data[i].cell_count*sizeof(*current->data[i].cells);
  if(begin<source+bytes&&end>source)return EINVAL;
 }
 return remesa_shader_host_pipeline_prepare_contract(pipeline,transfers,out);
}
int remesa_context_revalidate_shader_contract(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,const struct remesa_shader_host_pipeline_request *current,
 const struct remesa_pds_host_transfer_request *transfers,const struct remesa_shader_execution_contract *contract)
{
 int error=remesa_context_revalidate_host_shader_pipeline(p,pipeline,current);if(error)return error;
 return remesa_shader_host_pipeline_validate_contract(pipeline,transfers,contract);
}
int remesa_context_prepare_pixel_task_pipeline(struct pipe_context *p,
 const struct remesa_shader_host_pipeline_request *request,uint32_t metadata6,
 struct remesa_shader_host_pipeline **out)
{
 if(!p||p->draw_vbo!=draw||!request||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 return remesa_shader_host_pipeline_create_pixel_task(&programs,request,metadata6,out);
}
int remesa_context_prepare_pds_structure_pipeline(struct pipe_context *p,
 const struct remesa_shader_host_pipeline_request *request,const struct remesa_pds_structure_request *source,
 struct remesa_shader_host_pipeline **out)
{
 if(!p||p->draw_vbo!=draw||!request||!source||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 return remesa_shader_host_pipeline_create_pds_structure(&programs,request,source,out);
}
int remesa_context_revalidate_pds_structure_pipeline(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,const struct remesa_shader_host_pipeline_request *request,
 const struct remesa_pds_structure_request *source)
{
 if(!pipeline||!request||!source)return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 return remesa_shader_host_pipeline_revalidate_pds_structure(pipeline,&programs,request,source);
}
static int context_pixel_task_current(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,
 const struct remesa_shader_host_pipeline_request *current,uint32_t metadata6,
 const struct remesa_pds_cpu_pixel_task_output *out)
{
 if(!p||p->draw_vbo!=draw||!current||sizeof(*current)>UINTPTR_MAX-(uintptr_t)current||
    !context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct remesa_shader_draw_programs programs;
 int error=context_shader_programs(p,&programs);if(error)return error;
 error=remesa_shader_host_pipeline_revalidate_pixel_task(pipeline,&programs,current,metadata6);
 if(error)return error;
 /* Revalidation checked the consumed VS recipe. The FS recipe in current
  * is explicitly ignored by this API and need not point to accessible data. */
 uintptr_t begin=(uintptr_t)out,end=begin+sizeof(*out),source=(uintptr_t)current;
 if(begin<source+sizeof(*current)&&end>source)return EINVAL;
 source=(uintptr_t)current->data[0].cells;
 size_t bytes=current->data[0].cell_count*sizeof(*current->data[0].cells);
 if(begin<source+bytes&&end>source)return EINVAL;
 return 0;
}
int remesa_context_prepare_pixel_task_output(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,
 const struct remesa_shader_host_pipeline_request *current,uint32_t metadata6,
 const struct remesa_pds_host_transfer_request *transfers,struct remesa_pds_cpu_pixel_task_output *out)
{
 int error=context_pixel_task_current(p,pipeline,current,metadata6,out);if(error)return error;
 return remesa_shader_host_pipeline_prepare_pixel_task_output(pipeline,transfers,out);
}
int remesa_context_revalidate_pixel_task_output(struct pipe_context *p,
 const struct remesa_shader_host_pipeline *pipeline,
 const struct remesa_shader_host_pipeline_request *current,uint32_t metadata6,
 const struct remesa_pds_host_transfer_request *transfers,const struct remesa_pds_cpu_pixel_task_output *out)
{
 int error=context_pixel_task_current(p,pipeline,current,metadata6,out);if(error)return error;
 return remesa_shader_host_pipeline_validate_pixel_task_output(pipeline,transfers,out);
}
int remesa_context_prepare_shader_launch(struct pipe_context *p,
 const struct remesa_pds_request *vertex,const struct remesa_pds_request *fragment,
 struct remesa_shader_pipeline_launch *out)
{
 if(!p||!vertex||!fragment||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 struct context *ctx=c(p);
 if(!ctx->bound_vertex||!ctx->bound_fragment)return ENODATA;
 struct vertex *v=find_vertex(ctx,ctx->bound_vertex);
 struct fragment *f=find_fragment(ctx,ctx->bound_fragment);
 if(!v||!f)return EINVAL;
 if(f->uses_uniform)return ENOTSUP;
 return remesa_shader_pipeline_prepare_launch(&v->program,&f->program,vertex,fragment,out);
}
int remesa_context_revalidate_shader_launch(struct pipe_context *p,
 const struct remesa_shader_pipeline_launch *launch,const struct remesa_pds_request *vertex,
 const struct remesa_pds_request *fragment)
{
 if(!p||!launch||!vertex||!fragment)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 struct context *ctx=c(p);
 if(!ctx->bound_vertex||!ctx->bound_fragment)return ENODATA;
 struct vertex *v=find_vertex(ctx,ctx->bound_vertex);
 struct fragment *f=find_fragment(ctx,ctx->bound_fragment);
 if(!v||!f)return EINVAL;
 if(f->uses_uniform)return ENOTSUP;
 return remesa_shader_pipeline_revalidate_launch(launch,&v->program,&f->program,vertex,fragment);
}
#endif
int remesa_context_shader_linkage_snapshot(struct pipe_context *p,
 struct remesa_shader_linkage *out)
{
 if(!p||p->draw_vbo!=draw||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
#ifdef REMESA_WITH_NIR
 struct context *ctx=c(p);
 if(!context_output_valid(ctx,out,sizeof(*out)))return EINVAL;
 if(!ctx->bound_vertex||!ctx->bound_fragment)return ENODATA;
 struct vertex *v=find_vertex(ctx,ctx->bound_vertex);
 struct fragment *f=find_fragment(ctx,ctx->bound_fragment);
 if(!v||!f)return EINVAL;
 if(f->uses_uniform)return ENOTSUP;
 struct remesa_shader_program effective;
 const struct remesa_shader_program *vertex=&v->program;
 const struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if((ctx->homogeneous_draw_lab||s(p->screen)->native_draws)&&raster&&!ctx->invalid_fixed[FIXED_RASTER]&&raster->clamp_vertex_color){
  int error=remesa_shader_program_clamp_vertex_color(vertex,&effective);if(error)return error;
  vertex=&effective;
 }
 return remesa_shader_linkage_prepare(vertex,&f->program,out);
#else
 return ENOTSUP;
#endif
}
int remesa_context_shader_compile_status(struct pipe_context *p,unsigned stage,
 struct remesa_shader_compile_status *out)
{
 if(!p||p->draw_vbo!=draw||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 if(stage!=PIPE_SHADER_VERTEX&&stage!=PIPE_SHADER_FRAGMENT)return ENOTSUP;
#ifdef REMESA_WITH_NIR
 const struct remesa_shader_compile_status *status=&c(p)->shader_compile[stage==PIPE_SHADER_FRAGMENT];
 if(!status->attempts)return ENODATA;
 *out=*status;return 0;
#else
 return ENOTSUP;
#endif
}
/* Pure state admission does not generate new SGX state bytes. These immutable
 * descriptors require semantics equivalent to the unchanged restricted profile.
 * Invalid creates/binds remain latched independently of transient API errors. */
static void *create_fixed(struct pipe_context *p,enum fixed_kind kind,int error,
                         bool scissor,bool depth_clip)
{
 struct context *ctx=c(p);struct fixed *state=NULL;
 if(!error) {
  state=calloc(1,sizeof(*state));if(!state)error=ENOMEM;
  else {state->kind=kind;state->scissor=scissor;state->depth_clip=depth_clip;state->next=ctx->fixed_states;ctx->fixed_states=state;}
 }
 if(error){ctx->invalid_fixed[kind]=true;
  if(hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_FIXED_REJECT kind=%u errno=%d\n",kind,error);
 }
 ctx->error=error;return state;
}
static struct fixed *find_fixed(struct context *ctx,void *handle,enum fixed_kind kind)
{
 for(struct fixed *state=ctx->fixed_states;state;state=state->next)
  if(state==handle&&!state->deleted&&state->kind==kind)return state;
 return NULL;
}
static void bind_fixed(struct pipe_context *p,void *handle,enum fixed_kind kind)
{
 struct context *ctx=c(p);struct fixed *state=find_fixed(ctx,handle,kind);
 /* Mesa CSO cleanup explicitly unbinds these states with NULL. Unbinding
  * is valid lifecycle state, not an implicit executable default: NIR draws
  * still require all three bound objects in draw(). Foreign/deleted non-NULL
  * handles retain their separate rejection until a valid bind or unbind. */
 ctx->bound_fixed[kind]=state;ctx->invalid_fixed[kind]=handle&&!state;
 ctx->error=ctx->invalid_fixed[kind]?EINVAL:0;
}
static void delete_fixed(struct pipe_context *p,void *handle,enum fixed_kind kind)
{
 struct context *ctx=c(p);struct fixed *state=find_fixed(ctx,handle,kind);
 if(!state){ctx->error=EINVAL;return;}
 if(ctx->bound_fixed[kind]==state){ctx->bound_fixed[kind]=NULL;ctx->invalid_fixed[kind]=true;}
 state->deleted=true;
}
static void *create_blend(struct pipe_context *p,const struct pipe_blend_state *state)
{ int e=s(p->screen)->linked_scene_experiment ? remesa_validate_blend_experimental(state) : remesa_validate_blend(state);
  bool hybrid=false;
  if(e&&state&&hybrid_enabled(s(p->screen))&&state->rt[0].blend_enable){
   const struct pipe_rt_blend_state *rt=&state->rt[0];struct pipe_blend_state check=*state;
   check.rt[0].blend_enable=false;
   if(rt->colormask==PIPE_MASK_RGBA&&rt->rgb_func==PIPE_BLEND_ADD&&rt->alpha_func==PIPE_BLEND_ADD&&
      rt->rgb_src_factor==PIPE_BLENDFACTOR_ONE&&rt->alpha_src_factor==PIPE_BLENDFACTOR_ONE&&
      rt->rgb_dst_factor==PIPE_BLENDFACTOR_INV_SRC_ALPHA&&rt->alpha_dst_factor==PIPE_BLENDFACTOR_INV_SRC_ALPHA&&
      !remesa_validate_blend(&check)){e=0;hybrid=true;}
  }
  struct fixed *out=create_fixed(p,FIXED_BLEND,e,false,false);
  if(out&&state){out->colormask=state->rt[0].colormask;out->compositor_blend=hybrid;out->compositor_only=hybrid;}
  return out; }
static void bind_blend(struct pipe_context *p,void *state){bind_fixed(p,state,FIXED_BLEND);}
static void delete_blend(struct pipe_context *p,void *state){delete_fixed(p,state,FIXED_BLEND);}
static void *create_dsa(struct pipe_context *p,const struct pipe_depth_stencil_alpha_state *state)
{
 /* The typed GEM path shares the already qualified opaque LESS/write
  * contract. This admits state ownership only, never ordinary draw or CPU Z. */
 int error=(s(p->screen)->gears_runtime||s(p->screen)->linked_attachment_storage)?
  remesa_validate_gears_dsa(state):remesa_validate_dsa(state);
 struct fixed *out=create_fixed(p,FIXED_DSA,error,false,false);
 if(out&&state){out->depth_enabled=state->depth_enabled;out->depth_write=state->depth_writemask;out->depth_func=state->depth_func;}
 return out;
}
static void bind_dsa(struct pipe_context *p,void *state){bind_fixed(p,state,FIXED_DSA);}
static void delete_dsa(struct pipe_context *p,void *state){delete_fixed(p,state,FIXED_DSA);}
int remesa_context_linked_isp_snapshot(struct pipe_context *p,
 struct remesa_isp_opaque_triangle_request *out)
{
 if(!p||p->draw_vbo!=draw||!out||
    (uintptr_t)out%_Alignof(struct remesa_isp_opaque_triangle_request)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(!sc->linked_attachment_storage)return ENOTSUP;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!ctx->target||!ctx->depth_target)return ENODATA;
 if(r(ctx->target)->write_error)return r(ctx->target)->write_error;
 if(r(ctx->depth_target)->write_error)return r(ctx->depth_target)->write_error;
 if(ctx->invalid_fixed[FIXED_BLEND]||ctx->invalid_fixed[FIXED_DSA])return EINVAL;
 struct fixed *blend=ctx->bound_fixed[FIXED_BLEND],*depth=ctx->bound_fixed[FIXED_DSA];
 if(!blend||!depth)return ENODATA;
 /* The ISP DATA word records only full-vs-partial color output. The DRI
  * qualification screen may issue the single matrix case R-only so its
  * readback can determine whether the target preserves G/B/A. This is an
  * explicitly experimental probe, not an exact channel-mask implementation;
  * production and non-experimental linked screens remain full-RGBA only. */
 if(blend->compositor_only||depth->compositor_only)return ENOTSUP;
 if(blend->colormask!=PIPE_MASK_RGBA&&
    !(sc->linked_scene_experiment&&blend->colormask==PIPE_MASK_R))return ENOTSUP;
 if(depth->depth_enabled&&(depth->depth_func!=PIPE_FUNC_LESS&&
    depth->depth_func!=PIPE_FUNC_ALWAYS))return ENOTSUP;
 /* Depth write is admitted on and off; the ISP depth-control word carries
  * both values (original depth_control branch, recorded LESS/ALWAYS x
  * write0/1). Only the fully enabled RGBA mask is admitted here. Blend
  * factors and stencil remain rejected by their state validators. */
 const struct remesa_isp_opaque_triangle_request value={
  .depth_bits_present=true,.depth_test=depth->depth_enabled,
  .depth_write=depth->depth_enabled&&depth->depth_write,
  .compare=depth->depth_enabled?(depth->depth_func==PIPE_FUNC_LESS?
   REMESA_DEPTH_LESS:REMESA_DEPTH_ALWAYS):REMESA_DEPTH_ALWAYS,
  .rgba_mask=blend->colormask};
 *out=value;return 0;
}
static void *create_raster(struct pipe_context *p,const struct pipe_rasterizer_state *state)
{
 /* An immutable API descriptor can be retained before its complete native
  * raster contract is executable. The draw guard explicitly rejects this
  * pending class; recording it does not admit sampling, clipping or a job. */
 if((s(p->screen)->homogeneous_frontend_lab||s(p->screen)->native_draws)&&state&&state->half_pixel_center){
  struct fixed *out=create_fixed(p,FIXED_RASTER,remesa_validate_gears_rasterizer(state),state->scissor,
   state->depth_clip_near||state->depth_clip_far);
  if(out){out->native_raster_pending=true;
   out->native_w2_raster=!remesa_validate_homogeneous_w2_rasterizer(state);
   out->bottom_edge_rule=state->bottom_edge_rule;
   out->flat=state->flatshade;out->clamp_vertex_color=state->clamp_vertex_color;
   out->flat_first=state->flatshade_first;out->front_ccw=state->front_ccw;out->cull_face=state->cull_face;
   out->depth_clip_near=state->depth_clip_near;out->depth_clip_far=state->depth_clip_far;}
  return out;
 }
 if(s(p->screen)->gears_runtime){
  if(state&&getenv("REMESA_GEARS_TRACE"))fprintf(stderr,"GEARS_RASTER half=%u bottom=%u cull=%u ccw=%u flat=%u first=%u clamp_v=%u clamp_f=%u twoside=%u fill=%u/%u clip=%u/%u halfz=%u precision=%u/%u\n",state->half_pixel_center,state->bottom_edge_rule,state->cull_face,state->front_ccw,state->flatshade,state->flatshade_first,state->clamp_vertex_color,state->clamp_fragment_color,state->light_twoside,state->fill_front,state->fill_back,state->depth_clip_near,state->depth_clip_far,state->clip_halfz,state->subpixel_precision_x,state->subpixel_precision_y);
  struct fixed *out=create_fixed(p,FIXED_RASTER,remesa_validate_gears_rasterizer(state),state&&state->scissor,state&&(state->depth_clip_near||state->depth_clip_far));
  if(out){out->bottom_edge_rule=state->bottom_edge_rule;out->flat=state->flatshade;out->clamp_vertex_color=state->clamp_vertex_color;out->flat_first=state->flatshade_first;out->front_ccw=state->front_ccw;out->cull_face=state->cull_face;out->depth_clip_near=state->depth_clip_near;out->depth_clip_far=state->depth_clip_far;}
  return out;
 }
 const struct pipe_rasterizer_state *admitted=state;struct pipe_rasterizer_state host;
 bool recording=s(p->screen)->device.offline_test_backend&&!s(p->screen)->device.qualified_hardware_backend;
 /* Host-facing culling is connected only to the recording preparation path.
  * Physical state admission stays unchanged; no SGX cull bit is generated. */
 if(state&&state->cull_face&&recording&&state->depth_clip_near&&state->depth_clip_far) {
  host=*state;host.cull_face=PIPE_FACE_NONE;admitted=&host;
 }
 const struct remesa_device *device=&s(p->screen)->device;
 bool finite_lab=device->qualified_hardware_backend&&device->retained_fragment_carrier&&
  device->retained_gl_fbo_half_pixel_center;
 bool recording_window=recording&&admitted&&admitted->half_pixel_center&&admitted->bottom_edge_rule;
 /* The GLES lab uses window-coordinate sampled triangles. Edge-rule
  * equivalence is not qualified; allow the API descriptor only in the
  * explicitly nonconformant lab, never normal admission. No cull, clip,
  * blend or scissor emulation is introduced. */
 bool gles_edges=hre_gles_lab(s(p->screen))&&admitted&&admitted->half_pixel_center&&admitted->bottom_edge_rule&&
  !admitted->scissor&&!admitted->cull_face&&!admitted->flatshade;
 int error=gles_edges?remesa_validate_recording_window_rasterizer(admitted):
  recording_window?remesa_validate_recording_window_rasterizer(admitted):
  finite_lab?remesa_validate_lab_rasterizer(admitted,REMESA_LAB_RASTER_QUARTER_FBO):
  remesa_validate_rasterizer(admitted);
 bool hybrid=false;
 if(error&&state&&hybrid_enabled(s(p->screen))&&state->half_pixel_center&&!state->cull_face&&!state->flatshade){
  struct pipe_rasterizer_state check=*state;check.scissor=false;check.bottom_edge_rule=true;
  if(!remesa_validate_recording_window_rasterizer(&check)){error=0;hybrid=true;}
 }
 struct fixed *out=create_fixed(p,FIXED_RASTER,error,state&&state->scissor,state&&(state->depth_clip_near||state->depth_clip_far));
 if(out)out->compositor_only=hybrid;
 if(hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE")&&state)fprintf(stderr,"HRE_GLES_RASTER errno=%d half=%u bottom=%u cull=%u scissor=%u\n",error,state->half_pixel_center,state->bottom_edge_rule,state->cull_face,state->scissor);
 if(out){out->recording_edge_proof=recording_window;
  out->full_clip=state->depth_clip_near&&state->depth_clip_far;
  out->depth_clip_near=state->depth_clip_near;out->depth_clip_far=state->depth_clip_far;
  out->cull_face=state->cull_face;out->front_ccw=state->front_ccw;
  out->flat_first=state->flatshade_first;}
 return out; }
static void bind_raster(struct pipe_context *p,void *state){bind_fixed(p,state,FIXED_RASTER);}
static void delete_raster(struct pipe_context *p,void *state){delete_fixed(p,state,FIXED_RASTER);}
static void viewport_state(struct pipe_context *p,unsigned start,unsigned count,const struct pipe_viewport_state *v)
{
 struct context *ctx=c(p);ctx->invalid_viewport=true;
 if(start || count!=1 || !v){ctx->error=ENOTSUP;return;}
 if(!remesa_viewport_swizzle_is_identity(v)){ctx->error=ENOTSUP;return;}
 if(s(p->screen)->device.resource_only_backend&&!s(p->screen)->gears_runtime){
  for(unsigned i=0;i<3;i++)if(!isfinite(v->scale[i])||!isfinite(v->translate[i])){ctx->error=EINVAL;return;}
  /* State binding is independent of the selected serializer and never admits
   * a draw on a resource-only endpoint. Preserve the exact application bits. */
  ctx->viewport=*v;ctx->viewport_set=true;ctx->invalid_viewport=false;ctx->error=0;return;
 }
 if(s(p->screen)->gears_runtime){
  if(v->scale[0]!=640.0f||(v->scale[1]!=400.0f&&v->scale[1]!=-400.0f)||v->scale[2]!=0.5f||
     v->translate[0]!=640.0f||v->translate[1]!=400.0f||v->translate[2]!=0.5f){ctx->error=ENOTSUP;return;}
  ctx->viewport=*v;ctx->viewport_set=true;ctx->invalid_viewport=false;ctx->error=0;return;
 }

 bool identity=true,canonical=true;
 for(unsigned i=0;i<3;i++) {
  if(v->scale[i]!=1||v->translate[i]!=0)identity=false;
  float required=i==2?.5f:16;
  bool scale=v->scale[i]==required;
  if(i<2&&s(p->screen)->device.offline_test_backend&&!s(p->screen)->device.qualified_hardware_backend)
   scale=scale||v->scale[i]==-required;
  if(!scale||v->translate[i]!=required)canonical=false;
 }
 if(!identity&&!canonical){ctx->error=ENOTSUP;return;}
 ctx->viewport=*v;ctx->viewport_set=true;ctx->invalid_viewport=false;ctx->error=0;
}
static int window_viewport_request(struct context *ctx,uint32_t depth_bits,
 struct remesa_ta_window_viewport_request *out)
{
 struct screen *sc=s(ctx->base.screen);
 if(sc->closing)return ESHUTDOWN;
 if(!sc->device.resource_only_backend||sc->gears_runtime)return ENOTSUP;
 if(!ctx->viewport_set||ctx->invalid_viewport||!ctx->target)return ENODATA;
 const struct pipe_viewport_state *v=&ctx->viewport;
 struct remesa_ta_window_viewport_request request;
 int error=remesa_ta_viewport_from_gallium(ctx->target->width0,ctx->target->height0,
   depth_bits,v->scale,v->translate,&request);
 if(error){if(hybrid_enabled(sc))fprintf(stderr,"HRE_SCRATCH_VIEWPORT errno=%d size=%ux%u scale=%g,%g,%g translate=%g,%g,%g\n",error,ctx->target->width0,ctx->target->height0,v->scale[0],v->scale[1],v->scale[2],v->translate[0],v->translate[1],v->translate[2]);return error;}
 /* FBO CPU encoding is implemented, but hardware orientation and edge rules
  * have not been qualified. Existing live scene admission remains unchanged. */
 if(request.path!=REMESA_TA_VIEWPORT_MATRIX_WINDOW)return ENOTSUP;
 *out=request;return 0;
}
int remesa_context_window_viewport_snapshot(struct pipe_context *p,uint32_t depth_bits,
 struct remesa_ta_window_viewport_request *out)
{
 if(!p||p->draw_vbo!=draw||!out||
    (uintptr_t)out%_Alignof(struct remesa_ta_window_viewport_request)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 return window_viewport_request(c(p),depth_bits,out);
}
int remesa_context_window_viewport_parameters_snapshot(struct pipe_context *p,
 struct remesa_vertex_parameter_values *out)
{
 if(!p||p->draw_vbo!=draw||!out||
    (uintptr_t)out%_Alignof(struct remesa_vertex_parameter_values)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);
 struct remesa_ta_window_viewport_request viewport;
 int e=window_viewport_request(ctx,24,&viewport);if(e)return e;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(r(ctx->target)->write_error)return r(ctx->target)->write_error;
 struct remesa_vertex_parameter_values values={0};
 for(unsigned i=0;i<3;i++){
  memcpy(&values.coefficient_bits[i],&ctx->viewport.scale[i],4);
  memcpy(&values.coefficient_bits[4+i],&ctx->viewport.translate[i],4);
 }
 values.coefficient_bits[3]=UINT32_C(0x3f800000);
 *out=values;return 0;
}
int remesa_context_window_viewport_encode(struct pipe_context *p,uint32_t depth_bits,
 unsigned char out[28])
{
 if(!p||p->draw_vbo!=draw||!context_state_output_valid(c(p),out,28))return EINVAL;
 struct remesa_ta_window_viewport_request request;
 int error=window_viewport_request(c(p),depth_bits,&request);if(error)return error;
 return remesa_ta_window_viewport_encode(&request,out);
}
static void scissor_state(struct pipe_context *p,unsigned start,unsigned count,const struct pipe_scissor_state *v)
{
 struct context *ctx=c(p);ctx->invalid_scissor=true;
 if(hybrid_enabled(s(p->screen))&&!start&&count==1&&v&&v->minx<=v->maxx&&v->miny<=v->maxy){ctx->compositor_scissor=*v;ctx->invalid_scissor=false;ctx->scissor_set=true;ctx->error=0;return;}
 if(start || count!=1 || !v || v->minx || v->miny || v->maxx!=32 || v->maxy!=32){ctx->error=ENOTSUP;return;}
 ctx->invalid_scissor=false;ctx->scissor_set=true;ctx->error=0;
}
/* Mesa state tracker/CSO owns these host descriptors. Creating a nearest
 * descriptor does not admit GPU texture sampling. Nonempty bindings remain
 * draw-blocking independently of transient errors on unrelated callbacks. */
static void *create_sampler(struct pipe_context *p,const struct pipe_sampler_state *state)
{
 void *handle=NULL;
 c(p)->error=remesa_sampler_create(c(p)->samplers,state,&handle);
 return handle;
}
static void bind_samplers(struct pipe_context *p,enum pipe_shader_type stage,
 unsigned start,unsigned count,void **states)
{ c(p)->error=remesa_sampler_bind(c(p)->samplers,stage,start,count,states); }
static void delete_sampler(struct pipe_context *p,void *state)
{ c(p)->error=state?remesa_sampler_delete(c(p)->samplers,state):0; }
/* Query only resources from this screen. Backing metadata is not a kernel
 * generation or proof of GPU visibility; quarantined backing is inadmissible. */
static bool opaque_native_view(const struct context *ctx,const struct pipe_sampler_view *view)
{
 /* Shared snapshots force alpha to one. The private hybrid carrier can
  * also sample ordinary XRGB backing, because its CPU resolve discards X. */
 return view->format==PIPE_FORMAT_B8G8R8X8_UNORM&&(r(view->texture)->shared_opaque||ctx->compositor_carrier)&&
  (view->swizzle_a==PIPE_SWIZZLE_1||view->swizzle_a==PIPE_SWIZZLE_W);
}
static struct resource *sample_backing(struct pipe_resource *res)
{return r(res)->sample_shadow?r(r(res)->sample_shadow):r(res);}
static int texture_storage(void *owner,struct pipe_resource *resource,
 unsigned level,struct remesa_texture_storage *out)
{
 struct pipe_screen *screen=owner;
 if(!resource || resource->screen!=screen || !out) return EINVAL;
 if(s(screen)->closing) return ESHUTDOWN;
 if(r(resource)->write_error) return r(resource)->write_error;
 if(r(resource)->maps||r(resource)->native_clear_owner) return EBUSY;
 if(r(resource)->sample_shadow)resource=r(resource)->sample_shadow;
 if(r(resource)->write_error)return r(resource)->write_error;
 if((!r(resource)->bo&&!r(resource)->compositor_host_texture) || !r(resource)->pass.resource_cookie) return ESTALE;
 if(level>=r(resource)->layout.count)return EINVAL;
 const struct remesa_texture_level *mip=&r(resource)->layout.levels[level];
 *out=(struct remesa_texture_storage){.resource_cookie=r(resource)->pass.resource_cookie,
     .bytes=r(resource)->bytes,.stride=mip->stride,.offset=mip->offset,
     .width=mip->width,.height=mip->height,.levels=r(resource)->layout.count,
     .content_epoch=r(resource)->pass.content_epoch};return 0;
}
/* Frontend metadata bridge only. The provider must independently attest the
 * retained mapping; this API never encodes a texture or admits sampling. */
int remesa_context_texture_view_storage(struct pipe_context *p,
 const struct pipe_sampler_view *view,struct remesa_texture_storage *out)
{
 if(!p||p->draw_vbo!=draw||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 return remesa_texture_view_storage(c(p)->textures,view,out);
}
int remesa_context_texture_view_level_storage(struct pipe_context *p,
 const struct pipe_sampler_view *view,unsigned level,struct remesa_texture_storage *out)
{
 if(!p||p->draw_vbo!=draw||!out)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 return remesa_texture_view_level_storage(c(p)->textures,view,level,out);
}
int remesa_context_prepare_bound_texture_pds(struct pipe_context *p,void *code,
 void *geometry,void **out)
{
 if(!p||p->draw_vbo!=draw||!out||(uintptr_t)out%_Alignof(void *)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 int error=remesa_persistent_shader_output_check(&sc->device,out,sizeof(*out));if(error)return error;
 if(*out)return EBUSY;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 struct pipe_sampler_state sampler;
 error=remesa_sampler_fragment0_snapshot(ctx->samplers,&sampler);if(error)return error;
 const struct pipe_sampler_view *view=NULL;
 error=remesa_texture_fragment0_view(ctx->textures,&view);if(error)return error;
 uintptr_t at=(uintptr_t)out,vs=(uintptr_t)view,rs=(uintptr_t)view->texture;
 if((at<vs+sizeof(*view)&&vs<at+sizeof(*out))||
    (at<rs+sizeof(struct resource)&&rs<at+sizeof(*out)))return EINVAL;
 if(view->texture==ctx->target||view->texture==ctx->depth_target)return EINVAL;
 if(view->swizzle_r!=PIPE_SWIZZLE_X||view->swizzle_g!=PIPE_SWIZZLE_Y||
    view->swizzle_b!=PIPE_SWIZZLE_Z||(!opaque_native_view(ctx,view)&&view->swizzle_a!=PIPE_SWIZZLE_W))return ENOTSUP;
 unsigned format_id;
 if(view->format==PIPE_FORMAT_R8G8B8A8_UNORM)format_id=21;
 else if(view->format==PIPE_FORMAT_B8G8R8A8_UNORM||opaque_native_view(ctx,view))format_id=20;
 else return ENOTSUP;
 error=resource_sync(p->screen,r(view->texture),0);if(error)return error;
 struct remesa_texture_storage storage;
 error=remesa_texture_view_storage(ctx->textures,view,&storage);if(error)return error;
 struct resource *texture=sample_backing(view->texture);
 if(!texture->bo)return ENOTSUP; /* host-only is never a native descriptor */
 if(!texture->has_contents||!storage.content_epoch)return EAGAIN;
 const struct remesa_linked_texture_input image={texture->bo,storage.offset,
  storage.width,storage.height,storage.stride,format_id,
  sampler.min_img_filter==PIPE_TEX_FILTER_LINEAR,
  sampler.mag_img_filter==PIPE_TEX_FILTER_LINEAR,
  sampler.wrap_s==PIPE_TEX_WRAP_REPEAT,
  sampler.wrap_t==PIPE_TEX_WRAP_REPEAT};
 return remesa_persistent_psb_texture_pds_prepare(&sc->device,code,geometry,&image,out);
}
int remesa_context_prepare_texture_descriptor(struct pipe_context *p,
 const struct pipe_sampler_view *view,const struct pipe_sampler_state *sampler,
 uint64_t owner,remesa_texture_mapping_query query,void *user,
 struct remesa_texture_descriptor *out)
{
 struct remesa_texture_storage storage;int error;
 if(!p||p->draw_vbo!=draw||!out||!query)return EINVAL;
 error=remesa_context_texture_view_storage(p,view,&storage);if(error)return error;
 /* Pointer membership was checked before view dereference. Do not let a
  * provider's claimed completion override an unfinished frontend writer. */
 error=resource_sync(p->screen,r(view->texture),0);if(error)return error;
 return remesa_texture_descriptor_prepare(c(p)->textures,view,sampler,
     owner,query,user,out);
}
int remesa_context_revalidate_texture_descriptor(struct pipe_context *p,
 const struct remesa_texture_descriptor *descriptor,const struct pipe_sampler_view *view,
 const struct pipe_sampler_state *sampler,uint64_t owner,
 remesa_texture_mapping_query query,void *user)
{
 struct remesa_texture_storage storage;
 if(!p||p->draw_vbo!=draw||!descriptor||!query)return EINVAL;
 int error=remesa_context_texture_view_storage(p,view,&storage);if(error)return error;
 error=resource_sync(p->screen,r(view->texture),0);if(error)return error;
 return remesa_texture_descriptor_revalidate(descriptor,c(p)->textures,view,sampler,
     owner,query,user);
}
static struct pipe_sampler_view *create_sampler_view(struct pipe_context *p,
 struct pipe_resource *resource,const struct pipe_sampler_view *view)
{
 struct pipe_sampler_view *out=NULL;
 c(p)->error=remesa_texture_view_create(c(p)->textures,resource,view,&out);
 if(c(p)->error&&hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_EGL29_VIEW_CREATE_FAIL errno=%d\n",c(p)->error);
 return out;
}
static void destroy_sampler_view(struct pipe_context *p,struct pipe_sampler_view *view)
{
 c(p)->error=view?remesa_texture_view_destroy(c(p)->textures,view):0;
}
/* Mesa state_tracker releases even a NULL pixel-map view at teardown.
 * Release the frontend reference, preserving the view bank's owner callback.
 * This lifetime hook does not advertise texture execution support. */
static void release_sampler_view(struct pipe_context *p,struct pipe_sampler_view *view)
{
 (void)p;
 if(view && !__atomic_sub_fetch(&view->reference.count,1,__ATOMIC_ACQ_REL))
  view->context->sampler_view_destroy(view->context,view);
}
static void set_sampler_views(struct pipe_context *p,enum pipe_shader_type stage,
 unsigned start,unsigned count,unsigned trailing,struct pipe_sampler_view **views)
{ c(p)->error=remesa_texture_views_bind(c(p)->textures,stage,start,count,trailing,views);
 if(c(p)->error&&hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_EGL29_VIEW_BIND_FAIL stage=%u start=%u count=%u trailing=%u errno=%d\n",(unsigned)stage,start,count,trailing,c(p)->error); }
/* Mesa CSO cleanup invokes these even with zero shader/texture caps. */
static void constant_buffer(struct pipe_context *p,enum pipe_shader_type shader,unsigned slot,
 bool take_ownership,const struct pipe_constant_buffer *buffer)
{
 struct context *ctx=c(p);struct pipe_resource *owned=NULL,*incoming=NULL;
 if(buffer&&take_ownership)owned=buffer->buffer;
 /* A borrowed rebind may name the buffer held solely by the old binding.
  * Keep it alive while validation replaces that binding, including failures. */
 if(buffer&&buffer->buffer&&(shader==PIPE_SHADER_FRAGMENT||shader==PIPE_SHADER_VERTEX)&&!slot)
  remesa_resource_reference(&incoming,buffer->buffer);
 bool stage=shader==PIPE_SHADER_VERTEX||shader==PIPE_SHADER_FRAGMENT;
 bool empty=!buffer||(!buffer->buffer&&!buffer->user_buffer&&!buffer->buffer_size&&!buffer->buffer_offset);
 if(!stage||slot>=32){ctx->invalid_constants=true;ctx->error=ENOTSUP;}
 else {
  unsigned index=shader==PIPE_SHADER_VERTEX?0:1;
  if(shader==PIPE_SHADER_FRAGMENT&&!slot) {
   remesa_resource_reference(&ctx->fragment_constants,NULL);
   free(ctx->constant_snapshot);ctx->constant_snapshot=NULL;ctx->constant_size=0;ctx->constant_offset=0;
  }
  if(shader==PIPE_SHADER_VERTEX&&!slot) {
   remesa_resource_reference(&ctx->vertex_constants,NULL);
   free(ctx->vertex_constant_snapshot);ctx->vertex_constant_snapshot=NULL;
   ctx->vertex_constant_size=0;ctx->vertex_constant_offset=0;
  }
#ifdef REMESA_WITH_NIR
  if(!empty&&shader==PIPE_SHADER_VERTEX&&!slot) {
   int error=ENOTSUP;
   /* The complete state records declare9 or10 float4 vectors. This is
    * binding capacity, not the amount a particular shader reads. */
   if(buffer->buffer_size==144u||buffer->buffer_size==160u||
      (hre_gles_lab(s(p->screen))&&buffer->buffer_size>=4u&&
       buffer->buffer_size<=256u&&!(buffer->buffer_size&3u))) {
    if(buffer->buffer&&!buffer->user_buffer) {
     struct pipe_resource *b=buffer->buffer;
     if(b->screen==p->screen&&b->target==PIPE_BUFFER&&(b->bind&PIPE_BIND_CONSTANT_BUFFER)&&
        buffer->buffer_offset<=r(b)->bytes&&buffer->buffer_size<=r(b)->bytes-buffer->buffer_offset&&
        !(buffer->buffer_offset&15u)) {
      remesa_resource_reference(&ctx->vertex_constants,b);
      ctx->vertex_constant_offset=buffer->buffer_offset;error=0;
     }
    } else if(buffer->user_buffer&&!buffer->buffer&&!buffer->buffer_offset) {
     ctx->vertex_constant_snapshot=malloc(buffer->buffer_size);
     if(!ctx->vertex_constant_snapshot)error=ENOMEM;
     else {memcpy(ctx->vertex_constant_snapshot,buffer->user_buffer,buffer->buffer_size);error=0;}
    }
   }
   if(error)ctx->constant_rejections[index]|=1u<<slot;
   else {ctx->vertex_constant_size=buffer->buffer_size;ctx->constant_rejections[index]&=~(1u<<slot);}
   ctx->error=error;
  } else if(!empty&&shader==PIPE_SHADER_FRAGMENT&&!slot) {
   int error=ENOTSUP;
   if(buffer->buffer_size>=16&&buffer->buffer_size<=REMESA_UNIFORM_BYTES_MAX) {
    if(buffer->buffer&&!buffer->user_buffer) {
     struct pipe_resource *b=buffer->buffer;
     if(b->screen==p->screen&&b->target==PIPE_BUFFER&&(b->bind&PIPE_BIND_CONSTANT_BUFFER)&&
        buffer->buffer_offset<=r(b)->bytes&&buffer->buffer_size<=r(b)->bytes-buffer->buffer_offset&&
        !(buffer->buffer_offset&15u)) {
      remesa_resource_reference(&ctx->fragment_constants,b);
      ctx->constant_offset=buffer->buffer_offset;error=0;
     }
    } else if(buffer->user_buffer&&!buffer->buffer&&!buffer->buffer_offset) {
     ctx->constant_snapshot=malloc(buffer->buffer_size);
     if(!ctx->constant_snapshot)error=ENOMEM;
     else {memcpy(ctx->constant_snapshot,buffer->user_buffer,buffer->buffer_size);error=0;}
    }
   }
   if(error)ctx->constant_rejections[index]|=1u<<slot;
   else {ctx->constant_size=buffer->buffer_size;ctx->constant_rejections[index]&=~(1u<<slot);}
   ctx->error=error;
  } else
#endif
  if(!empty){ctx->constant_rejections[index]|=1u<<slot;ctx->error=ENOTSUP;}
  else {ctx->constant_rejections[index]&=~(1u<<slot);ctx->error=0;}
 }
 /* Rejected bindings still consume an explicitly transferred reference. */
 remesa_resource_reference(&owned,NULL);
 remesa_resource_reference(&incoming,NULL);
}
#ifdef REMESA_WITH_NIR
/* Specialize the existing constant fragment profile from synchronized CPU
 * bytes. This is not a GPU UBO instruction or a general shader compiler. */
static int fragment_color(struct pipe_context *p,uint32_t *argb)
{
 struct context *ctx=c(p);struct fragment *f=ctx->bound_fragment;
 /* Offline varying compilation is not a constant-color draw contract. */
 if(f&&!f->uses_uniform&&f->program.status==REMESA_PROGRAM_COMPILE_OFFLINE)return ENOTSUP;
 if(!f||!f->uses_uniform){*argb=ctx->argb;return 0;}
 if(!ctx->constant_size)return ENODATA;
 if(!ctx->fragment_constants)
  return remesa_uniform_color_resolve(&f->uniform,ctx->constant_snapshot,ctx->constant_size,argb);
 struct resource *b=r(ctx->fragment_constants);void *bytes=NULL;
 if(b->maps)return EBUSY;
 int error=resource_sync(p->screen,b,UINT64_MAX);if(error)return error;
 error=resource_map_backing(p->screen,b,false,&bytes);
 if(error){if(bytes)resource_unmap_backing(p->screen,b,false);return error;}
 error=bytes ? remesa_uniform_color_resolve(&f->uniform,(unsigned char *)bytes+ctx->constant_offset,
                                          ctx->constant_size,argb) : EPROTO;
 resource_unmap_backing(p->screen,b,false);return error;
}
#endif
int remesa_context_vertex_parameter_source(struct pipe_context *p,
 const struct remesa_pds_parameter_source_request *request,void *out,size_t capacity,size_t *written)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!request||
    (uintptr_t)request%_Alignof(struct remesa_pds_parameter_source_request)||
    sizeof(*request)>UINTPTR_MAX-(uintptr_t)request||
    !context_output_valid(c(p),out,capacity)||
    !context_output_valid(c(p),written,sizeof(*written)))return EINVAL;
 struct context *ctx=c(p);struct vertex *v=ctx->bound_vertex;
 if(!v||v->deleted||remesa_shader_ir_gears_vertex(&v->program.semantic)||
    ctx->invalid_constants||ctx->constant_rejections[0])return ENOTSUP;
 const unsigned coefficients=v->program.semantic.instructions[0].bits[0]*4u;
 if(request->coefficient_dwords!=coefficients||request->transfer_dwords!=((coefficients+4u)&~3u))return ENOTSUP;
 if(!ctx->vertex_constant_size)return ENODATA;
 if(ctx->vertex_constant_size<coefficients*4u)return ENOSPC;
 if(!ctx->vertex_constants)
  return remesa_pds_structure_encode_parameter_source(request,ctx->vertex_constant_snapshot,
   coefficients*4u,out,capacity,written);
 struct resource *b=r(ctx->vertex_constants);void *bytes=NULL;
 if(b->maps)return EBUSY;
 int error=resource_sync(p->screen,b,UINT64_MAX);if(error)return error;
 error=resource_map_backing(p->screen,b,false,&bytes);
 if(error){if(bytes)resource_unmap_backing(p->screen,b,false);return error;}
 error=bytes?remesa_pds_structure_encode_parameter_source(request,
  (unsigned char *)bytes+ctx->vertex_constant_offset,coefficients*4u,out,capacity,written):EPROTO;
 resource_unmap_backing(p->screen,b,false);return error;
#else
 (void)p;(void)request;(void)out;(void)capacity;(void)written;return ENOTSUP;
#endif
}

int remesa_context_prepare_vertex_parameters(struct pipe_context *p,uint32_t bank,void **out)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!out||(uintptr_t)out%_Alignof(void *)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->device.resource_only_backend||sc->gears_runtime)return ENOTSUP;
 int e=remesa_persistent_shader_output_check(&sc->device,out,sizeof(*out));if(e)return e;
 if(*out)return EBUSY;
 uint32_t offset;e=remesa_use_base_offset(bank,&offset);if(e)return e;
 struct vertex *v=ctx->bound_vertex;
 if(!v||v->deleted||remesa_shader_ir_gears_vertex(&v->program.semantic))return ENOTSUP;
 const uint32_t count=v->program.semantic.instructions[0].bits[0]*4u,transfer=(count+4u)&~3u;
 const struct remesa_pds_parameter_source_request request={0x20000000,4096,0,count,transfer};
 uint8_t source[176];size_t written;
 e=remesa_context_vertex_parameter_source(p,&request,source,sizeof source,&written);if(e)return e;
 if(written!=transfer*4u||count>40)return EPROTO;
 uint32_t coefficients[40];
 for(unsigned i=0;i<count;i++)coefficients[i]=(uint32_t)source[4+4*i]|
  (uint32_t)source[5+4*i]<<8|(uint32_t)source[6+4*i]<<16|(uint32_t)source[7+4*i]<<24;
 return remesa_persistent_vertex_parameter_block_prepare(&sc->device,coefficients,count,transfer,bank,out);
#else
 (void)p;(void)bank;(void)out;return ENOTSUP;
#endif
}
int remesa_context_gears_geometry_snapshot(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 struct remesa_gears_geometry **out)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!info||!draw_info||
    !context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct vertex *v=ctx->bound_vertex;struct elements *e=ctx->bound_elements;
 if(s(p->screen)->closing)return ESHUTDOWN;
 if(!v||v->deleted||remesa_shader_ir_gears_vertex(&v->program.semantic)||
    !e||e->deleted||ctx->invalid_elements)return ENOTSUP;
 unsigned attr=v->program.semantic.instructions[0].input_slot;
 if(attr>1||e->count!=1+attr)return ENOTSUP;
 struct pipe_vertex_buffer *vb[3]={&ctx->vb,&ctx->second_vb,&ctx->third_vb};
 const struct pipe_vertex_element *element[2]={&e->position,&e->normal};
 struct resource *resources[3]={0};void *bytes[3]={0};bool mapped[3]={0};
 unsigned resource_count=0,slot[2]={0},index_slot=0;
 int error=0;
 for(unsigned a=0;a<1+attr;a++) {
  unsigned b=element[a]->vertex_buffer_index;
  if(b>=ctx->vb_count||!vb[b]->buffer.resource)return ENODATA;
  struct resource *res=r(vb[b]->buffer.resource);unsigned j;
  for(j=0;j<resource_count&&resources[j]!=res;j++);
  if(j==resource_count)resources[resource_count++]=res;
  slot[a]=j;
 }
 if(info->index_size&&!info->has_user_indices) {
  struct pipe_resource *ib=info->index.resource;
  if(!ib||ib->screen!=p->screen||ib->target!=PIPE_BUFFER||!(ib->bind&PIPE_BIND_INDEX_BUFFER))return EINVAL;
  unsigned j;for(j=0;j<resource_count&&resources[j]!=r(ib);j++);
  if(j==resource_count)resources[resource_count++]=r(ib);
  index_slot=j;
 }
 /* Reject output aliases before inspecting its previous reference or mapping. */
 for(unsigned j=0;j<resource_count;j++) {
  uintptr_t x=(uintptr_t)out,y=(uintptr_t)resources[j];
  if(x<y+sizeof(*resources[j])&&y<x+sizeof(*out))return EINVAL;
  if(resources[j]->maps)return EBUSY;
 }
 if(*out)return EBUSY;
 for(unsigned j=0;j<resource_count;j++) {
  error=resource_sync(p->screen,resources[j],UINT64_MAX);if(error)goto done;
 }
 for(unsigned j=0;j<resource_count;j++) {
  error=resource_map_backing(p->screen,resources[j],false,&bytes[j]);
  mapped[j]=!error||bytes[j];if(error)goto done;
  if(!bytes[j]){error=EPROTO;goto done;}
 }
 struct remesa_gears_attribute attributes[2]={{0}};
 for(unsigned a=0;a<1+attr;a++) {
  const struct pipe_vertex_element *el=element[a];unsigned b=el->vertex_buffer_index;
  attributes[a]=(struct remesa_gears_attribute){bytes[slot[a]],resources[slot[a]]->bytes,
   (uint64_t)vb[b]->buffer_offset+el->src_offset,el->src_stride,el->src_format};
 }
 const void *indices=NULL;size_t index_bytes=0;
 if(info->index_size) {
  if(info->has_user_indices) {
   uint64_t n=((uint64_t)draw_info->start+draw_info->count-draw_info->count%3)*info->index_size;
   if(n>SIZE_MAX){error=EOVERFLOW;goto done;}
   indices=info->index.user;index_bytes=(size_t)n;
  } else {indices=bytes[index_slot];index_bytes=resources[index_slot]->bytes;}
 }
 error=remesa_gears_geometry_create(info,draw_info,attr,&attributes[0],attr?&attributes[1]:NULL,
                                   indices,index_bytes,out);
done:
 for(unsigned j=resource_count;j>0;j--)if(mapped[j-1])
  resource_unmap_backing(p->screen,resources[j-1],false);
 return error;
#else
 (void)p;(void)info;(void)draw_info;(void)out;return ENOTSUP;
#endif
}
static int context_vertex_inputs_snapshot(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 bool tex0,struct remesa_linked_vertex_inputs **out)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!info||!draw_info||
    !context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 uintptr_t at=(uintptr_t)out;
 if(sizeof(*info)>UINTPTR_MAX-(uintptr_t)info||sizeof(*draw_info)>UINTPTR_MAX-(uintptr_t)draw_info||
    (at<(uintptr_t)info+sizeof(*info)&&(uintptr_t)info<at+sizeof(*out))||
    (at<(uintptr_t)draw_info+sizeof(*draw_info)&&(uintptr_t)draw_info<at+sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct remesa_shader_linkage link;
 int error=remesa_context_shader_linkage_snapshot(p,&link);if(error)return error;
 const unsigned attribute_count=tex0?2:3;
 if(tex0){
  if(remesa_shader_ir_position_tex0_vertex(&link.vertex.semantic)||
     remesa_shader_ir_fragment_texture2d(&link.fragment.semantic)||
     link.vertex_layout.input_count!=2||link.vertex_layout.stride_dwords!=6)return ENOTSUP;
 }else if(remesa_shader_ir_white_lambert(&link.vertex.semantic)||link.vertex_layout.input_count!=3||
    link.vertex_layout.stride_dwords!=12)return ENOTSUP;
 struct elements *el=ctx->bound_elements;
 if(!el||el->deleted||ctx->invalid_elements||el->count!=attribute_count)return ENOTSUP;
 if(info->start_instance||info->instance_count>1||
    (info->index_size&&info->primitive_restart))return ENOTSUP;
 if(info->mode!=MESA_PRIM_TRIANGLES&&info->mode!=MESA_PRIM_TRIANGLE_STRIP&&info->mode!=MESA_PRIM_TRIANGLE_FAN)return ENOTSUP;
 if(!info->instance_count)return ENODATA;
 struct remesa_linked_topology topology;
 error=remesa_linked_topology_prepare(info->mode,draw_info->count,&topology);if(error)return error;
 const uint32_t count=topology.input_count;
 struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if(info->mode!=MESA_PRIM_TRIANGLES&&(!raster||raster->deleted||ctx->invalid_fixed[FIXED_RASTER]))return ENODATA;
 if(info->index_size&&info->index_size!=1&&info->index_size!=2&&info->index_size!=4)return EINVAL;
 size_t user_index_bytes=0;
 if(info->index_size&&info->has_user_indices){
  uint64_t n=((uint64_t)draw_info->start+count)*info->index_size;
  uintptr_t base=(uintptr_t)info->index.user;
  if(n>SIZE_MAX)return EOVERFLOW;
  if(!base||n>UINTPTR_MAX-base||
     (at<base+n&&base<at+sizeof(*out)))return EINVAL;
  user_index_bytes=(size_t)n;
 }
 struct pipe_vertex_buffer *vb[3]={&ctx->vb,&ctx->second_vb,&ctx->third_vb};
 const struct pipe_vertex_element *element[3]={&el->position,&el->normal,&el->light};
 struct resource *resources[4]={0};void *bytes[4]={0};bool mapped[4]={0};
 unsigned resource_count=0,slot[3]={0},index_slot=0;
 for(unsigned a=0;a<attribute_count;a++){
  if(link.vertex_layout.input_slot[a]!=a||element[a]->src_format!=(tex0&&a==1?PIPE_FORMAT_R32G32_FLOAT:PIPE_FORMAT_R32G32B32A32_FLOAT))return ENOTSUP;
  unsigned b=element[a]->vertex_buffer_index;
  if(b>=3||b>=ctx->vb_count||!vb[b]->buffer.resource)return ENODATA;
  struct resource *res=r(vb[b]->buffer.resource);unsigned j;
  for(j=0;j<resource_count&&resources[j]!=res;j++);
  if(j==resource_count)resources[resource_count++]=res;
  slot[a]=j;
 }
 if(info->index_size&&!info->has_user_indices){
  struct pipe_resource *ib=info->index.resource;
  if(!ib||ib->screen!=p->screen||ib->target!=PIPE_BUFFER||!(ib->bind&PIPE_BIND_INDEX_BUFFER))return EINVAL;
  unsigned j;for(j=0;j<resource_count&&resources[j]!=r(ib);j++);
  if(j==resource_count)resources[resource_count++]=r(ib);
  index_slot=j;
 }
 for(unsigned j=0;j<resource_count;j++){
  uintptr_t res=(uintptr_t)resources[j];
  if(at<res+sizeof(*resources[j])&&res<at+sizeof(*out))return EINVAL;
  if(resources[j]->maps)return EBUSY;
 }
 if(*out)return EBUSY;
 for(unsigned j=0;j<resource_count;j++){
  error=resource_sync(p->screen,resources[j],UINT64_MAX);if(error)goto done;
 }
 for(unsigned j=0;j<resource_count;j++){
  error=resource_map_backing(p->screen,resources[j],false,&bytes[j]);
  mapped[j]=!error||bytes[j];if(error)goto done;
  if(!bytes[j]){error=EPROTO;goto done;}
 }
 struct remesa_linked_attribute attributes[3];
 for(unsigned a=0;a<attribute_count;a++){
  unsigned b=element[a]->vertex_buffer_index;
  attributes[a]=(struct remesa_linked_attribute){bytes[slot[a]],resources[slot[a]]->bytes,
   (uint64_t)vb[b]->buffer_offset+element[a]->src_offset,element[a]->src_stride,element[a]->src_format};
 }
 const void *indices=NULL;size_t index_bytes=0;
 if(info->index_size){
  if(info->has_user_indices){
   indices=info->index.user;index_bytes=user_index_bytes;
  }else{indices=bytes[index_slot];index_bytes=resources[index_slot]->bytes;}
 }
 error=tex0?remesa_tex0_vertex_inputs_create_topology(info,draw_info,attributes,indices,index_bytes,
                                                    raster&&raster->flat_first,out):
  remesa_linked_vertex_inputs_create_topology(info,draw_info,attributes,indices,index_bytes,
                                            raster&&raster->flat_first,out);
done:
 for(unsigned j=resource_count;j>0;j--)if(mapped[j-1])
  resource_unmap_backing(p->screen,resources[j-1],false);
 return error;
#else
 (void)p;(void)info;(void)draw_info;(void)tex0;(void)out;return ENOTSUP;
#endif
}

/* Conservative execution domain for the first ordinary matrix draw. These
 * are bounds checks only: no transformed vertex is produced or uploaded.
 * Affine coefficients<=1, translation<=0.5 and POSITION.xyz<=1 are checked
 * with outward integer row bounds <=(7/8)*W, for constant positive W1/W2.
 * Perspective uses signed outward Q20 intervals, 1/8<=W<=4, and the same
 * strict clip margin. Geometry requiring clipping still refuses. This is not the old
 * byte-exact LAB witness or its admission recipe. */
#ifdef REMESA_WITH_NIR
static int native_draw_input_domain(const struct remesa_gears_geometry_view *view,
 const unsigned char source[160])
{
 if(view->stride_dwords!=8||!view->vertices||!view->vertex_count||view->vertex_count>65535||
    view->bytes!=(uint64_t)view->vertex_count*32)return ENOTSUP;
 return remesa_matrix_draw_values(view->vertices,view->bytes,view->vertex_count,32,source+4,144);
}
#endif
int remesa_context_linked_vertex_inputs_snapshot(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 struct remesa_linked_vertex_inputs **out)
{return context_vertex_inputs_snapshot(p,info,draw_info,false,out);}
int remesa_context_tex0_vertex_inputs_snapshot(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 struct remesa_linked_vertex_inputs **out)
{return context_vertex_inputs_snapshot(p,info,draw_info,true,out);}
static int context_prepare_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,bool gears,bool homogeneous,bool normal,
 struct remesa_scene_capture *out)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!info||!draw_info||!options||!out||
    (uintptr_t)options%_Alignof(struct remesa_linked_scene_request)||
    (uintptr_t)out%_Alignof(struct remesa_scene_capture)||
    !context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(gears&&(!context_state_output_valid(ctx,out,sizeof(*out))||
    !context_state_output_valid(ctx,options,sizeof(*options))||
    !context_state_output_valid(ctx,info,sizeof(*info))||
    !context_state_output_valid(ctx,draw_info,sizeof(*draw_info))))return EINVAL;
 if(!context_output_valid(ctx,options,sizeof(*options))||
    !context_output_valid(ctx,info,sizeof(*info))||!context_output_valid(ctx,draw_info,sizeof(*draw_info)))return EINVAL;
 uintptr_t at=(uintptr_t)out;
 if(sizeof(*info)>UINTPTR_MAX-(uintptr_t)info||sizeof(*draw_info)>UINTPTR_MAX-(uintptr_t)draw_info||
    (at<(uintptr_t)info+sizeof(*info)&&(uintptr_t)info<at+sizeof(*out))||
    (at<(uintptr_t)draw_info+sizeof(*draw_info)&&(uintptr_t)draw_info<at+sizeof(*out)))return EINVAL;
 if(info->index_size&&info->has_user_indices){
  if(info->index_size!=1&&info->index_size!=2&&info->index_size!=4)return EINVAL;
  uint64_t n=((uint64_t)draw_info->start+draw_info->count)*info->index_size;
  uintptr_t base=(uintptr_t)info->index.user;
  if(!base||n>UINTPTR_MAX-base||(at<base+n&&base<at+sizeof(*out)))return EINVAL;
 }
 if(sizeof(*options)>UINTPTR_MAX-(uintptr_t)options||
    (at<(uintptr_t)options+sizeof(*options)&&(uintptr_t)options<at+sizeof(*out)))return EINVAL;
 if(sc->closing)return ESHUTDOWN;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct remesa_linked_scene_request requested=*options;
 const struct remesa_linked_geometry_input *g=&requested.geometry;
 if(requested.color||requested.depth||requested.width||requested.height||requested.color_pitch||requested.linkage||
    g->vertices||g->vertex_bytes||g->vertex_count||g->indices||g->index_bytes||g->index_count)return EINVAL;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 struct pipe_resource *output_owners[]={ctx->target,ctx->depth_target,ctx->vb.buffer.resource,
  ctx->second_vb.buffer.resource,ctx->third_vb.buffer.resource,
  info->index_size&&!info->has_user_indices?info->index.resource:NULL};
 for(unsigned i=0;i<sizeof(output_owners)/sizeof(output_owners[0]);i++)if(output_owners[i]){
  uintptr_t base=(uintptr_t)output_owners[i];
  if(sizeof(struct resource)>UINTPTR_MAX-base||
     (at<base+sizeof(struct resource)&&base<at+sizeof(*out)))return EINVAL;
 }
 if(color->maps||depth->maps)return EBUSY;
 if(!normal&&(color->has_contents||depth->has_contents))return ENOTSUP;
 bool preserve_depth=normal&&!ctx->native_clear_color&&!ctx->native_clear_depth;
 if(normal&&(!sc->native_draws||
    (preserve_depth?(!sc->native_preserve_candidate||!ctx->native_content_expected):
     (ctx->native_clear_color!=ctx->target||ctx->native_clear_depth!=ctx->depth_target))))return ENOTSUP;
 if(out->owner||out->serial||out->slot||out->reserved)return EBUSY;
 if(homogeneous){
  if(!gears)return EINVAL;
  /* This mode obtains its coordinate/ISP contract from the bound context.
   * Never let manual options disagree with the live fixed/viewport state. */
  const struct remesa_isp_opaque_triangle_request *isp=&requested.state.isp;
  const struct remesa_ta_window_viewport_request *v=&requested.state.viewport;
  if(isp->depth_bits_present||isp->depth_test||isp->depth_write||isp->compare||isp->rgba_mask||
     v->framebuffer_width||v->framebuffer_height||v->x||v->y||v->width||v->height||
     v->depth_bits||v->near_z!=0||v->far_z!=0||v->path)return EINVAL;
  int state_error=remesa_context_linked_isp_snapshot(p,&requested.state.isp);
  if(state_error)return state_error;
  state_error=window_viewport_request(ctx,24,&requested.state.viewport);
  if(state_error)return state_error;
 }
 if(homogeneous){
  if((color->native_clear_owner&&color->native_clear_owner!=ctx)||
     (depth->native_clear_owner&&depth->native_clear_owner!=ctx)||
     (ctx->native_clear_color&&ctx->native_clear_color!=ctx->target)||
     (ctx->native_clear_depth&&ctx->native_clear_depth!=ctx->depth_target))return EBUSY;
  if(depth->native_clear_owner&&requested.clear_depth!=1.0)return ENOTSUP;
 }
 int error=homogeneous?resource_sync_writer(p->screen,color,UINT64_MAX):resource_sync(p->screen,color,UINT64_MAX);if(error)return error;
 error=homogeneous?resource_sync_writer(p->screen,depth,UINT64_MAX):resource_sync(p->screen,depth,UINT64_MAX);if(error)return error;
 if(preserve_depth){
  struct remesa_pass_snapshot current[2];
  error=remesa_render_pass_snapshot(&color->pass,&current[0]);if(error)return error;
  error=remesa_render_pass_snapshot(&depth->pass,&current[1]);if(error)return error;
  const struct remesa_pass_snapshot *expected[2]={&ctx->native_color_expected,&ctx->native_depth_expected};
  for(unsigned i=0;i<2;i++)if(current[i].content!=REMESA_PASS_PRESENT||
    current[i].resource_cookie!=expected[i]->resource_cookie||
    current[i].content_epoch!=expected[i]->content_epoch)return ESTALE;
 }
 /* Publish only the driver-owned upload-manager writes. External map leases
  * remain live and retain the existing global pre-GPU mapping refusal. Caller
  * inputs/outputs were checked against all mapped/staging spans before this
  * can invalidate a driver-owned transfer. */
 if(gears){
  if(p->stream_uploader)u_upload_unmap(p->stream_uploader);
  if(p->const_uploader&&p->const_uploader!=p->stream_uploader)u_upload_unmap(p->const_uploader);
 }
 struct remesa_shader_linkage link;error=remesa_context_shader_linkage_snapshot(p,&link);if(error)return error;
 if(gears){
  struct remesa_shader_selected_resources resources;
  error=remesa_shader_program_gears_attribute_resources(&link.vertex,&resources);if(error)return error;
  if(!sc->device.resource_only_backend||sc->gears_runtime)return ENOTSUP;
  struct remesa_gears_geometry *geometry=NULL;void *parameters=NULL;uint8_t *packed=NULL;
  error=remesa_context_gears_geometry_snapshot(p,info,draw_info,&geometry);if(error)return error;
  struct remesa_gears_geometry_view view;
  error=remesa_gears_geometry_inspect(geometry,&view);if(error)goto gears_done;
  if(normal){
   const struct remesa_ta_window_viewport_request *v=&requested.state.viewport;
   const struct remesa_pds_parameter_source_request q={0x20000000,4096,0,36,40};
   unsigned char source[160];size_t written=0;
   if(!homogeneous||v->x||v->y||v->width!=v->framebuffer_width||v->height!=v->framebuffer_height||
      v->near_z!=0||v->far_z!=1||v->depth_bits!=24){error=ENOTSUP;goto gears_done;}
   error=remesa_context_vertex_parameter_source(p,&q,source,sizeof source,&written);
   if(!error&&written!=sizeof source)error=EPROTO;
   if(!error)error=native_draw_input_domain(&view,source);
   if(error)goto gears_done;
  }
  if(ctx->homogeneous_api_lab){
   const struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
   const struct remesa_ta_window_viewport_request *v=&requested.state.viewport;
   const struct remesa_isp_opaque_triangle_request *isp=&requested.state.isp;
   if(!homogeneous||ctx->homogeneous_api_lab!=REMESA_HOMOGENEOUS_API_W2_CLAMPED||
      !raster||ctx->invalid_fixed[FIXED_RASTER]||!raster->native_w2_raster||
      remesa_shader_ir_gears_vertex_clamped(&link.vertex.semantic)||
      remesa_shader_ir_fragment_color_input(&link.fragment.semantic)||
      requested.clear_depth!=1||ctx->native_clear_color!=ctx->target||
      ctx->native_clear_depth!=ctx->depth_target||
      v->x||v->y||v->width!=v->framebuffer_width||v->height!=v->framebuffer_height||
      v->depth_bits!=24||v->near_z!=0||v->far_z!=1||v->path!=REMESA_TA_VIEWPORT_MATRIX_WINDOW||
      !isp->depth_bits_present||!isp->depth_test||!isp->depth_write||
      isp->compare!=REMESA_DEPTH_LESS||isp->rgba_mask!=15){error=ENOTSUP;goto gears_done;}
   /* Authenticate the finite clip/edge recipe before allocating native
    * program/parameter/geometry owners. This does not evaluate vertices. */
   const struct remesa_pds_parameter_source_request source_request={0x20000000,4096,0,36,40};
   uint8_t source[160];size_t written=0;
   error=remesa_context_vertex_parameter_source(p,&source_request,source,sizeof source,&written);
   if(error)goto gears_done;
   if(written!=sizeof source){error=EPROTO;goto gears_done;}
   error=remesa_admit_homogeneous_w2_inputs(view.vertices,view.bytes,source+4,144,
    ctx->target->width0,ctx->target->height0);if(error)goto gears_done;
  }
  if(view.normal_from_attribute!=1||view.stride_dwords!=8||!view.vertex_count||view.vertex_count>65535||
     view.bytes!=(size_t)view.vertex_count*32){error=ENOTSUP;goto gears_done;}
  packed=calloc(view.vertex_count,48);if(!packed){error=ENOMEM;goto gears_done;}
  /* The established snapshot already expands the selected index window.
   * Preserve P/N bits and initialize the unconsumed third float4. No vertex,
   * matrix, lighting or pixel arithmetic takes place on the CPU. */
  for(uint32_t i=0;i<view.vertex_count;i++)memcpy(packed+(size_t)i*48,(const uint8_t *)view.vertices+(size_t)i*32,32);
  error=remesa_context_prepare_vertex_parameters(p,requested.vertex_bank,&parameters);if(error)goto gears_done;
  struct remesa_linked_scene_request request=requested;
  request.color=color->bo;request.depth=depth->bo;request.width=ctx->target->width0;
  request.height=ctx->target->height0;request.color_pitch=color->stride/4;request.linkage=&link;
  request.geometry=(struct remesa_linked_geometry_input){.vertices=packed,.vertex_bytes=(size_t)view.vertex_count*48,.vertex_count=view.vertex_count};
  error=preserve_depth?remesa_persistent_gears_homogeneous_preserve_scene_prepare(&sc->device,&request,parameters,out):
   homogeneous?remesa_persistent_gears_homogeneous_scene_prepare(&sc->device,&request,parameters,out):
   remesa_persistent_gears_attribute_scene_prepare(&sc->device,&request,parameters,out);
 gears_done:
  if(parameters)sc->device.ops->destroy_bo(sc->device.priv,parameters);
  free(packed);remesa_gears_geometry_destroy(geometry);return error;
 }
 struct remesa_linked_vertex_inputs *owned=NULL;
 error=remesa_context_linked_vertex_inputs_snapshot(p,info,draw_info,&owned);if(error)return error;
 struct remesa_linked_vertex_inputs_view view;
 error=remesa_linked_vertex_inputs_inspect(owned,&view);
 if(!error){
  struct remesa_linked_scene_request request=requested;
  request.color=color->bo;request.depth=depth->bo;request.width=ctx->target->width0;
  request.height=ctx->target->height0;request.color_pitch=color->stride/4;request.linkage=&link;
  request.geometry=(struct remesa_linked_geometry_input){.vertices=view.vertices,.vertex_bytes=view.vertex_bytes,
   .vertex_count=view.vertex_count,.indices=view.indices,.index_count=view.index_count,.index_bytes=view.index_bytes};
  error=sc->device.ops->prepare_linked_scene(&sc->device,&request,out);
 }
 remesa_linked_vertex_inputs_destroy(owned);return error;
#else
(void)p;(void)info;(void)draw_info;(void)options;(void)gears;(void)homogeneous;(void)normal;(void)out;return ENOTSUP;
#endif
}
static int captured_scene_error(struct context *,int);
/* Shared body of cold sampled scene preparation. `replacement` skips only the
 * fresh-attachment refusal: graph replacement re-prepares over the same
 * already-written attachments still owned by the graph being replaced, after
 * the caller proves that ownership. Every other validation, snapshot and
 * failure cleanup step is identical. */
static int context_prepare_texture_scene_internal(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct remesa_scene_capture *out,
 bool replacement)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!info||!draw_info||!options||!out||
    (uintptr_t)out%_Alignof(struct remesa_scene_capture)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 uintptr_t at=(uintptr_t)out;
 const void *inputs[]={info,draw_info,options};
 const size_t lengths[]={sizeof(*info),sizeof(*draw_info),sizeof(*options)};
 for(unsigned i=0;i<3;i++){
  uintptr_t base=(uintptr_t)inputs[i];
  if(lengths[i]>UINTPTR_MAX-base||(at<base+lengths[i]&&base<at+sizeof(*out)))return EINVAL;
 }
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 int error=remesa_persistent_shader_output_check(&sc->device,out,sizeof(*out));if(error)return error;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct remesa_linked_scene_request request=*options;
 const struct remesa_linked_geometry_input *g=&request.geometry;
 const struct remesa_isp_opaque_triangle_request *isp=&request.state.isp;
 const struct remesa_ta_window_viewport_request *v=&request.state.viewport;
 if(request.color||request.depth||request.width||request.height||request.color_pitch||request.linkage||
    g->vertices||g->indices||g->vertex_bytes||g->index_bytes||g->vertex_count||g->index_count||
    isp->depth_bits_present||isp->depth_test||isp->depth_write||isp->compare||isp->rgba_mask||
    v->framebuffer_width||v->framebuffer_height||v->x||v->y||v->width||v->height||v->depth_bits||
    v->near_z!=0||v->far_z!=0||v->path)return EINVAL;
 if(out->owner||out->serial||out->slot||out->reserved)return EBUSY;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 /* Replacement re-prepares over attachments whose written contents belong to
  * the owned graph being replaced; ordinary preparation stays fresh-only. */
 if(!replacement&&(color->has_contents||depth->has_contents))return ENOTSUP;
 const struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if(!raster||raster->deleted||ctx->invalid_fixed[FIXED_RASTER]||
    raster->scissor||raster->cull_face||raster->flat)return ENOTSUP;
 error=remesa_context_linked_isp_snapshot(p,&request.state.isp);if(error)return error;
 error=window_viewport_request(ctx,24,&request.state.viewport);if(error)return error;
 request.color=color->bo;request.depth=depth->bo;request.width=ctx->target->width0;
 request.height=ctx->target->height0;request.color_pitch=color->stride/4;
 error=resource_sync(p->screen,color,UINT64_MAX);if(error)return captured_scene_error(ctx,error);
 error=resource_sync(p->screen,depth,UINT64_MAX);if(error)return captured_scene_error(ctx,error);
 if(p->stream_uploader)u_upload_unmap(p->stream_uploader);
 if(p->const_uploader&&p->const_uploader!=p->stream_uploader)u_upload_unmap(p->const_uploader);
 struct remesa_shader_linkage link;
 error=remesa_context_shader_linkage_snapshot(p,&link);if(error)return error;
 struct remesa_linked_vertex_inputs *owned=NULL;
 error=remesa_context_tex0_vertex_inputs_snapshot(p,info,draw_info,&owned);if(error)return error;
 struct remesa_linked_vertex_inputs_view vertices;
 void *code=NULL,*geometry=NULL,*pds=NULL;
 error=remesa_linked_vertex_inputs_inspect(owned,&vertices);if(error)goto done;
 const uint32_t banks[2]={request.vertex_bank,request.pixel_bank};
 error=remesa_persistent_linked_program_prepare(&sc->device,&link,banks,&code);if(error)goto done;
 const struct remesa_linked_geometry_input source={.vertices=vertices.vertices,.vertex_bytes=vertices.vertex_bytes,
  .vertex_count=vertices.vertex_count,.indices=vertices.indices,.index_bytes=vertices.index_bytes,.index_count=vertices.index_count};
 error=remesa_persistent_tex0_geometry_prepare(&sc->device,&source,&geometry);if(error)goto done;
 error=remesa_context_prepare_bound_texture_pds(p,code,geometry,&pds);if(error)goto done;
 error=remesa_persistent_texture_scene_prepare(&sc->device,&request,pds,out);
 done:
 if(pds)sc->device.ops->destroy_bo(sc->device.priv,pds);
 if(geometry)sc->device.ops->destroy_bo(sc->device.priv,geometry);
 if(code)sc->device.ops->destroy_bo(sc->device.priv,code);
 remesa_linked_vertex_inputs_destroy(owned);
 if(remesa_persistent_native_scene_ready(&sc->device)==EOWNERDEAD)error=EOWNERDEAD;
 return error?captured_scene_error(ctx,error):0;
#else
(void)p;(void)info;(void)draw_info;(void)options;(void)out;(void)replacement;return ENOTSUP;
#endif
}
int remesa_context_prepare_texture_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct remesa_scene_capture *out)
{return context_prepare_texture_scene_internal(p,info,draw_info,options,out,false);}
int remesa_context_prepare_linked_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct remesa_scene_capture *out)
{return context_prepare_scene(p,info,draw_info,options,false,false,false,out);}
int remesa_context_prepare_gears_attribute_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct remesa_scene_capture *out)
{return context_prepare_scene(p,info,draw_info,options,true,false,false,out);}
int remesa_context_prepare_gears_homogeneous_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct remesa_scene_capture *out)
{return context_prepare_scene(p,info,draw_info,options,true,true,false,out);}

static int context_issue_capture(struct pipe_context *p,struct remesa_scene_capture capture,
 bool keep,bool homogeneous,bool preserve_depth,struct pipe_fence_handle *f,struct pipe_fence_handle **out)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 struct remesa_render_pass cp=color->pass,zp=depth->pass;
 struct remesa_pass_ticket ct=color->ticket,zt=depth->ticket;
 enum remesa_pass_load load=preserve_depth?REMESA_PASS_PRESERVE:REMESA_PASS_DISCARD;
 /* Reserve both local attachment transitions as one transaction before
  * entering the transport. A failed second reservation cannot leave a
  * partially advanced first ticket, even on a subsequent release failure. */
 int error=remesa_render_pass_submit_pair(&cp,&zp,load,REMESA_PASS_STORE,
  sc->native_preserve_candidate,&ct,&zt);
 void *backend=NULL;
 if(!error)error=keep?remesa_persistent_scene_capture_submit_keep(&sc->device,capture,&backend):
  sc->device.ops->submit_linked_scene(&sc->device,capture,&backend);
 bool uncertain=error==EOWNERDEAD||(error&&backend)||(!error&&!backend);
 if(error&&!uncertain){
  int release=keep?0:sc->device.ops->release_linked_scene(&sc->device,capture);
  if(release){error=EOWNERDEAD;uncertain=true;}
  else {free(f);return error;}
 }
 if(uncertain){
  error=EOWNERDEAD;ctx->failed_submission=true;
  color->pass=cp;depth->pass=zp;color->ticket=ct;depth->ticket=zt;
  color->write_error=depth->write_error=error;
  (void)remesa_render_pass_fail(&color->pass,&color->ticket,error);
  (void)remesa_render_pass_fail(&depth->pass,&depth->ticket,error);
  if(backend)sc->device.ops->destroy_fence(sc->device.priv,backend);
  free(f);ctx->error=error;return error;
 }
 color->pass=cp;depth->pass=zp;color->ticket=ct;depth->ticket=zt;
 color->has_contents=depth->has_contents=true;
 f->refs=1;f->screen=sc;f->backend=backend;screen_hold(sc);
 fence_ref(p->screen,&color->writer,f);fence_ref(p->screen,&depth->writer,f);
 fence_ref(p->screen,&ctx->last,f);
 if(sc->native_draws&&homogeneous){
  /* Begin rejected epoch saturation. The next wait must authenticate actual
   * retirement before these expected content identities may be accepted. */
  ctx->native_color_expected=(struct remesa_pass_snapshot){cp.resource_cookie,cp.content_epoch+1,REMESA_PASS_PRESENT};
  ctx->native_depth_expected=(struct remesa_pass_snapshot){zp.resource_cookie,zp.content_epoch+1,REMESA_PASS_PRESENT};
  ctx->native_content_expected=true;
 }
 if(homogeneous)finish_native_clear(ctx,false);
 *out=f;return 0;
}
static int captured_scene_error(struct context *ctx,int error)
{
 if(error==EOWNERDEAD){
  ctx->failed_submission=true;ctx->error=error;
  if(ctx->target)r(ctx->target)->write_error=error;
  if(ctx->depth_target)r(ctx->depth_target)->write_error=error;
 }
 return error;
}
static void flush_frontbuffer(struct pipe_screen *screen,struct pipe_context *p,
 struct pipe_resource *resource,unsigned level,unsigned layer,void *drawable,
 unsigned nboxes,struct pipe_box *boxes)
{
 if(!p||p->screen!=screen||p->draw_vbo!=draw)return;
 struct context *ctx=c(p);struct screen *sc=s(screen);int error=EINVAL;
 if(sc->closing){ctx->error=ESHUTDOWN;return;}
 if(ctx->failed_submission){ctx->error=EOWNERDEAD;return;}
 if(ctx->publication_error){ctx->error=ctx->publication_error;return;}
 /* The private whole-frame gears queue has a separate frontend flush
  * contract; an older writer fence cannot attest unsubmitted batch work. */
 if(sc->gears_runtime){ctx->error=ENOTSUP;return;}
 if(sc->frontbuffer_busy||ctx->presenting){ctx->error=EBUSY;return;}
 if(!sc->frontbuffer.publish){ctx->error=ENOTSUP;return;}
 if(!resource||resource->screen!=screen||!drawable||level||layer||
    !color_storage_target(resource->target)||resource->format!=PIPE_FORMAT_B8G8R8A8_UNORM||
    !(resource->bind&PIPE_BIND_RENDER_TARGET)||!resource->width0||!resource->height0||resource->last_level||resource->nr_samples>1||
    resource->nr_storage_samples>1||resource->depth0!=1||resource->array_size!=1||
    (nboxes&&!boxes))goto done;
 for(unsigned i=0;i<nboxes;i++){
  const struct pipe_box *box=&boxes[i];
  if(box->x<0||box->y<0||box->z||box->width<0||box->height<0||box->depth!=1||
     (uint64_t)box->x+box->width>resource->width0||
     (uint64_t)box->y+box->height>resource->height0)goto done;
 }
 if(r(resource)->maps||r(resource)->native_clear_owner){error=EBUSY;goto done;}
 error=resource_sync_writer(screen,r(resource),0);
 if(error){error=captured_scene_error(ctx,error);goto done;}
 if(!r(resource)->has_contents){error=EAGAIN;goto done;}
 /* The CPU publisher receives only retired/published data. It must validate
  * its own drawable namespace and hold any queued snapshot through X ack.
  * Frontend/X errors alone are not GPU fence or address-space failures. */
 struct pipe_resource *held=NULL;remesa_resource_reference(&held,resource);
 sc->frontbuffer_busy=ctx->presenting=true;
 error=sc->frontbuffer.publish(sc->frontbuffer.user,p,resource,drawable,nboxes,boxes);
 sc->frontbuffer_busy=ctx->presenting=false;
 remesa_resource_reference(&held,NULL);
 if(error<0)error=EOWNERDEAD;
 if(ctx->failed_submission)error=EOWNERDEAD;
done:
 ctx->error=error;
}
int remesa_context_take_texture_scene(struct pipe_context *p,struct remesa_scene_capture *capture)
{
 if(!p||p->draw_vbo!=draw||!capture||(uintptr_t)capture%_Alignof(*capture)||
    !context_state_output_valid(c(p),capture,sizeof(*capture)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 int error=remesa_persistent_shader_output_check(&sc->device,capture,sizeof(*capture));if(error)return error;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(ctx->owned_texture_scene.owner)return EBUSY;
 if(!sc->texture_qualification||!ctx->target||!ctx->depth_target)return EOPNOTSUPP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 error=remesa_persistent_scene_capture_validate_attachments(&sc->device,*capture,color->bo,depth->bo,
  ctx->target->width0,ctx->target->height0);if(error)return captured_scene_error(ctx,error);
 error=remesa_persistent_scene_capture_take(&sc->device,*capture,ctx);
 if(error)return captured_scene_error(ctx,error);
 ctx->owned_texture_scene=*capture;*capture=(struct remesa_scene_capture){0};
 if(sc->hre){remesa_resource_reference(&ctx->hre_graph_color,ctx->target);
  remesa_resource_reference(&ctx->hre_graph_depth,ctx->depth_target);}
 return 0;
}
int remesa_context_release_texture_scene(struct pipe_context *p)
{
 if(!p||p->draw_vbo!=draw)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(!ctx->owned_texture_scene.owner)return 0;
 if(ctx->failed_submission)return EOWNERDEAD;
 struct pipe_resource *gc=sc->hre?ctx->hre_graph_color:ctx->target;
 struct pipe_resource *gd=sc->hre?ctx->hre_graph_depth:ctx->depth_target;
 if(!gc||!gd)return captured_scene_error(ctx,EOWNERDEAD);
 struct resource *color=r(gc),*depth=r(gd);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 int error=resource_sync_writer(p->screen,color,0);
 if(!error)error=resource_sync_writer(p->screen,depth,0);
 if(!error)error=remesa_persistent_scene_capture_release_owned(&sc->device,ctx->owned_texture_scene,ctx);
 if(error)return captured_scene_error(ctx,error);
 ctx->owned_texture_scene=(struct remesa_scene_capture){0};
 remesa_resource_reference(&ctx->hre_graph_color,NULL);
 remesa_resource_reference(&ctx->hre_graph_depth,NULL);
 ctx->texture_draw_state_valid=ctx->texture_draw_started=false;
 ctx->texture_replacement_pending=ctx->texture_graph_detached=false;return 0;
}
/* Transactional replacement of the context-owned sampled graph. The preflight
 * is conclusive and side-effect free; the replacement graph is prepared next
 * from the current bound state; the commit point is the authenticated CLOSE
 * of the old graph. A refused or uncertain CLOSE retains the old graph
 * (release_owned keeps it live) and the never-issued pending capture is
 * conclusively released; uncertainty poisons the context. A post-commit
 * failure leaves the context without a graph unless uncertainty retains it. */
int remesa_context_replace_texture_graph(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const uint64_t state[32])
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw||!info||!draw_info||!state)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 /* Preflight: nothing is modified before every conclusive check passes, so
  * any refusal here preserves the owned graph and its resources. */
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!ctx->owned_texture_scene.owner)return EINVAL;
 if(!ctx->texture_draw_state_valid||!ctx->texture_draw_started)return EBUSY;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 /* A zero-timeout wait retires a completed producer deterministically and
  * refuses a live writer without side effects; the owned graph survives. */
 int error=resource_sync_writer(p->screen,color,0);
 if(error)return (error==EAGAIN||error==ETIMEDOUT||error==EBUSY||error==EINTR)?EBUSY:captured_scene_error(ctx,error);
 error=resource_sync_writer(p->screen,depth,0);
 if(error)return (error==EAGAIN||error==ETIMEDOUT||error==EBUSY||error==EINTR)?EBUSY:captured_scene_error(ctx,error);
 /* Ownership proof: the owned graph must still authenticate both bound
  * attachments before any replacement object is prepared. */
 struct pipe_resource *gc=sc->hre?ctx->hre_graph_color:ctx->target;
 struct pipe_resource *gd=sc->hre?ctx->hre_graph_depth:ctx->depth_target;
 if(!gc||!gd)return captured_scene_error(ctx,EOWNERDEAD);
 if(r(gc)->maps||r(gd)->maps||r(gc)->native_clear_owner||r(gd)->native_clear_owner)return EBUSY;
 error=resource_sync_writer(p->screen,r(gc),0);
 if(!error)error=resource_sync_writer(p->screen,r(gd),0);
 if(error)return captured_scene_error(ctx,error);
 error=remesa_persistent_scene_capture_validate_attachments(&sc->device,
  ctx->owned_texture_scene,r(gc)->bo,r(gd)->bo,gc->width0,gc->height0);
 if(error)return captured_scene_error(ctx,error);
 /* Prepare the replacement first; prepare failure destroys its own objects
  * and leaves the owned graph untouched. */
 const struct remesa_linked_scene_request options={.vertex_bank=4,.pixel_bank=3,.state_bank=4,.clear_depth=1};
 struct remesa_scene_capture pending={0};
 const bool graph_lifetime=remesa_persistent_texture_graph_lifetime_ready(&sc->device)==0;
 if(graph_lifetime){
  if(!ctx->texture_graph_detached){
  error=remesa_persistent_scene_graph_drop(&sc->device,ctx->owned_texture_scene,ctx);
  if(error)return captured_scene_error(ctx,error);
  ctx->texture_graph_detached=true;
  }
  /* V3 freezes allocations while attached. Prepare the replacement only
   * after the retired old graph has been detached from the session. */
  error=context_prepare_texture_scene_internal(p,info,draw_info,&options,&pending,true);
  if(error){if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GRAPH_REPLACE_FAIL stage=prepare errno=%d\n",error);return error;}
  error=remesa_persistent_scene_capture_validate_attachments(&sc->device,pending,
   color->bo,depth->bo,ctx->target->width0,ctx->target->height0);
  if(!error)error=remesa_persistent_scene_capture_take(&sc->device,pending,ctx);
  if(error){
   int release=remesa_persistent_scene_capture_release(&sc->device,pending);
   if(release)error=EOWNERDEAD;
   return captured_scene_error(ctx,error);
  }
  error=remesa_persistent_scene_graph_replace(&sc->device,
   ctx->owned_texture_scene,pending,ctx);
  if(error){
   if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GRAPH_REPLACE_FAIL stage=bind errno=%d\n",error);
   if(error==EOWNERDEAD)ctx->failed_submission=true;
   else if(remesa_persistent_scene_capture_release_owned(&sc->device,pending,ctx))error=EOWNERDEAD;
   return captured_scene_error(ctx,error);
  }
  error=remesa_persistent_scene_capture_release_owned(&sc->device,ctx->owned_texture_scene,ctx);
  if(error){if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GRAPH_REPLACE_FAIL stage=release_old errno=%d\n",error);ctx->failed_submission=true;return captured_scene_error(ctx,error);}
  ctx->owned_texture_scene=pending;
  if(sc->hre){remesa_resource_reference(&ctx->hre_graph_color,ctx->target);
   remesa_resource_reference(&ctx->hre_graph_depth,ctx->depth_target);}
  ctx->texture_graph_detached=false;
 }else{
  error=context_prepare_texture_scene_internal(p,info,draw_info,&options,&pending,true);
  if(error)return error;
  /* Legacy persistent lifetime commits by closing the previous graph. */
  error=remesa_context_release_texture_scene(p);
  if(error){
   if(error!=EOWNERDEAD){
    int release=remesa_persistent_scene_capture_release(&sc->device,pending);
    if(release)error=EOWNERDEAD;
   }
   return captured_scene_error(ctx,error);
  }
  error=remesa_context_take_texture_scene(p,&pending);
  if(error){
   if(error!=EOWNERDEAD){
    int release=remesa_persistent_scene_capture_release(&sc->device,pending);
    if(release)error=EOWNERDEAD;
   }
   return captured_scene_error(ctx,error);
  }
 }
 memcpy(ctx->texture_draw_state,state,32*sizeof(uint64_t));ctx->texture_draw_state_valid=true;
 /* The new graph is owned but unissued: its OPEN fires on the resubmit, and a
  * conclusive submit refusal retains it instead of the fresh-graph release. */
 ctx->texture_replacement_pending=true;
 return 0;
#else
 (void)p;(void)info;(void)draw_info;(void)state;return ENOTSUP;
#endif
}
int remesa_context_submit_texture_scene(struct pipe_context *p,struct pipe_fence_handle **out)
{
 if(!p||p->draw_vbo!=draw)return EINVAL;
 if(!c(p)->owned_texture_scene.owner)return ENODATA;
 return remesa_context_submit_captured_scene(p,c(p)->owned_texture_scene,out);
}
int remesa_context_update_texture_vertices(struct pipe_context *p,uint32_t draw_index,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info)
{
 if(!p||p->draw_vbo!=draw)return EINVAL;
 if(!c(p)->owned_texture_scene.owner)return ENODATA;
 return remesa_context_update_captured_vertices(p,c(p)->owned_texture_scene,draw_index,info,draw_info);
}
int remesa_context_submit_captured_scene(struct pipe_context *p,
 struct remesa_scene_capture capture,struct pipe_fence_handle **out)
{
 if(!p||p->draw_vbo!=draw||!out||(uintptr_t)out%_Alignof(void *)||
    !context_state_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 int error=remesa_persistent_shader_output_check(&sc->device,out,sizeof(*out));if(error)return error;
 if(*out)return EBUSY;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 if(ctx->target->width0!=ctx->depth_target->width0||ctx->target->height0!=ctx->depth_target->height0)return EINVAL;
 error=remesa_persistent_scene_capture_validate_attachments(&sc->device,capture,color->bo,depth->bo,
  ctx->target->width0,ctx->target->height0);
 if(error)return captured_scene_error(ctx,error);
 error=resource_sync_writer(p->screen,color,UINT64_MAX);if(error)return captured_scene_error(ctx,error);
 error=resource_sync_writer(p->screen,depth,UINT64_MAX);if(error)return captured_scene_error(ctx,error);
 struct pipe_fence_handle *f=calloc(1,sizeof(*f));if(!f)return ENOMEM;
 return context_issue_capture(p,capture,true,false,false,f,out);
}

int remesa_context_clear_captured_color_cpu(struct pipe_context *p,struct remesa_scene_capture capture,
 const union pipe_color_union *value)
{
 if(!p||p->draw_vbo!=draw||!value)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(!context_state_output_valid(ctx,value,sizeof(*value)))return EINVAL;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 int e=remesa_persistent_scene_capture_validate_attachments(&sc->device,capture,color->bo,depth->bo,
  ctx->target->width0,ctx->target->height0);if(e)return captured_scene_error(ctx,e);
 struct remesa_color_clear plan;
 e=remesa_prepare_color_clear(ctx->target->format,ctx->target->width0,ctx->target->height0,
  color->stride,color->bytes,value,0,0,ctx->target->width0,ctx->target->height0,&plan);if(e)return e;
 e=resource_sync_writer(p->screen,color,0);if(e)return captured_scene_error(ctx,e);
 e=resource_sync_writer(p->screen,depth,0);if(e)return captured_scene_error(ctx,e);
 struct remesa_render_pass pass=color->pass;
 e=remesa_render_pass_cpu_write(&pass);if(e)return e;
 uint32_t pixel=(uint32_t)plan.pixel[0]|(uint32_t)plan.pixel[1]<<8|
  (uint32_t)plan.pixel[2]<<16|(uint32_t)plan.pixel[3]<<24;
 e=remesa_persistent_scene_color_clear_cpu(&sc->device,capture,pixel);
 if(e)return captured_scene_error(ctx,e);
 color->pass=pass;color->has_contents=true;++ctx->cpu_clears;return 0;
}
int remesa_context_update_captured_vertices(struct pipe_context *p,struct remesa_scene_capture capture,
 uint32_t draw_index,const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info)
{
 if(!p||p->draw_vbo!=draw||!draw_index)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->texture_qualification||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 int error=remesa_persistent_scene_capture_validate_attachments(&sc->device,capture,color->bo,depth->bo,
  ctx->target->width0,ctx->target->height0);if(error)return captured_scene_error(ctx,error);
 error=resource_sync_writer(p->screen,color,0);if(error)return captured_scene_error(ctx,error);
 error=resource_sync_writer(p->screen,depth,0);if(error)return captured_scene_error(ctx,error);
 struct remesa_linked_vertex_inputs *owned=NULL;
 error=remesa_context_tex0_vertex_inputs_snapshot(p,info,draw_info,&owned);if(error)return captured_scene_error(ctx,error);
 struct remesa_linked_vertex_inputs_view input;
 error=remesa_linked_vertex_inputs_inspect(owned,&input);
 if(!error)error=remesa_persistent_scene_vertices_update(&sc->device,capture,draw_index,&input);
 remesa_linked_vertex_inputs_destroy(owned);
 return error?captured_scene_error(ctx,error):0;
}
int remesa_context_update_captured_parameters(struct pipe_context *p,
 struct remesa_scene_capture capture,uint32_t draw_index)
{
 if(!p||p->draw_vbo!=draw||!draw_index)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color->maps||depth->maps||color->native_clear_owner||depth->native_clear_owner)return EBUSY;
 int e=remesa_persistent_scene_capture_validate_attachments(&sc->device,capture,color->bo,depth->bo,
  ctx->target->width0,ctx->target->height0);
 if(e)return captured_scene_error(ctx,e);
 e=resource_sync_writer(p->screen,color,0);if(e)return captured_scene_error(ctx,e);
 e=resource_sync_writer(p->screen,depth,0);if(e)return captured_scene_error(ctx,e);
 struct remesa_persistent_scene_parameters parameters;
 e=remesa_persistent_scene_parameters_snapshot(&sc->device,capture,&parameters);
 if(e)return captured_scene_error(ctx,e);
 const struct remesa_parameter_window *window=NULL;
 for(unsigned i=0;i<parameters.window_count;i++)if(parameters.windows[i].draw==draw_index){
  if(window)return EPROTO;
  window=&parameters.windows[i].window;
 }
 if(!window)return EINVAL;
 const struct remesa_pds_parameter_source_request request={window->gpu_va,window->allocation_bytes,
  window->source_offset,window->coefficient_dwords,window->transfer_dwords};
 uint8_t source[512];size_t written=0;
 e=remesa_context_vertex_parameter_source(p,&request,source,sizeof source,&written);if(e)return e;
 if(written!=window->transfer_dwords*4u)return EPROTO;
 uint32_t coefficients[127];
 for(unsigned i=0;i<window->coefficient_dwords;i++)coefficients[i]=(uint32_t)source[4+4*i]|
  (uint32_t)source[5+4*i]<<8|(uint32_t)source[6+4*i]<<16|(uint32_t)source[7+4*i]<<24;
 e=remesa_persistent_scene_parameters_update(&sc->device,capture,draw_index,coefficients,
  window->coefficient_dwords);
 return e?captured_scene_error(ctx,e):0;
}

static int context_submit_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,bool gears,bool homogeneous,bool normal,
 struct pipe_fence_handle **out)
{
 if(!p||p->draw_vbo!=draw||!info||!draw_info||!options||!out||
    (uintptr_t)out%_Alignof(void *)||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(gears&&!context_state_output_valid(ctx,out,sizeof(*out)))return EINVAL;
 /* Validate output aliases before inspecting it or preparing any scene. */
 const void *inputs[]={info,draw_info,options,ctx->target,ctx->depth_target,
  ctx->vb.buffer.resource,ctx->second_vb.buffer.resource,ctx->third_vb.buffer.resource};
 const size_t sizes[]={sizeof(*info),sizeof(*draw_info),sizeof(*options),
  sizeof(struct resource),sizeof(struct resource),sizeof(struct resource),sizeof(struct resource),sizeof(struct resource)};
 uintptr_t at=(uintptr_t)out;
 for(unsigned i=0;i<sizeof(inputs)/sizeof(inputs[0]);i++)if(inputs[i]){
  uintptr_t base=(uintptr_t)inputs[i];
  if(sizes[i]>UINTPTR_MAX-base||(at<base+sizes[i]&&base<at+sizeof(*out)))return EINVAL;
 }
 if(!context_output_valid(ctx,info,sizeof(*info))||
    !context_output_valid(ctx,draw_info,sizeof(*draw_info))||
    !context_output_valid(ctx,options,sizeof(*options)))return EINVAL;
 if(info->index_size){
  if(info->index_size!=1&&info->index_size!=2&&info->index_size!=4)return EINVAL;
  uintptr_t base=(uintptr_t)(info->has_user_indices?info->index.user:(void *)info->index.resource);
  uint64_t bytes=info->has_user_indices?((uint64_t)draw_info->start+draw_info->count)*info->index_size:sizeof(struct resource);
  if(!base||bytes>UINTPTR_MAX-base||(at<base+bytes&&base<at+sizeof(*out)))return EINVAL;
 }
 if(*out)return EBUSY;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->linked_attachment_storage||!ctx->target||!ctx->depth_target||
    !sc->device.ops->submit_linked_scene||!sc->device.ops->release_linked_scene)return ENOTSUP;
 struct resource *color=r(ctx->target),*depth=r(ctx->depth_target);
 if(color==depth)return EINVAL;
 struct pipe_fence_handle *f=calloc(1,sizeof(*f));if(!f)return ENOMEM;
 struct remesa_scene_capture capture={0};
 int error=context_prepare_scene(p,info,draw_info,options,gears,homogeneous,normal,&capture);
 if(error){
  if(error==EOWNERDEAD){
   /* Preparation can itself lose ownership of a provider allocation. An
    * older successful context fence must never hide that endpoint failure. */
   ctx->failed_submission=true;ctx->error=error;
   color->write_error=depth->write_error=error;
  }
  free(f);return error;
 }
 /* Reserve on local copies: neither attachment may change if the second
  * reservation fails or the backend conclusively reports NOT_ISSUED. */
 return context_issue_capture(p,capture,false,homogeneous,normal&&!ctx->native_clear_color&&!ctx->native_clear_depth,f,out);
}

int remesa_context_submit_linked_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct pipe_fence_handle **out)
{return context_submit_scene(p,info,draw_info,options,false,false,false,out);}
int remesa_context_submit_gears_attribute_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct pipe_fence_handle **out)
{return context_submit_scene(p,info,draw_info,options,true,false,false,out);}
int remesa_context_submit_gears_homogeneous_scene(struct pipe_context *p,
 const struct pipe_draw_info *info,const struct pipe_draw_start_count_bias *draw_info,
 const struct remesa_linked_scene_request *options,struct pipe_fence_handle **out)
{return context_submit_scene(p,info,draw_info,options,true,true,false,out);}
int remesa_context_enable_homogeneous_draw_lab(struct pipe_context *p)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(sc->native_draws)return ENOTSUP;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!sc->device.resource_only_backend||!sc->linked_attachment_storage||sc->gears_runtime||
    !sc->device.ops->submit_linked_scene||!sc->device.ops->release_linked_scene)return ENOTSUP;
 if(ctx->homogeneous_draw_lab)return EALREADY;
 ctx->homogeneous_draw_lab=true;return 0;
#else
 (void)p;return ENOTSUP;
#endif
}
int remesa_context_enable_homogeneous_api_lab(struct pipe_context *p,
 enum remesa_homogeneous_api_lab_profile profile)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->draw_vbo!=draw)return EINVAL;
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(profile!=REMESA_HOMOGENEOUS_API_W2_CLAMPED||!sc->homogeneous_frontend_lab||
    !ctx->homogeneous_draw_lab)return ENOTSUP;
 if(ctx->homogeneous_api_lab)return EALREADY;
 int error=remesa_persistent_native_scene_ready(&sc->device);if(error)return error;
 ctx->homogeneous_api_lab=profile;return 0;
#else
 (void)p;(void)profile;return ENOTSUP;
#endif
}

static void stencil_ref(struct pipe_context *p,const struct pipe_stencil_ref reference)
{ (void)reference;c(p)->error=0; /* All admitted DSA states disable stencil. */ }
static void blend_color(struct pipe_context *p,const struct pipe_blend_color *color)
{
 if(!color){c(p)->error=EINVAL;return;}
 for(unsigned i=0;i<4;i++)if(!isfinite(color->color[i])){c(p)->error=EINVAL;return;}
 c(p)->error=0; /* All admitted blend states disable blending. */
}
/* Mesa uploads the initial polygon pattern even when stippling is disabled.
 * Every admitted rasterizer state rejects poly_stipple_enable, so the pattern
 * cannot affect an admitted draw. Keep the required lifecycle hook non-NULL;
 * this neither implements stippling nor advertises additional raster caps. */
static void polygon_stipple(struct pipe_context *p,const struct pipe_poly_stipple *pattern)
{ c(p)->error=pattern?0:EINVAL; }
static void sample_mask(struct pipe_context *p,unsigned mask)
{ c(p)->sample_enabled=(mask&1)!=0;c(p)->error=0; /* Single sample only. */ }
/* Pack the existing color-clear semantics, then opt-in native fill or default
 * explicit CPU transfer. Depth is not admitted by the native color-fill path. */
static int prepare_rt_clear(struct pipe_screen *p,enum pipe_format fmt,unsigned w,unsigned h,
 unsigned stride,size_t bytes,const union pipe_color_union *color,unsigned x,unsigned y,unsigned rw,unsigned rh,
 struct remesa_color_clear *region)
{
 bool opaque=s(p)->egl_dmabuf_lab&&fmt==PIPE_FORMAT_B8G8R8X8_UNORM;
 int e=remesa_prepare_color_clear(opaque?PIPE_FORMAT_B8G8R8A8_UNORM:fmt,w,h,stride,bytes,color,x,y,rw,rh,region);
 if(!e&&opaque)region->pixel[3]=255;
 return e;
}
static int clear_resource(struct pipe_context *p,struct pipe_resource *target,
 const union pipe_color_union *color,double depth,unsigned x,unsigned y,unsigned width,unsigned height)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);struct remesa_color_clear region;void *ptr=NULL;int error;
 if(sc->closing)return ESHUTDOWN;
 if(ctx->presenting)return EBUSY;
 if(!target||target->screen!=p->screen||!color_storage_target(target->target)||
    !color)return ENOTSUP;
 if(target->format==PIPE_FORMAT_Z24X8_UNORM&&(sc->cpu_depth24_lab||sc->linked_attachment_storage))
  error=remesa_prepare_depth24_clear(target->format,target->width0,target->height0,r(target)->stride,
   r(target)->bytes,depth,x,y,width,height,&region);
 else error=prepare_rt_clear(p->screen,target->format,target->width0,target->height0,r(target)->stride,
   r(target)->bytes,color,x,y,width,height,&region);if(error)return error;
 if(!width||!height)return 0;
 if(sc->native_fill){
  if(target->format!=PIPE_FORMAT_B8G8R8A8_UNORM&&target->format!=PIPE_FORMAT_R8G8B8A8_UNORM)return ENOTSUP;
  return native_fill(p,target,0,x,y,width,height,region.pixel);
 }
 if(sc->buffer_renaming&&!x&&!y&&width==target->width0&&height==target->height0){
  const struct pipe_box whole={.width=width,.height=height,.depth=1};
  clear_texture(p,target,0,&whole,region.pixel);return ctx->error;
 }
 if(r(target)->maps)return EBUSY;
 error=resource_sync(p->screen,r(target),UINT64_MAX);if(error)return error;
 error=remesa_render_pass_admit_cpu_write(&r(target)->pass);if(error)return error;
 error=resource_map_backing(p->screen,r(target),true,&ptr);
 if(error){if(ptr)resource_unmap_backing(p->screen,r(target),true);return error;}
 if(!ptr){resource_unmap_backing(p->screen,r(target),true);return EPROTO;}
 for(unsigned row=0;row<region.rows;row++)
  remesa_cpu_fill_pixel32((unsigned char *)ptr+region.offset+(size_t)row*region.stride,region.row_bytes,region.pixel);
 resource_unmap_backing(p->screen,r(target),true);
 /* Checked UNMAP/sync may have quarantined the backing. Do not publish a
  * successful clear/content epoch after uncertain ownership or visibility. */
 if(r(target)->write_error)return captured_scene_error(ctx,r(target)->write_error);
 error=remesa_render_pass_cpu_write(&r(target)->pass);if(error){r(target)->write_error=error;return error;}
 r(target)->has_contents=true;++ctx->cpu_clears;return 0;
}
/* The native cold scene already clears COLOR=0 and Z=1 on the GPU.
 * Record matching API intent without touching backing. An independently
 * admitted draw must actually issue/retire that scene before publication. */
static int queue_native_clear(struct context *ctx,unsigned buffers,
 const struct pipe_scissor_state *scissor,const union pipe_color_union *color,double depth)
{
 struct pipe_screen *screen=ctx->base.screen;
 if(s(screen)->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!buffers)return 0;
 if(buffers&~(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))return ENOTSUP;
 if(!ctx->target||!ctx->depth_target)return ENOTSUP;
 unsigned w=ctx->target->width0,h=ctx->target->height0;
 if(scissor&&(scissor->minx||scissor->miny||scissor->maxx!=w||scissor->maxy!=h))return ENOTSUP;
 if((buffers&PIPE_CLEAR_DEPTH)&&depth!=1.0)return ENOTSUP;
 if(buffers&PIPE_CLEAR_COLOR0){
  if(!color)return EINVAL;
  for(unsigned i=0;i<4;i++)if(color->f[i]!=0.0f)return ENOTSUP;
 }
 struct pipe_resource *targets[]={ctx->target,ctx->depth_target};
 struct pipe_resource **slots[]={&ctx->native_clear_color,&ctx->native_clear_depth};
 const unsigned masks[]={PIPE_CLEAR_COLOR0,PIPE_CLEAR_DEPTH};
 /* Validate the whole pair before changing either pending owner/reference. */
 for(unsigned i=0;i<2;i++){
  struct resource *b=r(targets[i]);
  if((*slots[i]&&*slots[i]!=targets[i])||
     (b->native_clear_owner&&b->native_clear_owner!=ctx))return EBUSY;
  if(b->write_error)return b->write_error;
  if(b->maps)return EBUSY;
  if(b->has_contents||b->writer)return ENOTSUP; /* Load/preserve is separate. */
  struct remesa_render_pass pass=b->pass;struct remesa_pass_ticket ticket=b->ticket;
  int error=remesa_render_pass_begin(&pass,REMESA_PASS_DISCARD,REMESA_PASS_STORE,false,&ticket);
  if(error)return error;
 }
 for(unsigned i=0;i<2;i++)if(buffers&masks[i]){
  remesa_resource_reference(slots[i],targets[i]);r(targets[i])->native_clear_owner=ctx;
 }
 return 0;
}
/* Normal glClear: COLOR is an actual native fill, Z is explicit pending work
 * consumed by the existing Z-clear prefix of the following native draw.
 * DISCARD alone is never treated as either clear. No CPU fallback. */
static int native_draw_clear(struct pipe_context *p,unsigned buffers,
 const struct pipe_scissor_state *scissor,const union pipe_color_union *color,double depth)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(sc->closing)return ESHUTDOWN;
 if(ctx->failed_submission)return EOWNERDEAD;
 if(!buffers)return 0;
 if(buffers&~(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))return ENOTSUP;
 if(!ctx->target||!ctx->depth_target||!sc->native_fill)return ENOTSUP;
 unsigned width=ctx->target->width0,height=ctx->target->height0;
 if(scissor&&(scissor->minx||scissor->miny||scissor->maxx!=width||scissor->maxy!=height))return ENOTSUP;
 if((buffers&PIPE_CLEAR_DEPTH)&&depth!=1)return ENOTSUP;
 if(buffers&PIPE_CLEAR_COLOR0){
  if(!color)return EINVAL;
  for(unsigned i=0;i<4;i++)if(color->f[i]!=0)return ENOTSUP;
 }
 /* Gallium clear receives the mask selected by the state tracker. Bound
  * draw DSA/blend descriptors can be stale here and do not define a clear. */
 struct pipe_resource *targets[]={ctx->target,ctx->depth_target};
 struct pipe_resource **pending[]={&ctx->native_clear_color,&ctx->native_clear_depth};
 const unsigned masks[]={PIPE_CLEAR_COLOR0,PIPE_CLEAR_DEPTH};
 for(unsigned i=0;i<2;i++){
  struct resource *b=r(targets[i]);
  if(b->maps||(b->native_clear_owner&&b->native_clear_owner!=ctx)||
     (*pending[i]&&*pending[i]!=targets[i]))return EBUSY;
  if(b->write_error)return b->write_error;
  int e=resource_sync_writer(p->screen,b,UINT64_MAX);if(e)return captured_scene_error(ctx,e);
 }
 if(buffers&PIPE_CLEAR_COLOR0){
  int e=clear_resource(p,ctx->target,color,depth,0,0,width,height);if(e)return e;
 }
 for(unsigned i=0;i<2;i++)if(buffers&masks[i]){
  remesa_resource_reference(pending[i],targets[i]);r(targets[i])->native_clear_owner=ctx;
 }
 return 0;
}
static void clear_impl(struct pipe_context *p,unsigned buffers,const struct pipe_scissor_state *scissor,
 const union pipe_color_union *color,double depth,unsigned stencil)
{
 (void)stencil;struct context *ctx=c(p);
 if(ctx->presenting){ctx->error=EBUSY;return;}
 /* A sampled graph already owns the source and COLOR/Z. Do not try the
  * matrix native-fill path on that same endpoint. The retired sampled
  * graph's CPU COLOR transaction below is the only permitted writer.
  * Keep the matrix path unchanged for contexts without a sampled graph. */
 if(s(p->screen)->native_draws&&!ctx->owned_texture_scene.owner){ctx->error=native_draw_clear(p,buffers,scissor,color,depth);return;}
 if(s(p->screen)->native_draws&&ctx->owned_texture_scene.owner&&buffers&&
    (buffers!=PIPE_CLEAR_COLOR0||scissor)){ctx->error=ENOTSUP;return;}
 if(ctx->homogeneous_draw_lab){ctx->error=queue_native_clear(ctx,buffers,scissor,color,depth);return;}
 if(s(p->screen)->gears_runtime&&buffers){
  bool bad=(buffers&~(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))||ctx->gears_pending||ctx->gears_poisoned||!ctx->target||ctx->target->width0!=1280||ctx->target->height0!=800;
  if(scissor&&(scissor->minx||scissor->miny||scissor->maxx!=1280||scissor->maxy!=800))bad=true;
  if((buffers&PIPE_CLEAR_DEPTH)&&depth!=1.0)bad=true;
  if(buffers&PIPE_CLEAR_COLOR0){if(!color)bad=true;else for(unsigned i=0;i<4;i++)if(color->f[i]!=0.0f)bad=true;}
  if(bad){if(getenv("REMESA_GEARS_TRACE"))fprintf(stderr,"GEARS_CLEAR_REJECT buffers=%x pending=%u poisoned=%u size=%ux%u depth=%g color=%g,%g,%g,%g\n",buffers,ctx->gears_pending,ctx->gears_poisoned,ctx->target?ctx->target->width0:0,ctx->target?ctx->target->height0:0,depth,color?color->f[0]:0,color?color->f[1]:0,color?color->f[2]:0,color?color->f[3]:0);ctx->gears_poisoned=true;ctx->error=ENOTSUP;return;}
 }
 if(!buffers){ctx->error=0;return;}
 if(s(p->screen)->native_fill&&(buffers&PIPE_CLEAR_DEPTH)){ctx->error=ENOTSUP;return;}
 if((buffers&~(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))||
    ((buffers&PIPE_CLEAR_DEPTH)&&(!(s(p->screen)->cpu_depth24_lab||s(p->screen)->linked_attachment_storage)||!ctx->depth_target))||!ctx->target){ctx->error=ENOTSUP;return;}
 unsigned w=ctx->target->width0,h=ctx->target->height0;
 unsigned x=scissor?scissor->minx:0,y=scissor?scissor->miny:0;
 if(scissor&&(x>scissor->maxx||y>scissor->maxy||scissor->maxx>w||scissor->maxy>h)){ctx->error=EINVAL;return;}
 unsigned rw=scissor?scissor->maxx-x:w,rh=scissor?scissor->maxy-y:h;
 /* Validate both plans before either attachment is written. */
 struct remesa_color_clear plan;
 if(buffers&PIPE_CLEAR_DEPTH){ctx->error=remesa_prepare_depth24_clear(PIPE_FORMAT_Z24X8_UNORM,w,h,
  r(ctx->depth_target)->stride,r(ctx->depth_target)->bytes,depth,x,y,rw,rh,&plan);if(ctx->error)return;}
 if(buffers&PIPE_CLEAR_COLOR0){ctx->error=prepare_rt_clear(p->screen,ctx->target->format,w,h,
  r(ctx->target)->stride,r(ctx->target)->bytes,color,x,y,rw,rh,&plan);if(ctx->error)return;}
 /* A retained graph forbids ordinary WRITE maps. Resolve the exact current
  * pair on each full COLOR clear rather than caching a token across rebinds
  * or frontend destruction. The existing retired CPU transaction remains
  * the only writer, with its lease/coherence/uncertainty checks unchanged. */
 if(s(p->screen)->linked_attachment_storage&&ctx->depth_target&&ctx->target&&!r(ctx->target)->host_data&&
    buffers==PIPE_CLEAR_COLOR0&&!x&&!y&&rw==w&&rh==h){
  struct remesa_scene_capture capture={0};
  int e=remesa_persistent_scene_capture_find_attachments(&s(p->screen)->device,
   r(ctx->target)->bo,r(ctx->depth_target)->bo,w,h,&capture);
  if(e!=ENODATA){
   ctx->error=e?captured_scene_error(ctx,e):remesa_context_clear_captured_color_cpu(p,capture,color);
   return;
  }
 }
 /* Never fall through to the ordinary mapping/native fill path if a graph
  * is owned but cannot authenticate this attachment pair. */
 if(ctx->owned_texture_scene.owner){ctx->error=ENOTSUP;return;}
 ctx->error=0;
 if(buffers&PIPE_CLEAR_COLOR0)ctx->error=clear_resource(p,ctx->target,color,depth,x,y,rw,rh);
 if(!ctx->error&&(buffers&PIPE_CLEAR_DEPTH)){union pipe_color_union unused={0};
  ctx->error=clear_resource(p,ctx->depth_target,&unused,depth,x,y,rw,rh);} if(s(p->screen)->gears_runtime){
  if(ctx->error)ctx->gears_poisoned=true;
  else ctx->gears_clear_mask|=buffers;
 }
}
static uint64_t egl27_clear_clock(void)
{
 struct timespec ts;if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (uint64_t)ts.tv_sec*1000000u+(uint64_t)ts.tv_nsec/1000u;
}
static void clear(struct pipe_context *p,unsigned buffers,const struct pipe_scissor_state *scissor,
 const union pipe_color_union *color,double depth,unsigned stencil)
{
 struct context *ctx=c(p);struct resource *b=ctx->target?r(ctx->target):NULL;
 bool shared=b&&b->shared_rt&&(buffers&PIPE_CLEAR_COLOR0);
 uint64_t clear_start=egl27_clear_clock();
 if(shared){ctx->error=hre_shared_rt_sync(p->screen,b,false);if(ctx->error)goto failed;}
 clear_impl(p,buffers,scissor,color,depth,stencil);
 if(shared&&!ctx->error)ctx->error=hre_shared_rt_sync(p->screen,b,true);
 failed:if(shared&&ctx->error)ctx->publication_error=ctx->error;
 if(shared&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL27_CLEAR us=%llu errno=%d\n",(unsigned long long)(egl27_clear_clock()-clear_start),ctx->error);
}
static void clear_target(struct pipe_context *p,struct pipe_surface *surface,
 const union pipe_color_union *color,unsigned x,unsigned y,unsigned width,unsigned height,bool conditional)
{
 if(c(p)->homogeneous_draw_lab||s(p->screen)->native_draws){c(p)->error=ENOTSUP;return;}
 if(conditional||!surface||surface->context!=p||!color_rt_format(p->screen,surface->format)||
    surface->level||surface->first_layer||surface->last_layer||surface->nr_samples>1) {
  c(p)->error=ENOTSUP;return;
 }
 struct resource *b=r(surface->texture);
 if(b->shared_rt){c(p)->error=hre_shared_rt_sync(p->screen,b,false);if(c(p)->error)return;}
 c(p)->error=clear_resource(p,surface->texture,color,0,x,y,width,height);
 if(b->shared_rt&&!c(p)->error)c(p)->error=hre_shared_rt_sync(p->screen,b,true);
 if(b->shared_rt&&c(p)->error)c(p)->publication_error=c(p)->error;
}
/* Whole-frame gears preparation never calls the legacy CPU transform/clip
 * path. Only the existing pre-VS snapshot and typed uniform encoder run. */
#ifdef REMESA_WITH_NIR
static int gears_reject(struct context *ctx,unsigned line,int error)
{
 if(getenv("REMESA_GEARS_TRACE"))fprintf(stderr,"GEARS_DRIVER_REJECT line=%u error=%d clear=%x poisoned=%u viewport=%g,%g,%g/%g,%g,%g invalid=%u,%u,%u,%u fixed=%u,%u,%u\n",line,error,ctx->gears_clear_mask,ctx->gears_poisoned,ctx->viewport.scale[0],ctx->viewport.scale[1],ctx->viewport.scale[2],ctx->viewport.translate[0],ctx->viewport.translate[1],ctx->viewport.translate[2],ctx->invalid_viewport,ctx->invalid_scissor,ctx->invalid_constants,ctx->invalid_elements,ctx->invalid_fixed[0],ctx->invalid_fixed[1],ctx->invalid_fixed[2]);
 return error;
}
#endif
static int queue_gears(struct pipe_context *p,const struct pipe_draw_info *info,unsigned drawid,
 const struct pipe_draw_indirect_info *indirect,const struct pipe_draw_start_count_bias *draws,unsigned count)
{
#ifdef REMESA_WITH_NIR
 struct context *ctx=c(p);struct screen *sc=s(p->screen);int error=ENOTSUP;
 struct remesa_gears_geometry *geometry=NULL;struct remesa_gears_geometry_view view;
 unsigned char parameters[176];size_t written=0;
 if(ctx->gears_poisoned)return gears_reject(ctx,__LINE__,EIO);
 if(!info||!draws||count!=1||indirect||drawid||info->mode!=MESA_PRIM_TRIANGLES||info->instance_count!=1||info->start_instance)return gears_reject(ctx,__LINE__,ENOTSUP);
 if(!draws->count||!ctx->sample_enabled)return 0;
 if(!ctx->target||!ctx->depth_target||ctx->target->format!=PIPE_FORMAT_B8G8R8A8_UNORM||
    ctx->depth_target->format!=PIPE_FORMAT_Z24X8_UNORM||ctx->target->width0!=1280||ctx->target->height0!=800||
    ctx->depth_target->width0!=1280||ctx->depth_target->height0!=800||r(ctx->target)->maps||r(ctx->depth_target)->maps||
    r(ctx->target)->write_error||r(ctx->depth_target)->write_error||
    (ctx->gears_clear_mask&(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))!=(PIPE_CLEAR_COLOR0|PIPE_CLEAR_DEPTH))return gears_reject(ctx,__LINE__,ENOTSUP);
 if(ctx->invalid_viewport||ctx->invalid_scissor||ctx->invalid_constants||ctx->invalid_elements||ctx->constant_rejections[0]||ctx->constant_rejections[1])return gears_reject(ctx,__LINE__,ENOTSUP);
 for(unsigned i=0;i<FIXED_COUNT;i++)if(ctx->invalid_fixed[i]||!ctx->bound_fixed[i])return gears_reject(ctx,__LINE__,ENOTSUP);
 struct fixed *depth=ctx->bound_fixed[FIXED_DSA],*raster=ctx->bound_fixed[FIXED_RASTER];
 if(!depth->depth_enabled||!depth->depth_write||depth->depth_func!=PIPE_FUNC_LESS||raster->scissor||
    raster->cull_face!=PIPE_FACE_BACK||!raster->depth_clip_near||!raster->depth_clip_far)return gears_reject(ctx,__LINE__,ENOTSUP);
 if(!ctx->viewport_set||!remesa_viewport_swizzle_is_identity(&ctx->viewport)||
    ctx->viewport.scale[0]!=640.0f||ctx->viewport.scale[2]!=0.5f||
    ctx->viewport.translate[0]!=640.0f||ctx->viewport.translate[1]!=400.0f||ctx->viewport.translate[2]!=0.5f)return gears_reject(ctx,__LINE__,ENOTSUP);
 /* Mesa mirrors viewport Y and front-face together for bottom-origin
  * storage. Canonicalize only this paired convention, never vertices. */
 bool bottom_left=ctx->viewport.scale[1]==400.0f&&!raster->front_ccw;
 bool top_left=ctx->viewport.scale[1]==-400.0f&&raster->front_ccw;
 if((!bottom_left&&!top_left)||raster->bottom_edge_rule!=top_left)return gears_reject(ctx,__LINE__,ENOTSUP);
 if(ctx->gears_pending&&ctx->gears_bottom_left!=bottom_left)return gears_reject(ctx,__LINE__,ENOTSUP);
 if(!ctx->bound_vertex||!ctx->bound_fragment||ctx->bound_vertex->deleted||ctx->bound_fragment->deleted||
    remesa_shader_program_validate(&ctx->bound_vertex->program)||remesa_shader_program_validate(&ctx->bound_fragment->program)||
    remesa_shader_ir_gears_vertex(&ctx->bound_vertex->program.semantic))return gears_reject(ctx,__LINE__,ENOTSUP);
 bool flat=!remesa_shader_ir_fragment_flat_color_input(&ctx->bound_fragment->program.semantic);
 if((!flat&&remesa_shader_ir_fragment_color_input(&ctx->bound_fragment->program.semantic))||
    ctx->bound_fragment->program.semantic.instructions[0].input_slot!=1||
    (raster->flat&&!flat)||(flat&&raster->flat_first))return gears_reject(ctx,__LINE__,ENOTSUP);
 error=remesa_sampler_draw_admit(ctx->samplers);if(error)return error;
 error=remesa_texture_draw_admit(ctx->textures);if(error)return error;
 struct pipe_draw_start_count_bias complete=*draws;complete.count-=complete.count%3;
 if(!complete.count)return 0;
 error=remesa_context_gears_geometry_snapshot(p,info,&complete,&geometry);if(error)goto done;
 error=remesa_gears_geometry_inspect(geometry,&view);if(error)goto done;
 unsigned attr=view.normal_from_attribute;
 const struct remesa_pds_parameter_source_request source={0x20000000,131072,0x6400,attr?36u:40u,attr?40u:44u};
 error=remesa_context_vertex_parameter_source(p,&source,parameters,sizeof(parameters),&written);if(error)goto done;
 if(written!=source.transfer_dwords*4u){error=EPROTO;goto done;}
 if(ctx->gears_pending&&(ctx->gears_target!=ctx->target||ctx->gears_depth!=ctx->depth_target)){error=ENOTSUP;goto done;}
 if(!ctx->gears_pending){remesa_resource_reference(&ctx->gears_target,ctx->target);remesa_resource_reference(&ctx->gears_depth,ctx->depth_target);ctx->gears_pending=true;ctx->gears_bottom_left=bottom_left;ctx->gears_origin_valid=true;}
 const struct remesa_gears_runtime_draw request={.vertex=&ctx->bound_vertex->program,.fragment=&ctx->bound_fragment->program,
  .geometry=&view,.coefficients=parameters+4,.coefficient_bytes=source.coefficient_dwords*4u,
  .width=1280,.height=800,.stride=r(ctx->target)->stride,.format=ctx->target->format,
  .depth_target=r(ctx->depth_target)->bo,.depth_stride=r(ctx->depth_target)->stride,.depth_format=ctx->depth_target->format,
  .flat=flat,.front_ccw=true,.bottom_left_storage=bottom_left,.clamp_vertex_color=raster->clamp_vertex_color,.cull_face=raster->cull_face};
 error=sc->device.gears_runtime->queue(sc->device.priv,r(ctx->target)->bo,&request);
 done:remesa_gears_geometry_destroy(geometry);return error?gears_reject(ctx,__LINE__,error):0;
#else
 (void)p;(void)info;(void)drawid;(void)indirect;(void)draws;(void)count;return ENOTSUP;
#endif
}
#ifdef REMESA_WITH_NIR
/* Canonical comparison data, not a hash or executable native state. Pointer
 * identities name immutable shader/CSO tombstones. Sampling is revalidated on
 * every call, including the exact resource cookie, content epoch and image.
 * No struct padding or stale view pointer participates in this comparison. */
static int texture_draw_state_snapshot(struct pipe_context *p,uint64_t out[32])
{
 struct context *ctx=c(p);
 if(!ctx->bound_vertex||ctx->bound_vertex->deleted||!ctx->bound_fragment||ctx->bound_fragment->deleted)return ENODATA;
 for(unsigned i=0;i<FIXED_COUNT;i++)
  if(ctx->invalid_fixed[i]||!ctx->bound_fixed[i]||ctx->bound_fixed[i]->deleted)return ENOTSUP;
 const struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if(raster->scissor||raster->cull_face||raster->flat)return ENOTSUP;
 struct remesa_isp_opaque_triangle_request isp;
 int error=remesa_context_linked_isp_snapshot(p,&isp);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 struct remesa_ta_window_viewport_request viewport;
 error=window_viewport_request(ctx,24,&viewport);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 struct pipe_sampler_state sampler;
 error=remesa_sampler_fragment0_snapshot(ctx->samplers,&sampler);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 /* The encoded sampled PDS depends on the admitted sampler subset: the
  * filter selection selects encoder word0 bits, so the sampler identity is
  * part of the ordinary-state key like every other encoded input. */
 const struct pipe_sampler_view *view=NULL;
 error=remesa_texture_fragment0_view(ctx->textures,&view);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 if(view->texture==ctx->target||view->texture==ctx->depth_target)return EINVAL;
 if((view->format!=PIPE_FORMAT_R8G8B8A8_UNORM&&view->format!=PIPE_FORMAT_B8G8R8A8_UNORM&&!opaque_native_view(ctx,view))||
    view->swizzle_r!=PIPE_SWIZZLE_X||view->swizzle_g!=PIPE_SWIZZLE_Y||
    view->swizzle_b!=PIPE_SWIZZLE_Z||(!opaque_native_view(ctx,view)&&view->swizzle_a!=PIPE_SWIZZLE_W))return ENOTSUP;
 error=resource_sync(p->screen,r(view->texture),0);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 struct remesa_texture_storage image;
 error=remesa_texture_view_storage(ctx->textures,view,&image);if(error){if(hybrid_enabled(s(p->screen)))fprintf(stderr,"HRE_SCRATCH_STATE_REJECT line=%d errno=%d\n",__LINE__,error);return error;}
 if(!sample_backing(view->texture)->bo)return ENOTSUP;
 if(!sample_backing(view->texture)->has_contents||!image.content_epoch)return EAGAIN;
 uint32_t near_bits,far_bits;memcpy(&near_bits,&viewport.near_z,4);memcpy(&far_bits,&viewport.far_z,4);
 uint64_t state[32]={
  (uintptr_t)ctx->bound_vertex,(uintptr_t)ctx->bound_fragment,
  (uintptr_t)ctx->bound_fixed[FIXED_BLEND],(uintptr_t)ctx->bound_fixed[FIXED_DSA],
  (uintptr_t)raster,image.resource_cookie,image.content_epoch,image.offset,image.bytes,
  image.width,image.height,image.stride,image.levels,view->format,view->target,
  view->u.tex.first_level,view->u.tex.last_level,
  viewport.framebuffer_width,viewport.framebuffer_height,viewport.x,viewport.y,
  viewport.width,viewport.height,near_bits,far_bits,viewport.path,viewport.depth_bits,
  (uintptr_t)sample_backing(view->texture)->bo,
  (uint64_t)sampler.min_img_filter|((uint64_t)sampler.mag_img_filter<<4)|
   ((uint64_t)sampler.wrap_s<<8)|((uint64_t)sampler.wrap_t<<12)|
   ((uint64_t)sampler.wrap_r<<16)};
 memcpy(out,state,sizeof(state));return 0;
}
static int managed_texture_draw(struct pipe_context *p,const struct pipe_draw_info *info,
 const struct pipe_draw_start_count_bias *draw_info)
{
 struct context *ctx=c(p);uint64_t state[32];
 int error=texture_draw_state_snapshot(p,state);if(error)return captured_scene_error(ctx,error);
 if(hre_gles_lab(s(p->screen))&&getenv("REMESA_DRI_TRACE"))
  fprintf(stderr,"HRE_RC3_GRAPH cookie=%llu epoch=%llu detached=%u\n",(unsigned long long)state[5],(unsigned long long)state[6],(unsigned)ctx->texture_graph_detached);
 if(ctx->owned_texture_scene.owner){
  /* A committed replacement is already owned and unissued: its ordinary-
   * state key was captured at the commit, so a retry submits it directly. */
  if(!ctx->texture_replacement_pending){
   /* Manually adopted graphs have no authenticated ordinary-state key. */
   if(!ctx->texture_draw_state_valid||!ctx->texture_draw_started)return EBUSY;
   if(ctx->texture_graph_detached||memcmp(state,ctx->texture_draw_state,sizeof(state))){
    /* Changed ordinary state rebuilds the graph transactionally: the owned
     * graph survives every conclusive refusal and uncertainty retains it. */
    if(ctx->compositor_carrier&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL24_GRAPH_REBUILD reason=state\n");
    error=remesa_context_replace_texture_graph(p,info,draw_info,state);if(error){if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_NATIVE_STAGE_FAIL stage=replace errno=%d\n",error);return error;}
   }else{
    error=remesa_context_update_texture_vertices(p,1,info,draw_info);
    if(!error&&ctx->compositor_carrier&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL24_GRAPH_REPLAY\n");
    const char *dynamic=getenv("REMESA_HRE_DYNAMIC");
    if(error==EINVAL&&s(p->screen)->hre&&dynamic&&!strcmp(dynamic,"1")){
     /* A changed count/index topology, or more than the fixed 21-record
      * update ABI, requires a fresh graph, not truncation or partial writes. */
     struct remesa_linked_vertex_inputs *checked=NULL;
     error=remesa_context_tex0_vertex_inputs_snapshot(p,info,draw_info,&checked);
     if(!error){
      struct remesa_linked_vertex_inputs_view view;
      error=remesa_linked_vertex_inputs_inspect(checked,&view);
      if(!error)error=remesa_texture_draw_values(view.vertices,view.vertex_bytes,view.vertex_count);
     }
     remesa_linked_vertex_inputs_destroy(checked);
     if(!error){if(ctx->compositor_carrier&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL24_GRAPH_REBUILD reason=topology\n");error=remesa_context_replace_texture_graph(p,info,draw_info,state);}
    }
    if(error)return error;
   }
  }
 }else{
  const struct remesa_linked_scene_request options={.vertex_bank=4,.pixel_bank=3,.state_bank=4,.clear_depth=1};
  struct remesa_scene_capture capture={0};
  error=remesa_context_prepare_texture_scene(p,info,draw_info,&options,&capture);if(error){if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_NATIVE_STAGE_FAIL stage=prepare errno=%d\n",error);return error;}
  error=remesa_context_take_texture_scene(p,&capture);
  if(error){
   if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_NATIVE_STAGE_FAIL stage=take errno=%d\n",error);
   if(error!=EOWNERDEAD){int release=remesa_persistent_scene_capture_release(&s(p->screen)->device,capture);if(release)error=EOWNERDEAD;}
   return captured_scene_error(ctx,error);
  }
  memcpy(ctx->texture_draw_state,state,sizeof(state));ctx->texture_draw_state_valid=true;
 }
 struct pipe_fence_handle *f=NULL;
 error=remesa_context_submit_texture_scene(p,&f);fence_ref(p->screen,&f,NULL);
 if(error&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_NATIVE_STAGE_FAIL stage=submit errno=%d\n",error);
 if(!error){ctx->texture_draw_started=true;ctx->texture_replacement_pending=false;}
 if(!error&&hre_gles_lab(s(p->screen))&&getenv("REMESA_HRE_DEPTH_PROBE")){
  struct pipe_transfer *transfer=NULL;
  struct pipe_box box={.x=ctx->depth_target->width0/2,.y=ctx->depth_target->height0/2,.width=1,.height=1,.depth=1};
  const uint8_t *pixel=map(p,ctx->depth_target,0,PIPE_MAP_READ,&box,&transfer);
  if(!pixel)error=ctx->error?ctx->error:EIO;
  else {
   uint32_t z=(uint32_t)pixel[0]|((uint32_t)pixel[1]<<8)|((uint32_t)pixel[2]<<16);
   unmap(p,transfer);error=r(ctx->depth_target)->write_error;
   if(!error)fprintf(stderr,"HRE_RC3_DEPTH raw=%u\n",z);
  }
  if(error)return captured_scene_error(ctx,error);
 }
 else if(error!=EOWNERDEAD&&!ctx->texture_draw_started&&!ctx->texture_replacement_pending){
  /* An unissued initial draw cannot accept changed inputs as the frozen first
   * draw. Conclusive CLOSE is required before a new graph can be prepared.
   * A committed replacement keeps its unissued graph instead: the old graph
   * is already retired, so the transaction stands and the retry resubmits. */
  int release=remesa_context_release_texture_scene(p);if(release)error=release;
 }
 return error?captured_scene_error(ctx,error):0;
}
static int qualify_texture_draw(struct pipe_context *p,const struct pipe_draw_info *info,
 unsigned drawid,const struct pipe_draw_indirect_info *indirect,
 const struct pipe_draw_start_count_bias *draws,unsigned count)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(!sc->texture_qualification)return ENOTSUP;
 if(ctx->failed_submission)return EOWNERDEAD;
 const char *opt=getenv("REMESA_HRE_DYNAMIC");
 bool dynamic=sc->hre&&opt&&!strcmp(opt,"1");
 if(!info||!draws||count!=1||drawid||indirect||
    info->instance_count!=1||info->start_instance||info->primitive_restart||
    !ctx->target||!ctx->target->width0||!ctx->target->height0||
    ctx->target->width0>2048||ctx->target->height0>2048)return ENOTSUP;
 if(!dynamic){
  if(info->mode!=MESA_PRIM_TRIANGLES||draws->count!=3)return ENOTSUP;
 }else{
  struct remesa_linked_topology topology;
  int topology_error=remesa_linked_topology_prepare(info->mode,draws->count,&topology);
  /* Incomplete primitives are a no-op, and the assembler bounds expanded
   * indices before any backing is mapped. */
  if(topology_error==ENODATA)return 0;
  if(topology_error)return topology_error;
 }
 if(!ctx->sample_enabled)return 0;
 int lifetime=remesa_persistent_texture_lifetime_ready(&sc->device);
 if(!lifetime)return managed_texture_draw(p,info,draws);
 if(lifetime!=EOPNOTSUPP)return captured_scene_error(ctx,lifetime);
 const struct remesa_linked_scene_request options={.vertex_bank=4,.pixel_bank=3,.state_bank=4,.clear_depth=1};
 struct remesa_scene_capture capture={0};struct pipe_fence_handle *f=NULL;
 int error=remesa_context_prepare_texture_scene(p,info,draws,&options,&capture);if(error)return error;
 error=remesa_context_submit_captured_scene(p,capture,&f);
 /* Only a conclusively unissued or acknowledged operation may release the
  * producer graph. Uncertainty retains the graph, endpoint and both targets. */
 if(error!=EOWNERDEAD){int release=remesa_persistent_scene_capture_release(&sc->device,capture);if(release)error=EOWNERDEAD;}
 fence_ref(p->screen,&f,NULL);
 return error?captured_scene_error(ctx,error):0;
}
#endif
#ifdef REMESA_WITH_NIR
/* CPU execution of the linked Solid Lambert pair. This route performs no
 * SGX submission; synchronized Gallium maps retain resource ownership rules. */
static int cpu_solid_lambert_draw(struct pipe_context *p,const struct pipe_draw_info *info,
 const struct pipe_draw_start_count_bias *draws,unsigned count,unsigned drawid,
 const struct pipe_draw_indirect_info *indirect)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(!sc->linked_attachment_storage||!info||!draws||count!=1||drawid||indirect||
    info->mode!=MESA_PRIM_TRIANGLES||info->primitive_restart||info->instance_count!=1||
    info->start_instance||!ctx->sample_enabled||!ctx->target||!ctx->depth_target||
    ctx->target->format!=PIPE_FORMAT_B8G8R8A8_UNORM||ctx->depth_target->format!=PIPE_FORMAT_Z24X8_UNORM||
    ctx->target->width0!=ctx->depth_target->width0||ctx->target->height0!=ctx->depth_target->height0||
    !r(ctx->target)->has_contents||!r(ctx->depth_target)->has_contents||
    ctx->invalid_viewport||!ctx->viewport_set||ctx->invalid_scissor||ctx->scissor_set||
    ctx->invalid_elements||ctx->invalid_fixed[FIXED_BLEND]||ctx->invalid_fixed[FIXED_DSA]||
    ctx->invalid_fixed[FIXED_RASTER]||!ctx->bound_fixed[FIXED_BLEND]||!ctx->bound_fixed[FIXED_DSA]||
    !ctx->bound_fixed[FIXED_RASTER]||!ctx->pipeline_bound||!ctx->position_bound||ctx->vb_count!=1)
  return ENOTSUP;
 if(ctx->failed_submission)return EOWNERDEAD;
 const struct fixed *blend=ctx->bound_fixed[FIXED_BLEND],*depth=ctx->bound_fixed[FIXED_DSA];
 const struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if(blend->deleted||depth->deleted||raster->deleted||blend->colormask!=PIPE_MASK_RGBA||
    !depth->depth_enabled||!depth->depth_write||depth->depth_func!=PIPE_FUNC_LESS||
    raster->cull_face||raster->scissor||raster->flat||raster->depth_clip||raster->full_clip||
    raster->bottom_edge_rule||raster->front_ccw||raster->clamp_vertex_color||
    !remesa_viewport_swizzle_is_identity(&ctx->viewport))return ENOTSUP;
 for(unsigned i=0;i<3;i++)if(!isfinite(ctx->viewport.scale[i])||!isfinite(ctx->viewport.translate[i]))return EINVAL;
 if(!ctx->bound_vertex||!ctx->bound_fragment||!ctx->bound_elements||ctx->bound_elements->count!=3)return ENODATA;
 struct remesa_shader_linkage link;
 int error=remesa_context_shader_linkage_snapshot(p,&link);if(error)return error;
 if(remesa_shader_ir_white_lambert(&link.vertex.semantic)||
    remesa_shader_ir_fragment_color_input(&link.fragment.semantic))return ENOTSUP;
 if(!draws->count)return 0;
 struct remesa_linked_vertex_inputs *owned=NULL;
 error=remesa_context_linked_vertex_inputs_snapshot(p,info,draws,&owned);if(error)return error;
 struct remesa_linked_vertex_inputs_view input;
 error=remesa_linked_vertex_inputs_inspect(owned,&input);
 if(error||input.stride_bytes!=48||input.index_count%3||!input.indices){
  remesa_linked_vertex_inputs_destroy(owned);return error?error:EPROTO;
 }
 /* Validate the whole draw before acquiring writable targets. Clipping is
  * deliberately not implemented in this CPU subset, so crossing primitives
  * fail atomically instead of being silently dropped or partially rendered. */
 for(uint32_t i=0;i<input.vertex_count;i++){
  const float *v=(const float *)((const uint8_t *)input.vertices+(size_t)i*48);
  for(unsigned j=0;j<12;j++)if(!isfinite(v[j])){error=EINVAL;break;}
  if(error)break;
  if(v[3]<=0||v[0]<-v[3]||v[0]>v[3]||v[1]<-v[3]||v[1]>v[3]||v[2]<0||v[2]>v[3]){error=ENOTSUP;break;}
 }
 for(uint32_t i=0;!error&&i<input.index_count;i++)if(input.indices[i]>=input.vertex_count)error=EPROTO;
 if(error){remesa_linked_vertex_inputs_destroy(owned);return error;}
 struct pipe_box box={.width=(int)ctx->target->width0,.height=(int)ctx->target->height0,.depth=1};
 struct pipe_transfer *ct=NULL,*zt=NULL;
 uint8_t *color=map(p,ctx->target,0,PIPE_MAP_WRITE,&box,&ct);
 if(!color){error=ctx->error?ctx->error:EIO;goto cpu_done;}
 uint8_t *zbytes=map(p,ctx->depth_target,0,PIPE_MAP_WRITE,&box,&zt);
 if(!zbytes){error=ctx->error?ctx->error:EIO;unmap(p,ct);ct=NULL;goto cpu_done;}
 const uint32_t width=ctx->target->width0,height=ctx->target->height0;
 for(uint32_t t=0;t<input.index_count;t+=3){
  double x[3],y[3],z[3],shade[3],invw[3];
  for(unsigned k=0;k<3;k++){
   uint16_t id=input.indices[t+k];
   const float *v=(const float *)((const uint8_t *)input.vertices+(size_t)id*48);
   invw[k]=1.0/(double)v[3];
   x[k]=(double)ctx->viewport.translate[0]+(double)ctx->viewport.scale[0]*v[0]*invw[k];
   y[k]=(double)ctx->viewport.translate[1]+(double)ctx->viewport.scale[1]*v[1]*invw[k];
   z[k]=(double)ctx->viewport.translate[2]+(double)ctx->viewport.scale[2]*v[2]*invw[k];
   double dot=(double)v[4]*v[8]+(double)v[5]*v[9]+(double)v[6]*v[10];
   shade[k]=dot<0?0:dot>1?1:dot;
  }
  double area=(x[1]-x[0])*(y[2]-y[0])-(y[1]-y[0])*(x[2]-x[0]);
  if(!isfinite(area)){error=ERANGE;break;}if(fabs(area)<1e-15)continue;
  double left=fmax(0.0,floor(fmin(x[0],fmin(x[1],x[2]))));
  double right=fmin((double)width,ceil(fmax(x[0],fmax(x[1],x[2]))));
  double bottom=fmax(0.0,floor(fmin(y[0],fmin(y[1],y[2]))));
  double top=fmin((double)height,ceil(fmax(y[0],fmax(y[1],y[2]))));
  if(right<=left||top<=bottom)continue;
  int minx=(int)left,maxx=(int)right,miny=(int)bottom,maxy=(int)top;
  for(int py=miny;py<maxy;py++)for(int px=minx;px<maxx;px++){
   double sx=px+0.5,sy=py+0.5;
   double a=((x[1]-sx)*(y[2]-sy)-(y[1]-sy)*(x[2]-sx))/area;
   double b=((x[2]-sx)*(y[0]-sy)-(y[2]-sy)*(x[0]-sx))/area,d=1.0-a-b;
   if(a<0||b<0||d<0)continue;
   double fragz=a*z[0]+b*z[1]+d*z[2];if(fragz<0||fragz>1)continue;
   uint32_t depth24=(uint32_t)(fragz*16777215.0+0.5);
   uint8_t *zp=zbytes+(size_t)py*zt->stride+(size_t)px*4;
   uint32_t old=(uint32_t)zp[0]|(uint32_t)zp[1]<<8|(uint32_t)zp[2]<<16;
   if(depth24>=old)continue;
   double reciprocal=a*invw[0]+b*invw[1]+d*invw[2];
   if(!(reciprocal>0)||!isfinite(reciprocal)){error=ERANGE;break;}
   double varying=(a*shade[0]*invw[0]+b*shade[1]*invw[1]+d*shade[2]*invw[2])/reciprocal;
   uint8_t q=(uint8_t)((varying*255.0)+0.5);
   uint8_t *cp=color+(size_t)py*ct->stride+(size_t)px*4;
   cp[0]=cp[1]=cp[2]=cp[3]=q;
   zp[0]=(uint8_t)depth24;zp[1]=(uint8_t)(depth24>>8);zp[2]=(uint8_t)(depth24>>16);zp[3]=0;
  }
  if(error)break;
 }
 unmap(p,zt);zt=NULL;unmap(p,ct);ct=NULL;
 if(!error&&r(ctx->target)->write_error)error=r(ctx->target)->write_error;
 if(!error&&r(ctx->depth_target)->write_error)error=r(ctx->depth_target)->write_error;
cpu_done:
 if(zt)unmap(p,zt);
 if(ct)unmap(p,ct);
 remesa_linked_vertex_inputs_destroy(owned);return error;
}
#endif
#ifdef REMESA_WITH_NIR
#include "remesa_compositor_live.inc"
#endif
static void draw(struct pipe_context *p,const struct pipe_draw_info *info,unsigned drawid,
 const struct pipe_draw_indirect_info *indirect,const struct pipe_draw_start_count_bias *draws,unsigned count)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);
 struct pipe_draw_info validated_info;struct pipe_resource *owned_index=NULL;
 struct pipe_draw_start_count_bias complete_draw;
 struct remesa_shader_draw_inputs inputs={0};
 void *ip=NULL,*vp=NULL,*backend=NULL;struct remesa_draw_packet *packet=NULL;
 void *shader_programs=NULL;
#ifdef REMESA_WITH_NIR
 struct remesa_shader_draw_programs *shader_snapshot=NULL;
#endif
 enum remesa_draw_status packed;int err=ENOTSUP;uint32_t draw_argb=ctx->argb;bool submitted=false,v_mapped=false,i_mapped=false;struct pipe_fence_handle *f=NULL;
 if(!info) goto done;
 /* Nonindexed draws do not initialize the index union. */
 if(info->index_size && info->take_index_buffer_ownership && !info->has_user_indices)
  owned_index=info->index.resource;
 if(ctx->presenting||sc->frontbuffer_busy){err=EBUSY;goto done;}
 if(sc->closing) { err=ESHUTDOWN;goto done; }
 if(sc->hre&&ctx->publication_error){err=ctx->publication_error;goto done;}
#ifdef REMESA_WITH_NIR
 if((ctx->bound_vertex&&ctx->bound_vertex->compositor_live)||(ctx->bound_fragment&&ctx->bound_fragment->compositor_live)){
  if(hybrid_enabled(sc)&&ctx->bound_vertex&&ctx->bound_fragment&&ctx->bound_vertex->compositor_live&&ctx->bound_fragment->compositor_live&&!ctx->bound_vertex->deleted&&!ctx->bound_fragment->deleted){
   uint64_t wall_start=egl22_now_us();
   err=hybrid_draw(p,info,drawid,indirect,draws,count);
   if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL29_DRAW_WALL us=%llu errno=%d\n",(unsigned long long)(egl22_now_us()-wall_start),err);
   if(err)fprintf(stderr,"HRE_COMPOSITOR_HYBRID_REJECT errno=%d\n",err);
  }
  goto done;
 }
 if(ctx->target&&r(ctx->target)->shared_rt&&r(ctx->target)->host_data){err=ENOTSUP;goto done;}
 for(unsigned k=0;k<FIXED_COUNT;k++)if(ctx->bound_fixed[k]&&ctx->bound_fixed[k]->compositor_only)goto done;
 /* HRE is explicitly a native sampled renderer. Do not let unsupported
  * draws enter the older CPU Lambert rasterizer or a host-only SSA staging
  * path. Return a sticky rejection through the existing draw accounting. */
 if(sc->hre&&(!ctx->bound_fragment||ctx->bound_fragment->deleted||
    ctx->bound_fragment->program.semantic.instructions[0].op!=REMESA_IR_TEXTURE2D_FRAGMENT||
    !ctx->bound_vertex||ctx->bound_vertex->deleted||ctx->bound_vertex->ssa_only||
    remesa_shader_ir_position_tex0_vertex(&ctx->bound_vertex->program.semantic))){
  err=ctx->failed_submission?EOWNERDEAD:ENOTSUP;goto done;
 }
 if(ctx->bound_vertex&&ctx->bound_vertex->ssa_only){
  if(ctx->failed_submission){err=EOWNERDEAD;goto done;}
  if(!ctx->bound_fragment||ctx->bound_fragment->uses_uniform||ctx->owned_texture_scene.owner)goto done;
  /* Never route a candidate through legacy/texture/gears profile substitution. */
  if(ctx->ssa_code&&(ctx->ssa_vertex!=ctx->bound_vertex||ctx->ssa_fragment!=ctx->bound_fragment)){
   err=release_ssa_code(ctx);if(err)goto done;
  }
  if(!ctx->ssa_code){
   if(p->stream_uploader)u_upload_unmap(p->stream_uploader);
   if(p->const_uploader&&p->const_uploader!=p->stream_uploader)u_upload_unmap(p->const_uploader);
   const uint32_t banks[2]={4,3};void *code=NULL;
   err=remesa_persistent_ssa_code_prepare(&sc->device,&ctx->bound_vertex->ssa,&ctx->bound_fragment->program,banks,&code);
   if(code){ctx->ssa_code=code;ctx->ssa_vertex=ctx->bound_vertex;ctx->ssa_fragment=ctx->bound_fragment;}
   if(err){if(err==EOWNERDEAD)ctx->failed_submission=true;goto done;}
  }
  /* Single-DMA PDS compiler integration. This is deliberately a host-only
   * candidate, not a dispatch. Accept exactly dense float4 input slots. */
  const struct remesa_ssa_vertex_shader *vs=&ctx->bound_vertex->ssa;
  struct elements *el=ctx->bound_elements;
  if(draws&&count==1&&!indirect&&!drawid&&!info->index_size&&info->mode==MESA_PRIM_TRIANGLES&&
     info->instance_count==1&&!info->start_instance&&el&&!el->deleted&&!ctx->invalid_elements&&
     el->count==vs->attribute_count&&ctx->vb_count==1&&ctx->vb.buffer.resource&&
     vs->attribute_count<=3&&draws->count&&draws->count%3==0&&draws->count<=65535){
   const struct pipe_vertex_element *a[3]={&el->position,&el->normal,&el->light};
   unsigned stride=16*vs->attribute_count;bool dense=true;
   for(unsigned j=0;j<el->count;j++)if(a[j]->src_format!=PIPE_FORMAT_R32G32B32A32_FLOAT||
      a[j]->src_stride!=stride||a[j]->src_offset!=16*j||a[j]->vertex_buffer_index)dense=false;
   struct resource *raw=r(ctx->vb.buffer.resource);
   uint64_t offset=(uint64_t)ctx->vb.buffer_offset+(uint64_t)draws->start*stride;
   uint64_t bytes=(uint64_t)draws->count*stride;
   if(dense&&raw->host_data&&!raw->maps&&offset<=raw->bytes&&bytes<=raw->bytes-offset){
    err=resource_sync(p->screen,raw,UINT64_MAX);if(err)goto done;
    err=remesa_persistent_ssa_pds_prepare(&sc->device,ctx->ssa_code,
     (const uint8_t *)raw->host_data+(size_t)offset,(size_t)bytes,draws->count);
    if(err){if(err==EOWNERDEAD)ctx->failed_submission=true;goto done;}
    struct remesa_ssa_pds_backing linked;
    err=remesa_persistent_ssa_pds_snapshot(&sc->device,ctx->ssa_code,&linked);if(err)goto done;
    if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"reMESA V107 SSA PDS candidate linked: VS=%zu FS=%zu stride=%u temp=%u source=%u; VS task offsets=%u/%u/%u masks=%08x/%08x/%08x; task/scene admission unavailable; submitted=0\n",linked.image_bytes[0],linked.image_bytes[1],linked.stride_bytes,linked.temporary_dwords,linked.source.handle,linked.task[0].byte_offset[0],linked.task[0].byte_offset[1],linked.task[0].byte_offset[2],linked.task[0].known_mask[0],linked.task[0].known_mask[1],linked.task[0].known_mask[2]);
   }
  }
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"reMESA V107 SSA CODE staged; no executable PDS task/scene admission; submitted=0\n");
  err=ENOTSUP;goto done;
 }
 if(ctx->owned_texture_scene.owner&&(!ctx->bound_fragment||
    ctx->bound_fragment->program.semantic.instructions[0].op!=REMESA_IR_TEXTURE2D_FRAGMENT))goto done;
 /* Compiling a sampled FS for scene preparation must never let the legacy
  * constant-color ABI treat its placeholder argb as an executable result. */
 if(ctx->bound_fragment&&ctx->bound_fragment->program.semantic.instructions[0].op==REMESA_IR_TEXTURE2D_FRAGMENT){
  if(hre_gles_lab(sc)&&getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_GLES_DRAW_ROUTE sampled_native\n");
  if(sc->hre_headless&&sc->base.resource_from_handle==hre_import_sampler){const struct pipe_sampler_view *view=NULL;
   err=remesa_texture_fragment0_view(ctx->textures,&view);
   if(err)goto done;
   if(r(view->texture)->shared_sampler){err=hre_refresh_sampler(p,view->texture);if(err)goto done;}
  }
  struct resource *shared_target=ctx->target&&r(ctx->target)->shared_rt?r(ctx->target):NULL;
  if(shared_target&&!shared_target->shared_discard){err=hre_shared_rt_sync(p->screen,shared_target,false);if(err)goto done;}
  uint64_t old_epoch=shared_target?shared_target->pass.content_epoch:0;
  err=qualify_texture_draw(p,info,drawid,indirect,draws,count);
  if(!err&&shared_target&&shared_target->has_contents&&(shared_target->writer||shared_target->pass.content_epoch!=old_epoch))
   err=hre_shared_rt_sync(p->screen,shared_target,true);
  goto done;
 }
#endif
 if(ctx->target&&r(ctx->target)->shared_rt&&r(ctx->target)->host_data){err=ENOTSUP;goto done;}
 if(sc->native_draws){
  if(ctx->failed_submission){err=EOWNERDEAD;goto done;}
  if(!draws||count!=1||indirect||drawid||info->index_size||info->mode!=MESA_PRIM_TRIANGLES||
     info->instance_count!=1||info->start_instance)goto done;
  complete_draw=*draws;complete_draw.count-=complete_draw.count%3;
  if(!complete_draw.count||!ctx->sample_enabled){err=0;goto done;}
  for(unsigned k=0;k<FIXED_COUNT;k++)if(ctx->invalid_fixed[k]||!ctx->bound_fixed[k])goto done;
  const struct fixed *state=ctx->bound_fixed[FIXED_RASTER];
  /* A disabled scissor cannot affect raster coverage. Do not reject a
   * native draw merely because Mesa supplied an unused scissor rectangle.
   * Enabled scissoring is still outside this hardware contract. */
  if(!state->native_w2_raster||state->cull_face||state->scissor||state->flat){
   if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"reMESA V100 native-raster refusal w2=%u cull=%u scissor=%u flat=%u bottom=%u ccw=%u viewport_y=%g\n",(unsigned)state->native_w2_raster,state->cull_face,(unsigned)state->scissor,(unsigned)state->flat,(unsigned)state->bottom_edge_rule,(unsigned)state->front_ccw,ctx->viewport.scale[1]);
   goto done;
  }
  /* Admit exactly the fixed-function subset that the linked ISP snapshot
   * and packet encoder can represent. This includes the already encoded
   * LESS/ALWAYS and depth-write on/off variants plus opaque color masks;
   * blend factors and stencil remain rejected by their state validators. */
  struct remesa_isp_opaque_triangle_request isp_snapshot;
  err=remesa_context_linked_isp_snapshot(p,&isp_snapshot);if(err)goto done;
  err=remesa_sampler_draw_admit(ctx->samplers);if(err)goto done;
  err=remesa_texture_draw_admit(ctx->textures);if(err)goto done;
  const struct remesa_linked_scene_request options={.vertex_bank=4,.pixel_bank=3,.state_bank=4,.clear_depth=1};
  struct pipe_fence_handle *native=NULL;
  err=context_submit_scene(p,info,&complete_draw,&options,true,true,true,&native);
  fence_ref(p->screen,&native,NULL);goto done;
 }
 if(sc->gears_runtime){err=queue_gears(p,info,drawid,indirect,draws,count);if(err)ctx->gears_poisoned=true;goto done;}
 if(ctx->homogeneous_draw_lab){
  if(!draws||count!=1||indirect||drawid)goto done;
  if(ctx->failed_submission){err=EOWNERDEAD;goto done;}
  if(!draws->count||!info->instance_count||!ctx->sample_enabled){err=0;goto done;}
  if(ctx->invalid_scissor)goto done;
  for(unsigned kind=0;kind<FIXED_COUNT;kind++)
   if(ctx->invalid_fixed[kind]||!ctx->bound_fixed[kind])goto done;
  struct fixed *state=ctx->bound_fixed[FIXED_RASTER];
  /* The closed native scene has no cull/scissor/clip lowering. Never ignore
   * an API raster state merely because its shader/geometry is recognized. */
  if(state&&state->native_raster_pending){
   /* Only the explicit finite API route may proceed. Its complete bound
    * shader/input/viewport/ISP/clear contract is checked in preparation. */
   if(ctx->homogeneous_api_lab!=REMESA_HOMOGENEOUS_API_W2_CLAMPED||!state->native_w2_raster)goto done;
  }else if(state&&(state->scissor||state->cull_face||state->depth_clip||state->flat||
     state->front_ccw||state->bottom_edge_rule||state->clamp_vertex_color))goto done;
  err=remesa_sampler_draw_admit(ctx->samplers);if(err)goto done;
  err=remesa_texture_draw_admit(ctx->textures);if(err)goto done;
  const struct remesa_linked_scene_request options={.vertex_bank=4,.pixel_bank=3,
   .state_bank=4,.clear_depth=1};
  struct pipe_fence_handle *native=NULL;
  err=remesa_context_submit_gears_homogeneous_scene(p,info,draws,&options,&native);
  /* Submission already shared this fence with COLOR/Z/context. Drop only
   * this local reference; common legacy cleanup must not destroy it twice. */
  fence_ref(p->screen,&native,NULL);goto done;
 }
#ifdef REMESA_WITH_NIR
 if(ctx->bound_vertex&&ctx->bound_fragment&&ctx->depth_target){
  err=cpu_solid_lambert_draw(p,info,draws,count,drawid,indirect);goto done;
 }
#endif
 if(sc->device.resource_only_backend||ctx->depth_target) goto done; /* Other CPU-only depth draws remain closed. */
 if(!draws || count!=1 || indirect || drawid) goto done;
 /* Triangle-list assembly ignores an incomplete final primitive. Do this
  * before buffer mapping or range checks: its unused vertices/indices need
  * not be present in the supplied resources. Other modes remain unsupported. */
 if(info->mode==MESA_PRIM_TRIANGLES){complete_draw=*draws;complete_draw.count-=complete_draw.count%3;draws=&complete_draw;}
 if(!draws->count || !info->instance_count || !ctx->sample_enabled) { err=0;goto done; }
#ifdef REMESA_WITH_NIR
 /* A recognized flat FS cannot inherit a smooth legacy raster contract. */
 if(ctx->bound_fragment&&!remesa_shader_ir_fragment_flat_color_input(&ctx->bound_fragment->program.semantic))goto done;
#endif
 /* Expanded host bindings never widen the historical GPU draw contract. */
 if(ctx->vb_count!=1||!ctx->bound_elements||ctx->bound_elements->count!=1)goto done;
 if(ctx->vb.buffer.resource&&!(ctx->vb.buffer.resource->bind&PIPE_BIND_VERTEX_BUFFER))goto done;
 int sampling=remesa_sampler_draw_admit(ctx->samplers);if(sampling){err=sampling;goto done;}
 sampling=remesa_texture_draw_admit(ctx->textures);if(sampling){err=sampling;goto done;}
 if(ctx->invalid_viewport || ctx->invalid_scissor || ctx->invalid_elements || ctx->invalid_constants || ctx->constant_rejections[0] || ctx->constant_rejections[1]) goto done;
 for(unsigned kind=0;kind<FIXED_COUNT;kind++)
  if(ctx->invalid_fixed[kind]||(ctx->vertex_required&&!ctx->bound_fixed[kind]))goto done;
 struct fixed *raster=ctx->bound_fixed[FIXED_RASTER];
 if(raster&&((raster->scissor&&!ctx->scissor_set)||(raster->depth_clip&&!ctx->bound_vertex)))goto done;
 if(ctx->vertex_required) {
  bool host=sc->device.offline_test_backend&&!sc->device.qualified_hardware_backend;
  if(!ctx->bound_vertex||!ctx->viewport_set||
     (ctx->viewport.scale[0]!=16&&(!host||ctx->viewport.scale[0]!=-16))||
     (ctx->viewport.scale[1]!=16&&(!host||ctx->viewport.scale[1]!=-16))||
     ctx->viewport.scale[2]!=.5f||ctx->viewport.translate[0]!=16||ctx->viewport.translate[1]!=16||ctx->viewport.translate[2]!=.5f)goto done;
 } else if(ctx->viewport_set) {
  for(unsigned axis=0;axis<3;axis++)if(ctx->viewport.scale[axis]!=1||ctx->viewport.translate[axis]!=0)goto done;
 }
 if((info->index_size && info->has_user_indices) || !ctx->target || !ctx->pipeline_bound ||
    !ctx->position_bound || !ctx->vb.buffer.resource ||
    (info->index_size && (!info->index.resource || info->index.resource->screen!=p->screen||
     info->index.resource->target!=PIPE_BUFFER||!(info->index.resource->bind&PIPE_BIND_INDEX_BUFFER)))) goto done;
#ifdef REMESA_WITH_NIR
 /* Validate actual owned host programs together before synchronization or
  * mapping. Linkage metadata never admits hardware encoding or execution. */
 if(ctx->bound_vertex) {
  int shader_error=remesa_shader_program_validate(&ctx->bound_vertex->program);
  if(shader_error){err=shader_error;goto done;}
  if(ctx->bound_fragment&&!ctx->bound_fragment->uses_uniform) {
   struct remesa_shader_pipeline pair;
   shader_error=remesa_context_shader_pipeline_report(p,&pair);
   if(shader_error){err=shader_error;goto done;}
   if(pair.position_input_slot!=ctx->bound_vertex->input_slot||pair.fragment_argb!=draw_argb)
    {err=EPROTO;goto done;}
  }
 }
 bool original_shader_draw=ctx->vertex_required||ctx->bound_fragment;
 /* Reject a missing original-program backend before uniform BO reads too. */
 if(original_shader_draw&&!sc->device.ops->prepare_shader_programs)goto done;
 int color_error=fragment_color(p,&draw_argb);if(color_error){err=color_error;goto done;}
 if(original_shader_draw) {
  if(!ctx->bound_vertex||!ctx->bound_fragment){err=ENODATA;goto done;}
  struct remesa_shader_program uniform_program;
  const struct remesa_shader_program *fragment_program=&ctx->bound_fragment->program;
  if(ctx->bound_fragment->uses_uniform) {
   err=remesa_shader_program_prepare_color(draw_argb,&uniform_program);if(err)goto done;
   fragment_program=&uniform_program;
  }
  shader_snapshot=malloc(sizeof(*shader_snapshot));if(!shader_snapshot){err=ENOMEM;goto done;}
  err=remesa_shader_draw_programs_prepare(&ctx->bound_vertex->program,
       fragment_program,shader_snapshot);if(err)goto done;
  if(shader_snapshot->pipeline.fragment_argb!=draw_argb){err=EPROTO;goto done;}
  err=ENOTSUP;
 }
#else
 const bool original_shader_draw=false;
#endif
 /* The retained native executor still checks its exact diagnostic profile.
  * Original shader preparation must independently qualify its own programs;
  * semantic color equality never selects or admits a retained program. */
 if(r(ctx->target)->maps || r(ctx->vb.buffer.resource)->maps ||
    (info->index_size && r(info->index.resource)->maps)) { err=EBUSY;goto done; }
 /* A retained handle is not proof of preserved pixels. The current native
  * profile initializes COLOR to zero and replaces the whole render resource.
  * Fail before dispatch rather than erase a clear/prior ordinary draw. */
 if(r(ctx->target)->has_contents&&!ctx->diagnostic_discard&&
    sc->device.framebuffer_mode!=REMESA_FRAMEBUFFER_PRESERVE)goto done;
 /* NIR draws never fall through to the retained fixed-shader submit path.
  * A real backend owns encoding, upload and PDS/USSE admission. Preparation
  * failures return before framebuffer reservation or any draw dispatch. */
#ifdef REMESA_WITH_NIR
 if(original_shader_draw&&!(raster&&raster->recording_edge_proof)) {
  err=sc->device.ops->prepare_shader_programs(sc->device.priv,shader_snapshot,&shader_programs);
  if(err)goto done;
  if(!shader_programs){err=EPROTO;goto done;}
 }
#endif
 err=resource_sync(p->screen,r(ctx->target),UINT64_MAX);if(err) goto done;
 err=resource_sync(p->screen,r(ctx->vb.buffer.resource),UINT64_MAX);if(err)goto done;
 if(info->index_size) {err=resource_sync(p->screen,r(info->index.resource),UINT64_MAX);if(err)goto done;}
 if(info->index_size) {
  err=resource_map_backing(p->screen,r(info->index.resource),false,&ip);if(err) goto done;
  i_mapped=true;if(!ip){err=EPROTO;goto done;}
 }
 validated_info=*info;validated_info.take_index_buffer_ownership=false;
 err=resource_map_backing(p->screen,r(ctx->vb.buffer.resource),false,&vp);if(err) goto done;
 v_mapped=true;if(!vp){err=EPROTO;goto done;}
 packet=malloc(sizeof(*packet));f=calloc(1,sizeof(*f));if(!packet || !f) { err=ENOMEM;goto done; }
 /* CPU primitive clipping is connected to the real callback only for the
  * recording backend and explicit depth-clip state. This does not qualify
  * GPU edge rules or expand the live executor's historical profile. */
 if(sc->device.offline_test_backend && !sc->device.qualified_hardware_backend &&
    ctx->bound_vertex && raster && raster->full_clip) {
  struct remesa_prepared_triangles *prepared=malloc(sizeof(*prepared));
  if(!prepared){err=ENOMEM;goto done;}
  packed=remesa_prepare_constant_draw(&validated_info,draws,&ctx->vb,&ctx->position,
      vp,r(ctx->vb.buffer.resource)->bytes,ip,info->index_size?r(info->index.resource)->bytes:0,
      draw_argb,&ctx->viewport,ctx->target->width0,ctx->target->height0,prepared);
  if(packed==REMESA_DRAW_VALIDATED&&raster->cull_face) {
   unsigned kept=0;
   for(unsigned vertex=0;vertex<prepared->vertex_count;vertex+=3) {
    bool discard=false;
    float triangle[3][4];memcpy(triangle,&prepared->positions[vertex],sizeof(triangle));
    int facing=remesa_cull_window_triangle((const float (*)[4])triangle,
      raster->cull_face,raster->front_ccw,&discard);
    if(facing){free(prepared);err=facing;goto done;}
    if(!discard){memmove(&prepared->positions[kept],&prepared->positions[vertex],3*sizeof(prepared->positions[0]));kept+=3;}
   }
   prepared->vertex_count=kept;
   if(!kept)packed=REMESA_DRAW_EMPTY;
  }
  if(packed==REMESA_DRAW_VALIDATED)packed=remesa_pack_prepared_triangles(prepared,packet);
  free(prepared);
  if(packed==REMESA_DRAW_EMPTY){err=0;goto done;}
 } else {
 packed=remesa_pack_triangle_draw_vertex(&validated_info,draws,&ctx->vb,&ctx->position,
     vp,r(ctx->vb.buffer.resource)->bytes,ip,info->index_size ? r(info->index.resource)->bytes : 0,draw_argb,ctx->bound_vertex ? &ctx->viewport : NULL,packet);
 }
 if(packed!=REMESA_DRAW_VALIDATED) { err=packed==REMESA_DRAW_NOMEM ? ENOMEM :
     packed==REMESA_DRAW_UNSUPPORTED ? ENOTSUP : EINVAL;goto done; }
 if(raster&&raster->recording_edge_proof) {
  /* Never enter this model on a real backend, regardless of raster handle. */
  if(!sc->device.offline_test_backend||sc->device.qualified_hardware_backend){err=ENOTSUP;goto done;}
  for(unsigned i=0;i<packet->index_count;i+=3) {
   float triangle[3][4];
   for(unsigned v=0;v<3;v++)memcpy(triangle[v],packet->positions[packet->indices[i+v]],sizeof(triangle[v]));
   err=remesa_prove_half_pixel_edge_independence((const float (*)[4])triangle,packet->width,packet->height);
   if(err)goto done;
  }
#ifdef REMESA_WITH_NIR
  if(original_shader_draw) {
   err=sc->device.ops->prepare_shader_programs(sc->device.priv,shader_snapshot,&shader_programs);
   if(err)goto done;
   if(!shader_programs){err=EPROTO;goto done;}
  }
#endif
 }
 enum remesa_pass_load load=r(ctx->target)->has_contents&&!ctx->diagnostic_discard ? REMESA_PASS_PRESERVE : REMESA_PASS_DISCARD;
 if(original_shader_draw) {
  /* Preserve the actual pre-VS data and fixed state. Passing just packet's
   * projected positions would apply the viewport twice or silently replace
   * the vertex shader with CPU execution. All pointers expire on unmap. */
  inputs=(struct remesa_shader_draw_inputs){
   .vertex_data=vp,.index_data=info->index_size?ip:NULL,
   .vertex_bytes=ctx->vb.buffer.resource->width0,
   .index_bytes=info->index_size?info->index.resource->width0:0,
   .color_bytes=r(ctx->target)->bytes,
   .vertex_offset=ctx->vb.buffer_offset,.element_offset=ctx->position.src_offset,
   .vertex_stride=ctx->position.src_stride,.position_input_slot=ctx->bound_vertex->input_slot,
   .start=draws->start,.count=draws->count,.index_size=info->index_size,
   .index_bias=info->index_size?draws->index_bias:0,
   .position_format=ctx->position.src_format,.color_format=ctx->target->format,
   .color_width=ctx->target->width0,.color_height=ctx->target->height0,
   .color_stride=r(ctx->target)->stride,.viewport=ctx->viewport,
   .cull_face=raster?raster->cull_face:0,.front_ccw=raster&&raster->front_ccw,
   .depth_clip_near=raster&&raster->depth_clip_near,.depth_clip_far=raster&&raster->depth_clip_far,
   .scissor_enabled=raster&&raster->scissor,.preserve_color=load==REMESA_PASS_PRESERVE,
   .retained_fragment_carrier=sc->device.retained_fragment_carrier
  };
  if(inputs.scissor_enabled)inputs.scissor=(struct pipe_scissor_state){.maxx=32,.maxy=32};
  struct remesa_draw_plan raw_plan;
  err=remesa_shader_draw_inputs_validate(&inputs,&raw_plan);if(err)goto done;
 }
 err=remesa_render_pass_begin(&r(ctx->target)->pass,load,REMESA_PASS_STORE,
    sc->device.framebuffer_mode==REMESA_FRAMEBUFFER_PRESERVE,&r(ctx->target)->ticket);if(err)goto done;
 err=remesa_render_pass_submitted(&r(ctx->target)->pass,&r(ctx->target)->ticket);if(err)goto done;
 submitted=true;
 if(original_shader_draw) {
  err=sc->device.ops->submit_shader_programs(sc->device.priv,r(ctx->target)->bo,
                                          packet,&inputs,shader_programs,&backend);
 }
 else err=sc->device.ops->submit(sc->device.priv,r(ctx->target)->bo,packet,&backend);
 if(!err && !backend) err=EPROTO;
 if(!err) {
  r(ctx->target)->has_contents=true;
  f->refs=1;f->screen=sc;f->backend=backend;screen_hold(sc);
  fence_ref(p->screen,&r(ctx->target)->writer,f);
  fence_ref(p->screen,&ctx->last,f);fence_ref(p->screen,&f,NULL);
 }
 done:
 if(v_mapped||vp) resource_unmap_backing(p->screen,r(ctx->vb.buffer.resource),false);
 if(i_mapped||ip) resource_unmap_backing(p->screen,r(info->index.resource),false);
 /* A backend-returned fence is owned even on failure. Its destructor must
  * retain uncertain device backing; frontend cleanup cannot imply retirement. */
 if(err && submitted) {
  /* A returned error fence may represent uncertain issuance. Never let a CPU
   * overwrite or another draw turn it into an apparently valid resource. */
  ctx->failed_submission=true;
  r(ctx->target)->write_error=err;
  remesa_render_pass_fail(&r(ctx->target)->pass,&r(ctx->target)->ticket,err);
  if(backend) sc->device.ops->destroy_fence(sc->device.priv,backend);
 }
 remesa_resource_reference(&owned_index,NULL);
 if(shader_programs)sc->device.ops->destroy_shader_programs(sc->device.priv,shader_programs);
#ifdef REMESA_WITH_NIR
 free(shader_snapshot);
#endif
 free(packet);free(f);ctx->error=err;
#ifdef REMESA_WITH_NIR
 if(hre_gles_lab(sc)&&(err||getenv("REMESA_DRI_TRACE")))
  fprintf(stderr,"HRE_GLES_DRAW_RESULT errno=%d vs=%u fs=%u color=%u depth=%u viewport=%u fixed=%u/%u/%u\n",err,
   (unsigned)(ctx->bound_vertex!=NULL),(unsigned)(ctx->bound_fragment!=NULL),
   (unsigned)(ctx->target!=NULL),(unsigned)(ctx->depth_target!=NULL),(unsigned)ctx->viewport_set,
   (unsigned)(ctx->bound_fixed[FIXED_BLEND]!=NULL),(unsigned)(ctx->bound_fixed[FIXED_DSA]!=NULL),(unsigned)(ctx->bound_fixed[FIXED_RASTER]!=NULL));
#endif
 if(err) {
  if(ctx->draw_rejections.failures!=UINT64_MAX)ctx->draw_rejections.failures++;
  ctx->draw_rejections.error=err;
  /* A later bind/READ map can clear the temporary API error, not restore a
   * frame whose required draw was refused. Callback reentry is excluded: it
   * is rejected before any frame operation and must not poison its caller. */
  if(!ctx->presenting&&!sc->frontbuffer_busy&&!ctx->publication_error)ctx->publication_error=err;
 }
}
static int flush_gears(struct pipe_context *p)
{
 struct context *ctx=c(p);struct screen *sc=s(p->screen);void *backend=NULL;int error=0;
 if(!ctx->gears_pending)return ctx->gears_poisoned?EIO:0;
 if(ctx->gears_poisoned)return EIO;
 struct resource *color=r(ctx->gears_target),*depth=r(ctx->gears_depth);
 struct pipe_fence_handle *f=calloc(1,sizeof(*f));if(!f)return ENOMEM;
 error=resource_sync(p->screen,color,UINT64_MAX);if(!error)error=resource_sync(p->screen,depth,UINT64_MAX);
 if(!error)error=remesa_render_pass_submit_pair(&color->pass,&depth->pass,
  REMESA_PASS_DISCARD,REMESA_PASS_STORE,false,&color->ticket,&depth->ticket);
 /* No backend flush attempted: preserve previous attachment state and keep
  * the queued owner alive. Do not quarantine an unrelated ready resource. */
 if(error){free(f);return error;}
 error=sc->device.gears_runtime->flush(sc->device.priv,color->bo,&backend);
 if(!error&&!backend)error=EPROTO;
 if(error){
  ctx->failed_submission=ctx->gears_poisoned=true;color->write_error=depth->write_error=error;
  remesa_render_pass_fail(&color->pass,&color->ticket,error);remesa_render_pass_fail(&depth->pass,&depth->ticket,error);
  if(backend)sc->device.ops->destroy_fence(sc->device.priv,backend);
  free(f);return error;
 }
 f->refs=1;f->screen=sc;f->backend=backend;screen_hold(sc);
 color->has_contents=depth->has_contents=true;
 fence_ref(p->screen,&color->writer,f);fence_ref(p->screen,&depth->writer,f);fence_ref(p->screen,&ctx->last,f);fence_ref(p->screen,&f,NULL);
 ctx->gears_pending=false;ctx->gears_clear_mask=0;
 remesa_resource_reference(&ctx->gears_target,NULL);remesa_resource_reference(&ctx->gears_depth,NULL);
 return 0;
}
static void flush(struct pipe_context *p,struct pipe_fence_handle **f,unsigned flags)
{
 (void)flags;
 if(c(p)->native_clear_color||c(p)->native_clear_depth){
  /* Standalone clear execution is not supplied by the cold draw executor.
   * Never represent unissued clear work with an older completed fence. */
  c(p)->error=c(p)->failed_submission?EOWNERDEAD:ENOTSUP;
  if(f)fence_ref(p->screen,f,NULL);
  return;
 }
 if(s(p->screen)->gears_runtime){int error=flush_gears(p);if(error)c(p)->error=error;}
 /* A rejected, unissued draw does not cancel earlier work. Preserve its
  * real fence even when validation or a resource poll reports an error.
  * Conversely an uncertain failed submission must never be represented by
  * an older successful fence. That condition remains sticky for this context. */
 if(f)fence_ref(p->screen,f,c(p)->failed_submission ? NULL : c(p)->last);
}
/* DRI frontbuffer flush is also invoked for private pbuffers.  Do not
 * publish a display or invent a fence: synchronize the actual resource. */
static void flush_private_resource(struct pipe_context *p,struct pipe_resource *res)
{
 struct context *ctx=c(p);int error;
 if(s(p->screen)->closing)error=ESHUTDOWN;
 else if(ctx->failed_submission)error=EOWNERDEAD;
 else if(ctx->publication_error)error=ctx->publication_error;
 else if(!res||res->screen!=p->screen)error=EINVAL;
 else if(r(res)->maps)error=EBUSY;
 else error=resource_sync(p->screen,r(res),UINT64_MAX);
 if(error)ctx->error=captured_scene_error(ctx,error);
 if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_RESOURCE_FLUSH errno=%d\n",error);
}
static void destroy_context(struct pipe_context *p)
{ struct context *ctx=c(p);struct screen *sc=s(p->screen);
 if(ctx->presenting){ctx->error=EBUSY;return;}
 /* Uncertain physical 2D work must retain the owning context and GEMs. */
 if(ctx->failed_submission&&(ctx->egl31_src||ctx->egl31_dst||ctx->egl32_spare)){ctx->error=EOWNERDEAD;return;}
 remesa_resource_reference(&ctx->egl31_src,NULL);
 remesa_resource_reference(&ctx->egl31_dst,NULL);
 remesa_resource_reference(&ctx->egl32_spare,NULL);
 if(ctx->compositor_scratch){struct pipe_context *q=ctx->compositor_scratch;int e=remesa_context_release_texture_scene(q);if(e||c(q)->failed_submission){ctx->error=e?e:EOWNERDEAD;return;}ctx->compositor_scratch=NULL;q->destroy(q);}
 /* No attachment, frontend state or screen reference may disappear before
  * native CLOSE is acknowledged. Refusal retains a retryable owner; an
  * uncertain close leaves the entire context and graph quarantined. */
 if(ctx->owned_texture_scene.owner){
#ifdef REMESA_WITH_NIR
  /* Clear uploader-owned transfer pointers before walking remaining maps. */
  if(p->stream_uploader)u_upload_unmap(p->stream_uploader);
  if(p->const_uploader&&p->const_uploader!=p->stream_uploader)u_upload_unmap(p->const_uploader);
#endif
  while(ctx->transfers)unmap(p,&ctx->transfers->base);
 }
 int release_error=remesa_context_release_texture_scene(p);
 if(release_error){ctx->error=release_error;return;}
 #ifdef REMESA_WITH_NIR
 release_error=release_ssa_code(ctx);if(release_error){ctx->error=release_error;return;}
#endif
 finish_native_clear(ctx,true);
 if(ctx->gears_pending){
  int error=sc->device.gears_runtime->cancel(sc->device.priv,r(ctx->gears_target)->bo);
  if(error){ctx->error=error;ctx->failed_submission=true;return;}
  ctx->gears_pending=false;
 }
 remesa_resource_reference(&ctx->gears_target,NULL);remesa_resource_reference(&ctx->gears_depth,NULL);
#ifdef REMESA_WITH_NIR
 /* Release upload-owned map leases and references while the context callbacks
  * and screen owner are still live, including partial construction failure. */
 if(p->const_uploader)u_upload_destroy(p->const_uploader);
 if(p->stream_uploader)u_upload_destroy(p->stream_uploader);
#endif
 while(ctx->transfers)unmap(p,&ctx->transfers->base);
 remesa_resource_reference(&ctx->vb.buffer.resource,NULL);
 remesa_resource_reference(&ctx->second_vb.buffer.resource,NULL);
 remesa_resource_reference(&ctx->third_vb.buffer.resource,NULL);
 remesa_resource_reference(&ctx->target,NULL);
 remesa_resource_reference(&ctx->depth_target,NULL);
 remesa_resource_reference(&ctx->fragment_constants,NULL);
 remesa_resource_reference(&ctx->vertex_constants,NULL);free(ctx->vertex_constant_snapshot);
 free(ctx->constant_snapshot);fence_ref(p->screen,&ctx->last,NULL);
 while(ctx->fragments){struct fragment *f=ctx->fragments;ctx->fragments=f->next;free(f);}
 while(ctx->vertices){struct vertex *v=ctx->vertices;ctx->vertices=v->next;free(v);}
 while(ctx->fixed_states){struct fixed *state=ctx->fixed_states;ctx->fixed_states=state->next;free(state);}
 while(ctx->elements){struct elements *e=ctx->elements;ctx->elements=e->next;free(e);}
 for(unsigned i=0;i<2;i++)if(ctx->compositor_views[i])release_sampler_view(p,ctx->compositor_views[i]);
 remesa_resource_reference(&ctx->compositor_upload_cache,NULL);
 remesa_sampler_bank_destroy(ctx->samplers);remesa_texture_binding_close(ctx->textures);
 if(ctx->egl33_release)egl33_report(&ctx->egl33,ctx,true);
 free(ctx);screen_drop(sc);
}
static struct pipe_context *create_context(struct pipe_screen *p,void *priv,unsigned flags)
{
 /* PREFER_THREADED is a hint; NO_LOD_BIAS adds no unsupported sampler state.
  * Other semantic/context-security flags remain unavailable. */
 struct context *ctx;if((flags & ~(PIPE_CONTEXT_PREFER_THREADED|PIPE_CONTEXT_NO_LOD_BIAS)) || s(p)->closing) return NULL;ctx=calloc(1,sizeof(*ctx));if(!ctx) return NULL;
 ctx->samplers=remesa_sampler_bank_create(NULL,NULL,NULL);if(!ctx->samplers){free(ctx);return NULL;}
 ctx->textures=remesa_texture_binding_create(p,texture_storage,p,NULL,NULL,NULL);
 if(!ctx->textures){remesa_sampler_bank_destroy(ctx->samplers);free(ctx);return NULL;}
 if(hybrid_enabled(s(p))&&getenv("REMESA_HRE_EGL29_LIVE_VIEWS")){
  if(remesa_texture_binding_gallium_live_only(ctx->textures)){remesa_texture_binding_close(ctx->textures);remesa_sampler_bank_destroy(ctx->samplers);free(ctx);return NULL;}
  if(getenv("REMESA_DRI_TRACE"))fprintf(stderr,"HRE_EGL29_LIVE_VIEWS enabled=1\n");
 }
 ctx->egl33_release=hybrid_enabled(s(p))&&getenv("REMESA_HRE_EGL33_RELEASE")!=NULL;
 ctx->sample_enabled=true;ctx->base.screen=p;ctx->base.priv=priv;ctx->base.destroy=destroy_context;
 ctx->base.buffer_map=map;ctx->base.texture_map=map;ctx->base.buffer_unmap=unmap;ctx->base.texture_unmap=unmap;
 ctx->base.transfer_flush_region=flush_region;
 ctx->base.buffer_subdata=buffer_subdata;ctx->base.texture_subdata=texture_subdata;
 ctx->base.resource_copy_region=copy_region;
 ctx->base.invalidate_resource=invalidate_resource;
 ctx->base.clear_texture=clear_texture;
 ctx->base.set_vertex_buffers=set_vb;ctx->base.create_vertex_elements_state=create_elements;
 ctx->base.bind_vertex_elements_state=bind_elements;ctx->base.delete_vertex_elements_state=delete_elements;
 ctx->base.create_surface=create_surface;ctx->base.surface_destroy=surface_destroy;
 ctx->base.create_fs_state=unsupported_shader;ctx->base.create_vs_state=unsupported_shader;ctx->base.clear=clear;ctx->base.clear_render_target=clear_target;
#ifdef REMESA_WITH_NIR
 ctx->base.create_vs_state=create_vertex;ctx->base.bind_vs_state=bind_vertex;ctx->base.delete_vs_state=delete_vertex;
 ctx->base.create_fs_state=create_fragment;ctx->base.bind_fs_state=bind_fragment;ctx->base.delete_fs_state=delete_fragment;
#endif
 ctx->base.create_blend_state=create_blend;ctx->base.bind_blend_state=bind_blend;ctx->base.delete_blend_state=delete_blend;
 ctx->base.create_depth_stencil_alpha_state=create_dsa;ctx->base.bind_depth_stencil_alpha_state=bind_dsa;ctx->base.delete_depth_stencil_alpha_state=delete_dsa;
 ctx->base.create_rasterizer_state=create_raster;ctx->base.bind_rasterizer_state=bind_raster;ctx->base.delete_rasterizer_state=delete_raster;
 ctx->base.set_stencil_ref=stencil_ref;ctx->base.set_blend_color=blend_color;
 ctx->base.set_constant_buffer=constant_buffer;ctx->base.set_sample_mask=sample_mask;
 ctx->base.set_polygon_stipple=polygon_stipple;
 ctx->base.create_sampler_state=create_sampler;ctx->base.bind_sampler_states=bind_samplers;ctx->base.delete_sampler_state=delete_sampler;
 ctx->base.create_sampler_view=create_sampler_view;ctx->base.sampler_view_destroy=destroy_sampler_view;ctx->base.sampler_view_release=release_sampler_view;ctx->base.set_sampler_views=set_sampler_views;
 ctx->base.set_viewport_states=viewport_state;ctx->base.set_scissor_states=scissor_state;
 ctx->base.set_framebuffer_state=framebuffer;ctx->base.draw_vbo=draw;ctx->base.flush=flush;screen_hold(s(p));
 ctx->base.flush_resource=s(p)->display?flush_display_resource:flush_private_resource;
#ifdef REMESA_WITH_NIR
 /* Standard Mesa-owned uploads for the production NIR context. Keep stream
  * and constant backing separate; no persistent mappings or GPU capability
  * is implied. Start at one page, sufficient for the restricted draw profile. */
 ctx->base.stream_uploader=u_upload_create(&ctx->base,4096,
  PIPE_BIND_VERTEX_BUFFER|PIPE_BIND_INDEX_BUFFER,PIPE_USAGE_STREAM,0);
 if(!ctx->base.stream_uploader){destroy_context(&ctx->base);return NULL;}
 ctx->base.const_uploader=u_upload_create(&ctx->base,4096,
  PIPE_BIND_CONSTANT_BUFFER,PIPE_USAGE_STREAM,0);
 if(!ctx->base.const_uploader){destroy_context(&ctx->base);return NULL;}
#endif
 if(s(p)->homogeneous_frontend_lab&&remesa_context_enable_homogeneous_draw_lab(&ctx->base)){
  destroy_context(&ctx->base);return NULL;
 }
 return &ctx->base;
}
static void destroy_screen(struct pipe_screen *p)
{
 struct screen *sc=s(p);
 if(sc->frontbuffer_busy)return; /* Callback reentry cannot destroy its owner. */
 if(!sc->closing){
  sc->closing=true;
  struct remesa_frontbuffer_sink sink=sc->frontbuffer;
  sc->frontbuffer=(struct remesa_frontbuffer_sink){0};sc->base.flush_frontbuffer=NULL;
  if(sink.release)sink.release(sink.user);
  screen_drop(sc);
 }
}
struct pipe_screen *remesa_screen_create_owned(struct remesa_device *device,int (*release)(struct remesa_device *))
{
 struct screen *sc;
 if(!device || (device->framebuffer_mode!=REMESA_FRAMEBUFFER_REPLACE&&device->framebuffer_mode!=REMESA_FRAMEBUFFER_PRESERVE) ||
    (device->framebuffer_mode==REMESA_FRAMEBUFFER_PRESERVE&&(!device->offline_test_backend||device->qualified_hardware_backend)) || (!device->offline_test_backend && !device->qualified_hardware_backend && !device->resource_only_backend) || !device->ops ||
    !device->ops->allocate || !device->ops->destroy_bo || !device->ops->map || !device->ops->unmap ||
    !device->ops->submit || !device->ops->wait || !device->ops->destroy_fence) return NULL;
 if((device->ops->prepare_shader_programs||device->ops->submit_shader_programs||device->ops->destroy_shader_programs)&&
    (!device->ops->prepare_shader_programs||!device->ops->submit_shader_programs||!device->ops->destroy_shader_programs))return NULL;
 if(!!device->ops->map_retired_color!=!!device->ops->unmap_retired_color)return NULL;
 sc=calloc(1,sizeof(*sc));if(!sc) return NULL;sc->device=*device;sc->refs=1;sc->release_device=release;
 sc->base.destroy=destroy_screen;sc->base.get_name=name;sc->base.get_vendor=vendor;sc->base.context_create=create_context;
 set_capabilities(sc);
 #ifdef REMESA_WITH_NIR
 sc->base.get_compiler_options=compiler_options;
#endif
 sc->base.is_format_supported=format;sc->base.resource_create=create_resource;sc->base.resource_destroy=destroy_resource;
 sc->base.fence_reference=fence_ref;sc->base.fence_finish=finish;
 if(release) memset(device,0,sizeof(*device));
 return &sc->base;
}
int remesa_screen_collect(struct pipe_screen *p)
{
 struct screen *sc;
 if(!p || p->destroy!=destroy_screen) return EINVAL;
 sc=s(p);if(!sc->closing || !sc->release_pending || __atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1) return EBUSY;
 if(sc->release_error!=EBUSY && sc->release_error!=EAGAIN) return sc->release_error;
 /* Only backend collection/release may retry. No draw can be redispatched. */
 int error=release_screen_backend(sc);
 if(error) { sc->release_error=error;return error; }
 free(sc);return 0;
}
int remesa_screen_destroy_checked(struct pipe_screen *p)
{
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return EALREADY;
 if(sc->frontbuffer_busy||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1)return EBUSY;
 sc->closing=true;
 struct remesa_frontbuffer_sink sink=sc->frontbuffer;
 sc->frontbuffer=(struct remesa_frontbuffer_sink){0};sc->base.flush_frontbuffer=NULL;
 if(sink.release)sink.release(sink.user);
 int error=release_screen_backend(sc);
 if(error){sc->release_pending=true;sc->release_error=error;return error;}
 free(sc);return 0;
}
static bool image_resource_get_handle(struct pipe_screen *screen,struct pipe_context *ctx,
 struct pipe_resource *res,struct winsys_handle *handle,unsigned usage)
{
 /* The image frontend probes SHMID and must take its ordinary CPU-transfer
  * fallback. A display-target bind never implies an exportable GEM/SHM BO. */
 (void)screen;(void)ctx;(void)res;(void)handle;(void)usage;return false;
}
int remesa_screen_take_frontbuffer_sink(struct pipe_screen *p,const struct remesa_frontbuffer_sink *sink)
{
 if(!p||p->destroy!=destroy_screen||!sink||!sink->publish||!sink->release)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(sc->frontbuffer.publish||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1)return EBUSY;
 sc->frontbuffer=*sink;sc->base.flush_frontbuffer=flush_frontbuffer;
 if(!sc->base.resource_get_handle)sc->base.resource_get_handle=image_resource_get_handle;
 return 0;
}
struct pipe_screen *remesa_screen_create(struct remesa_device *device)
{ return remesa_screen_create_owned(device,NULL); }
int remesa_context_gears_bottom_left(struct pipe_context *p,bool *bottom_left)
{
 if(!p||p->draw_vbo!=draw||!bottom_left||!context_output_valid(c(p),bottom_left,sizeof(*bottom_left)))return EINVAL;
 if(!s(p->screen)->gears_runtime||!c(p)->gears_origin_valid||c(p)->gears_poisoned)return ENOTSUP;
 *bottom_left=c(p)->gears_bottom_left;return 0;
}
int remesa_screen_enable_gears_runtime(struct pipe_screen *p)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);const struct remesa_gears_runtime_ops *ops=sc->device.gears_runtime;
 if(!ops||!ops->queue||!ops->flush||!ops->cancel||sc->device.resource_only_backend||
    sc->device.retained_fragment_carrier||sc->device.offline_test_backend==sc->device.qualified_hardware_backend)return ENOTSUP;
 if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    __atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED))return EBUSY;
 sc->gears_runtime=true;sc->cpu_depth24_lab=true;set_capabilities(sc);return 0;
#else
 (void)p;return ENOTSUP;
#endif
}
int remesa_screen_enable_linked_attachment_storage(struct pipe_screen *p)
{
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(!sc->device.resource_only_backend)return ENOTSUP;
 if(sc->closing||sc->linked_attachment_storage||sc->cpu_depth24_lab||sc->gears_runtime||
    __atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    __atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED))return EBUSY;
 if(!sc->device.ops->validate_attachment_storage||!sc->device.ops->allocate_color_attachment||
    !sc->device.ops->allocate_depth_attachment||!sc->device.ops->destroy_attachment||
    !sc->device.ops->prepare_linked_scene)return ENOTSUP;
 int error=sc->device.ops->validate_attachment_storage(&sc->device);if(error)return error;
 sc->linked_attachment_storage=true;return 0;
}
int remesa_screen_enable_linked_scene_experiment(struct pipe_screen *p)
{
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(!sc->device.resource_only_backend||!sc->linked_attachment_storage||
    !sc->device.ops->submit_linked_scene||!sc->device.ops->release_linked_scene)return ENOTSUP;
 if(sc->linked_scene_experiment)return EALREADY;
 if(__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    __atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED))return EBUSY;
 sc->linked_scene_experiment=true;set_capabilities(sc);return 0;
}
int remesa_screen_enable_native_draws(struct pipe_screen *p)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(sc->native_draws)return EALREADY;
 if(!sc->device.resource_only_backend||!sc->linked_attachment_storage||!sc->native_fill||
    sc->homogeneous_frontend_lab||sc->cpu_depth24_lab||sc->gears_runtime||
    !sc->device.ops->submit_linked_scene||!sc->device.ops->release_linked_scene)return ENOTSUP;
 if(__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->resource_cookie)return EBUSY;
 int e=sc->device.ops->native_draw_ready?
  sc->device.ops->native_draw_ready(&sc->device):remesa_persistent_native_draw_ready(&sc->device);
 if(e)return e;
 uint32_t w=sc->device.resource_limits.max_width?sc->device.resource_limits.max_width:32;
 uint32_t h=sc->device.resource_limits.max_height?sc->device.resource_limits.max_height:32;
 uint32_t bound=w<h?w:h,dimension=32;
 if(bound<32)return ENOTSUP;
 if(bound>2048)bound=2048;
 while(dimension<=bound/2)dimension*=2;
 sc->homogeneous_frontend_dimension=dimension;
 sc->native_draws=true;set_capabilities(sc);return 0;
#else
 (void)p;return ENOTSUP;
#endif
}
int remesa_screen_enable_native_preserve_candidate(struct pipe_screen *p)
{
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(!sc->native_draws)return ENOTSUP;
 if(sc->native_preserve_candidate)return EALREADY;
 if(__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->resource_cookie)return EBUSY;
 sc->native_preserve_candidate=true;return 0;
}
int remesa_screen_enable_homogeneous_frontend_lab(struct pipe_screen *p)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(sc->native_draws||!remesa_persistent_native_draw_ready(&sc->device))return ENOTSUP;
 if(!sc->device.resource_only_backend||!sc->linked_attachment_storage||sc->gears_runtime||
    sc->cpu_depth24_lab||!sc->device.ops->submit_linked_scene||!sc->device.ops->release_linked_scene)return ENOTSUP;
 if(sc->homogeneous_frontend_lab)return EALREADY;
 if(__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    __atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED))return EBUSY;
 int ready=remesa_persistent_native_scene_ready(&sc->device);if(ready)return ready;
 uint32_t width=sc->device.resource_limits.max_width?sc->device.resource_limits.max_width:32;
 uint32_t height=sc->device.resource_limits.max_height?sc->device.resource_limits.max_height:32;
 uint32_t bound=width<height?width:height,dimension=32;
 if(bound<32)return ENOTSUP;
 if(bound>2048)bound=2048; /* Existing typed render-target contract. */
 while(dimension<=bound/2)dimension*=2;
 sc->homogeneous_frontend_dimension=dimension;
 sc->homogeneous_frontend_lab=true;set_capabilities(sc);return 0;
#else
 (void)p;return ENOTSUP;
#endif
}
int remesa_screen_enable_cpu_depth24_lab(struct pipe_screen *p)
{
 if(!p||p->destroy!=destroy_screen)return EINVAL;
 struct screen *sc=s(p);
 if(!sc->device.offline_test_backend||sc->device.qualified_hardware_backend||sc->device.resource_only_backend)return ENOTSUP;
 if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    __atomic_load_n(&sc->resource_cookie,__ATOMIC_RELAXED))return EBUSY;
 sc->cpu_depth24_lab=true;set_capabilities(sc);return 0;
}
int remesa_resource_wait_writer(struct pipe_context *ctx,struct pipe_resource *res,uint64_t timeout)
{
 if(!ctx || ctx->draw_vbo!=draw || !res || res->screen!=ctx->screen) return EINVAL;
 if(r(res)->maps) return EBUSY;
 return resource_sync(ctx->screen,r(res),timeout);
}
int remesa_resource_attach_writer(struct pipe_context *ctx,struct pipe_resource *res,void *backend,struct pipe_fence_handle **out)
{
 struct pipe_fence_handle *f;
 if(!ctx || ctx->draw_vbo!=draw || s(ctx->screen)->closing || !s(ctx->screen)->device.resource_only_backend || !res || res->screen!=ctx->screen || !backend || !out || *out ||
    r(res)->maps || r(res)->writer || r(res)->write_error)return EINVAL;
 f=calloc(1,sizeof(*f));if(!f)return ENOMEM;
 int error=remesa_render_pass_import_writer(&r(res)->pass,&r(res)->ticket);
 if(error){free(f);return error;}
 f->refs=1;f->screen=s(ctx->screen);f->backend=backend;screen_hold(f->screen);
 r(res)->has_contents=true;fence_ref(ctx->screen,&r(res)->writer,f);*out=f;return 0;
}
int remesa_bind_diagnostic_pipeline(struct pipe_context *p,uint32_t argb)
{ if(!p || p->draw_vbo!=draw) return EINVAL;
  c(p)->bound_vertex=NULL;c(p)->bound_fragment=NULL;c(p)->vertex_required=false;
  c(p)->argb=argb;c(p)->pipeline_bound=true;c(p)->diagnostic_discard=true;return 0; }
int remesa_context_set_framebuffer_load(struct pipe_context *p,bool preserve)
{
 if(!p||p->draw_vbo!=draw)return EINVAL;
 if(s(p->screen)->closing)return ESHUTDOWN;
 /* The qualified hardware profile is explicitly REPLACE-only.  Reject a
  * preserve request at admission instead of accepting state that can only
  * fail later, after a caller has assumed load semantics.  Offline recording
  * fixtures may still exercise the state machine with an explicit PRESERVE
  * device mode. */
 if(preserve && s(p->screen)->device.qualified_hardware_backend &&
    s(p->screen)->device.framebuffer_mode!=REMESA_FRAMEBUFFER_PRESERVE)
  return ENOTSUP;
 c(p)->diagnostic_discard=!preserve;return 0;
}
uint64_t remesa_context_cpu_clear_count(const struct pipe_context *p) { return p && p->draw_vbo==draw ? ((const struct context *)p)->cpu_clears : 0; }
/* Desktop 2D uses CPU writers and only the retired framebuffer-copy callback.
 * This policy does not enable a draw or the legacy diagnostic GPU-fill path. */
int remesa_screen_enable_texture_qualification(struct pipe_screen *p)
{
#ifdef REMESA_WITH_NIR
 if(!p||p->context_create!=create_context)return EINVAL;
 struct screen *sc=s(p);
 if(!sc->device.resource_only_backend||!sc->linked_attachment_storage)return ENOTSUP;
 /* One explicitly opted-in EGL/DRI linked screen needs both dispatches:
  * sampled NIR draws use the managed texture graph, while other linked
  * programs use native_draws. They share the per-file owner and retirement
  * path. Keep the standalone lab combinations mutually exclusive. */
 bool linked_experiment=sc->linked_scene_experiment;
 if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||
    sc->texture_qualification||sc->hybrid_2d||sc->native_copy||sc->gears_runtime||
    (!linked_experiment&&(sc->native_fill||sc->native_draws)))return EBUSY;
 int error=remesa_persistent_texture_qualification_ready(&sc->device);
 if(error==EOPNOTSUPP||error==EINVAL){
  error=sc->device.ops->texture_graph_lifetime_ready?
   sc->device.ops->texture_graph_lifetime_ready(&sc->device):
   remesa_persistent_texture_graph_lifetime_ready(&sc->device);
 }
 if(error)return error;
 sc->texture_qualification=true;return 0;
#else
 (void)p;return ENOTSUP;
#endif
}
int remesa_screen_enable_hre(struct pipe_screen *p,remesa_copy_region_fn fn)
{
 if(!p||p->context_create!=create_context||!fn)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->resource_cookie||sc->native_copy||sc->hybrid_2d)return EBUSY;
 if(!sc->texture_qualification||sc->native_draws||sc->native_fill)return ENOTSUP;
 int error=remesa_persistent_enable_hre(&sc->device);if(error)return error;
 sc->hre=true;sc->hybrid_2d=true;sc->native_copy=fn;return 0;
}
bool remesa_screen_is_hre_headless(struct pipe_screen *p)
{return p&&p->context_create==create_context&&s(p)->hre_headless;}
int remesa_screen_enable_hre_headless(struct pipe_screen *p)
{
 if(!p||p->context_create!=create_context)return EINVAL;
 struct screen *sc=s(p);
 if(!sc->hre||!sc->linked_attachment_storage||!sc->texture_qualification)return ENOTSUP;
 if(sc->closing||sc->display||sc->frontbuffer.publish||sc->hre_headless||
    __atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->resource_cookie)return EBUSY;
 const char *egl=getenv("REMESA_HRE_EGL_DMABUF_LAB");
 sc->hre_headless=true;
 sc->egl_dmabuf_lab=egl&&!strcmp(egl,"1")&&hre_gles_lab(sc);
 set_capabilities(sc);
 const char *shared=getenv("REMESA_HRE_SHARED_LAB");
 if(sc->egl_dmabuf_lab||(shared&&!strcmp(shared,"1"))){
  sc->base.resource_from_handle=hre_import_sampler;
  sc->base.resource_get_handle=hre_get_sampler_handle;
  if(sc->egl_dmabuf_lab){sc->base.resource_get_param=hre_shared_param;
   sc->base.query_dmabuf_modifiers=hre_shared_modifiers;}
  /* Import-only explicit experiment. Never advertise scanout, export caps,
   * implicit GPU synchronization or production compositor support. */
 }
 return 0;
}
int remesa_screen_enable_hybrid_2d(struct pipe_screen *p,remesa_copy_region_fn fn)
{
 if(!p||p->context_create!=create_context||!fn)return EINVAL;
 struct screen *sc=s(p);
 if(!sc->device.resource_only_backend)return ENOTSUP;
 if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->native_copy||sc->native_fill||sc->hybrid_2d||sc->texture_qualification)return EBUSY;
 sc->hybrid_2d=true;sc->native_copy=fn;return 0;
}
int remesa_screen_scanout_import(struct pipe_screen *p,uint32_t fb,uint32_t handle,
 uint32_t width,uint32_t height,uint32_t stride,void **out)
{
 if(!p||p->context_create!=create_context||!out)return EINVAL;
 struct screen *sc=s(p);if(sc->closing||!sc->hybrid_2d||sc->hre)return ENOTSUP;
 return remesa_persistent_scanout_import(&sc->device,fb,handle,width,height,stride,out);
}
int remesa_screen_scanout_release(struct pipe_screen *p,void *bo)
{if(!p||p->context_create!=create_context||!bo)return EINVAL;return remesa_persistent_scanout_release(&s(p)->device,bo);}
int remesa_screen_scanout_cpu_begin(struct pipe_screen *p,void *bo,bool write)
{if(!p||p->context_create!=create_context||!bo)return EINVAL;return remesa_persistent_scanout_cpu_begin(&s(p)->device,bo,write);}
int remesa_screen_scanout_cpu_end(struct pipe_screen *p,void *bo,bool write)
{if(!p||p->context_create!=create_context||!bo)return EINVAL;return remesa_persistent_scanout_cpu_end(&s(p)->device,bo,write);}
int remesa_screen_scanout_copy(struct pipe_screen *p,void *bo,uint32_t sx,uint32_t sy,
 uint32_t dx,uint32_t dy,uint32_t width,uint32_t height)
{if(!p||p->context_create!=create_context||!bo)return EINVAL;return remesa_persistent_scanout_copy(&s(p)->device,bo,sx,sy,dx,dy,width,height);}
int remesa_screen_enable_buffer_renaming(struct pipe_screen *p)
{
 if(!p||p->context_create!=create_context)return EINVAL;
 struct screen *sc=s(p);
 if(sc->closing)return ESHUTDOWN;
 if(!sc->hybrid_2d||!sc->device.resource_only_backend||sc->linked_attachment_storage)return ENOTSUP;
 if(sc->buffer_renaming)return EALREADY;
 if(__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->resource_cookie)return EBUSY;
 sc->buffer_renaming=true;return 0;
}
int remesa_screen_enable_native_fill(struct pipe_screen *p,remesa_fill_region_fn fn)
{
 if(!p||p->context_create!=create_context||!fn)return EINVAL;
 if(s(p)->hybrid_2d||s(p)->texture_qualification)return ENOTSUP;
 struct screen *sc=s(p);if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->native_fill)return EBUSY;
 sc->native_fill=fn;return 0;
}
uint64_t remesa_context_native_fill_count(const struct pipe_context *p)
{return p&&p->draw_vbo==draw?((const struct context *)p)->native_fills:0;}
int remesa_screen_enable_native_copy(struct pipe_screen *p,remesa_copy_region_fn fn)
{
 if(!p||p->context_create!=create_context||!fn)return EINVAL;
 if(s(p)->texture_qualification)return ENOTSUP;
 struct screen *sc=s(p);if(sc->closing||__atomic_load_n(&sc->refs,__ATOMIC_ACQUIRE)!=1||sc->native_copy)return EBUSY;
 sc->native_copy=fn;return 0;
}
uint64_t remesa_context_native_copy_count(const struct pipe_context *p)
{return p&&p->draw_vbo==draw?((const struct context *)p)->native_copies:0;}
uint64_t remesa_context_cpu_copy_count(const struct pipe_context *p) { return p && p->draw_vbo==draw ? ((const struct context *)p)->cpu_copies : 0; }
int remesa_context_error(const struct pipe_context *p) { return p && p->draw_vbo==draw ? ((const struct context *)p)->error : EINVAL; }
int remesa_context_draw_rejections(struct pipe_context *p,struct remesa_draw_rejection_status *out)
{
 if(!p||p->draw_vbo!=draw||!context_output_valid(c(p),out,sizeof(*out)))return EINVAL;
 *out=c(p)->draw_rejections;return 0;
}
int remesa_drawable_buffers_replace(struct pipe_screen *p,uint32_t width,uint32_t height,
 bool double_buffer,bool depth,struct remesa_drawable_buffers *out)
{
 if(!p||p->resource_create!=create_resource||!out)return EINVAL;
 if(s(p)->closing)return ESHUTDOWN;
 if((out->front&&out->front->screen!=p)||(out->back&&out->back->screen!=p)||
    (!out->front&&out->back)||(out->front&&out->front==out->back))return EINVAL;
 if(out->generation==UINT64_MAX)return EOVERFLOW;
 /* Storage planning does not authorize new hardware surface state. */
 if(width!=32||height!=32||depth)return ENOTSUP;
 struct remesa_drawable_layout layout;
 uint64_t budget=s(p)->device.resource_limits.max_resource_bytes;
 if(!budget)budget=UINT64_C(64)*1024*1024;
 int error=remesa_drawable_layout(&s(p)->device.resource_limits,width,height,
  double_buffer,0,budget>SIZE_MAX?SIZE_MAX:(size_t)budget,&layout);
 if(error)return error;
 struct pipe_resource t={.target=PIPE_TEXTURE_2D,.format=PIPE_FORMAT_B8G8R8A8_UNORM,
  .width0=width,.height0=height,.depth0=1,.array_size=1,.bind=PIPE_BIND_RENDER_TARGET};
 struct pipe_resource *fresh[2]={0};
 for(unsigned i=0;i<layout.count;i++) {
  fresh[i]=p->resource_create(p,&t);
  if(!fresh[i]){
   for(unsigned j=0;j<i;j++)remesa_resource_reference(&fresh[j],NULL);
   return ENOMEM;
  }
 }
 struct remesa_drawable_buffers previous=*out;
 *out=(struct remesa_drawable_buffers){.front=fresh[0],.back=fresh[1],
  .width=width,.height=height,.generation=previous.generation+1};
 remesa_drawable_buffers_release(&previous);return 0;
}
void remesa_drawable_buffers_release(struct remesa_drawable_buffers *out)
{
 if(!out)return;
 remesa_resource_reference(&out->front,NULL);remesa_resource_reference(&out->back,NULL);
 memset(out,0,sizeof(*out));
}
#else
#include "remesa_persistent.h" /* Complete by-value capture token for the stub. */
int remesa_screen_take_drm_display(struct pipe_screen *p,struct remesa_drm_display **d,
 const struct remesa_display_access *a)
{(void)p;(void)d;(void)a;return ENOTSUP;}
int remesa_screen_take_frontbuffer_sink(struct pipe_screen *p,const struct remesa_frontbuffer_sink *sink)
{(void)p;(void)sink;return ENOTSUP;}
int remesa_context_tex0_vertex_inputs_snapshot(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,struct remesa_linked_vertex_inputs **o)
{(void)p;(void)i;(void)d;(void)o;return ENOTSUP;}
int remesa_context_prepare_texture_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct remesa_scene_capture *o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}

int remesa_context_prepare_bound_texture_pds(struct pipe_context *p,void *c,void *g,void **o)
{(void)p;(void)c;(void)g;(void)o;return ENOTSUP;}

int remesa_context_submit_captured_scene(struct pipe_context *p,struct remesa_scene_capture c,struct pipe_fence_handle **o)
{(void)p;(void)c;(void)o;return ENOTSUP;}
int remesa_context_take_texture_scene(struct pipe_context *p,struct remesa_scene_capture *c)
{(void)p;(void)c;return ENOTSUP;}
int remesa_context_release_texture_scene(struct pipe_context *p)
{(void)p;return ENOTSUP;}
int remesa_context_replace_texture_graph(struct pipe_context *p,
 const struct pipe_draw_info *i,const struct pipe_draw_start_count_bias *d,const uint64_t *s)
{(void)p;(void)i;(void)d;(void)s;return ENOTSUP;}
int remesa_context_submit_texture_scene(struct pipe_context *p,struct pipe_fence_handle **o)
{(void)p;(void)o;return ENOTSUP;}
int remesa_context_update_texture_vertices(struct pipe_context *p,uint32_t d,
 const struct pipe_draw_info *i,const struct pipe_draw_start_count_bias *b)
{(void)p;(void)d;(void)i;(void)b;return ENOTSUP;}
int remesa_context_clear_captured_color_cpu(struct pipe_context *p,struct remesa_scene_capture c,
 const union pipe_color_union *v)
{(void)p;(void)c;(void)v;return ENOTSUP;}
int remesa_context_update_captured_vertices(struct pipe_context *p,struct remesa_scene_capture c,uint32_t d,
 const struct pipe_draw_info *i,const struct pipe_draw_start_count_bias *b)
{(void)p;(void)c;(void)d;(void)i;(void)b;return ENOTSUP;}
int remesa_context_update_captured_parameters(struct pipe_context *p,struct remesa_scene_capture c,uint32_t draw)
{(void)p;(void)c;(void)draw;return ENOTSUP;}
int remesa_context_prepare_vertex_parameters(struct pipe_context *p,uint32_t bank,void **out)
{(void)p;(void)bank;(void)out;return ENOTSUP;}
int remesa_context_window_viewport_parameters_snapshot(struct pipe_context *p,struct remesa_vertex_parameter_values *out)
{(void)p;(void)out;return ENOTSUP;}
int remesa_context_linked_isp_snapshot(struct pipe_context *p,struct remesa_isp_opaque_triangle_request *out)
{(void)p;(void)out;return ENOTSUP;}
int remesa_context_window_viewport_snapshot(struct pipe_context *p,uint32_t bits,struct remesa_ta_window_viewport_request *out)
{(void)p;(void)bits;(void)out;return ENOTSUP;}
int remesa_screen_enable_linked_attachment_storage(struct pipe_screen *p)
{(void)p;return ENOTSUP;}
int remesa_context_prepare_linked_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct remesa_scene_capture *o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_prepare_gears_attribute_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct remesa_scene_capture *o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_prepare_gears_homogeneous_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct remesa_scene_capture *o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_submit_linked_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct pipe_fence_handle **o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_submit_gears_attribute_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct pipe_fence_handle **o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_submit_gears_homogeneous_scene(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,const struct remesa_linked_scene_request *r,struct pipe_fence_handle **o)
{(void)p;(void)i;(void)d;(void)r;(void)o;return ENOTSUP;}
int remesa_context_window_viewport_encode(struct pipe_context *p,uint32_t bits,unsigned char out[28])
{(void)p;(void)bits;(void)out;return ENOTSUP;}
int remesa_context_enable_homogeneous_draw_lab(struct pipe_context *p)
{(void)p;return ENOTSUP;}
int remesa_context_enable_homogeneous_api_lab(struct pipe_context *p,enum remesa_homogeneous_api_lab_profile profile)
{(void)p;(void)profile;return ENOTSUP;}
int remesa_screen_enable_homogeneous_frontend_lab(struct pipe_screen *p)
{(void)p;return ENOTSUP;}
int remesa_screen_enable_native_draws(struct pipe_screen *p)
{(void)p;return ENOTSUP;}
int remesa_screen_enable_native_preserve_candidate(struct pipe_screen *p)
{(void)p;return ENOTSUP;}
int remesa_screen_enable_gears_runtime(struct pipe_screen *p){(void)p;return ENOTSUP;}
int remesa_context_gears_bottom_left(struct pipe_context *p,bool *b){(void)p;(void)b;return ENOTSUP;}
int remesa_context_gears_geometry_snapshot(struct pipe_context *p,const struct pipe_draw_info *i,
 const struct pipe_draw_start_count_bias *d,struct remesa_gears_geometry **o)
{(void)p;(void)i;(void)d;(void)o;return ENOTSUP;}
int remesa_context_vertex_parameter_source(struct pipe_context *p,const struct remesa_pds_parameter_source_request *r,void *o,size_t n,size_t *w)
{(void)p;(void)r;(void)o;(void)n;(void)w;return ENOTSUP;}
int remesa_drawable_buffers_replace(struct pipe_screen *p,uint32_t w,uint32_t h,bool b,bool z,struct remesa_drawable_buffers *o)
{(void)p;(void)w;(void)h;(void)b;(void)z;(void)o;return ENOTSUP;}
void remesa_drawable_buffers_release(struct remesa_drawable_buffers *o) {(void)o;}
int remesa_context_set_framebuffer_load(struct pipe_context *p,bool preserve) { (void)p;(void)preserve;return ENOTSUP; }
uint64_t remesa_context_cpu_clear_count(const struct pipe_context *p) { (void)p;return 0; }
int remesa_screen_enable_texture_qualification(struct pipe_screen *p)
{(void)p;return EOPNOTSUPP;}
int remesa_screen_enable_hre(struct pipe_screen *p,remesa_copy_region_fn fn)
{(void)p;(void)fn;return ENOTSUP;}
bool remesa_screen_is_hre_headless(struct pipe_screen *p){(void)p;return false;}
int remesa_screen_enable_hre_headless(struct pipe_screen *p){(void)p;return ENOTSUP;}
int remesa_screen_enable_hybrid_2d(struct pipe_screen *p,remesa_copy_region_fn fn)
{(void)p;(void)fn;return EOPNOTSUPP;}
int remesa_screen_scanout_import(struct pipe_screen *p,uint32_t f,uint32_t h,uint32_t w,uint32_t y,uint32_t s,void **o)
{(void)p;(void)f;(void)h;(void)w;(void)y;(void)s;(void)o;return EOPNOTSUPP;}
int remesa_screen_scanout_release(struct pipe_screen *p,void *b){(void)p;(void)b;return EOPNOTSUPP;}
int remesa_screen_scanout_cpu_begin(struct pipe_screen *p,void *b,bool w){(void)p;(void)b;(void)w;return EOPNOTSUPP;}
int remesa_screen_scanout_cpu_end(struct pipe_screen *p,void *b,bool w){(void)p;(void)b;(void)w;return EOPNOTSUPP;}
int remesa_screen_scanout_copy(struct pipe_screen *p,void *b,uint32_t sx,uint32_t sy,uint32_t dx,uint32_t dy,uint32_t w,uint32_t h)
{(void)p;(void)b;(void)sx;(void)sy;(void)dx;(void)dy;(void)w;(void)h;return EOPNOTSUPP;}
int remesa_screen_enable_buffer_renaming(struct pipe_screen *p)
{(void)p;return EOPNOTSUPP;}
int remesa_screen_enable_native_fill(struct pipe_screen *p,remesa_fill_region_fn fn)
{(void)p;(void)fn;return EOPNOTSUPP;}
uint64_t remesa_context_native_fill_count(const struct pipe_context *p){(void)p;return 0;}
int remesa_screen_enable_native_copy(struct pipe_screen *p,remesa_copy_region_fn fn)
{(void)p;(void)fn;return EOPNOTSUPP;}
uint64_t remesa_context_native_copy_count(const struct pipe_context *p){(void)p;return 0;}
uint64_t remesa_context_cpu_copy_count(const struct pipe_context *p) { (void)p;return 0; }
int remesa_screen_collect(struct pipe_screen *screen) { (void)screen;return ENOTSUP; }
struct pipe_screen *remesa_screen_create_owned(struct remesa_device *device,int (*release)(struct remesa_device *)) { (void)device;(void)release;return 0; }
struct pipe_screen *remesa_screen_create(struct remesa_device *device) { (void)device;return 0; }
#endif
const char *remesa_screen_unavailable_reason(void) { return "Qualified clean hardware backend required; recording tests do not render"; }
