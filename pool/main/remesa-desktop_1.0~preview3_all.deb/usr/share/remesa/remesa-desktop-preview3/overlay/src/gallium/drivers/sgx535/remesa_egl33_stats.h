/* SPDX-License-Identifier: MIT */
#ifndef REMESA_EGL33_STATS_H
#define REMESA_EGL33_STATS_H
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
struct egl33_stats { uint64_t batches, cpu_blit, solid, gpu2d, native_tiles, total_us, max_us, bins[9]; };
static inline void egl33_record(struct egl33_stats *s,uint64_t us,bool blit,bool solid,unsigned gpu2d,unsigned tiles)
{
 static const uint64_t limits[]={1000,2000,4000,8000,15000,16667,33333,100000};
 unsigned i=0;while(i<8&&us>limits[i])i++;
 s->bins[i]++;s->batches++;s->total_us+=us;if(us>s->max_us)s->max_us=us;
 s->gpu2d+=gpu2d;s->native_tiles+=tiles;
 if(blit&&!gpu2d)s->cpu_blit++;
 if(solid)s->solid++;
}
static inline void egl33_report(const struct egl33_stats *s,const void *context,bool final)
{
 if(!s->batches)return;
 fprintf(stderr,"HRE_EGL33_SUMMARY context=%p final=%u batches=%llu cpu_blit=%llu solid=%llu gpu2d_rects=%llu native_tiles=%llu total_us=%llu max_us=%llu hist=%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu\n",context,(unsigned)final,
 (unsigned long long)s->batches,(unsigned long long)s->cpu_blit,(unsigned long long)s->solid,(unsigned long long)s->gpu2d,(unsigned long long)s->native_tiles,(unsigned long long)s->total_us,(unsigned long long)s->max_us,
 (unsigned long long)s->bins[0],(unsigned long long)s->bins[1],(unsigned long long)s->bins[2],(unsigned long long)s->bins[3],(unsigned long long)s->bins[4],(unsigned long long)s->bins[5],(unsigned long long)s->bins[6],(unsigned long long)s->bins[7],(unsigned long long)s->bins[8]);
}
#endif
