/* SPDX-License-Identifier: MIT */
#ifndef REMESA_EGL34_ROWS_H
#define REMESA_EGL34_ROWS_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#if defined(__SSE2__)
#include <emmintrin.h>
#endif
/* BGRA/XRGB little-endian byte layout. No alignment or padding assumption. */
static inline void egl34_force_alpha(uint8_t *row,size_t pixels)
{
 size_t i=0;
#if defined(__SSE2__)
 const __m128i mask=_mm_set1_epi32((int)0xff000000u);
 for(;pixels-i>=4;i+=4){
  __m128i v=_mm_loadu_si128((const __m128i *)(const void *)(row+4*i));
  _mm_storeu_si128((__m128i *)(void *)(row+4*i),_mm_or_si128(v,mask));
 }
#endif
 for(;i<pixels;i++)row[4*i+3]=255;
}
/* Copy GPU mapping once; compare only the cached staging copy. On mismatch
 * caller rejects the entire draw before publication. Never normalize first. */
static inline int egl34_readback_row(uint8_t *out,const uint8_t *gpu,const uint8_t *expected,size_t pixels,int opaque)
{
 memcpy(out,gpu,pixels*4);
 if(memcmp(out,expected,pixels*4))return 1;
 if(opaque)egl34_force_alpha(out,pixels);
 return 0;
}
#endif
