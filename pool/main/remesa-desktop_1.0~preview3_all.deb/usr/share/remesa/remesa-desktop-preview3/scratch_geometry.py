#!/usr/bin/env python3
"""Independent rectangle/depth/alpha witness; no software rasterizer."""
from collections import Counter

def fixture():
    # Logical 56x56 output surrounded by a 4-pixel guard on each side.
    # Original rectangle is (3,5)-(52,50); damage clips to (7,6)-(41,38).
    # In scratch top-left coordinates this is (11,10)-(45,42).
    w=h=64
    x0,y0,x1,y1=11,10,45,42
    def vertex(x,y):
        return (2*x/w-1,1-2*y/h,.25,1,.25,.25)
    mesh=[v for x,y in ((x0,y0),(x1,y0),(x1,y1),(x0,y0),(x1,y1),(x0,y1)) for v in vertex(x,y)]
    return w,h,mesh,[32,64,96,128],(x0,y0,x1,y1)

def mul(a,b):return (a*b+127)//255

def verify_pixels(w,h,rgba,depth,src,rect):
    if len(rgba)!=w*h*4 or len(depth)!=w*h:raise RuntimeError('bad readback size')
    x0,y0,x1,y1=rect
    # GL_UNSIGNED_INT scales the 24-bit depth value to 32-bit UNORM.
    def z24(v):return (v*0xffffff+0x7fffffff)//0xffffffff
    zs=Counter(z24(v) for v in depth)
    colors=Counter(tuple(rgba[i:i+4]) for i in range(0,len(rgba),4))
    print('HRE_SCRATCH_DEPTH_HISTOGRAM',zs,flush=True)
    print('HRE_SCRATCH_COLOR_HISTOGRAM',colors.most_common(8),flush=True)
    hit=0; dst=(40,80,120,255); opacity=128
    # Expected depth is 0xa00000 for clip z=.25, W=1 (the prior physical
    # geometry test observed this). Allow 1 LSB for GL readback conversion.
    for y in range(h):
        for x in range(w):
            i=(h-1-y)*w+x; z=z24(depth[i]); c=tuple(rgba[4*i:4*i+4])
            inside=x0<=x<x1 and y0<=y<y1
            if inside:
                if abs(z-0xa00000)>1:raise RuntimeError(f'coverage at {x},{y}: {z:#x}')
                if c!=tuple(src):raise RuntimeError(f'RGBA at {x},{y}: {c}, expected {src}')
                hit+=1
                a=mul(c[3],opacity)
                composed=tuple(min(255,mul(c[k],opacity)+mul(dst[k],255-a)) for k in range(3))+(255,)
                if composed!=(46,92,138,255):raise RuntimeError(f'blend reference {composed}')
            elif z!=0xffffff:
                raise RuntimeError(f'outside coverage at {x},{y}: {z:#x}')
    if hit!=(x1-x0)*(y1-y0):raise RuntimeError('coverage mismatch')
    print('HRE_SCRATCH_EXACT_COVERAGE',hit,'ALPHA',src[3],flush=True)
    print('HRE_SCRATCH_HYBRID_BLEND_REFERENCE_PASS (CPU resolve, native GPU sample)',flush=True)

if __name__=='__main__':
    w,h,m,s,r=fixture(); x0,y0,x1,y1=r
    assert max(abs(m[i]) for i in range(len(m)) if i%6 in (0,1))<=.875
    b=bytearray(w*h*4); z=[0xffffffff]*(w*h)
    for y in range(y0,y1):
        for x in range(x0,x1):
            i=(h-1-y)*w+x; b[i*4:i*4+4]=bytes(s);z[i]=0xa00000a0
    verify_pixels(w,h,b,z,s,r)
    for p in ('alpha','outside'):
        q=b[:]; d=z[:]
        if p=='alpha':q[4*((h-1-y0)*w+x0)+3]=255
        else:d[0]=0xa00000a0
        try:verify_pixels(w,h,q,d,s,r)
        except RuntimeError:pass
        else:raise AssertionError('bad pixels accepted')
    print('HRE_SCRATCH_FIXTURE_SELFTEST_PASS (synthetic only)')
