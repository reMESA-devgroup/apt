#!/usr/bin/env python3
"""Report DRM event-delivery cadence; events can include non-pageflip vblank requests."""
import collections,math,pathlib,re,statistics,sys
text=pathlib.Path(sys.argv[1]).read_text(errors='replace')
if re.search(r'^\s*(?:overrun|commit overrun|dropped events):\s*[1-9]\d*',text,re.M):
 print('WARNING: trace buffer lost events; cadence not reliable')
pat=re.compile(r'\s(\d+\.\d+):\s+drm_vblank_event_delivered:\s+(?:file=(\S+?),|pid=(\d+),)\s*crtc=(\d+),\s*seq=(\d+)')
groups=collections.defaultdict(list)
for t,f,p,c,s in pat.findall(text): groups[(f or p,c)].append((float(t),int(s)))
if not groups: sys.exit('No matching DRM event delivery evidence; no FPS inference')
for (f,c),g in groups.items():
 g.sort(); dt=[1000*(b[0]-a[0]) for a,b in zip(g,g[1:]) if b[0]>a[0]]
 if not dt: continue
 dt.sort(); print('file_or_pid=%s crtc=%s delivered=%d intervals=%d median_ms=%.3f p95_ms=%.3f max_ms=%.3f'%(f,c,len(g),len(dt),statistics.median(dt),dt[math.ceil(.95*len(dt))-1],dt[-1]))
print('Delivery cadence only: not necessarily page flips, visible frames, or input-to-display latency.')
