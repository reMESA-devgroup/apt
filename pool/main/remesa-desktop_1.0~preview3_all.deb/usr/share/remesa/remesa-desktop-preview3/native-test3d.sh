#!/usr/bin/env bash
set -Eeuo pipefail
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID != 0 ]] || { echo 'Invoke as ordinary user; supervised test requests sudo.'; exit 2; }
seconds=${1:-60}; [[ $# -le 1 && $seconds =~ ^[0-9]{2,4}$ ]] && ((10#$seconds>=30 && 10#$seconds<=1800)) || { echo 'Usage: native-test3d.sh [30..1800]'; exit 2; }
if pgrep -x 'Xorg|Xwayland|labwc|sway|weston|kwin_wayland|slimski' >/dev/null; then echo 'Stop the existing graphical session from TTY/SSH first; native test requires exclusive DRM.'; exit 2; fi
sudo -v
O=$(mktemp "$HOME/remesa-native3d.XXXXXXXX.log")
echo "Native compositor 3D test; keep Foot visible, type and move the window. Log: $O"
sudo bash "$D/desktop/run.sh" --stage foot --seconds "$seconds" --native3d --hardware-cursor --debug 2>&1 | tee "$O"
L=$(sed -n 's/^EGL19_DESKTOP_EXIT=0 LOG=\(\/tmp\/remesa-egl19-desktop\.[[:alnum:]]*\)$/\1/p' "$O" | tail -1)
[[ -n $L ]] || { echo 'Missing successful run log'; exit 1; }
sudo grep -Eq '^HRE_NATIVE_RETIRED .*retired=1' "$L"
sudo grep -Eq '^HRE_COMPOSITOR_HYBRID_DRAW_OK .*sampled=1 ' "$L"
sudo grep -q '^EGL19_CLEAN_SHUTDOWN$' "$L"
echo 'REMESA_NATIVE3D_COMPOSITOR_PASS (physical retirements; not general GLES2, rootless or FPS certification)'
