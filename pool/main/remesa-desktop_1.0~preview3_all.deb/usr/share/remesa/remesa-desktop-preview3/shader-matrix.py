#!/usr/bin/env python3
"""Actual EGL + GLES entry points, isolated non-conformant context test."""
import ctypes as c, pathlib, sys, faulthandler, os, time
faulthandler.enable()
r=pathlib.Path(sys.argv[1]);e=c.CDLL(str(r/'lib/libEGL.so.1'));g=c.CDLL(str(r/'lib/libGLESv2.so.2'))
P=c.c_void_p; I=c.c_int; U=c.c_uint; S=c.c_char_p; PI=c.POINTER(I)
def bind(lib,name,result,args):
 f=getattr(lib,name);f.restype=result;f.argtypes=args;return f
for n,t,a in [('eglGetPlatformDisplay',P,[U,P,P]),('eglInitialize',U,[P,PI,PI]),('eglGetError',U,[]),('eglQueryString',S,[P,I]),('eglGetConfigs',U,[P,P,I,PI]),('eglGetConfigAttrib',U,[P,P,I,PI]),('eglBindAPI',U,[U]),('eglCreateContext',P,[P,P,P,PI]),('eglMakeCurrent',U,[P,P,P,P]),('eglDestroyContext',U,[P,P]),('eglTerminate',U,[P])]:bind(e,n,t,a)
def need(value,stage):
 if not value:raise RuntimeError(f'{stage}: EGL error 0x{e.eglGetError():04x}')
 return value
def attrib(d,cfg,key):
 value=I();need(e.eglGetConfigAttrib(d,cfg,key,c.byref(value)),f'config {key:#x}');return value.value
D=need(e.eglGetPlatformDisplay(0x31DD,None,None),'get display');ctx=None;surface=None;current=False;initialized=False
try:
 major,minor=I(),I();need(e.eglInitialize(D,c.byref(major),c.byref(minor)),'initialize');initialized=True
 print(f'EGL_INITIALIZED {major.value}.{minor.value}',flush=True)
 apis=e.eglQueryString(D,0x308D) or b'';print('EGL_CLIENT_APIS',apis,flush=True)
 if b'OpenGL_ES' not in apis.split():raise RuntimeError('GLES lab API not admitted')
 n=I();need(e.eglGetConfigs(D,None,0,c.byref(n)),'config count')
 if not 0<n.value<=4096:raise RuntimeError('invalid config count')
 cfgs=(P*n.value)();got=I();need(e.eglGetConfigs(D,cfgs,n.value,c.byref(got)),'configs')
 if not 0<got.value<=n.value:raise RuntimeError('invalid returned count')
 cfg=next((x for x in cfgs[:got.value] if attrib(D,x,0x3040)&4 and not attrib(D,x,0x3042)&4 and attrib(D,x,0x3027)==0x3051),None)
 if not cfg:raise RuntimeError('no explicitly non-conformant ES2 config')
 print('EGL_ES2_CONFIG_NONCONFORMANT',flush=True)
 need(e.eglBindAPI(0x30A0),'bind ES');attrs=(I*3)(0x3098,2,0x3038)
 ctx=need(e.eglCreateContext(D,cfg,None,attrs),'create context');print('EGL_CONTEXT_CREATED',flush=True)
 bind(e,'eglCreatePbufferSurface',P,[P,P,PI]);bind(e,'eglDestroySurface',U,[P,P])
 surface=need(e.eglCreatePbufferSurface(D,cfg,(I*5)(0x3057,64,0x3056,64,0x3038)),'pbuffer')
 current=bool(need(e.eglMakeCurrent(D,surface,surface,ctx),'make current'));print('EGL_CONTEXT_CURRENT',flush=True)
 get=bind(g,'glGetString',S,[U]);err=bind(g,'glGetError',U,[])
 renderer=get(0x1f01) or b'';version=get(0x1f02) or b'';glsl=get(0x8b8c) or b''
 print('GL_RENDERER',renderer,flush=True);print('GL_VERSION',version,flush=True);print('GLSL_VERSION',glsl,flush=True)
 if b'12.3 RC7 HRE' not in renderer or b'[topology-1]' not in renderer or b'sgx535' not in renderer.lower() or any(x in renderer.lower() for x in (b'llvmpipe',b'softpipe',b'swrast')) or not version.startswith(b'OpenGL ES '):raise RuntimeError('unexpected GLES dispatch/renderer')
 if err():raise RuntimeError('GL dispatch error')
 def gl(n,t,*a):
  f=bind(g,n,t,list(a))
  def checked(*args):
   print("GLES_CALL_BEGIN",n,flush=True);result=f(*args);check(n);print('GLES_CALL_PASS',n,flush=True);return result
  return checked
 def check(stage):
  x=err()
  if x:raise RuntimeError(f'{stage}: GL error {x:#x}')
 F=c.c_float; PU=c.POINTER(U)
 create=gl('glCreateShader',U,U); source=gl('glShaderSource',None,U,I,c.POINTER(S),PI);compile=gl('glCompileShader',None,U); status=gl('glGetShaderiv',None,U,U,PI)
 def shader(kind,code):
  sh=create(kind);src=S(code);source(sh,1,c.byref(src),None);compile(sh);v=I();status(sh,0x8b81,c.byref(v))
  if not v.value:
   buf=c.create_string_buffer(4096);gl('glGetShaderInfoLog',None,U,I,PI,P)(sh,len(buf),None,buf);raise RuntimeError(buf.value)
  return sh
 # Compile/link only: this does not establish native execution.
 vs_base=b'attribute vec4 position; attribute vec2 uv; varying vec2 texcoord; void main(){gl_Position=position;texcoord=uv;}'
 fs_head=b'precision mediump float; varying vec2 texcoord; uniform sampler2D image; uniform vec4 tint; '
 cases=[('baseline',vs_base,b'gl_FragColor=texture2D(image,texcoord);'),('multiply',vs_base,b'gl_FragColor=texture2D(image,texcoord)*tint;'),('add',vs_base,b'gl_FragColor=texture2D(image,texcoord)+tint;'),('mix',vs_base,b'gl_FragColor=mix(texture2D(image,texcoord),tint,texcoord.x);'),('branch',vs_base,b'if(texcoord.x>0.5) gl_FragColor=tint; else gl_FragColor=texture2D(image,texcoord);'),('matrix',b'attribute vec4 position; attribute vec2 uv; varying vec2 texcoord; uniform mat4 m; void main(){gl_Position=m*position;texcoord=uv;}',b'gl_FragColor=texture2D(image,texcoord);')]
 for name,vsrc,expr in cases:
  try:
   vs=shader(0x8b31,vsrc);fs=shader(0x8b30,fs_head+b'void main(){'+expr+b'}')
   program=gl('glCreateProgram',U)();attach=gl('glAttachShader',None,U,U);attach(program,vs);attach(program,fs)
   loc=gl('glBindAttribLocation',None,U,U,S);loc(program,0,b'position');loc(program,1,b'uv');gl('glLinkProgram',None,U)(program)
   v=I();gl('glGetProgramiv',None,U,U,PI)(program,0x8b82,c.byref(v))
   print('EGL20_SHADER_LINK_RESULT',name,v.value,flush=True)
   gl('glDeleteProgram',None,U)(program);gl('glDeleteShader',None,U)(vs);gl('glDeleteShader',None,U)(fs)
  except RuntimeError as ex:print('EGL20_SHADER_REFUSAL',name,str(ex),flush=True)

finally:
 if current:need(e.eglMakeCurrent(D,None,None,None),'release current')
 if ctx:need(e.eglDestroyContext(D,ctx),'destroy context')
 if surface:need(e.eglDestroySurface(D,surface),'destroy surface')
 if initialized:need(e.eglTerminate(D),'terminate')
print('EGL20_SHADER_MATRIX_CLEAN_CLOSE',flush=True)
