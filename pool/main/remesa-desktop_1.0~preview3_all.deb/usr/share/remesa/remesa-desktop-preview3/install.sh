#!/usr/bin/env bash
# Installer for trusted local EGL34 preview; never replaces the stock GPU module.
set -Eeuo pipefail
trap 'echo "INSTALL_FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd)
if [[ ${1:-} == --nested-only ]]; then shift; exec bash "$D/installer/install-nested.sh" "$@"; fi
usage(){ cat <<'HELP'
Usage: bash install.sh [--deb FILE] [--kernel-module FILE] [--deps]
       bash install.sh --nested-only [--deps|--check|--uninstall]
       bash install.sh --check
       bash install.sh --uninstall
Requires a matching EGL14 LINEAR experimental .ko (or the previously installed
EGL14 initramfs) and the EGL34 i386 .deb. No module is loaded during installation.
--deps installs missing desktop packages using the configured distribution repos.
--uninstall removes only this desktop's entry and profile; keeps the Mesa package.
HELP
}
DEB=; MODULE=; DEPS=0; MODE=install
while (($#)); do case $1 in --deb) DEB=$(realpath -e "${2:?}"); shift 2;; --kernel-module) MODULE=$(realpath -e "${2:?}"); shift 2;; --deps) DEPS=1; shift;; --check) MODE=check; shift;; --uninstall) MODE=uninstall; shift;; -h|--help) usage; exit 0;; *) usage; exit 2;; esac; done
K=$(uname -r); TAG=remesa-desktop-$K; OLD=remesa-egl14-linear-$K
DEST=/opt/remesa/desktop-preview; ENTRY=/etc/grub.d/45_remesa_desktop_preview; RULE=/etc/udev/rules.d/99-remesa-render.rules; GROUP=remesa-render
supported(){ [[ $1 =~ ^(5\.(1[0-9])|6\.(0|[1-9]|10|18))([.\-]|$) ]]; }
# --check is read-only; stock driver may be active.
if [[ $MODE == check ]]; then
 printf 'kernel=%s architecture=%s\n' "$K" "$(dpkg --print-architecture)"; supported "$K" && echo KERNEL_TARGET_RANGE || echo KERNEL_OUTSIDE_TARGET_RANGE
 dpkg-query -W -f='${Version}\n' remesa-hre-cross 2>/dev/null || :
 ls -l "/boot/initrd.img-$OLD" "/boot/initrd.img-$TAG" /dev/dri/renderD* 2>/dev/null || :
 for c in labwc waybar foot thunar fuzzel swaybg mako wdisplays pavucontrol nmcli connmanctl; do command -v "$c" || echo "optional/missing: $c"; done
 exit 0
fi
if ((EUID!=0)); then
 if [[ $MODE == uninstall ]]; then exec sudo bash "$D/install.sh" --uninstall; fi
 args=(); [[ -z $DEB ]] || args+=(--deb "$DEB"); [[ -z $MODULE ]] || args+=(--kernel-module "$MODULE"); [[ $DEPS == 0 ]] || args+=(--deps)
 exec sudo bash "$D/install.sh" "${args[@]}"
fi
U=${SUDO_USER:-}; [[ -n $U && $U != root && $(id -u "$U") != 0 ]] || { echo 'Invoke from ordinary account using sudo'; exit 2; }
UH=$(getent passwd "$U" | cut -d: -f6)
if command -v update-grub >/dev/null; then update=(update-grub); elif command -v grub-mkconfig >/dev/null; then update=(grub-mkconfig -o /boot/grub/grub.cfg); else echo 'GRUB generator missing'; exit 2; fi
# Do not run this uninstall while the new boot is in use.
if [[ $MODE == uninstall ]]; then
 [[ -f $DEST/installed.state && ! -L $DEST ]] || { echo 'No installer-owned profile'; exit 2; }
 ! grep -qw remesa_boot=egl34-desktop /proc/cmdline || { echo 'Boot stock before uninstalling'; exit 2; }
 installed_kernel=$(sed -n 's/^kernel=//p' "$DEST/installed.state"); [[ $installed_kernel =~ ^[A-Za-z0-9._+-]+$ ]] || exit 2
 [[ -f $ENTRY && $(head -2 "$ENTRY" | tail -1) == '# reMESA Desktop Preview managed entry' ]] || { echo 'GRUB script missing or changed; inspect manually'; exit 2; }
 T=$(mktemp -d); trap 'rm -rf "$T"' EXIT; mv "$ENTRY" "$T/entry"
 if ! "${update[@]}"; then mv "$T/entry" "$ENTRY"; "${update[@]}" || :; exit 1; fi
 rm -f "/boot/initrd.img-remesa-desktop-$installed_kernel" "/boot/remesa-desktop-$installed_kernel.build-id"
 if [[ -f /usr/local/bin/remesa-desktop ]] && cmp -s /usr/local/bin/remesa-desktop "$DEST/installer/launcher.sh"; then rm /usr/local/bin/remesa-desktop; fi
 # Only remove rule if created by this installer and unchanged; keep pre-existing group grants.
 if grep -qx 'rule_created=1' "$DEST/installed.state" && cmp -s "$RULE" "$DEST/installer/render.rules"; then rm "$RULE"; udevadm control --reload-rules || :; fi
 if grep -qx 'member_added=1' "$DEST/installed.state"; then member=$(sed -n 's/^member=//p' "$DEST/installed.state"); gpasswd -d "$member" "$GROUP" || :; fi
 rm -rf -- "$DEST"; echo 'DESKTOP_REMOVED; private runtime package retained; stock untouched'; exit 0
fi
supported "$K" || { echo "Outside target range (5.10–6.10 or 6.18): $K"; exit 2; }
[[ $(dpkg --print-architecture) == i386 ]] || { echo 'This EGL34 runtime package is i386 only'; exit 2; }
[[ -f /boot/vmlinuz-$K && -f /boot/initrd.img-$K && -f /boot/grub/grub.cfg && -d /etc/initramfs-tools ]] || { echo 'Expected Debian/antiX GRUB + initramfs-tools'; exit 2; }
found=0; for p in /sys/bus/pci/devices/*; do [[ -r $p/vendor && -r $p/device ]] || continue; if [[ $(cat "$p/vendor") == 0x8086 && $(cat "$p/device") == 0x8108 ]]; then found=$((found+1)); fi; done
[[ $found == 1 ]] || { echo 'Expected one Poulsbo PCI 8086:8108'; exit 2; }
for c in mkinitramfs lsinitramfs grub-script-check objcopy modinfo python3 udevadm groupadd usermod gpasswd; do command -v "$c" >/dev/null || { echo "Missing prerequisite: $c"; exit 2; }; done
[[ ! -e $DEST && ! -L $DEST && ! -e $ENTRY && ! -L $ENTRY && ! -e /boot/initrd.img-$TAG && ! -e /boot/$TAG.build-id && ! -e /usr/local/bin/remesa-desktop && ! -L /usr/local/bin/remesa-desktop ]] || { echo 'Desktop entry/profile already exists; use --uninstall from stock before reinstalling'; exit 2; }
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
# Reuse only the original authenticated build from the existing experimental initramfs.
if [[ -z $MODULE ]]; then
 [[ -f /boot/initrd.img-$OLD && -f /boot/$OLD.build-id && ! -L /boot/$OLD.build-id && $(stat -c '%u:%a' /boot/$OLD.build-id) == 0:600 ]] || { echo 'No authenticated EGL14 initramfs. Supply --kernel-module /path/remesa_gma500gfx.ko'; exit 2; }
 command -v unmkinitramfs >/dev/null || { echo 'Missing unmkinitramfs'; exit 2; }
 echo "[reMESA] Extracting existing experimental kernel module"
 unmkinitramfs "/boot/initrd.img-$OLD" "$T/extract"
 mapfile -t modules < <(find "$T/extract" -type f -name remesa_gma500gfx.ko)
 [[ ${#modules[@]} == 1 ]] || { echo 'Cannot recover exactly one uncompressed experimental .ko; supply --kernel-module'; exit 2; }
 MODULE=${modules[0]}; REUSED=1
else REUSED=0; fi
cp "$MODULE" "$T/remesa.ko"; M=$T/remesa.ko
[[ $(modinfo -F name "$M") == remesa_gma500gfx && $(modinfo -F vermagic "$M" | cut -d' ' -f1) == "$K" && $(modinfo -F remesa_hre_revision "$M") == 116c2-dpm-reset ]] || { echo 'Kernel module name/revision/vermagic mismatch'; exit 2; }
LC_ALL=C grep -aq 'reMESA EGL14 V3 OPEN' "$M" || { echo 'EGL14 kernel marker missing'; exit 2; }
modinfo -p "$M" | grep -q '^render_probe_unprivileged:' || { echo 'Kernel parameter absent'; exit 2; }
objcopy --dump-section .note.gnu.build-id="$T/module.build-id" "$M" "$T/inspect.ko"
[[ -s $T/module.build-id ]]; if [[ $REUSED == 1 ]]; then cmp -s "$T/module.build-id" "/boot/$OLD.build-id" || { echo 'Recovered module identity mismatch'; exit 2; }; fi
if [[ -z $DEB && -f $UH/remesa-hre-cross_1.0~topology2.egl34_i386.deb ]]; then DEB=$UH/remesa-hre-cross_1.0~topology2.egl34_i386.deb; fi
if [[ -n $DEB ]]; then
 cp "$DEB" "$T/runtime.deb"; DEB=$T/runtime.deb
 [[ $(dpkg-deb -f "$DEB" Package) == remesa-hre-cross && $(dpkg-deb -f "$DEB" Version) == 1.0~topology2.egl34 && $(dpkg-deb -f "$DEB" Architecture) == i386 ]] || { echo 'Unexpected runtime package'; exit 2; }
elif [[ $(dpkg-query -W -f='${Status} ${Version}' remesa-hre-cross 2>/dev/null || :) != 'install ok installed 1.0~topology2.egl34' ]]; then echo 'Supply --deb EGL34_i386.deb'; exit 2; fi
echo "[reMESA] Checking known legacy package conflict"
bash "$D/installer/migrate-legacy.sh"
if [[ $DEPS == 1 ]]; then
 echo "[reMESA] Checking desktop dependencies"
 packages=(labwc waybar foot thunar fuzzel swaybg mako-notifier wdisplays pavucontrol libnotify-bin dbus acl build-essential python3 libsdl2-2.0-0)
 apt-get install --no-install-recommends "${packages[@]}"
fi
for c in cc labwc waybar foot thunar fuzzel swaybg mako dbus-run-session runuser setfacl getfacl setsid; do command -v "$c" >/dev/null || { echo "Missing desktop dependency: $c (try --deps or install from distribution repos)"; exit 2; }; done
for c in wdisplays pavucontrol notify-send; do command -v "$c" >/dev/null || echo "Optional settings tool missing: $c"; done
# Stage all boot files and validate before changing GRUB.
cp -a /etc/initramfs-tools/. "$T/initcfg/"; mkdir -p "$T/initcfg/hooks" "$T/initcfg/scripts/init-top"
# Refuse conflicting inherited reMESA hooks; the original installer used a temporary config.
[[ ! -e $T/initcfg/hooks/remesa-native && ! -e $T/initcfg/scripts/init-top/remesa-native ]] || { echo 'Conflicting global initramfs hook'; exit 2; }
cat > "$T/initcfg/hooks/remesa-native" <<HOOK
#!/bin/sh
set -e
case "\${1:-}" in prereqs) exit 0;; esac
. /usr/share/initramfs-tools/hook-functions
for dep in $(modinfo -F depends "$M" | tr ',' ' '); do manual_add_modules "\$dep"; done
mkdir -p "\$DESTDIR/lib/modules/$K/extra"
cp '$M' "\$DESTDIR/lib/modules/$K/extra/remesa_gma500gfx.ko"
HOOK
cat > "$T/initcfg/scripts/init-top/remesa-native" <<'HOOK'
#!/bin/sh
case "${1:-}" in prereqs) exit 0;; esac
case " $(cat /proc/cmdline) " in *' remesa_boot=egl34-desktop '* ) modprobe remesa_gma500gfx render_probe_unprivileged=1 noirq=1 || echo 'reMESA module failed; boot stock' >&2;; esac
HOOK
chmod 755 "$T/initcfg/hooks/remesa-native" "$T/initcfg/scripts/init-top/remesa-native"
echo "[reMESA] Generating experimental initramfs (compression, not Mesa compilation)"
mkinitramfs -d "$T/initcfg" -o "$T/initrd" "$K"
lsinitramfs "$T/initrd" > "$T/initrd.list"; grep -Eq 'extra/remesa_gma500gfx\.ko(\..*)?$' "$T/initrd.list"
REMESA_NATIVE_INIT=$(cat /proc/1/comm) python3 "$D/installer/grub-entry.py" /boot/grub/grub.cfg "$K" "$TAG" > "$T/entry"
grub-script-check "$T/entry"
{ printf '#!/bin/sh\n# reMESA Desktop Preview managed entry\ncat <<\047REMESA_GRUB\047\n'; cat "$T/entry"; printf 'REMESA_GRUB\n'; } > "$T/grub-script"
READLINK=$(command -v readlink); [[ $READLINK == /usr/bin/readlink || $READLINK == /bin/readlink ]] || exit 2
printf '%s\n' '# reMESA EGL33: trusted-user experimental render node only' "SUBSYSTEM==\"drm\", KERNEL==\"renderD[0-9]*\", ATTRS{vendor}==\"0x8086\", ATTRS{device}==\"0x8108\", PROGRAM==\"$READLINK -f /sys%p/device/driver/module\", RESULT==\"/sys/module/remesa_gma500gfx\", GROUP=\"$GROUP\", MODE=\"0660\"" > "$T/render.rules"
[[ ! -L $RULE ]] && { [[ ! -e $RULE ]] || cmp -s "$RULE" "$T/render.rules"; } || { echo 'Conflicting render udev rule; inspect manually'; exit 2; }
# Install private runtime, never replace stock Mesa. The user must stop graphics before launching, not before staging.
if [[ -n $DEB ]]; then dpkg -i "$DEB"; fi
[[ $(dpkg-query -W -f='${Status} ${Version}' remesa-hre-cross) == 'install ok installed 1.0~topology2.egl34' ]]; for f in libEGL.so.1 libGLESv2.so.2 libgbm.so.1 dri/gma500_dri.so; do [[ -e /opt/remesa/12.3/lib/$f ]]; done
# Copy only executable session/probe material into a root-owned installation; no user-writable privileged config.
mkdir -p "$T/profile/installer"; cp -a "$D/desktop" "$T/profile/"; cp "$D/install.sh" "$D/render-access.sh" "$D/render-probe.sh" "$D/probe-egl-gbm.py" "$D/nested.sh" "$D/native-test3d.sh" "$T/profile/"; cp "$D/installer/launcher.sh" "$D/installer/install-nested.sh" "$D/installer/nested-launcher.sh" "$D/installer/migrate-legacy.sh" "$T/profile/installer/"; cp "$T/render.rules" "$T/profile/installer/"
[[ -z $(find "$T/profile" ! -type f ! -type d -print -quit) ]] || { echo 'Unexpected nonregular profile file'; exit 2; }
chown -R root:root "$T/profile"; chmod -R go-w "$T/profile"; chmod 755 "$T/profile" "$T/profile/installer/launcher.sh"
rule_created=0; member_added=0; committed=0; created_profile=0; created_boot=0; created_entry=0; created_launcher=0
rollback(){ rc=$?; trap - EXIT; if [[ $committed == 0 ]]; then
 [[ $created_launcher == 0 ]] || rm -f /usr/local/bin/remesa-desktop
 [[ $created_entry == 0 ]] || rm -f "$ENTRY"
 [[ $created_boot == 0 ]] || rm -f "/boot/initrd.img-$TAG" "/boot/$TAG.build-id"
 [[ $created_profile == 0 ]] || rm -rf -- "$DEST"
 [[ $rule_created == 0 ]] || { rm -f "$RULE"; udevadm control --reload-rules || :; }
 [[ $member_added == 0 ]] || gpasswd -d "$U" "$GROUP" || :
 [[ $created_entry == 0 ]] || "${update[@]}" || :
 fi; rm -rf "$T"; exit "$rc"; }
trap rollback EXIT
getent group "$GROUP" >/dev/null || groupadd --system "$GROUP"
if ! id -nG "$U" | tr ' ' '\n' | grep -qx "$GROUP"; then usermod -aG "$GROUP" "$U"; member_added=1; fi
if [[ ! -e $RULE ]]; then install -m 644 "$T/render.rules" "$RULE"; rule_created=1; fi
udevadm control --reload-rules || echo 'udev reload unavailable; new rules load next boot' >&2
printf 'kernel=%s\nrule_created=%s\nmember_added=%s\nmember=%s\n' "$K" "$rule_created" "$member_added" "$U" > "$T/profile/installed.state"
mkdir -p /opt/remesa; created_profile=1; cp -a "$T/profile" "$DEST"
created_boot=1; install -m 600 "$T/initrd" "/boot/initrd.img-$TAG"; install -m 600 "$T/module.build-id" "/boot/$TAG.build-id"
created_entry=1; install -m 755 "$T/grub-script" "$ENTRY"
created_launcher=1; install -m 755 "$D/installer/launcher.sh" /usr/local/bin/remesa-desktop
echo "[reMESA] Generating and validating GRUB configuration"
"${update[@]}"; grub-script-check /boot/grub/grub.cfg
committed=1
printf '%s\n' 'REMESA_DESKTOP_INSTALL_PASS (installation only; GPU qualification pending)' 'Reboot manually; choose reMESA Desktop (experimental). Stop slimski on antiX from a TTY/SSH, then run remesa-desktop.' 'Stock kernel/module/initramfs unchanged. Rootless private GPU IOCTLs remain blocked.'
