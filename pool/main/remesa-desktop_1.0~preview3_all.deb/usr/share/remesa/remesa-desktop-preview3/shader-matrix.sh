#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
[[ $EUID == 0 ]] || exit 2
[[ $(dpkg-query -W -f='${Version}' remesa-hre-cross) == '1.0~topology2.egl24' ]] || exit 2
bash "$D/desktop/tools/activate.sh"
R=/opt/remesa/12.3
exec env -i PATH=/usr/bin:/bin LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_DRI_TRACE=1 REMESA_HRE_GLES_LAB=1 REMESA_HRE_RECEIPTS=1 MESA_GLES_VERSION_OVERRIDE=2.0 python3 "$D/shader-matrix.py" "$R"
