#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
P=${1:-/home/gama/remesa-egl}; R=/opt/remesa/12.3
[[ $EUID == 0 ]] || { echo 'Run via sudo in isolated PRIME mmap boot'; exit 2; }
grep -qw remesa_boot=prime-mmap /proc/cmdline || { echo 'Select PRIME mmap experimental boot'; exit 2; }
[[ $(dpkg-query -W -f='${Status} ${Version}' remesa-hre-cross) == 'install ok installed 1.0~topology2.egl5' ]] || { echo 'Requires physically tested EGL5 runtime; no new build required'; exit 2; }
exec 9>/run/lock/remesa-hre-qualification.lock
flock -n 9 || { echo 'Qualification already active'; exit 2; }
# Preserve exact boot/module identity, gates and compositor exclusion.
bash "$P/tools/activate-v116c2.sh"
L=$(mktemp /tmp/remesa-scratch.XXXXXX)
echo "Log: $L"
if ! env -i PATH=/usr/bin:/bin HOME=/root LD_LIBRARY_PATH="$R/lib" LIBGL_DRIVERS_PATH="$R/lib/dri" MESA_LOADER_DRIVER_OVERRIDE=gma500 REMESA_DRI_EXPERIMENTAL=1 REMESA_DRI_EXPERIMENTAL_HEADLESS=1 REMESA_DRI_HRE=1 REMESA_HRE_DYNAMIC=1 REMESA_DRI_TRACE=1 REMESA_HRE_GLES_LAB=1 REMESA_HRE_RECEIPTS=1 REMESA_HRE_DEPTH_PROBE=1 REMESA_HRE_UPLOAD_REBIND=1 REMESA_HRE_EGL_DMABUF_LAB=1 MESA_GLES_VERSION_OVERRIDE=2.0 PYTHONUNBUFFERED=1 python3 "$D/probe-scratch.py" "$R" 2>&1 | tee "$L"; then
 echo "SCRATCH_NOT_QUALIFIED: $L; stop and inspect; recover stock before retry if submission uncertain"; exit 1
fi
python3 - "$L" <<'PY'
import sys,re
s=open(sys.argv[1]).read()
for pat in (r'^HRE_GLES_VS compile_errno=0$',r'^HRE_GLES_FS compile_errno=0$',r'^HRE_GLES_DRAW_ROUTE sampled_native$',r'^HRE_SCRATCH_COLOR_DEPTH_PASS$',r'^GLES_CONTEXT_LAB_CLEAN_CLOSE$'):
 if not re.search(pat,s,re.M):sys.exit('Missing evidence: '+pat)
a=re.findall(r'^HRE_NATIVE_RETIRED sequence=(\d+) operation=(\d+) cookie=(\d+) phase=9 ledger=0x7 retired=1$',s,re.M)
if len(a)!=1 or int(a[0][0])!=1 or a[0][1]!=a[0][2] or int(a[0][1])==0:sys.exit('Invalid retirement evidence: '+repr(a))
if len(re.findall(r'^HRE_GLES_DRAW_RESULT errno=0 ',s,re.M))!=1 or re.search(r'^HRE_GLES_DRAW_RESULT errno=[1-9]|^HRE_RESOURCE_FLUSH errno=[1-9]|^HRE_RC2_UPLOAD_FAIL',s,re.M):sys.exit('Invalid draw evidence')
print('HRE_SCRATCH_PHYSICAL_PASS (one isolated native draw; not Labwc or scanout)')
PY
