#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cat > "$T/stats.c" <<'C'
#include "remesa_egl33_stats.h"
#include <assert.h>
int main(void){struct egl33_stats s={0};egl33_record(&s,1000,1,0,0,0);egl33_record(&s,15000,0,1,0,0);egl33_record(&s,16667,1,0,2,0);egl33_record(&s,100001,0,0,0,3);assert(s.batches==4&&s.cpu_blit==1&&s.solid==1&&s.gpu2d==2&&s.native_tiles==3&&s.bins[0]==1&&s.bins[4]==1&&s.bins[5]==1&&s.bins[8]==1);egl33_report(&s,&s,1);}
C
cc -std=c11 -Wall -Wextra -Werror -O2 -I"$D/overlay/src/gallium/drivers/sgx535" "$T/stats.c" -o "$T/stats"
cat > "$T/log" <<'LOG'
GL renderer: reMESA 12.3 / PowerVR SGX535
EGL15_KMS_FB_CHANGE crtc=1 from=2 to=3
EGL19_CLIENT_START name=foot pid=10 uid=1000
EGL19_CLIENT_START name=waybar pid=11 uid=1000
EGL19_CLIENT_START name=thunar pid=12 uid=1000
EGL19_CLIENTS_READY stage=desktop uid=1000
EGL19_CLEAN_SHUTDOWN
LOG
"$T/stats" 2>>"$T/log"
python3 "$D/desktop/tools/check-release.py" "$T/log" desktop | tee "$T/report"
grep -q 'batches=4 gpu2d_rects=2 native_tiles=3 cpu_blit=1 solid=1' "$T/report"
grep -q '<=15ms=2/4 >100ms=1' "$T/report"
python3 - "$D" "$T" <<'PY'
import pathlib,subprocess,sys,time
D,T=map(pathlib.Path,sys.argv[1:]);p=T/'incremental';p.write_text('good\n')
cmd=[sys.executable,str(D/'desktop/tools/watch-errors.py'),str(p)]
w=subprocess.Popen(cmd,stderr=subprocess.PIPE)
try:
 time.sleep(.35)
 with p.open('a') as f: f.write('HRE_GLES_DRAW_RESULT err');f.flush()
 time.sleep(.4);assert w.poll() is None
 with p.open('a') as f:f.write('no=2 vs=1\n');f.flush()
 assert w.wait(timeout=3)==1 and b'errno=2' in w.stderr.read()
finally:
 if w.poll() is None:w.kill();w.wait()
print('EGL33_INCREMENTAL_SPLIT_ERROR_PASS')
PY
printf 'HRE_RC3_UPLOAD errno=2 epoch=1\n' >>"$T/log"
if python3 "$D/desktop/tools/check-release.py" "$T/log" desktop; then exit 1; fi
printf 'EGL33_RELEASE_ERROR_REFUSAL_PASS\n'
