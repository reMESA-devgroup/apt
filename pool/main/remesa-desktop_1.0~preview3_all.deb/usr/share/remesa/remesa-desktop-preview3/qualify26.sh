#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "EGL26 QUALIFICATION FAILED line=$LINENO command=$BASH_COMMAND" >&2' ERR
D=$(cd "$(dirname "$0")" && pwd); cd "$D"
MODE=${1:-cloud}; [[ $MODE == cloud || $MODE == compare ]] || exit 2
OUT=$(mktemp -d "$HOME/egl26-results.XXXXXX"); echo "RESULTS=$OUT"
sudo -v
sudo dpkg -i "$HOME/remesa-hre-cross_1.0~topology2.egl26_i386.deb"
sudo bash run.sh --preflight
run_test(){
 local name=$1; shift
 local rc=0 log
 echo "=== EGL26 TEST: $name ==="
 sudo bash desktop/run.sh "$@" 2>&1 | tee "$OUT/$name-run.log" || rc=$?
 log=$(sed -n 's/^EGL19_DESKTOP_EXIT=[0-9]* LOG=\(\/tmp\/remesa-egl19-desktop\.[[:alnum:]]*\)$/\1/p' "$OUT/$name-run.log" | tail -1)
 if [[ -n $log ]]; then sudo python3 profile26.py "$log" | tee "$OUT/$name-profile.log"; fi
 [[ $rc == 0 ]] || { echo "FAILED $name rc=$rc"; return "$rc"; }
 [[ -n $log ]] && sudo grep -q '^EGL19_CLEAN_SHUTDOWN$' "$log"
}
if [[ $MODE == compare ]]; then
 run_test baseline --stage foot --seconds 60 --god-mode --hardware-cursor
 run_test native_cache --stage foot --seconds 60 --god-mode --native-cache --direct-region --hardware-cursor
fi
run_test cloud --stage foot --seconds 60 --cloud --hardware-cursor
printf 'Results: %s\n' "$OUT"
