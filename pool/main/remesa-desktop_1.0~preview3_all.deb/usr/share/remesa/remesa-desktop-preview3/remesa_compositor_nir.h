/* SPDX-License-Identifier: MIT */
/* Bounded scalar/vector reference execution for the observed compositor NIR.
 * Host evaluation only; not a USSE compiler or GPU submission admission. */
#ifndef REMESA_COMPOSITOR_NIR_H
#define REMESA_COMPOSITOR_NIR_H
#include "nir.h"
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#define RC_MAX 96
#define RC_NONE 255
/* Four lanes per register. Explicit component/swizzle references. */
enum rc_op { RC_CONST,RC_INPUT,RC_UNIFORM,RC_ADD_I,RC_ADD_F,RC_MUL,RC_DOT3,RC_MOV,RC_VEC,RC_TEX,RC_STORE };
struct rc_ref { uint8_t reg,lane; };
struct rc_ins { enum rc_op op; uint8_t dst,n,slot; struct rc_ref a[4],b[4]; uint32_t bits[4]; };
struct rc_program { unsigned count,regs,stage,outputs; struct rc_ins ins[RC_MAX]; };
struct rc_io { float input[4],varying[2],position[4],uv[2],color[4]; const void *uniforms; size_t bytes; int (*sample)(void *,const float[2],float[4]); void *opaque; };
struct rc_build { const nir_def *defs[RC_MAX]; unsigned n; };
static inline int rc_ref_get(const struct rc_build *b,const nir_def *d,unsigned lane,struct rc_ref *r)
{ if(!d||lane>=d->num_components||d->bit_size!=32)return ENOTSUP; for(unsigned i=0;i<b->n;i++)if(b->defs[i]==d){*r=(struct rc_ref){i,lane};return 0;}return ENOTSUP; }
static inline int rc_dst(struct rc_program *p,struct rc_build *b,const nir_def *d,struct rc_ins *i)
{ if(!d||!d->num_components||d->num_components>4||d->bit_size!=32||b->n>=RC_MAX)return ENOTSUP; i->dst=b->n;i->n=d->num_components;b->defs[b->n++]=d;p->regs=b->n;return 0; }
static inline int rc_output(struct rc_program *p,struct rc_ins *i,unsigned loc,unsigned n)
{ unsigned slot;if(p->stage==MESA_SHADER_VERTEX){if(loc==VARYING_SLOT_POS&&n==4)slot=0;else if(loc==VARYING_SLOT_VAR0&&n==2)slot=1;else return ENOTSUP;}else{if((loc!=FRAG_RESULT_COLOR&&loc!=FRAG_RESULT_DATA0)||n!=4)return ENOTSUP;slot=0;}if(p->outputs&(1u<<slot))return ENOTSUP;p->outputs|=1u<<slot;i->op=RC_STORE;i->slot=slot;i->n=n;i->dst=RC_NONE;return 0; }
static inline bool rc_is_zero(nir_src s){return nir_src_is_const(s)&&s.ssa->num_components==1&&s.ssa->bit_size==32&&!nir_src_as_uint(s);}
static inline int rc_compile(const nir_shader *s,struct rc_program *out)
{
 if(!s||!out)return EINVAL;
 if((s->info.stage!=MESA_SHADER_VERTEX&&s->info.stage!=MESA_SHADER_FRAGMENT)||s->scratch_size||s->global_mem_size||s->constant_data_size||s->xfb_info||s->info.writes_memory||s->info.num_ubos||s->info.num_ssbos||s->info.num_images||s->info.num_abos||s->info.num_textures>1||s->info.outputs_read||s->info.float_controls_execution_mode||s->info.clip_distance_array_size||s->info.cull_distance_array_size)return ENOTSUP;
 if(s->info.stage==MESA_SHADER_FRAGMENT&&(s->info.fs.uses_discard||s->info.fs.uses_fbfetch_output||s->info.fs.color_is_dual_source||s->info.fs.uses_sample_shading||s->info.fs.quad_derivatives))return ENOTSUP;
 for(unsigned j=0;j<ARRAY_SIZE(s->info.system_values_read);j++)if(s->info.system_values_read[j])return ENOTSUP;
 struct rc_program p={.stage=s->info.stage};struct rc_build b={0};unsigned functions=0,blocks=0,steps=0;
 nir_foreach_function(fn,s){
  if(++functions!=1||!fn->is_entrypoint||!fn->impl||fn->num_params||!fn->impl->structured||!exec_list_is_empty(&fn->impl->locals))return ENOTSUP;
  foreach_list_typed(nir_cf_node,node,node,&fn->impl->body){
   if(++blocks!=1||node->type!=nir_cf_node_block)return ENOTSUP;
   nir_foreach_instr(ins,nir_cf_node_as_block(node)){
    if(++steps>RC_MAX||p.count>=RC_MAX)return ENOTSUP;
    struct rc_ins i={.dst=RC_NONE};
    switch(ins->type){
     case nir_instr_type_deref:{nir_deref_instr *d=nir_instr_as_deref(ins);
      if(d->deref_type==nir_deref_type_var){if(d->var->data.mode!=nir_var_uniform&&d->var->data.mode!=nir_var_shader_in&&d->var->data.mode!=nir_var_shader_out)return ENOTSUP;}
      else if(d->deref_type==nir_deref_type_array){if(!nir_src_is_const(d->arr.index)||!nir_deref_instr_get_variable(d)||nir_deref_instr_get_variable(d)->data.mode!=nir_var_uniform)return ENOTSUP;}
      else return ENOTSUP;continue;}
     case nir_instr_type_load_const:{nir_load_const_instr *v=nir_instr_as_load_const(ins);if(rc_dst(&p,&b,&v->def,&i))return ENOTSUP;i.op=RC_CONST;for(unsigned k=0;k<i.n;k++)i.bits[k]=v->value[k].u32;break;}
     case nir_instr_type_alu:{nir_alu_instr *a=nir_instr_as_alu(ins);if(rc_dst(&p,&b,&a->def,&i)||a->exact||a->no_signed_wrap||a->no_unsigned_wrap)return ENOTSUP;
      switch(a->op){case nir_op_iadd:i.op=RC_ADD_I;break;case nir_op_fadd:i.op=RC_ADD_F;break;case nir_op_fmul:i.op=RC_MUL;break;case nir_op_fdot3:i.op=RC_DOT3;break;case nir_op_mov:i.op=RC_MOV;break;case nir_op_vec2:case nir_op_vec3:case nir_op_vec4:i.op=RC_VEC;break;default:return ENOTSUP;}
      unsigned n=i.op==RC_DOT3?3:i.n;if(i.op==RC_DOT3&&i.n!=1)return ENOTSUP;
      for(unsigned k=0;k<n;k++){if(i.op==RC_VEC){if(rc_ref_get(&b,a->src[k].src.ssa,a->src[k].swizzle[0],&i.a[k]))return ENOTSUP;}
       else if(i.op==RC_MOV){if(rc_ref_get(&b,a->src[0].src.ssa,a->src[0].swizzle[k],&i.a[k]))return ENOTSUP;}else if(rc_ref_get(&b,a->src[0].src.ssa,a->src[0].swizzle[k],&i.a[k])||rc_ref_get(&b,a->src[1].src.ssa,a->src[1].swizzle[k],&i.b[k]))return ENOTSUP;}
      break;}
     case nir_instr_type_intrinsic:{nir_intrinsic_instr *v=nir_instr_as_intrinsic(ins);
      switch(v->intrinsic){
       case nir_intrinsic_load_input:{nir_io_semantics se=nir_intrinsic_io_semantics(v);if(p.stage!=MESA_SHADER_VERTEX||se.location!=VERT_ATTRIB_GENERIC0||nir_intrinsic_dest_type(v)!=nir_type_float32||nir_intrinsic_base(v)||nir_intrinsic_component(v)||!rc_is_zero(v->src[0])||v->num_components!=2||rc_dst(&p,&b,&v->def,&i))return ENOTSUP;i.op=RC_INPUT;break;}
       case nir_intrinsic_load_uniform:if(nir_intrinsic_dest_type(v)!=nir_type_float32||nir_intrinsic_base(v)>15||nir_intrinsic_range(v)>16||rc_ref_get(&b,v->src[0].ssa,0,&i.a[0])||rc_dst(&p,&b,&v->def,&i))return ENOTSUP;i.op=RC_UNIFORM;i.slot=nir_intrinsic_base(v);i.bits[0]=nir_intrinsic_range(v);if(!i.bits[0])return ENOTSUP;break;
       case nir_intrinsic_load_deref:{nir_deref_instr *d=nir_src_as_deref(v->src[0]);if(p.stage!=MESA_SHADER_FRAGMENT||!d||d->deref_type!=nir_deref_type_var||d->var->data.mode!=nir_var_shader_in||d->var->data.location!=VARYING_SLOT_VAR0||d->var->data.location_frac||v->num_components!=2||nir_intrinsic_access(v)||rc_dst(&p,&b,&v->def,&i))return ENOTSUP;i.op=RC_INPUT;break;}
       case nir_intrinsic_store_output:{nir_io_semantics se=nir_intrinsic_io_semantics(v);if(v->num_components>4||!v->num_components||nir_intrinsic_src_type(v)!=nir_type_float32||nir_intrinsic_component(v)||!rc_is_zero(v->src[1])||nir_intrinsic_write_mask(v)!=((1u<<v->num_components)-1)||rc_output(&p,&i,se.location,v->num_components))return ENOTSUP;for(unsigned k=0;k<i.n;k++)if(rc_ref_get(&b,v->src[0].ssa,k,&i.a[k]))return ENOTSUP;break;}
       case nir_intrinsic_store_deref:{nir_deref_instr *d=nir_src_as_deref(v->src[0]);if(p.stage!=MESA_SHADER_FRAGMENT||!d||d->deref_type!=nir_deref_type_var||d->var->data.mode!=nir_var_shader_out||d->var->data.location_frac||nir_intrinsic_access(v)||nir_intrinsic_write_mask(v)!=15||rc_output(&p,&i,d->var->data.location,v->num_components))return ENOTSUP;for(unsigned k=0;k<i.n;k++)if(rc_ref_get(&b,v->src[1].ssa,k,&i.a[k]))return ENOTSUP;break;}
       default:return ENOTSUP;
      }break;}
     case nir_instr_type_tex:{nir_tex_instr *t=nir_instr_as_tex(ins);if(p.stage!=MESA_SHADER_FRAGMENT||t->op!=nir_texop_tex||(t->sampler_dim!=GLSL_SAMPLER_DIM_2D&&t->sampler_dim!=GLSL_SAMPLER_DIM_EXTERNAL)||t->dest_type!=nir_type_float32||t->is_array||t->is_shadow||t->texture_index||t->sampler_index||t->num_srcs!=1||t->src[0].src_type!=nir_tex_src_coord||t->coord_components!=2||t->def.num_components!=4||rc_ref_get(&b,t->src[0].src.ssa,0,&i.a[0])||rc_ref_get(&b,t->src[0].src.ssa,1,&i.a[1])||rc_dst(&p,&b,&t->def,&i))return ENOTSUP;i.op=RC_TEX;break;}
     default:return ENOTSUP;
    }
    p.ins[p.count++]=i;
   }
  }
 }
 if(functions!=1||blocks!=1||!(p.outputs&1))return ENOTSUP;
 *out=p;return 0;
}
static inline float rc_float(uint32_t x){float f;memcpy(&f,&x,4);return f;}
static inline uint32_t rc_bits(float f){uint32_t x;memcpy(&x,&f,4);return x;}
static inline int rc_eval(const struct rc_program *p,struct rc_io *io)
{
 if(!p||!io||p->count>RC_MAX||p->regs>RC_MAX||io->bytes>256||(!io->uniforms&&io->bytes))return EINVAL;
 uint32_t v[RC_MAX][4]={{0}};struct rc_io result=*io;
 #define R(q) v[(q).reg][(q).lane]
 for(unsigned j=0;j<p->count;j++){
  const struct rc_ins *i=&p->ins[j];uint32_t *d=i->dst==RC_NONE?NULL:v[i->dst];
  switch(i->op){
   case RC_CONST:memcpy(d,i->bits,i->n*4);break;
   case RC_INPUT:for(unsigned k=0;k<i->n;k++)d[k]=rc_bits(p->stage==MESA_SHADER_VERTEX?io->input[k]:io->varying[k]);break;
   case RC_UNIFORM:{uint32_t off=R(i->a[0]);if(off>=i->bits[0]||off>15||i->slot+off>15)return ERANGE;size_t pos=(i->slot+off)*16;if(pos>io->bytes||i->n*4>io->bytes-pos)return ERANGE;memcpy(d,(const uint8_t*)io->uniforms+pos,i->n*4);break;}
   case RC_ADD_I:for(unsigned k=0;k<i->n;k++)d[k]=R(i->a[k])+R(i->b[k]);break;
   case RC_ADD_F:case RC_MUL:for(unsigned k=0;k<i->n;k++){float a=rc_float(R(i->a[k])),b=rc_float(R(i->b[k]));d[k]=rc_bits(i->op==RC_MUL?a*b:a+b);}break;
   case RC_DOT3:{float x=0;for(unsigned k=0;k<3;k++)x+=rc_float(R(i->a[k]))*rc_float(R(i->b[k]));d[0]=rc_bits(x);break;}
   case RC_MOV:case RC_VEC:for(unsigned k=0;k<i->n;k++)d[k]=R(i->a[k]);break;
   case RC_TEX:{float uv[2]={rc_float(R(i->a[0])),rc_float(R(i->a[1]))},rgba[4];if(!io->sample||!isfinite(uv[0])||!isfinite(uv[1]))return ENOTSUP;int e=io->sample(io->opaque,uv,rgba);if(e)return e;for(unsigned k=0;k<4;k++)d[k]=rc_bits(rgba[k]);break;}
   case RC_STORE:{float *dst=p->stage==MESA_SHADER_VERTEX?(i->slot?result.uv:result.position):result.color;for(unsigned k=0;k<i->n;k++){float x=rc_float(R(i->a[k]));if(!isfinite(x))return ERANGE;dst[k]=x;}break;}
   default:return ENOTSUP;
  }
 }
 #undef R
 *io=result;return 0;
}
#endif
